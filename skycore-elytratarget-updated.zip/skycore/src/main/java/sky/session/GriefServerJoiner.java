package sky.session;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import sky.SkyInit;
import sky.event.network.PacketSendEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.module.misc.AutoJoiner;
import sky.util.text.ChatNotifier;
import sky.util.inventory.ItemSwapUtil;
import sky.util.entity.PlayerUtil;
import sky.access.SkyClientAccess;

public final class GriefServerJoiner implements SkyClientAccess {
    private int targetGrief = -1;
    private boolean enabled;
    private static GriefServerJoiner instance;
    private Integer manualGrief;
    private int pendingArrowClicks;
    private boolean clickedTarget;
    private boolean retryCompass;
    private long nextActionAt;

    public GriefServerJoiner() {
        instance = this;
        EventManager.register(this);
    }

    public static GriefServerJoiner getInstance() {
        return instance;
    }

    public static void setManualGrief(int grief) {
        if (instance != null) {
            instance.manualGrief = grief;
        }
    }

    public static void clearManualGrief() {
        if (instance != null) {
            instance.manualGrief = null;
        }
    }

    public static int getGrief() {
        if (mc.world == null) {
            return -1;
        }

        Scoreboard scoreboard = mc.world.getScoreboard();
        for (ScoreboardObjective objective : scoreboard.getObjectives()) {
            String displayName = objective.getDisplayName().getString();
            // Grief server scoreboard title, e.g. "ГРИФ #12"
            if (displayName.contains("ГРИФ #")) {
                return Integer.parseInt(displayName.split("#")[1].replace(" ", ""));
            }
        }
        return -1;
    }

    public static void startRejoin() {
        if (instance == null || mc.player == null) {
            return;
        }

        instance.targetGrief = instance.manualGrief != null ? instance.manualGrief : getGrief();
        if (instance.targetGrief <= 0) {
            ChatNotifier.displayError("Could not determine grief number");
            return;
        }

        instance.pendingArrowClicks = Math.max(0, (instance.targetGrief - 1) / 32);
        instance.enabled = true;
        instance.clickedTarget = false;
        instance.retryCompass = false;
        instance.nextActionAt = 0L;
        useCompassAndOpenSelector();
    }

    public static void disable() {
        if (instance == null) {
            return;
        }

        instance.enabled = false;
        instance.manualGrief = null;
        instance.targetGrief = -1;
        instance.pendingArrowClicks = 0;
        instance.clickedTarget = false;
        instance.retryCompass = false;
        instance.nextActionAt = 0L;
    }

    private static void useCompassAndOpenSelector() {
        int compassSlot = ItemSwapUtil.getSlot(Items.COMPASS);
        if (compassSlot == -1 || mc.player == null || mc.getNetworkHandler() == null) {
            ChatNotifier.displayError("Compass not found in inventory");
            return;
        }

        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(compassSlot));
        mc.getNetworkHandler().sendPacket(new PlayerInteractItemC2SPacket(
                Hand.MAIN_HAND, 0, mc.player.getYaw(), mc.player.getPitch()));
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (!enabled || !event.isReceive() || mc.player == null) {
            return;
        }

        if (event.getPacket() instanceof GameMessageS2CPacket message && !message.overlay()) {
            String content = message.content().getString();
            if (content.contains("Подождите несколько секунд перед повторым подключением!")) {
                event.setCancelled(true);
            } else if (content.contains("Не удалось подключиться к серверу")
                    || content.contains("К сожалению сервер переполнен")) {
                event.setCancelled(true);
                sendAttemptResult(false);
                clickedTarget = false;
                retryCompass = true;
                nextActionAt = System.currentTimeMillis() + 2500L;
            }
        }

        if (event.getPacket() instanceof OpenScreenS2CPacket openScreen
                && openScreen.getName().getString().contains("Выбор сервера")
                && mc.player.currentScreenHandler != null) {
            ItemStack clicked = ItemStack.EMPTY;
            if (mc.player.currentScreenHandler.slots.size() > 21) {
                clicked = mc.player.currentScreenHandler.getSlot(21).getStack().copy();
            }

            mc.player.networkHandler.sendPacket(new ClickSlotC2SPacket(
                    openScreen.getSyncId(),
                    mc.player.currentScreenHandler.getRevision(),
                    21, 0, SlotActionType.PICKUP, clicked,
                    Int2ObjectMaps.emptyMap()));
            event.setCancelled(true);
        }

        if (event.getPacket() instanceof GameJoinS2CPacket) {
            sendAttemptResult(true);
            enabled = false;

            AutoJoiner autoJoiner = SkyInit.getInstance().getModuleManager().getModule(AutoJoiner.class);
            if (autoJoiner != null && autoJoiner.isEnabled()) {
                autoJoiner.settoggled(false);
            }
        }
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (!enabled || mc.player == null || mc.player.currentScreenHandler == null) {
            return;
        }

        if (System.currentTimeMillis() < nextActionAt) {
            return;
        }

        if (retryCompass) {
            retryCompass = false;
            useCompassAndOpenSelector();
            nextActionAt = System.currentTimeMillis() + 500L;
            return;
        }

        if (mc.currentScreen instanceof HandledScreen) {
            mc.setScreen(null);
        }

        ScreenHandler handler = mc.player.currentScreenHandler;
        if (pendingArrowClicks > 0) {
            for (int index = 0; index < handler.slots.size(); index++) {
                Slot slot = handler.getSlot(index);
                if (slot == null || slot.getStack().isEmpty()) {
                    continue;
                }

                ItemStack stack = slot.getStack();
                if (stack.getItem() != Items.ARROW) {
                    continue;
                }

                PlayerUtil.clickSlot(handler.syncId, index, 0, SlotActionType.PICKUP, mc.player);
                pendingArrowClicks--;
                nextActionAt = System.currentTimeMillis() + 200L;
                return;
            }
        }

        if (clickedTarget) {
            return;
        }

        String targetName = String.format("ГРИФ #%s (1.16.5+)", targetGrief);
        for (int index = 0; index < handler.slots.size(); index++) {
            Slot slot = handler.getSlot(index);
            if (slot == null || slot.getStack().isEmpty()) {
                continue;
            }

            String name = slot.getStack().getName().getString();
            if (name.equalsIgnoreCase(targetName)) {
                PlayerUtil.clickSlot(handler.syncId, index, 0, SlotActionType.PICKUP, mc.player);
                clickedTarget = true;
                nextActionAt = System.currentTimeMillis() + 400L;
                return;
            }
        }
    }

    private void sendAttemptResult(boolean success) {
        String message = String.format("Attempt to join grief: #%s: %s", targetGrief,
                success ? "Done" : "Failed");
        if (success) {
            ChatNotifier.displayInfo(message);
        } else {
            ChatNotifier.displayError(message);
        }
    }
}
