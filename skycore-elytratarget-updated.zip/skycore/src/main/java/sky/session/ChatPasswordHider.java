package sky.session;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

public final class ChatPasswordHider {
    private static final String CONFIG_NAME = "skycore_chat_password_hider.txt";
    private static boolean enabled;
    private static boolean loaded;

    private ChatPasswordHider() {
    }

    private static Path configPath() {
        return MinecraftClient.getInstance().runDirectory.toPath().resolve(CONFIG_NAME);
    }

    public static void renderMask(DrawContext context, TextRenderer textRenderer, String text, int x, int y) {
        if (!shouldHide(text)) {
            return;
        }
        int secretStart = getSecretStart(text);
        if (secretStart < 0 || secretStart >= text.length()) {
            return;
        }
        String prefix = text.substring(0, secretStart);
        String secret = text.substring(secretStart);
        int left = x + textRenderer.getWidth(prefix) - 1;
        int right = left + Math.max(7, textRenderer.getWidth(secret) + 2);
        int top = y - 1;
        int bottom = y + 10;
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(0.0F, 0.0F, 400.0F);
        context.fill(left, top, right, bottom, 0xFF000000);
        matrices.pop();
    }

    private static void save() {
        try {
            Files.writeString(configPath(), Boolean.toString(enabled));
        } catch (IOException ignored) {
        }
    }

    public static boolean shouldHide(String text) {
        return isEnabled() && getSecretStart(text) >= 0;
    }

    public static void toggle() {
        load();
        enabled = !enabled;
        save();
    }

    public static boolean isEnabled() {
        load();
        return enabled;
    }

    private static int getSecretStart(String text) {
        if (text == null || text.isBlank()) {
            return -1;
        }
        String trimmed = text.stripLeading();
        String normalized = trimmed.toLowerCase(Locale.ROOT);
        int leadingOffset = text.length() - trimmed.length();
        for (String command : new String[]{"/reg", "/register", "/l", "/login", "/cp", "/changepassword"}) {
            if (!normalized.startsWith(command)) {
                continue;
            }
            int index = leadingOffset + command.length();
            while (index < text.length() && Character.isWhitespace(text.charAt(index))) {
                index++;
            }
            return index < text.length() ? index : -1;
        }
        return -1;
    }

    private static void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        Path path = configPath();
        if (!Files.exists(path)) {
            return;
        }
        try {
            enabled = Boolean.parseBoolean(Files.readString(path).trim());
        } catch (IOException ignored) {
            enabled = false;
        }
    }
}
