package sky.session;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import sky.event.network.PacketSendEvent;
import sky.module.visuals.Interface;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import sky.access.SkyClientAccess;
import sky.hud.HudManager;

public final class ChatAlertListener implements SkyClientAccess {
    private static final int TOTEM_POP_STATUS = 35;
    // Incoming spectator/spec chat keywords (server messages stay Russian)
    private static final String[] SPEC_KEYWORDS = {
            "spec", "наблюдатель", "наблюдает", "следит", "спектатор",
            "наблюдение", "зритель", "spectate", "spectator", "spect"
    };
    private static final Pattern ANGLE_BRACKET_NAME = Pattern.compile("<\\s*([^>]+?)\\s*>");
    private static final Pattern BRACKET_NAME = Pattern.compile("\\[\\s*([^\\]]+?)\\s*\\]");
    private static final Pattern COLON_NAME = Pattern.compile("^\\s*([^:]{2,16})\\s*:");

    public ChatAlertListener() {
        EventManager.register(this);
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (!event.isReceive() || mc.player == null || mc.world == null) {
            return;
        }
        if (!Interface.INSTANCE.isNotificationsEnabled()) {
            return;
        }
        Packet<?> packet = event.getPacket();
        if (packet instanceof GameMessageS2CPacket message) {
            handleChatMessage(message.content().getString());
            return;
        }
        if (packet instanceof EntityStatusS2CPacket statusPacket && statusPacket.getStatus() == TOTEM_POP_STATUS) {
            handleTotemPop(statusPacket);
        }
    }

    private void handleChatMessage(String message) {
        if (message == null || message.isBlank()) {
            return;
        }
        String normalized = message.toLowerCase(Locale.ROOT);
        if (!containsSpecKeyword(normalized)) {
            return;
        }
        String playerName = extractPlayerName(message, normalized);
        if (playerName == null || playerName.isBlank()) {
            return;
        }
        HudManager.getInstance().notifications.pushSpecWarning(playerName.trim());
    }

    private void handleTotemPop(EntityStatusS2CPacket packet) {
        Entity entity = packet.getEntity(mc.world);
        if (!(entity instanceof PlayerEntity player) || player == mc.player || !player.isAlive()) {
            return;
        }
        double viewDistance = mc.gameRenderer.getViewDistance();
        if (mc.player.squaredDistanceTo(player) > viewDistance * viewDistance) {
            return;
        }
        HudManager.getInstance().notifications.pushTotemLost(player.getName().getString(), 1);
    }

    private boolean containsSpecKeyword(String message) {
        for (String keyword : SPEC_KEYWORDS) {
            if (message.contains(keyword)) {
                return true;
            }
        }
        return false;
    }

    private String extractPlayerName(String message, String normalizedMessage) {
        Matcher angleMatcher = ANGLE_BRACKET_NAME.matcher(message);
        if (angleMatcher.find()) {
            return angleMatcher.group(1).trim();
        }
        Matcher bracketMatcher = BRACKET_NAME.matcher(message);
        if (bracketMatcher.find()) {
            return bracketMatcher.group(1).trim();
        }
        Matcher colonMatcher = COLON_NAME.matcher(message);
        if (colonMatcher.find()) {
            return colonMatcher.group(1).trim();
        }
        for (String keyword : SPEC_KEYWORDS) {
            int index = normalizedMessage.indexOf(keyword);
            if (index <= 0) {
                continue;
            }
            String beforeKeyword = message.substring(0, index).trim();
            if (beforeKeyword.isEmpty()) {
                continue;
            }
            String[] words = beforeKeyword.split("\\s+");
            if (words.length <= 0) {
                continue;
            }
            // Keep Cyrillic letters so Russian nicknames survive stripping
            String playerName = words[words.length - 1].replaceAll("[^\\wА-Яа-яЁё._-]", "");
            if (!playerName.isEmpty()) {
                return playerName;
            }
        }
        return null;
    }
}
