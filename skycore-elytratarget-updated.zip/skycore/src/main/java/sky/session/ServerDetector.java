package sky.session;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.hud.BossBarHud;
import net.minecraft.client.gui.hud.ClientBossBar;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.math.MathHelper;
import org.apache.commons.lang3.StringUtils;
import sky.event.network.PacketSendEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.mixin.gui.BossBarHudAccessor;
import sky.util.MsTimer;
import sky.util.entity.PlayerUtil;
import sky.access.SkyClientAccess;

/**
 * Identifies which server the client is connected to and tracks server-side state that the
 * rest of the client keys off: measured TPS, the current anarchy world and whether PvP is active.
 */
public final class ServerDetector implements SkyClientAccess {
    private final MsTimer pvpWatch = new MsTimer();
    private String server = "Vanilla";
    private float tps = 20.0F;

    private int anarchy;
    private long timestamp;
    private boolean serverSprint;
    private boolean pvpEnd;

    public ServerDetector() {
        EventManager.register(this);
    }

    public String getServer() {
        return server;
    }

    public boolean isHolyWorld() {
        return "HolyWorld".equals(server);
    }

    public int getAnarchy() {
        return anarchy;
    }

    public float getTps() {
        return tps;
    }

    public boolean isPvp() {
        return !pvpWatch.finished(250L);
    }

    @EventTarget
    public void tick(PlayerUpdateEvent event) {
        if (mc.world != null) {
            anarchy = getAnarchyMode();
        }
        server = updateServer();
        pvpEnd = inPvpEnd();
        if (inPvp()) {
            pvpWatch.reset();
        }
    }

    @EventTarget
    public void packet(PacketSendEvent event) {
        if (event.getPacket() instanceof WorldTimeUpdateS2CPacket) {
            long now = System.nanoTime();
            float measured = 20.0F * (1.0E9F / (now - timestamp));
            tps = MathHelper.clamp(measured, 0.0F, 20.0F);
            timestamp = now;
        }
    }

    /**
     * Servers echo the client's own sprint toggles back, which would otherwise desynchronise the
     * sprint state, so redundant toggles are cancelled here.
     */
    @EventTarget
    public void onPacket(PacketSendEvent event) {
        Packet<?> packet = event.getPacket();
        if (packet instanceof ClientCommandC2SPacket commandPacket) {
            if (commandPacket.getMode().equals(ClientCommandC2SPacket.Mode.START_SPRINTING)) {
                event.setCancelled(serverSprint);
                serverSprint = true;
            } else if (commandPacket.getMode().equals(ClientCommandC2SPacket.Mode.STOP_SPRINTING)) {
                event.setCancelled(!serverSprint);
                serverSprint = false;
            }
        }
    }

    private String updateServer() {
        if (!PlayerUtil.nullCheck()
            && mc.getNetworkHandler() != null
            && mc.getNetworkHandler().getServerInfo() != null
            && mc.getNetworkHandler().getBrand() != null) {

            String address = mc.getNetworkHandler().getServerInfo().address.toLowerCase();
            String brand = mc.getNetworkHandler().getBrand().toLowerCase();

            if (brand.contains("botfilter")) {
                return "FunTime";
            }
            if (address.contains("funtime")
                || address.contains("skytime")
                || address.contains("space-times")
                || address.contains("funsky")) {
                return "CopyTime";
            }
            if (brand.contains("holyworld")
                || brand.contains("leaf")
                || brand.contains("vk.com/idwok")) {
                return "HolyWorld";
            }
            if (address.contains("lonygrief")) {
                return "LonyGrief";
            }
            return address.contains("reallyworld") ? "ReallyWorld" : "Vanilla";
        }
        return "Vanilla";
    }

    /** Reads the anarchy world number out of the sidebar scoreboard title. */
    private int getAnarchyMode() {
        Scoreboard scoreboard = mc.world.getScoreboard();
        ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);

        if ("HolyWorld".equals(server) && objective != null) {
            for (ScoreboardEntry entry : scoreboard.getScoreboardEntries(objective)) {
                String line = Team.decorateName(
                    scoreboard.getScoreHolderTeam(entry.owner()), entry.name()).getString();
                if (!line.isEmpty()) {
                    // HolyWorld sidebar anarchy marker, e.g. "#12 -?-"
                    String number = StringUtils.substringBetween(line, "#", " -?-");
                    if (number != null && !number.isEmpty()) {
                        return Integer.parseInt(number);
                    }
                }
            }
        }
        return -1;
    }

    private boolean inPvp() {
        BossBarHud bossBarHud = mc.inGameHud.getBossBarHud();
        return ((BossBarHudAccessor) bossBarHud).getBossBars().values().stream()
            .map(bar -> ((ClientBossBar) bar).getName().getString().toLowerCase())
            .anyMatch(name -> name.contains("pvp") || name.contains("пвп")); // "пвп" = Russian PvP bossbar
    }

    private boolean inPvpEnd() {
        BossBarHud bossBarHud = mc.inGameHud.getBossBarHud();
        return ((BossBarHudAccessor) bossBarHud).getBossBars().values().stream()
            .map(bar -> ((ClientBossBar) bar).getName().getString().toLowerCase())
            .anyMatch(name -> (name.contains("pvp") || name.contains("пвп")) // Russian PvP bossbar
                && (name.contains("0") || name.contains("1")));
    }
}
