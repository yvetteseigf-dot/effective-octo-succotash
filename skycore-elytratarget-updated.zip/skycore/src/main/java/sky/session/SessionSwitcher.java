package sky.session;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import sky.mixin.client.MinecraftClientSessionAccessor;

/** Replaces the active Minecraft session used by multiplayer and the window title. */
public final class SessionSwitcher {
    private SessionSwitcher() {
    }

    public static void apply(AltAccount account) {
        if (account == null) {
            return;
        }
        apply(account.toSession());
    }

    public static void apply(Session session) {
        MinecraftClient client = MinecraftClient.getInstance();
        ((MinecraftClientSessionAccessor) client).skycore$setSession(session);
        WindowTitleAnimator animator = WindowTitleAnimator.getInstance();
        if (animator != null) {
            animator.user = session.getUsername();
        }
    }

    public static AltAccount current() {
        return AltAccount.fromSession(MinecraftClient.getInstance().getSession());
    }
}
