package sky.session;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.session.Session;
import sky.config.AbstractConfigFile;
import sky.config.ClientPaths;

/** Persisted alt list stored at {@link ClientPaths#ACCOUNTS_FILE_REL}. */
public final class AccountsFile extends AbstractConfigFile<List<AltAccount>> {
    public AccountsFile() {
        super(ClientPaths.ACCOUNTS_FILE_REL);
    }

    @Override
    protected void initializeData() {
        data = new ArrayList<>();
    }

    public List<AltAccount> getAccounts() {
        return data;
    }

    public AltAccount addOffline(String username) {
        if (!AltAccount.isValidUsername(username)) {
            return null;
        }
        AltAccount existing = find(username);
        if (existing != null) {
            return existing;
        }
        AltAccount created = AltAccount.offline(username);
        data.add(created);
        save();
        return created;
    }

    public void addIfAbsent(AltAccount account) {
        if (account == null || find(account.getUsername()) != null) {
            return;
        }
        data.add(account);
        save();
    }

    public boolean remove(AltAccount account) {
        if (account == null) {
            return false;
        }
        boolean removed = data.removeIf(entry -> entry.sameName(account.getUsername()));
        if (removed) {
            save();
        }
        return removed;
    }

    public AltAccount find(String username) {
        if (username == null) {
            return null;
        }
        for (AltAccount account : data) {
            if (account.sameName(username)) {
                return account;
            }
        }
        return null;
    }

    @Override
    protected JsonObject serializeData() {
        JsonObject object = new JsonObject();
        JsonArray accounts = new JsonArray();
        for (AltAccount account : data) {
            JsonObject value = new JsonObject();
            value.addProperty("username", account.getUsername());
            value.addProperty("uuid", account.getUuid().toString());
            value.addProperty("accessToken", account.getAccessToken());
            value.addProperty("type", account.getAccountType().getName());
            accounts.add(value);
        }
        object.add("accounts", accounts);
        return object;
    }

    @Override
    protected void deserializeData(JsonObject object) {
        data.clear();
        if (!object.has("accounts") || !object.get("accounts").isJsonArray()) {
            return;
        }
        JsonArray accounts = object.getAsJsonArray("accounts");
        for (JsonElement element : accounts) {
            if (!element.isJsonObject()) {
                continue;
            }
            JsonObject value = element.getAsJsonObject();
            String username = string(value, "username");
            if (!AltAccount.isValidUsername(username)) {
                continue;
            }
            UUID uuid;
            try {
                uuid = UUID.fromString(string(value, "uuid"));
            } catch (RuntimeException ignored) {
                data.add(AltAccount.offline(username));
                continue;
            }
            String token = string(value, "accessToken");
            Session.AccountType type = Session.AccountType.byName(string(value, "type"));
            data.add(new AltAccount(username, uuid, token, type == null ? Session.AccountType.LEGACY : type));
        }
    }

    @Override
    protected void handleLoadError(Exception exception) {
        if (data == null) {
            initializeData();
        }
    }

    private static String string(JsonObject object, String key) {
        JsonElement element = object.get(key);
        return element == null || element.isJsonNull() ? "" : element.getAsString();
    }
}
