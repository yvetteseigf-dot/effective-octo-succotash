package sky.module.visuals;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import sky.SkyInit;
import sky.config.BooleanSetting;
import sky.theme.GuiTheme;
import sky.config.ModeSetting;
import sky.config.MultiBooleanSetting;
import sky.config.NumberSetting;
import sky.event.render.RenderWorldEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.combat.AntiBot;
import sky.render.shader.LegacyShaderManager;
import sky.render.WorldDrawHelper;
import sky.util.render.ColorUtil;

public final class Chams extends Module {
    public static final Chams INSTANCE = new Chams();

    private static final Color DAMAGE_COLOR = new Color(255, 50, 50);
    private static final float MODEL_SCALE = 0.0625f;
    private static final float PLAYER_SCALE = 0.9375f;
    private static final float PLAYER_Y_OFFSET = -1.501f;

    private final MultiBooleanSetting targets;
    private final ModeSetting style;
    private final ModeSetting shaderPattern;
    private final NumberSetting opacity;
    private final NumberSetting outlineWidth;
    private final BooleanSetting halo;
    private final NumberSetting haloStrength;
    private final NumberSetting haloLayers;
    private final BooleanSetting breath;
    private final NumberSetting breathRate;
    private final BooleanSetting hurtFlash;
    private final BooleanSetting hideModel;
    private final BooleanSetting hideOthers;
    private final BooleanSetting hideLocal;

    private final long pulseStart;

    private PlayerEntityModel wideModel;
    private PlayerEntityModel slimModel;
    private float partialTicks;

    private Chams() {
        super("Chams", "Applies a colored overlay to player models", Category.VISUALS);
        this.targets = new MultiBooleanSetting("Targets",
                new BooleanSetting("Players", true),
                new BooleanSetting("Friends", true),
                new BooleanSetting("Local", false));
        this.style = new ModeSetting("Style", "Fill + Outline", "Fill + Outline", "Shader");
        this.shaderPattern = new ModeSetting("Pattern", "Plasma", () -> style.is("Shader"),
                "Plasma", "Cosmos", "Nebula", "Sakura", "Ethereal", "Summer");
        this.opacity = new NumberSetting("Opacity", 0.3f, 0.05f, 1.0f, 0.05f);
        this.outlineWidth = new NumberSetting("Outline", 1.5f, 0.5f, 5.0f, 0.1f);
        this.halo = new BooleanSetting("Halo", true);
        this.haloStrength = new NumberSetting("Intensity", 2.0f, 1.0f, 5.0f, 0.1f, halo::isEnabled);
        this.haloLayers = new NumberSetting("Layers", 3.0f, 1.0f, 6.0f, 1.0f, halo::isEnabled);
        this.breath = new BooleanSetting("Breath", false);
        this.breathRate = new NumberSetting("Rate", 2.0f, 0.5f, 5.0f, 0.1f, breath::isEnabled);
        this.hurtFlash = new BooleanSetting("Hurt flash", true);
        this.hideModel = new BooleanSetting("Hide model", false);
        this.hideOthers = new BooleanSetting("Others", true, hideModel::isEnabled);
        this.hideLocal = new BooleanSetting("Own model", false, hideModel::isEnabled);
        this.pulseStart = System.currentTimeMillis();
        addSettings(targets, style, shaderPattern, opacity, outlineWidth, halo, haloStrength, haloLayers,
                breath, breathRate, hurtFlash, hideModel, hideOthers, hideLocal);
    }

    public boolean shouldHideEntity(Entity entity) {
        if (!isEnabled() || !hideModel.isEnabled() || entity == null || mc.player == null) {
            return false;
        }

        if (entity == mc.player) {
            return hideLocal.isEnabled()
                    && targets.is("Local")
                    && !mc.options.getPerspective().isFirstPerson();
        }

        if (entity instanceof PlayerEntity) {
            return hideOthers.isEnabled() && (targets.is("Players") || targets.is("Friends"));
        }

        return false;
    }

    @EventTarget
    private void onRender3D(RenderWorldEvent event) {
        if (mc.world == null || mc.player == null) {
            return;
        }

        ensureModels();
        partialTicks = event.getPartialTicks();

        MatrixStack matrices = event.getMatrixStack();
        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();

        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        if (halo.isEnabled()) {
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        } else {
            RenderSystem.defaultBlendFunc();
        }
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);

        try {
            for (Entity entity : mc.world.getEntities()) {
                if (!(entity instanceof LivingEntity living)) {
                    continue;
                }
                if (!shouldRender(living)) {
                    continue;
                }

                if (living instanceof AbstractClientPlayerEntity player) {
                    renderPlayer(matrices, player, partialTicks, cameraPos);
                } else {
                    renderEntityBox(living, partialTicks);
                }
            }
        } finally {
            GL11.glDisable(GL11.GL_LINE_SMOOTH);
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
        }
    }

    private boolean shouldRender(LivingEntity entity) {
        if (!entity.isAlive() || entity.age < 3) {
            return false;
        }

        if (!(entity instanceof PlayerEntity player)) {
            return false;
        }

        if (entity == mc.player) {
            return targets.is("Local") && !mc.options.getPerspective().isFirstPerson();
        }

        if (AntiBot.isBot(player)) {
            return false;
        }

        boolean friend = SkyInit.getInstance().getFriendManager().isFriend(player.getGameProfile().getName());
        if (friend) {
            return targets.is("Friends");
        }

        return targets.is("Players");
    }

    private void ensureModels() {
        if (wideModel != null) {
            return;
        }

        wideModel = createPlayerModel(false);
        slimModel = createPlayerModel(true);
    }

    private static PlayerEntityModel createPlayerModel(boolean slim) {
        ModelPart root = TexturedModelData
                .of(PlayerEntityModel.getTexturedModelData(Dilation.NONE, slim), 64, 64)
                .createModel();
        return new PlayerEntityModel(root, slim);
    }

    private void renderPlayer(MatrixStack matrices, AbstractClientPlayerEntity player, float tickDelta, Vec3d cameraPos) {
        EntityRenderer<?, ?> renderer = mc.getEntityRenderDispatcher().getRenderer(player);
        if (!(renderer instanceof PlayerEntityRenderer playerRenderer)) {
            renderEntityBox(player, tickDelta);
            return;
        }

        boolean damaged = hurtFlash.isEnabled() && player.hurtTime > 0;
        int fill = applyPulse(resolveFill(damaged));
        int outline = applyPulse(resolveOutline(damaged));

        boolean slim = player.getSkinTextures().model() == SkinTextures.Model.SLIM;
        PlayerEntityModel model = slim ? slimModel : wideModel;

        PlayerEntityRenderState state = new PlayerEntityRenderState();
        playerRenderer.updateRenderState(player, state, tickDelta);
        model.getRootPart().traverse().forEach(ModelPart::resetTransform);
        model.setAngles(state);

        matrices.push();
        applyPlayerTransform(matrices, player, tickDelta, cameraPos);

        if (halo.isEnabled()) {
            int layers = Math.round(haloLayers.getCurrent());
            float strength = haloStrength.getCurrent();
            for (int layer = layers; layer >= 0; layer--) {
                float expand = layer * 0.5f * strength;
                float fade = layer == 0 ? 1.0f : 0.7f / (layer + 1);
                drawPlayerParts(matrices, model, expand, scaleAlpha(fill, fade), scaleAlpha(outline, fade), damaged);
            }
        } else {
            drawPlayerParts(matrices, model, 0.0f, fill, outline, damaged);
        }

        matrices.pop();
    }

    private void applyPlayerTransform(MatrixStack matrices, AbstractClientPlayerEntity player, float tickDelta, Vec3d cameraPos) {
        double offsetX = MathHelper.lerp(tickDelta, player.lastRenderX, player.getX()) - cameraPos.x;
        double offsetY = MathHelper.lerp(tickDelta, player.lastRenderY, player.getY()) - cameraPos.y;
        double offsetZ = MathHelper.lerp(tickDelta, player.lastRenderZ, player.getZ()) - cameraPos.z;
        matrices.translate(offsetX, offsetY, offsetZ);

        float bodyYaw = MathHelper.lerpAngleDegrees(tickDelta, player.prevBodyYaw, player.bodyYaw);
        float leaningPitch = player.getLeaningPitch(tickDelta);

        if (player.isGliding()) {
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - bodyYaw));
            if (!player.isUsingRiptide()) {
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0f - player.getPitch()));
            }

            Vec3d look = player.getRotationVec(tickDelta);
            Vec3d velocity = player.getVelocity();
            double horizontalSpeedSq = velocity.x * velocity.x + velocity.z * velocity.z;
            double horizontalLookSq = look.x * look.x + look.z * look.z;
            if (horizontalSpeedSq > 0.0d && horizontalLookSq > 0.0d) {
                double alignment = (velocity.x * look.x + velocity.z * look.z)
                        / Math.sqrt(horizontalSpeedSq * horizontalLookSq);
                double side = velocity.x * look.z - velocity.z * look.x;
                matrices.multiply(RotationAxis.POSITIVE_Y.rotation(
                        (float) (Math.signum(side) * Math.acos(MathHelper.clamp(alignment, -1.0d, 1.0d)))));
            }
        } else if (leaningPitch > 0.0f) {
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - bodyYaw));
            float swimPitch = player.isInSwimmingPose() ? -90.0f - player.getPitch() : -90.0f;
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(MathHelper.lerp(leaningPitch, 0.0f, swimPitch)));
            if (player.isInSwimmingPose()) {
                matrices.translate(0.0d, -1.0d, 0.3d);
            }
        } else {
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - bodyYaw));
        }

        if (player.isInSneakingPose()) {
            matrices.translate(0.0d, -0.11d, 0.0d);
        }

        matrices.scale(-1.0f, -1.0f, 1.0f);
        matrices.scale(PLAYER_SCALE, PLAYER_SCALE, PLAYER_SCALE);
        matrices.translate(0.0d, PLAYER_Y_OFFSET, 0.0d);
    }

    private void drawPlayerParts(MatrixStack matrices, PlayerEntityModel model, float expand, int fill, int outline, boolean damaged) {
        drawPart(matrices, model.head, -4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f, expand, fill, outline, damaged);
        drawPart(matrices, model.body, -4.0f, 0.0f, -2.0f, 8.0f, 12.0f, 4.0f, expand, fill, outline, damaged);
        drawPart(matrices, model.rightArm, -3.0f, -2.0f, -2.0f, 4.0f, 12.0f, 4.0f, expand, fill, outline, damaged);
        drawPart(matrices, model.leftArm, -1.0f, -2.0f, -2.0f, 4.0f, 12.0f, 4.0f, expand, fill, outline, damaged);
        drawPart(matrices, model.rightLeg, -2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, expand, fill, outline, damaged);
        drawPart(matrices, model.leftLeg, -2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, expand, fill, outline, damaged);
    }

    private void drawPart(MatrixStack matrices, ModelPart part,
                          float originX, float originY, float originZ,
                          float sizeX, float sizeY, float sizeZ,
                          float expand, int fill, int outline, boolean damaged) {
        matrices.push();
        part.rotate(matrices);

        float grow = expand * MODEL_SCALE;
        float minX = originX * MODEL_SCALE - grow;
        float minY = originY * MODEL_SCALE - grow;
        float minZ = originZ * MODEL_SCALE - grow;
        float maxX = (originX + sizeX) * MODEL_SCALE + grow;
        float maxY = (originY + sizeY) * MODEL_SCALE + grow;
        float maxZ = (originZ + sizeZ) * MODEL_SCALE + grow;

        Matrix4f matrix = matrices.peek().getPositionMatrix();
        boolean shaderStyle = style.is("Shader");
        if (shaderStyle && !damaged && LegacyShaderManager.isChamsShaderReady(shaderPattern.get())) {
            drawShaderFill(matrix, minX, minY, minZ, maxX, maxY, maxZ, ColorUtil.alphaf(fill));
        } else {
            float fillRed = ColorUtil.redf(fill);
            float fillGreen = ColorUtil.greenf(fill);
            float fillBlue = ColorUtil.bluef(fill);
            float fillAlpha = ColorUtil.alphaf(fill);

            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferBuilder buffer = Tessellator.getInstance()
                    .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            putFilledBox(buffer, matrix, minX, minY, minZ, maxX, maxY, maxZ,
                    fillRed, fillGreen, fillBlue, fillAlpha);
            BufferRenderer.drawWithGlobalProgram(buffer.end());
        }

        float outlineRed = ColorUtil.redf(outline);
        float outlineGreen = ColorUtil.greenf(outline);
        float outlineBlue = ColorUtil.bluef(outline);
        float outlineAlpha = ColorUtil.alphaf(outline);

        RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);
        RenderSystem.lineWidth(outlineWidth.getCurrent());
        BufferBuilder buffer = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
        putOutline(buffer, matrices, matrix, minX, minY, minZ, maxX, maxY, maxZ,
                outlineRed, outlineGreen, outlineBlue, outlineAlpha);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        matrices.pop();
    }

    private void drawShaderFill(Matrix4f matrix, float minX, float minY, float minZ,
                                float maxX, float maxY, float maxZ, float alpha) {
        if (!LegacyShaderManager.isChamsShaderReady(shaderPattern.get())) {
            Color accent = GuiTheme.theme.getAccent();
            BufferBuilder fallback = Tessellator.getInstance()
                    .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            putFilledBox(fallback, matrix, minX, minY, minZ, maxX, maxY, maxZ,
                    accent.getRed() / 255.0f, accent.getGreen() / 255.0f, accent.getBlue() / 255.0f, alpha);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferRenderer.drawWithGlobalProgram(fallback.end());
            return;
        }

        LegacyShaderManager.LegacyGlProgram program = LegacyShaderManager.chamsProgram(shaderPattern.get());
        Color accent = GuiTheme.theme.getAccent();
        float scale = Ambience.INSTANCE.isEnabled() ? Ambience.INSTANCE.skyScale.getCurrent() : 1.0f;
        float speed = Ambience.INSTANCE.isEnabled() ? Ambience.INSTANCE.skySpeed.getCurrent() : 1.2f;
        float worldTime = mc.world != null ? (float) mc.world.getTime() : 0.0f;
        float time = (worldTime + partialTicks) * speed * 0.08f;

        BufferBuilder buffer = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        putDirectionFilledBox(buffer, matrix, minX, minY, minZ, maxX, maxY, maxZ);
        BuiltBuffer built = buffer.end();

        program.attach();
        program.uniformMatrix4f("ModelViewMat", RenderSystem.getModelViewMatrix());
        program.uniformMatrix4f("ProjMat", RenderSystem.getProjectionMatrix());
        program.uniform4f("u_Color",
                accent.getRed() / 255.0f, accent.getGreen() / 255.0f, accent.getBlue() / 255.0f, 1.0f);
        program.uniform1f("u_Scale", scale);
        program.uniform1f("u_Time", time);
        program.uniform1f("u_Alpha", alpha);
        BufferRenderer.draw(built);
        program.detach();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
    }

    private void renderEntityBox(LivingEntity entity, float tickDelta) {
        boolean damaged = hurtFlash.isEnabled() && entity.hurtTime > 0;
        applyPulse(resolveFill(damaged));
        int outline = applyPulse(resolveOutline(damaged));

        double offsetX = MathHelper.lerp(tickDelta, entity.lastRenderX, entity.getX()) - entity.getX();
        double offsetY = MathHelper.lerp(tickDelta, entity.lastRenderY, entity.getY()) - entity.getY();
        double offsetZ = MathHelper.lerp(tickDelta, entity.lastRenderZ, entity.getZ()) - entity.getZ();

        Box box = entity.getBoundingBox().offset(offsetX, offsetY, offsetZ).expand(0.02d);
        WorldDrawHelper.drawBox(box, outline, outlineWidth.getCurrent(), true, true, false);
    }

    private int resolveFill(boolean damaged) {
        float alpha = opacity.getCurrent();
        if (damaged) {
            return ColorUtil.rgba(DAMAGE_COLOR.getRed(), DAMAGE_COLOR.getGreen(), DAMAGE_COLOR.getBlue(),
                    Math.round(alpha * 255.0f));
        }

        Color accent = GuiTheme.theme.getAccent();
        return ColorUtil.rgba(accent.getRed(), accent.getGreen(), accent.getBlue(), Math.round(alpha * 255.0f));
    }

    private int resolveOutline(boolean damaged) {
        float alpha = Math.max(0.5f, opacity.getCurrent());
        if (damaged) {
            return ColorUtil.rgba(DAMAGE_COLOR.getRed(), DAMAGE_COLOR.getGreen(), DAMAGE_COLOR.getBlue(),
                    Math.round(alpha * 255.0f));
        }

        Color accent = GuiTheme.theme.getAccent();
        return ColorUtil.rgba(accent.getRed(), accent.getGreen(), accent.getBlue(), Math.round(alpha * 255.0f));
    }

    private int applyPulse(int color) {
        if (!breath.isEnabled()) {
            return color;
        }

        float seconds = (System.currentTimeMillis() - pulseStart) / 1000.0f;
        float wave = (float) ((Math.sin(seconds * breathRate.getCurrent() * Math.PI) + 1.0d) / 2.0d);
        return scaleAlpha(color, 0.3f + 0.7f * wave);
    }

    private static int scaleAlpha(int color, float multiplier) {
        int alpha = MathHelper.clamp((int) ((color >> 24 & 255) * multiplier), 0, 255);
        return alpha << 24 | color & 0xFFFFFF;
    }

    private void putFilledBox(BufferBuilder buffer, Matrix4f matrix,
                              float minX, float minY, float minZ, float maxX, float maxY, float maxZ,
                              float red, float green, float blue, float alpha) {
        quad(buffer, matrix,
                minX, maxY, minZ, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ,
                red, green, blue, alpha);
        quad(buffer, matrix,
                minX, minY, maxZ, minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ,
                red, green, blue, alpha);
        quad(buffer, matrix,
                minX, minY, minZ, minX, maxY, minZ, maxX, maxY, minZ, maxX, minY, minZ,
                red, green, blue, alpha);
        quad(buffer, matrix,
                maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, minX, minY, maxZ,
                red, green, blue, alpha);
        quad(buffer, matrix,
                minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ, minX, minY, minZ,
                red, green, blue, alpha);
        quad(buffer, matrix,
                maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ,
                red, green, blue, alpha);
    }

    private void quad(BufferBuilder buffer, Matrix4f matrix,
                      float x1, float y1, float z1, float x2, float y2, float z2,
                      float x3, float y3, float z3, float x4, float y4, float z4,
                      float red, float green, float blue, float alpha) {
        buffer.vertex(matrix, x1, y1, z1).color(red, green, blue, alpha);
        buffer.vertex(matrix, x2, y2, z2).color(red, green, blue, alpha);
        buffer.vertex(matrix, x3, y3, z3).color(red, green, blue, alpha);
        buffer.vertex(matrix, x4, y4, z4).color(red, green, blue, alpha);
    }

    private void putDirectionFilledBox(BufferBuilder buffer, Matrix4f matrix,
                                       float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
        float centerX = (minX + maxX) * 0.5f;
        float centerY = (minY + maxY) * 0.5f;
        float centerZ = (minZ + maxZ) * 0.5f;

        dirQuad(buffer, matrix, centerX, centerY, centerZ,
                minX, maxY, minZ, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ);
        dirQuad(buffer, matrix, centerX, centerY, centerZ,
                minX, minY, maxZ, minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ);
        dirQuad(buffer, matrix, centerX, centerY, centerZ,
                minX, minY, minZ, minX, maxY, minZ, maxX, maxY, minZ, maxX, minY, minZ);
        dirQuad(buffer, matrix, centerX, centerY, centerZ,
                maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, minX, minY, maxZ);
        dirQuad(buffer, matrix, centerX, centerY, centerZ,
                minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ, minX, minY, minZ);
        dirQuad(buffer, matrix, centerX, centerY, centerZ,
                maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ);
    }

    private void dirQuad(BufferBuilder buffer, Matrix4f matrix,
                         float centerX, float centerY, float centerZ,
                         float x1, float y1, float z1, float x2, float y2, float z2,
                         float x3, float y3, float z3, float x4, float y4, float z4) {
        dirVertex(buffer, matrix, centerX, centerY, centerZ, x1, y1, z1);
        dirVertex(buffer, matrix, centerX, centerY, centerZ, x2, y2, z2);
        dirVertex(buffer, matrix, centerX, centerY, centerZ, x3, y3, z3);
        dirVertex(buffer, matrix, centerX, centerY, centerZ, x4, y4, z4);
    }

    private void dirVertex(BufferBuilder buffer, Matrix4f matrix,
                           float centerX, float centerY, float centerZ, float x, float y, float z) {
        float dirX = x - centerX;
        float dirY = y - centerY;
        float dirZ = z - centerZ;
        float length = MathHelper.sqrt(dirX * dirX + dirY * dirY + dirZ * dirZ);
        if (length > 1.0E-6f) {
            dirX /= length;
            dirY /= length;
            dirZ /= length;
        } else {
            dirX = 0.0f;
            dirY = 1.0f;
            dirZ = 0.0f;
        }

        buffer.vertex(matrix, x, y, z)
                .color(dirX * 0.5f + 0.5f, dirY * 0.5f + 0.5f, dirZ * 0.5f + 0.5f, 1.0f);
    }

    private void putOutline(BufferBuilder buffer, MatrixStack matrices, Matrix4f matrix,
                            float minX, float minY, float minZ, float maxX, float maxY, float maxZ,
                            float red, float green, float blue, float alpha) {
        line(buffer, matrices, matrix, minX, minY, minZ, maxX, minY, minZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, maxX, minY, minZ, maxX, minY, maxZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, maxX, minY, maxZ, minX, minY, maxZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, minX, minY, maxZ, minX, minY, minZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, minX, maxY, minZ, maxX, maxY, minZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, maxX, maxY, minZ, maxX, maxY, maxZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, maxX, maxY, maxZ, minX, maxY, maxZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, minX, maxY, maxZ, minX, maxY, minZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, minX, minY, minZ, minX, maxY, minZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, maxX, minY, minZ, maxX, maxY, minZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, maxX, minY, maxZ, maxX, maxY, maxZ, red, green, blue, alpha);
        line(buffer, matrices, matrix, minX, minY, maxZ, minX, maxY, maxZ, red, green, blue, alpha);
    }

    private void line(BufferBuilder buffer, MatrixStack matrices, Matrix4f matrix,
                      float x1, float y1, float z1, float x2, float y2, float z2,
                      float red, float green, float blue, float alpha) {
        float deltaX = x2 - x1;
        float deltaY = y2 - y1;
        float deltaZ = z2 - z1;
        float length = MathHelper.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);

        float normalX = 0.0f;
        float normalY = 1.0f;
        float normalZ = 0.0f;
        if (length > 1.0E-4f) {
            normalX = deltaX / length;
            normalY = deltaY / length;
            normalZ = deltaZ / length;
        }

        buffer.vertex(matrix, x1, y1, z1)
                .color(red, green, blue, alpha)
                .normal(matrices.peek(), normalX, normalY, normalZ);
        buffer.vertex(matrix, x2, y2, z2)
                .color(red, green, blue, alpha)
                .normal(matrices.peek(), normalX, normalY, normalZ);
    }
}
