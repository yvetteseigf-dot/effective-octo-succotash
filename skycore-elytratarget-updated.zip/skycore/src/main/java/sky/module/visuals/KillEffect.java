package sky.module.visuals;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import sky.config.BooleanSetting;
import sky.theme.GuiTheme;
import sky.config.NumberSetting;
import sky.event.player.PlayerUpdateEvent;
import sky.event.render.RenderWorldEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.combat.AttackAura;

public final class KillEffect extends Module {
    public static final KillEffect INSTANCE = new KillEffect();

    private static final Identifier GLOW = Identifier.of("skycore", "icons/glow.png");

    private final BooleanSetting beam;
    private final BooleanSetting soul;
    private final BooleanSetting runes;
    private final NumberSetting duration;
    private final NumberSetting intensity;
    private final NumberSetting beamHeight;
    private final NumberSetting soulHeight;
    private final NumberSetting runeSize;
    private final List<Effect> effects;

    private int trackedTargetId;
    private Vec3d trackedTargetPos;
    private float trackedTargetHeight;

    private KillEffect() {
        super("KillEffect", "Effects on kill", Category.VISUALS);
        this.beam = new BooleanSetting("Beam", true);
        this.soul = new BooleanSetting("Soul", false);
        this.runes = new BooleanSetting("Runes", true);
        this.duration = new NumberSetting("Duration, ms", 1600.0f, 600.0f, 3000.0f, 100.0f);
        this.intensity = new NumberSetting("Brightness", 0.95f, 0.35f, 1.75f, 0.05f);
        this.beamHeight = new NumberSetting("Beam Height", 8.5f, 4.0f, 18.0f, 0.5f, beam::get);
        this.soulHeight = new NumberSetting("Soul Height", 1.6f, 0.8f, 4.5f, 0.1f, soul::get);
        this.runeSize = new NumberSetting("Rune Size", 2.4f, 1.2f, 5.5f, 0.1f, runes::get);
        this.effects = new ArrayList<>();
        this.trackedTargetId = -1;
        addSettings(beam, soul, runes, duration, intensity, beamHeight, soulHeight, runeSize);
    }

    @Override
    public void onDisable() {
        effects.clear();
        trackedTargetId = -1;
        trackedTargetPos = null;
        super.onDisable();
    }

    @EventTarget
    private void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.world == null || mc.player == null) {
            effects.clear();
            trackedTargetId = -1;
            trackedTargetPos = null;
            return;
        }

        LivingEntity auraTarget = AttackAura.INSTANCE.getTarget();
        if (auraTarget != null && auraTarget != mc.player) {
            trackedTargetId = auraTarget.getId();
            trackedTargetPos = auraTarget.getPos();
            trackedTargetHeight = auraTarget.getHeight();
        }

        if (trackedTargetId != -1 && trackedTargetPos != null) {
            Entity raw = mc.world.getEntityById(trackedTargetId);
            LivingEntity living = raw instanceof LivingEntity entity ? entity : null;
            if (living == null || !living.isAlive() || living.getHealth() <= 0.0f) {
                effects.add(new Effect(
                        trackedTargetPos,
                        Math.max(0.6f, trackedTargetHeight),
                        System.currentTimeMillis(),
                        Math.round(duration.get())));
                trackedTargetId = -1;
                trackedTargetPos = null;
            } else {
                trackedTargetPos = living.getPos();
                trackedTargetHeight = living.getHeight();
            }
        }

        long now = System.currentTimeMillis();
        effects.removeIf(effect -> effect.isDone(now));
    }

    @EventTarget
    private void onRender3D(RenderWorldEvent event) {
        if (effects.isEmpty() || mc.world == null || mc.player == null) {
            return;
        }

        MatrixStack stack = event.getMatrixStack();
        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();
        int color = 0xFF000000 | (GuiTheme.theme.getAccent().getRGB() & 0xFFFFFF);
        long now = System.currentTimeMillis();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        try {
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
            RenderSystem.setShaderTexture(0, GLOW);
            Iterator<Effect> iterator = effects.iterator();
            while (iterator.hasNext()) {
                Effect effect = iterator.next();
                float progress = effect.progress(now);
                if (progress >= 1.0f) {
                    iterator.remove();
                    continue;
                }
                float alpha = (1.0f - progress) * intensity.get();
                Vec3d pos = effect.pos().subtract(cameraPos);
                if (beam.isEnabled()) {
                    drawBeam(stack, pos, color, alpha, progress);
                }
                if (soul.isEnabled()) {
                    drawSoul(stack, pos, color, alpha, progress);
                }
                if (runes.isEnabled()) {
                    drawRunes(stack, pos, color, alpha, progress);
                }
            }
        } finally {
            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
        }
    }

    private void drawBeam(MatrixStack stack, Vec3d pos, int color, float alpha, float progress) {
        float height = beamHeight.get() * (0.85f + 0.15f * MathHelper.sin(progress * 3.1415927f));
        float width = 0.38f + progress * 0.22f;
        float yaw = mc.gameRenderer.getCamera().getYaw();
        float cos = MathHelper.cos((float) Math.toRadians(yaw));
        float sin = MathHelper.sin((float) Math.toRadians(yaw));
        drawVerticalQuad(stack, pos, cos, sin, width, height, color, alpha * 0.35f);
    }

    private void drawSoul(MatrixStack stack, Vec3d pos, int color, float alpha, float progress) {
        stack.push();
        stack.translate(pos.x, pos.y + 0.6f + soulHeight.get() * progress, pos.z);
        stack.multiply(mc.gameRenderer.getCamera().getRotation());
        Matrix4f matrix = stack.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        emitQuad(buffer, matrix, 0.65f * (1.0f - progress * 0.35f), withAlpha(color, alpha * 0.85f));
        emitQuad(buffer, matrix, 1.25f * (1.0f - progress * 0.15f), withAlpha(color, alpha * 0.22f));
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        stack.pop();
    }

    private void drawRunes(MatrixStack stack, Vec3d pos, int color, float alpha, float progress) {
        stack.push();
        stack.translate(pos.x, pos.y + 0.03f, pos.z);
        stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0f));
        stack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(progress * 180.0f));
        Matrix4f matrix = stack.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        float size = runeSize.get() * (1.0f + progress * 0.15f);
        emitQuad(buffer, matrix, size, withAlpha(color, alpha * (1.0f - progress) * 0.55f));
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        stack.pop();
    }

    private void drawVerticalQuad(MatrixStack stack, Vec3d pos, float dirX, float dirZ, float width, float height,
                                 int color, float alpha) {
        Matrix4f matrix = stack.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        int tint = withAlpha(color, alpha);
        float x = (float) pos.x;
        float y = (float) pos.y;
        float z = (float) pos.z;
        buffer.vertex(matrix, x - dirX * width, y + height, z - dirZ * width).texture(0.0f, 1.0f).color(tint);
        buffer.vertex(matrix, x + dirX * width, y + height, z + dirZ * width).texture(1.0f, 1.0f).color(tint);
        buffer.vertex(matrix, x + dirX * width, y, z + dirZ * width).texture(1.0f, 0.0f).color(tint);
        buffer.vertex(matrix, x - dirX * width, y, z - dirZ * width).texture(0.0f, 0.0f).color(tint);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private static void emitQuad(BufferBuilder buffer, Matrix4f matrix, float size, int color) {
        float half = size * 0.5f;
        buffer.vertex(matrix, -half, -half, 0.0f).texture(0.0f, 1.0f).color(color);
        buffer.vertex(matrix, half, -half, 0.0f).texture(1.0f, 1.0f).color(color);
        buffer.vertex(matrix, half, half, 0.0f).texture(1.0f, 0.0f).color(color);
        buffer.vertex(matrix, -half, half, 0.0f).texture(0.0f, 0.0f).color(color);
    }

    private static int withAlpha(int color, float alpha) {
        return (MathHelper.clamp(Math.round(alpha * 255.0f), 0, 255) << 24) | (color & 0xFFFFFF);
    }

    record Effect(Vec3d pos, float height, long startMs, long durationMs) {
        private boolean isDone(long now) {
            return now - startMs >= durationMs;
        }

        private float progress(long now) {
            return MathHelper.clamp((now - startMs) / (float) durationMs, 0.0f, 1.0f);
        }
    }
}
