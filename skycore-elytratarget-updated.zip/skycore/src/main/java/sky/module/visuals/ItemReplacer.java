package sky.module.visuals;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.json.Transformation;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Identifier;
import org.joml.Vector3f;
import sky.config.ModeSetting;
import sky.module.Category;
import sky.module.Module;

public final class ItemReplacer extends Module {
    private static final SwordVariant[] SWORD_VARIANTS = createSwordVariants();
    private static final Map<String, SwordVariant> VARIANTS_BY_LABEL = createVariantMap();

    public static final ItemReplacer INSTANCE = new ItemReplacer();

    private final ModeSetting swordModel;

    private String cachedSelectedLabel;
    private SwordVariant cachedSelectedVariant;

    private ItemReplacer() {
        super("ItemReplacer", "Replaces sword models", Category.VISUALS);
        this.swordModel = new ModeSetting("Sword Model", SWORD_VARIANTS[0].label, getVariantLabels());
        this.cachedSelectedVariant = SWORD_VARIANTS[0];
        addSettings(swordModel);
    }

    public static String[] getVariantLabels() {
        String[] labels = new String[SWORD_VARIANTS.length];
        for (int i = 0; i < SWORD_VARIANTS.length; i++) {
            labels[i] = SWORD_VARIANTS[i].label;
        }

        return labels;
    }

    public static boolean renderReplacement(ItemStack stack, ModelTransformationMode transformType,
                                            MatrixStack matrixStack, VertexConsumerProvider buffer,
                                            int combinedLight, int combinedOverlay) {
        if (stack == null || stack.isEmpty() || !stack.isIn(ItemTags.SWORDS)) {
            return false;
        }

        if (!INSTANCE.isEnabled()) {
            return false;
        }

        return INSTANCE.getSelectedVariant().model
                .render(stack, transformType, matrixStack, buffer, combinedLight, combinedOverlay);
    }

    public SwordVariant getSelectedVariant() {
        String label = swordModel.get();
        if (label == null) {
            return SWORD_VARIANTS[0];
        }

        if (label.equalsIgnoreCase(cachedSelectedLabel)) {
            return cachedSelectedVariant;
        }

        SwordVariant variant = VARIANTS_BY_LABEL.get(label.toLowerCase(Locale.ROOT));
        if (variant == null) {
            variant = SWORD_VARIANTS[0];
        }

        cachedSelectedLabel = label;
        cachedSelectedVariant = variant;
        return variant;
    }

    public void clearLoadedModels() {
        for (SwordVariant variant : SWORD_VARIANTS) {
            variant.model.clear();
        }
    }

    @Override
    protected void onDisable() {
        clearLoadedModels();
        super.onDisable();
    }

    private static Map<String, SwordVariant> createVariantMap() {
        Map<String, SwordVariant> byLabel = new HashMap<>(SWORD_VARIANTS.length * 2);
        for (SwordVariant variant : SWORD_VARIANTS) {
            byLabel.put(variant.label.toLowerCase(Locale.ROOT), variant);
        }

        return byLabel;
    }

    private static SwordVariant[] createSwordVariants() {
        String[][] entries = {
                {"Abominable Blade", "abominableblade"},
                {"Abominable Greatsaber", "abominablegreatsaber"},
                {"Abominable Scythe", "abominablescythe"},
                {"Acid Demon", "aciddemon"},
                {"Amethyst Shuriken", "amethyst_shuriken"},
                {"Ancient Royal Greatsword", "ancient_royal_great_sword"},
                {"Aquantic Sacred Blade", "aquantic_sacred_blade"},
                {"Aquantic Trident", "aquantictrident"},
                {"Arcanethyst", "arcanethyst"},
                {"Ashura Blade", "ashura_blade"},
                {"Awakened Lichblade", "awakened_lichblade"},
                {"Blood Edge", "bloodedge"},
                {"Bloody Death", "bloodydeath"},
                {"Bramblethorn", "bramblethorn"},
                {"Brimstone Claymore", "brimstone_claymore"},
                {"Carian Sword", "cariansword"},
                {"Chrono Blade", "chrono_blade"},
                {"Corrupted Mythic Blade", "corruptedmythicblade"},
                {"Creation Splitter", "creationsplitter"},
                {"Crescent Rose", "crescentrose"},
                {"Cyber Katana", "cyberkatana"},
                {"Cyber Mantis Blade", "cybermantisblade"},
                {"Cybernetic Katana", "cybernetickatana"},
                {"Cybernetic Knife", "cyberneticknife"},
                {"Cybernetic Sawblade", "cyberneticsawblade"},
                {"Cyber Sword", "cybersword"},
                {"Dainsleif", "dainsleif"},
                {"Dark Blade", "dark_blade"},
                {"Dark Cleaver", "dark_cleaver"},
                {"Death Knight Dagger", "death_knight_dagger"},
                {"Death Knight Sword", "death_knight_sword"},
                {"Demigod's Unholy Blade", "demigodsunholyblade"},
                {"Demigod's Unholy Halberd", "demigodsunholyhalberd"},
                {"Demonic Blade", "demonicblade"},
                {"Demonic Cleaver", "demoniccleaver"},
                {"Demon Lord's Great Axe", "demonlordsgreataxe"},
                {"Demon Lord's Sword", "demonlordsword"},
                {"Divine Justice", "divine_justice"},
                {"Divine Reaper", "divine_reaper"},
                {"Divine Axe Rhitta", "divineaxerhitta"},
                {"Divine Punisher", "divinepunisher"},
                {"Dragon Slaying Blade", "dragonslayingblade"},
                {"Edge of the Astral Plane", "edgeoftheastralplane"},
                {"Emberblade", "emberblade"},
                {"Enigma", "enigma"},
                {"Epic Sword", "epicsword"},
                {"Estoc", "estoc"},
                {"Excalibur", "excalibur"},
                {"Fallen God Spear", "fallengodspear"},
                {"Fallen God Sword", "fallengodsword"},
                {"Floral Longsword", "floral_longsword"},
                {"Floral Sabre", "floral_sabre"},
                {"Forest Guardian Glaive", "forest_guardian_glaive"},
                {"Frost Axe", "frostaxe"},
                {"Frostblade", "frostblade"},
                {"Frost Scythe", "frostscythe"},
                {"Green Scythe", "greenscythe"},
                {"Hearthflame", "hearthflame"},
                {"Hero Sword", "herosword"},
                {"Holy Moonlight Sword", "holymoonlightsword"},
                {"Hornet's Needle", "hornetsneedle"},
                {"Ice Whisper", "icewhisper"},
                {"Jade Halberd", "jadehalberd"},
                {"Katana", "katana"},
                {"Legendary Sword", "legendarysword"},
                {"Longsword", "longsword"},
                {"Magi Scythe", "magiscythe"},
                {"Masamune", "masamune"},
                {"Mjolnir", "mjolnir"},
                {"Molten Blade", "moltenblade"},
                {"Molten Sword", "moltensword"},
                {"Muramasa", "muramasa"},
                {"Mystical Spellblade", "mysticalspellblade"},
                {"Mythic Blade", "mythicblade"},
                {"Partisan", "partisan"},
                {"Pharaoh's Treasure", "pharaohs_treasure"},
                {"Phoenix Grace", "pheonixgrace"},
                {"Powerfuse Hammer", "powerfusehammer"},
                {"Powerfuse Sword", "powerfusesword"},
                {"Requiem of Hell", "requiem_of_hell"},
                {"Ribbon Cleaver", "ribboncleaver"},
                {"Righteous Relic", "righteous_relic"},
                {"Rivers of Blood", "riversofblood"},
                {"Royal Chakram", "royalchakram"},
                {"Royal Rapier", "royalrapier"},
                {"Sabre", "sabre"},
                {"Scissor Blade", "scissorblade"},
                {"Sculk Cleaver", "sculkcleaver"},
                {"Sculk Scythe", "sculkscythe"},
                {"Sculk Sword", "sculksword"},
                {"Sentinel's Will", "sentinels_will"},
                {"Silverine Blade", "silverine_blade"},
                {"Soul Claws", "soulclaws"},
                {"Soul Edge", "souledge"},
                {"Soul Harvester", "soulharvester"},
                {"Soul Render", "soulrender"},
                {"Soul Stealer", "soulstealer"},
                {"Soul Collector", "soul_collector"},
                {"Soul Devourer", "soul_devourer"},
                {"Star's Edge", "stars_edge"},
                {"Steel Sword", "steelsword"},
                {"Stop Sign", "stop_sign"},
                {"Stormbringer", "stormbringer"},
                {"Storm's Edge", "storms_edge"},
                {"Sunbreak", "sunbreak"},
                {"Tengen's Blade", "tengensblade"},
                {"Terrablade", "terrablade"},
                {"Thousand Demon Daggers", "thousanddemondaggers"},
                {"Thunderbrand", "thunderbrand"},
                {"Thunderbringer", "thunderbringer"},
                {"Toxic Longsword", "toxic_longsword"},
                {"Vampiric Needle", "vampiricneedle"},
                {"Wakizashi", "wakizashi"},
                {"Watcher Claymore", "watcher_claymore"},
                {"Watching Warglaive", "watching_warglaive"},
                {"Waxweaver", "waxweaver"},
                {"Whisperwind", "whisperwind"},
                {"Wickpiercer", "wickpiercer"},
                {"Yoru", "yoru"}
        };

        SwordVariant[] variants = new SwordVariant[entries.length];
        for (int i = 0; i < entries.length; i++) {
            variants[i] = new SwordVariant(entries[i][0], entries[i][1]);
        }

        return variants;
    }

    public static final class SwordVariant {
        public final String label;
        public final String modelName;

        private final RuntimeSwordModel model;

        private SwordVariant(String label, String modelName) {
            this.label = label;
            this.modelName = modelName;
            this.model = new RuntimeSwordModel(modelName);
        }
    }

    private static final class RuntimeSwordModel {
        private static final String MODEL_ROOT = "item_replacer/sword/models/";
        private static final String TEXTURE_ROOT = "textures/item_replacer/sword/";
        private static final String LEGACY_TEXTURE_ROOT = "item_replacer/sword/textures/";
        private static final float PIXEL = 0.0625f;
        private static final float MODEL_CENTER = 0.5f;
        private static final int VERTEX_STRIDE = 8;

        private final MinecraftClient mc = MinecraftClient.getInstance();
        private final ArrayList<ModelCube> cubes = new ArrayList<>();
        private final Transformation[] displayTransforms = new Transformation[8];
        private final String modelPath;

        private float[] bakedMesh = new float[0];
        private int vertexCount;
        private boolean loaded;
        private Identifier textureLocation;
        private RenderLayer renderLayer;

        private RuntimeSwordModel(String modelName) {
            this.modelPath = MODEL_ROOT + modelName + ".json";
        }

        private boolean render(ItemStack stack, ModelTransformationMode transformType, MatrixStack matrixStack,
                               VertexConsumerProvider buffer, int combinedLight, int combinedOverlay) {
            loadIfNeeded();
            if (vertexCount == 0 || renderLayer == null) {
                return false;
            }

            VertexConsumer consumer =
                    ItemRenderer.getItemGlintConsumer(buffer, renderLayer, true, stack.hasGlint());
            matrixStack.push();
            applyDisplayTransform(matrixStack, transformType);
            drawMesh(consumer, matrixStack.peek(), combinedLight, combinedOverlay);
            matrixStack.pop();
            return true;
        }

        private void clear() {
            loaded = false;
            textureLocation = null;
            renderLayer = null;
            bakedMesh = new float[0];
            vertexCount = 0;
            cubes.clear();

            for (int i = 0; i < displayTransforms.length; i++) {
                displayTransforms[i] = null;
            }
        }

        private void loadIfNeeded() {
            if (loaded) {
                return;
            }

            loaded = true;
            Identifier location = Identifier.of("skycore", modelPath);

            try (InputStream stream = mc.getResourceManager().getResource(location).orElseThrow().getInputStream()) {
                String json = new String(stream.readAllBytes(), StandardCharsets.UTF_8);
                readModel(JsonParser.parseString(json).getAsJsonObject());
            } catch (Exception exception) {
                System.err.println("[ItemReplacer] Failed to load model " + modelPath + ": "
                        + exception.getMessage());
            }
        }

        private void readModel(JsonObject root) {
            JsonObject textures = root.getAsJsonObject("textures");
            if (textures == null) {
                return;
            }

            Map<String, String> textureMap = new HashMap<>();
            for (Map.Entry<String, JsonElement> texture : textures.entrySet()) {
                textureMap.put(texture.getKey(), texture.getValue().getAsString());
            }

            String primaryKey = resolvePrimaryTextureKey(textureMap, root);
            String texturePath = textureMap.get(primaryKey);
            if (texturePath == null) {
                return;
            }

            String textureName = texturePath.contains("/")
                    ? texturePath.substring(texturePath.lastIndexOf('/') + 1)
                    : texturePath;
            textureLocation = resolveTextureIdentifier(textureName);
            if (textureLocation == null) {
                return;
            }

            renderLayer = hasPartialAlpha(textureLocation)
                    ? RenderLayer.getEntityTranslucent(textureLocation)
                    : RenderLayer.getEntityCutout(textureLocation);

            JsonArray elements = root.getAsJsonArray("elements");
            if (elements == null) {
                return;
            }

            String primaryTextureReference = "#" + primaryKey;
            for (JsonElement element : elements) {
                JsonObject elementObject = element.getAsJsonObject();
                JsonArray from = elementObject.getAsJsonArray("from");
                JsonArray to = elementObject.getAsJsonArray("to");
                if (from == null || to == null) {
                    continue;
                }

                ModelCube cube = new ModelCube(
                        from.get(0).getAsFloat() * PIXEL,
                        from.get(1).getAsFloat() * PIXEL,
                        from.get(2).getAsFloat() * PIXEL,
                        to.get(0).getAsFloat() * PIXEL,
                        to.get(1).getAsFloat() * PIXEL,
                        to.get(2).getAsFloat() * PIXEL);

                JsonObject faces = elementObject.getAsJsonObject("faces");
                if (faces == null) {
                    continue;
                }

                if (!readFaces(cube, faces, primaryTextureReference)) {
                    continue;
                }

                if (elementObject.has("rotation")) {
                    readRotation(cube, elementObject.getAsJsonObject("rotation"));
                }

                cubes.add(cube);
            }

            bakeMesh();
            readDisplayTransforms(root);
        }

        private String resolvePrimaryTextureKey(Map<String, String> textureMap, JsonObject root) {
            if (textureMap.containsKey("0")) {
                return "0";
            }

            Map<String, Integer> usage = new HashMap<>();
            JsonArray elements = root.getAsJsonArray("elements");
            if (elements != null) {
                for (JsonElement element : elements) {
                    JsonObject faces = element.getAsJsonObject().getAsJsonObject("faces");
                    if (faces == null) {
                        continue;
                    }

                    for (Map.Entry<String, JsonElement> face : faces.entrySet()) {
                        JsonObject faceObject = face.getValue().getAsJsonObject();
                        if (!faceObject.has("texture")) {
                            continue;
                        }

                        String reference = faceObject.get("texture").getAsString().replace("#", "");
                        usage.merge(reference, 1, Integer::sum);
                    }
                }
            }

            String best = null;
            int bestCount = -1;
            for (Map.Entry<String, Integer> entry : usage.entrySet()) {
                String key = entry.getKey();
                int count = entry.getValue();
                if (!textureMap.containsKey(key) || "particle".equals(key) || count <= bestCount) {
                    continue;
                }

                best = key;
                bestCount = count;
            }

            if (best != null) {
                return best;
            }

            for (String key : textureMap.keySet()) {
                if (!"particle".equals(key)) {
                    return key;
                }
            }

            return textureMap.keySet().iterator().next();
        }

        private Identifier resolveTextureIdentifier(String textureName) {
            Identifier modern = Identifier.of("skycore", TEXTURE_ROOT + textureName + ".png");
            if (mc.getResourceManager().getResource(modern).isPresent()) {
                return modern;
            }

            Identifier legacy = Identifier.of("skycore", LEGACY_TEXTURE_ROOT + textureName + ".png");
            if (mc.getResourceManager().getResource(legacy).isPresent()) {
                return legacy;
            }

            System.err.println("[ItemReplacer] Missing texture for sword model: " + textureName);
            return null;
        }

        private boolean hasPartialAlpha(Identifier location) {
            try (InputStream stream = mc.getResourceManager().getResource(location).orElseThrow().getInputStream();
                 NativeImage image = NativeImage.read(stream)) {
                for (int y = 0; y < image.getHeight(); y++) {
                    for (int x = 0; x < image.getWidth(); x++) {
                        int alpha = image.getColorArgb(x, y) >>> 24 & 255;
                        if (alpha > 0 && alpha < 255) {
                            return true;
                        }
                    }
                }

                return false;
            } catch (Exception ignored) {
                return true;
            }
        }

        private boolean readFaces(ModelCube cube, JsonObject faces, String primaryTextureReference) {
            boolean any = false;

            if (faces.has("north")) {
                cube.north = readFace(faces.getAsJsonObject("north"), primaryTextureReference);
                any |= cube.north != null;
            }

            if (faces.has("south")) {
                cube.south = readFace(faces.getAsJsonObject("south"), primaryTextureReference);
                any |= cube.south != null;
            }

            if (faces.has("east")) {
                cube.east = readFace(faces.getAsJsonObject("east"), primaryTextureReference);
                any |= cube.east != null;
            }

            if (faces.has("west")) {
                cube.west = readFace(faces.getAsJsonObject("west"), primaryTextureReference);
                any |= cube.west != null;
            }

            if (faces.has("up")) {
                cube.up = readFace(faces.getAsJsonObject("up"), primaryTextureReference);
                any |= cube.up != null;
            }

            if (faces.has("down")) {
                cube.down = readFace(faces.getAsJsonObject("down"), primaryTextureReference);
                any |= cube.down != null;
            }

            return any;
        }

        private FaceUv readFace(JsonObject face, String primaryTextureReference) {
            if (face.has("texture")
                    && !face.get("texture").getAsString().equals(primaryTextureReference)) {
                return null;
            }

            JsonArray uv = face.getAsJsonArray("uv");
            if (uv == null || uv.size() < 4) {
                return null;
            }

            return new FaceUv(
                    uv.get(0).getAsFloat() * PIXEL,
                    uv.get(1).getAsFloat() * PIXEL,
                    uv.get(2).getAsFloat() * PIXEL,
                    uv.get(3).getAsFloat() * PIXEL);
        }

        private void readRotation(ModelCube cube, JsonObject rotation) {
            if (rotation == null || !rotation.has("origin") || !rotation.has("axis")
                    || !rotation.has("angle")) {
                return;
            }

            JsonArray origin = rotation.getAsJsonArray("origin");
            cube.rotationOriginX = origin.get(0).getAsFloat() * PIXEL;
            cube.rotationOriginY = origin.get(1).getAsFloat() * PIXEL;
            cube.rotationOriginZ = origin.get(2).getAsFloat() * PIXEL;
            cube.setRotation(rotation.get("axis").getAsString(), rotation.get("angle").getAsFloat());
        }

        private void readDisplayTransforms(JsonObject root) {
            if (!root.has("display")) {
                return;
            }

            JsonObject display = root.getAsJsonObject("display");
            displayTransforms[0] = readDisplayTransform(display, "thirdperson_righthand");
            displayTransforms[1] = readDisplayTransform(display, "thirdperson_lefthand");
            displayTransforms[2] = readDisplayTransform(display, "firstperson_righthand");
            displayTransforms[3] = readDisplayTransform(display, "firstperson_lefthand");
            displayTransforms[4] = readDisplayTransform(display, "ground");
            displayTransforms[5] = readDisplayTransform(display, "gui");
            displayTransforms[6] = readDisplayTransform(display, "head");
            displayTransforms[7] = readDisplayTransform(display, "fixed");
        }

        private Transformation readDisplayTransform(JsonObject display, String key) {
            if (!display.has(key)) {
                return null;
            }

            JsonObject entry = display.getAsJsonObject(key);
            Vector3f rotation = new Vector3f();
            Vector3f translation = new Vector3f();
            Vector3f scale = new Vector3f(1.0f, 1.0f, 1.0f);

            if (entry.has("rotation")) {
                readVector3f(entry.getAsJsonArray("rotation"), rotation);
            }

            if (entry.has("translation")) {
                readVector3f(entry.getAsJsonArray("translation"), translation);
                translation.mul(PIXEL);
            }

            if (entry.has("scale")) {
                readVector3f(entry.getAsJsonArray("scale"), scale);
            }

            return new Transformation(rotation, translation, scale);
        }

        private void readVector3f(JsonArray array, Vector3f target) {
            for (int i = 0; i < 3 && i < array.size(); i++) {
                target.setComponent(i, array.get(i).getAsFloat());
            }
        }

        private Transformation getDisplayTransform(ModelTransformationMode type) {
            return switch (type) {
                case THIRD_PERSON_RIGHT_HAND -> displayTransforms[0];
                case THIRD_PERSON_LEFT_HAND -> displayTransforms[1];
                case FIRST_PERSON_RIGHT_HAND -> displayTransforms[2];
                case FIRST_PERSON_LEFT_HAND -> displayTransforms[3];
                case GROUND -> displayTransforms[4];
                case GUI -> displayTransforms[5];
                case HEAD -> displayTransforms[6];
                case FIXED -> displayTransforms[7];
                default -> null;
            };
        }

        private void applyDisplayTransform(MatrixStack matrixStack, ModelTransformationMode type) {
            Transformation transformation = getDisplayTransform(type);
            if (transformation == null) {
                return;
            }

            boolean leftHanded = type == ModelTransformationMode.THIRD_PERSON_LEFT_HAND
                    || type == ModelTransformationMode.FIRST_PERSON_LEFT_HAND;
            transformation.apply(leftHanded, matrixStack);
        }

        private void bakeMesh() {
            int faces = 0;
            for (ModelCube cube : cubes) {
                faces += cube.countFaces();
            }

            float[] mesh = new float[faces * 4 * VERTEX_STRIDE];
            int offset = 0;
            for (ModelCube cube : cubes) {
                offset = bakeCube(mesh, offset, cube);
            }

            bakedMesh = mesh;
            vertexCount = offset / VERTEX_STRIDE;
            cubes.clear();
            cubes.trimToSize();
        }

        private int bakeCube(float[] out, int offset, ModelCube cube) {
            float x1 = cube.x1;
            float y1 = cube.y1;
            float z1 = cube.z1;
            float x2 = cube.x2;
            float y2 = cube.y2;
            float z2 = cube.z2;

            if (cube.north != null) {
                FaceUv face = cube.north;
                offset = writeBakedVertex(out, offset, cube, x2, y1, z1, face.u1, face.v2, 0.0f, 0.0f, -1.0f);
                offset = writeBakedVertex(out, offset, cube, x1, y1, z1, face.u2, face.v2, 0.0f, 0.0f, -1.0f);
                offset = writeBakedVertex(out, offset, cube, x1, y2, z1, face.u2, face.v1, 0.0f, 0.0f, -1.0f);
                offset = writeBakedVertex(out, offset, cube, x2, y2, z1, face.u1, face.v1, 0.0f, 0.0f, -1.0f);
            }

            if (cube.south != null) {
                FaceUv face = cube.south;
                offset = writeBakedVertex(out, offset, cube, x1, y1, z2, face.u1, face.v2, 0.0f, 0.0f, 1.0f);
                offset = writeBakedVertex(out, offset, cube, x2, y1, z2, face.u2, face.v2, 0.0f, 0.0f, 1.0f);
                offset = writeBakedVertex(out, offset, cube, x2, y2, z2, face.u2, face.v1, 0.0f, 0.0f, 1.0f);
                offset = writeBakedVertex(out, offset, cube, x1, y2, z2, face.u1, face.v1, 0.0f, 0.0f, 1.0f);
            }

            if (cube.east != null) {
                FaceUv face = cube.east;
                offset = writeBakedVertex(out, offset, cube, x2, y1, z2, face.u1, face.v2, 1.0f, 0.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x2, y1, z1, face.u2, face.v2, 1.0f, 0.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x2, y2, z1, face.u2, face.v1, 1.0f, 0.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x2, y2, z2, face.u1, face.v1, 1.0f, 0.0f, 0.0f);
            }

            if (cube.west != null) {
                FaceUv face = cube.west;
                offset = writeBakedVertex(out, offset, cube, x1, y1, z1, face.u1, face.v2, -1.0f, 0.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x1, y1, z2, face.u2, face.v2, -1.0f, 0.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x1, y2, z2, face.u2, face.v1, -1.0f, 0.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x1, y2, z1, face.u1, face.v1, -1.0f, 0.0f, 0.0f);
            }

            if (cube.up != null) {
                FaceUv face = cube.up;
                offset = writeBakedVertex(out, offset, cube, x1, y2, z1, face.u1, face.v1, 0.0f, 1.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x1, y2, z2, face.u1, face.v2, 0.0f, 1.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x2, y2, z2, face.u2, face.v2, 0.0f, 1.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x2, y2, z1, face.u2, face.v1, 0.0f, 1.0f, 0.0f);
            }

            if (cube.down != null) {
                FaceUv face = cube.down;
                offset = writeBakedVertex(out, offset, cube, x1, y1, z2, face.u1, face.v1, 0.0f, -1.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x1, y1, z1, face.u1, face.v2, 0.0f, -1.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x2, y1, z1, face.u2, face.v2, 0.0f, -1.0f, 0.0f);
                offset = writeBakedVertex(out, offset, cube, x2, y1, z2, face.u2, face.v1, 0.0f, -1.0f, 0.0f);
            }

            return offset;
        }

        private int writeBakedVertex(float[] out, int offset, ModelCube cube, float x, float y, float z,
                                     float u, float v, float normalX, float normalY, float normalZ) {
            if (cube.rotationAxis != ModelCube.NO_ROTATION) {
                float dx = x - cube.rotationOriginX;
                float dy = y - cube.rotationOriginY;
                float dz = z - cube.rotationOriginZ;
                float sin = cube.rotationSin;
                float cos = cube.rotationCos;

                switch (cube.rotationAxis) {
                    case ModelCube.ROTATE_X -> {
                        y = cube.rotationOriginY + dy * cos - dz * sin;
                        z = cube.rotationOriginZ + dy * sin + dz * cos;
                        float rotatedY = normalY * cos - normalZ * sin;
                        float rotatedZ = normalY * sin + normalZ * cos;
                        normalY = rotatedY;
                        normalZ = rotatedZ;
                    }
                    case ModelCube.ROTATE_Y -> {
                        x = cube.rotationOriginX + dx * cos + dz * sin;
                        z = cube.rotationOriginZ - dx * sin + dz * cos;
                        float rotatedX = normalX * cos + normalZ * sin;
                        float rotatedZ = -normalX * sin + normalZ * cos;
                        normalX = rotatedX;
                        normalZ = rotatedZ;
                    }
                    case ModelCube.ROTATE_Z -> {
                        x = cube.rotationOriginX + dx * cos - dy * sin;
                        y = cube.rotationOriginY + dx * sin + dy * cos;
                        float rotatedX = normalX * cos - normalY * sin;
                        float rotatedY = normalX * sin + normalY * cos;
                        normalX = rotatedX;
                        normalY = rotatedY;
                    }
                    default -> {
                    }
                }
            }

            out[offset++] = x - MODEL_CENTER;
            out[offset++] = y - MODEL_CENTER;
            out[offset++] = z - MODEL_CENTER;
            out[offset++] = u;
            out[offset++] = v;
            out[offset++] = normalX;
            out[offset++] = normalY;
            out[offset++] = normalZ;
            return offset;
        }

        private void drawMesh(VertexConsumer builder, MatrixStack.Entry entry, int light, int overlay) {
            int total = vertexCount * VERTEX_STRIDE;
            for (int i = 0; i < total; i += VERTEX_STRIDE) {
                builder.vertex(entry, bakedMesh[i], bakedMesh[i + 1], bakedMesh[i + 2])
                        .color(255, 255, 255, 255)
                        .texture(bakedMesh[i + 3], bakedMesh[i + 4])
                        .overlay(overlay)
                        .light(light)
                        .normal(entry, bakedMesh[i + 5], bakedMesh[i + 6], bakedMesh[i + 7]);
            }
        }
    }

    private static final class ModelCube {
        private static final int NO_ROTATION = 0;
        private static final int ROTATE_X = 1;
        private static final int ROTATE_Y = 2;
        private static final int ROTATE_Z = 3;

        private final float x1;
        private final float y1;
        private final float z1;
        private final float x2;
        private final float y2;
        private final float z2;

        private FaceUv north;
        private FaceUv south;
        private FaceUv east;
        private FaceUv west;
        private FaceUv up;
        private FaceUv down;

        private int rotationAxis = NO_ROTATION;
        private float rotationCos = 1.0f;
        private float rotationSin;
        private float rotationOriginX;
        private float rotationOriginY;
        private float rotationOriginZ;

        private ModelCube(float x1, float y1, float z1, float x2, float y2, float z2) {
            this.x1 = x1;
            this.y1 = y1;
            this.z1 = z1;
            this.x2 = x2;
            this.y2 = y2;
            this.z2 = z2;
        }

        private void setRotation(String axis, float angle) {
            switch (axis) {
                case "x" -> rotationAxis = ROTATE_X;
                case "y" -> rotationAxis = ROTATE_Y;
                case "z" -> rotationAxis = ROTATE_Z;
                default -> {
                    rotationAxis = NO_ROTATION;
                    return;
                }
            }

            float radians = (float) Math.toRadians(angle);
            rotationSin = (float) Math.sin(radians);
            rotationCos = (float) Math.cos(radians);
        }

        private int countFaces() {
            int count = 0;
            if (north != null) {
                count++;
            }

            if (south != null) {
                count++;
            }

            if (east != null) {
                count++;
            }

            if (west != null) {
                count++;
            }

            if (up != null) {
                count++;
            }

            if (down != null) {
                count++;
            }

            return count;
        }
    }

    private static final class FaceUv {
        private final float u1;
        private final float v1;
        private final float u2;
        private final float v2;

        private FaceUv(float u1, float v1, float u2, float v2) {
            this.u1 = u1;
            this.v1 = v1;
            this.u2 = u2;
            this.v2 = v2;
        }
    }
}
