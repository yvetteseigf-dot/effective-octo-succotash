package sky.module.visuals;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import sky.SkyInit;
import sky.config.BooleanSetting;
import sky.config.ModeSetting;
import sky.config.MultiBooleanSetting;
import sky.config.NumberSetting;
import sky.event.render.OverlayRenderEvent;
import sky.module.Category;
import sky.module.Module;
import sky.render.DrawHelper;
import sky.util.render.BlendStateUtil;
import sky.util.render.ColorUtil;
import sky.util.render.HudScaleUtil;

import java.awt.Color;

public final class Arrows extends Module {
    private static final int COLOR_PLAYER = -1;
    private static final int COLOR_FRIEND = -16711936;
    private static final int COLOR_ITEM = -1;
    private static final float ARROW_SIZE = 20.0F;

    public static final Arrows INSTANCE = new Arrows();

    private static final Identifier ARROW_UNUSUAL = Identifier.of("skycore", "icons/world_render/triangle.png");
    private static final Identifier ARROW_FILLED = Identifier.of("skycore", "icons/world_render/arrow.png");

    private final MultiBooleanSetting rendering;
    private final NumberSetting radius;
    private final BooleanSetting onlyIfNotVisible;
    private final ModeSetting type;

    private Arrows() {
        super("Arrows", "Draws pointers toward nearby entities", Category.VISUALS);
        this.rendering = new MultiBooleanSetting("Show",
                new BooleanSetting("Players", true),
                new BooleanSetting("Friends", true),
                new BooleanSetting("Naked", false),
                new BooleanSetting("Items", false));
        this.radius = new NumberSetting("Radius", 40.0F, 30.0F, 80.0F, 5.0F);
        this.onlyIfNotVisible = new BooleanSetting("Only if not visible", false);
        this.type = new ModeSetting("Arrow type", "Unusual", "Unusual", "Filled");
        addSettings(rendering, onlyIfNotVisible, radius, type);
    }

    @EventTarget
    private void onRender(OverlayRenderEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        if (mc.getDebugHud() != null && mc.getDebugHud().shouldShowDebugHud()) {
            return;
        }

        float cameraYaw = mc.gameRenderer.getCamera().getYaw();
        double yawCos = Math.cos(Math.toRadians(cameraYaw));
        double yawSin = Math.sin(Math.toRadians(cameraYaw));

        float screenWidth = HudScaleUtil.getRenderWidth();
        float screenHeight = HudScaleUtil.getRenderHeight();
        double baseRadius = radius.getCurrent();

        Identifier arrowTexture = type.is("Unusual") ? ARROW_UNUSUAL : ARROW_FILLED;
        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();
        float partialTicks = event.getPartialTicks();

        for (Entity entity : mc.world.getEntities()) {
            if (!isValidEntity(entity)) {
                continue;
            }

            double arrowRadius = entity instanceof ItemEntity
                    ? Math.max(baseRadius - 20.0, 0.0)
                    : baseRadius;

            double centerX = screenWidth / 2.0 - arrowRadius;
            double centerY = screenHeight / 2.0 - arrowRadius;

            double renderX = MathHelper.lerp(partialTicks, entity.lastRenderX, entity.getX());
            double renderZ = MathHelper.lerp(partialTicks, entity.lastRenderZ, entity.getZ());

            double offsetX = (renderX - cameraPos.x) * 0.01;
            double offsetZ = (renderZ - cameraPos.z) * 0.01;

            double rotationY = -(offsetZ * yawCos - offsetX * yawSin);
            double rotationX = -(offsetX * yawCos + offsetZ * yawSin);
            double angle = Math.toDegrees(Math.atan2(rotationY, rotationX));

            double screenX = arrowRadius * Math.cos(Math.toRadians(angle)) + centerX + arrowRadius;
            double screenY = arrowRadius * Math.sin(Math.toRadians(angle)) + centerY + arrowRadius;

            if (!isValidRotation(rotationX, rotationY, arrowRadius)) {
                continue;
            }

            Color color = toColor(determineEntityColor(entity));
            MatrixStack matrices = event.getStack();
            DrawHelper renderer = DrawHelper.get();
            if (matrices == null || renderer == null) {
                return;
            }
            matrices.push();
            matrices.translate((float) screenX, (float) screenY, 0.0F);
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) angle));
            BlendStateUtil.runBlended(() -> renderer.drawTexture(arrowTexture,
                    -ARROW_SIZE / 2.0F, -ARROW_SIZE / 2.0F, ARROW_SIZE, ARROW_SIZE, color, matrices));
            matrices.pop();
        }
    }

    private boolean isValidEntity(Entity entity) {
        boolean tracked = isPlayerTarget(entity) || isItemTarget(entity);
        if (!tracked || !entity.isAlive() || entity == mc.player) {
            return false;
        }
        return !onlyIfNotVisible.isEnabled() || !isEntityVisible(entity);
    }

    private boolean isPlayerTarget(Entity entity) {
        if (!(entity instanceof PlayerEntity player) || entity == mc.player) {
            return false;
        }

        boolean friend = SkyInit.getInstance().getFriendManager()
                .isFriend(player.getGameProfile().getName());
        boolean naked = player.getArmor() == 0;

        if (friend) {
            return rendering.is("Friends");
        }
        if (naked) {
            return rendering.is("Naked");
        }
        return rendering.is("Players");
    }

    private boolean isItemTarget(Entity entity) {
        return entity instanceof ItemEntity && rendering.is("Items");
    }

    private int determineEntityColor(Entity entity) {
        if (entity instanceof PlayerEntity player) {
            boolean friend = SkyInit.getInstance().getFriendManager()
                    .isFriend(player.getGameProfile().getName());
            return friend ? COLOR_FRIEND : COLOR_PLAYER;
        }
        if (entity instanceof ItemEntity) {
            return COLOR_ITEM;
        }
        return COLOR_PLAYER;
    }

    private boolean isEntityVisible(Entity entity) {
        Vec3d eyePos = mc.player.getEyePos();
        Vec3d targetPos = entity.getPos().add(0.0, entity.getHeight() / 2.0, 0.0);

        RaycastContext context = new RaycastContext(eyePos, targetPos,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player);
        BlockHitResult hitResult = mc.world.raycast(context);
        return hitResult.getType() == HitResult.Type.MISS;
    }

    private boolean isValidRotation(double rotationX, double rotationY, double arrowRadius) {
        double negatedY = -rotationY;
        double negatedX = -rotationX;
        return Math.sqrt(negatedX * negatedX + negatedY * negatedY) < arrowRadius;
    }

    private Color toColor(int argb) {
        int fixed = ColorUtil.fixBrightness(argb);
        return new Color((fixed >> 16) & 255, (fixed >> 8) & 255, fixed & 255, (fixed >> 24) & 255);
    }
}
