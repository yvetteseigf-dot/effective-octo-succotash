package sky.module.visuals;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.hit.HitResult;
import sky.config.BooleanSetting;
import sky.config.NumberSetting;
import sky.event.render.CrosshairRenderEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.movement.FreeCamera;
import sky.render.DrawHelper;
import sky.util.render.ColorUtil;
import sky.util.render.HudScaleUtil;

public final class Crosshair extends Module {
    public static final Crosshair INSTANCE = new Crosshair();

    private final NumberSetting gap;
    private final NumberSetting length;
    private final NumberSetting thickness;
    private final BooleanSetting changeColorOnHover;
    private final BooleanSetting dynamicCrosshair;
    private final BooleanSetting showOutline;
    private final BooleanSetting showDot;

    private Crosshair() {
        super("Crosshair", "Lets you customize the crosshair", Category.VISUALS);
        this.gap = new NumberSetting("Gap", 2.0f, 0.0f, 6.0f, 0.5f);
        this.length = new NumberSetting("Length", 3.0f, 2.0f, 5.0f, 0.5f);
        this.thickness = new NumberSetting("Thickness", 2.0f, 1.0f, 6.0f, 1.0f);
        this.changeColorOnHover = new BooleanSetting("Change color on hover", false);
        this.dynamicCrosshair = new BooleanSetting("Dynamic gap", false);
        this.showOutline = new BooleanSetting("Outline", true);
        this.showDot = new BooleanSetting("Center dot", true);
        addSettings(gap, length, thickness, changeColorOnHover, dynamicCrosshair, showOutline, showDot);
    }

    @EventTarget
    public void onRender2D(CrosshairRenderEvent event) {
        if (mc.player == null || mc.options == null) {
            return;
        }
        if (mc.options.getPerspective() != Perspective.FIRST_PERSON && !FreeCamera.INSTANCE.isEnabled()) {
            return;
        }
        DrawContext context = event.getContext();
        if (context == null) {
            return;
        }
        float centerX = HudScaleUtil.getRenderWidth() / 2.0f;
        float centerY = HudScaleUtil.getRenderHeight() / 2.0f;
        float cooldown = 1.0f - mc.player.getAttackCooldownProgress(event.getPartialTicks());
        drawCustomCrosshair(context, centerX, centerY, cooldown);
        event.setCancelled(true);
    }

    private void drawCustomCrosshair(DrawContext context, float centerX, float centerY, float cooldown) {
        float gapValue = gap.get();
        float thicknessValue = thickness.get();
        float lengthValue = length.get();
        float currentGap = dynamicCrosshair.isEnabled() ? gapValue + 8.0f * cooldown : gapValue;
        float outline = 1.0f;
        int color = changeColorOnHover.isEnabled()
                && mc.crosshairTarget != null
                && mc.crosshairTarget.getType() == HitResult.Type.ENTITY
                ? ColorUtil.rgba(255, 64, 64, 255)
                : -1;
        DrawHelper render = DrawHelper.get();
        if (render == null) {
            return;
        }
        int outlineColor = ColorUtil.rgba(0, 0, 0, 255);
        if (showOutline.isEnabled()) {
            render.drawMinecraftRectangle(context,
                    centerX + currentGap - outline / 2.0f,
                    centerY - thicknessValue / 2.0f - outline / 2.0f,
                    lengthValue + outline, thicknessValue + outline, outlineColor);
            render.drawMinecraftRectangle(context,
                    centerX - currentGap - lengthValue - outline / 2.0f,
                    centerY - thicknessValue / 2.0f - outline / 2.0f,
                    lengthValue + outline, thicknessValue + outline, outlineColor);
            render.drawMinecraftRectangle(context,
                    centerX - thicknessValue / 2.0f - outline / 2.0f,
                    centerY - currentGap - lengthValue - outline / 2.0f,
                    thicknessValue + outline, lengthValue + outline, outlineColor);
            render.drawMinecraftRectangle(context,
                    centerX - thicknessValue / 2.0f - outline / 2.0f,
                    centerY + currentGap - outline / 2.0f,
                    thicknessValue + outline, lengthValue + outline, outlineColor);
        }
        render.drawMinecraftRectangle(context,
                centerX + currentGap, centerY - thicknessValue / 2.0f,
                lengthValue, thicknessValue, color);
        render.drawMinecraftRectangle(context,
                centerX - currentGap - lengthValue, centerY - thicknessValue / 2.0f,
                lengthValue, thicknessValue, color);
        render.drawMinecraftRectangle(context,
                centerX - thicknessValue / 2.0f, centerY - currentGap - lengthValue,
                thicknessValue, lengthValue, color);
        render.drawMinecraftRectangle(context,
                centerX - thicknessValue / 2.0f, centerY + currentGap,
                thicknessValue, lengthValue, color);
        if (showDot.isEnabled() && currentGap > 0.0f) {
            float size = thicknessValue;
            float dotX = centerX - size / 2.0f;
            float dotY = centerY - size / 2.0f;
            if (showOutline.isEnabled()) {
                render.drawMinecraftRectangle(context,
                        dotX - outline / 2.0f, dotY - outline / 2.0f,
                        size + outline, size + outline, outlineColor);
            }
            render.drawMinecraftRectangle(context, dotX, dotY, size, size, color);
        }
    }
}
