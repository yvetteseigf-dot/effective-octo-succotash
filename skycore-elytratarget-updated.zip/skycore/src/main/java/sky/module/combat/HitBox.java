package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import sky.config.BooleanSetting;
import sky.config.NumberSetting;
import sky.event.combat.EntityHitboxEvent;
import sky.module.Category;
import sky.module.Module;

public final class HitBox extends Module {
    public static final HitBox INSTANCE = new HitBox();

    public final NumberSetting size;

    private final BooleanSetting showHitBox;

    private HitBox() {
        super("HitBox", "Expands entity hitboxes", Category.COMBAT);
        this.size = new NumberSetting("Size", 0.2F, 0.0F, 1.0F, 0.05F);
        this.showHitBox = new BooleanSetting("Show size", true);
        addSettings(this.size, this.showHitBox);
    }

    public boolean shouldKeepVanillaHitbox(LivingEntity entity) {
        ElytraTarget elytraTarget = ElytraTarget.INSTANCE;
        AttackAura attackAura = AttackAura.INSTANCE;
        if (elytraTarget == null || attackAura == null || !elytraTarget.isEnabled()) {
            return false;
        }

        if (!elytraTarget.isPedikPredict() && !elytraTarget.isTestPredict() && !elytraTarget.isSmartPredict()) {
            return false;
        }

        if (mc.player == null || !mc.player.isGliding() || !entity.isGliding()) {
            return false;
        }

        return entity == attackAura.getTarget();
    }

    @EventTarget
    public void onHitBox(EntityHitboxEvent event) {
        if (!(event.getEntity() instanceof LivingEntity livingEntity)) {
            return;
        }

        if (shouldKeepVanillaHitbox(livingEntity)) {
            return;
        }

        if (!isEnabled()) {
            return;
        }

        event.setSize(size.getCurrent());
    }

    public boolean shouldShowHitBox() {
        return isEnabled() && showHitBox.isEnabled();
    }
}
