package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import sky.event.network.PacketSendEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.combat.ThornsDamageEvent;
import sky.mixin.network.EntityStatusS2CPacketMixin;
import sky.module.Category;
import sky.module.Module;

public final class AntiThorns extends Module {
    public static final AntiThorns INSTANCE = new AntiThorns();

    private static final int THORNS_VELOCITY_SUPPRESS_TICKS = 8;
    private static final int THORNS_ENTITY_STATUS_OPCODE = 33;

    private int suppressVelocityTicks;

    private AntiThorns() {
        super("AntiThorns", "Removes thorns damage and knockback", Category.COMBAT);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        tickSuppressTimer();
    }

    @EventTarget
    public void onThornsDamage(ThornsDamageEvent event) {
        if (shouldCancelThornsDamage(event.getAttacker())) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (!event.isReceive() || mc.player == null || mc.world == null) {
            return;
        }

        if (event.getPacket() instanceof EntityStatusS2CPacket statusPacket) {
            if (statusPacket.getStatus() == THORNS_ENTITY_STATUS_OPCODE
                    && ((EntityStatusS2CPacketMixin) statusPacket).skycore$getEntityId() == mc.player.getId()
                    && isLocalPlayerElytraFlying()) {
                armVelocitySuppress();
            }
            return;
        }

        if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket velocityPacket
                && shouldCancelVelocityPacket(velocityPacket)) {
            event.setCancelled(true);
            resetVelocitySuppress();
        }
    }

    public boolean shouldCancelThornsDamage(Entity attacker) {
        if (!isEnabled() || mc.player == null || attacker == null) {
            return false;
        }

        if (attacker != mc.player && !attacker.getUuid().equals(mc.player.getUuid())) {
            return false;
        }

        if (isLocalPlayerElytraFlying()) {
            armVelocitySuppress();
        }
        return true;
    }

    public boolean shouldCancelVelocityPacket(EntityVelocityUpdateS2CPacket packet) {
        return isVelocitySuppressActive()
                && packet != null
                && mc.player != null
                && packet.getEntityId() == mc.player.getId();
    }

    public boolean isVelocitySuppressActive() {
        return suppressVelocityTicks > 0 && isLocalPlayerElytraFlying();
    }

    public void armVelocitySuppress() {
        suppressVelocityTicks = THORNS_VELOCITY_SUPPRESS_TICKS;
    }

    public void resetVelocitySuppress() {
        suppressVelocityTicks = 0;
    }

    public void tickSuppressTimer() {
        if (mc.player == null || !isLocalPlayerElytraFlying()) {
            resetVelocitySuppress();
            return;
        }

        if (suppressVelocityTicks > 0) {
            suppressVelocityTicks--;
        }
    }

    public int getSuppressVelocityTicks() {
        return suppressVelocityTicks;
    }

    private boolean isLocalPlayerElytraFlying() {
        LivingEntity player = mc.player;
        return player != null && player.isGliding();
    }

    @Override
    public void onEnable() {
        resetVelocitySuppress();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        resetVelocitySuppress();
        super.onDisable();
    }
}
