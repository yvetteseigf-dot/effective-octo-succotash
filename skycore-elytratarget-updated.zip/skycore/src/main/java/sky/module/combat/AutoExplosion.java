package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.rotation.RotationManager;
import sky.event.network.PacketSendEvent;
import sky.event.network.EntitySpawnEvent;
import sky.event.player.MotionPostEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.player.BlockPlaceEvent;
import sky.event.player.ItemUseEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.combat.AttackPacketUtil;
import sky.util.entity.EntityVectorUtil;
import sky.util.inventory.ItemSwapUtil;
import sky.util.combat.Rotation;

public final class AutoExplosion extends Module {
    public static final AutoExplosion INSTANCE = new AutoExplosion();

    private final BooleanSetting test;
    private final BooleanSetting fast;
    private final BooleanSetting noExplodeResources;

    private int pendingCrystalId;
    private boolean needSync;
    private int oldSlot;
    private BlockPos targetPos;
    private Vec3d pendingCrystalPos;
    private int explodeTicks;
    private int pkmCrystalSlot;
    private boolean blocked;
    private boolean pkmBlocked;
    private Box crystalArea;
    private int targetSlot;
    private int pendingCrystalTicks;
    private BlockPos pkmPlacePos;

    private AutoExplosion() {
        super("Auto Explosion", "Automatically explodes crystals within a 3-block radius", Category.COMBAT);
        this.pendingCrystalId = -1;
        this.pkmCrystalSlot = -1;
        this.test = new BooleanSetting("Explode on RMB", true);
        this.fast = new BooleanSetting("Fast", true);
        this.noExplodeResources = new BooleanSetting("Don't explode resources", false);
        addSettings(test, fast, noExplodeResources);
    }

    @Override
    public void onDisable() {
        clearExplosionState();
        targetPos = null;
        pkmPlacePos = null;
        pkmCrystalSlot = -1;
        pkmBlocked = false;
        super.onDisable();
    }

    @EventTarget
    private void onEvent(MotionPostEvent e) {
        if (needSync) {
            needSync = false;
            if (mc.player != null) {
                mc.player.getInventory().selectedSlot = oldSlot;
                ItemSwapUtil.syncCurrentPlayItem();
            }
        }
    }

    @EventTarget
    private void onClick(ItemUseEvent e) {
        if (proverkacrystala() || !test.get()) {
            return;
        }

        int crystalSlot = ItemSwapUtil.getItemSlot(Items.END_CRYSTAL);
        if (crystalSlot == -1) {
            return;
        }

        Item mainHandItem = mc.player.getMainHandStack().getItem();
        if (mainHandItem instanceof BlockItem && mainHandItem != Items.PLAYER_HEAD) {
            return;
        }
        Item offHandItem = mc.player.getOffHandStack().getItem();
        if (offHandItem instanceof BlockItem && offHandItem != Items.PLAYER_HEAD) {
            return;
        }

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof BlockHitResult blockHit)) {
            return;
        }

        BlockPos pos = blockHit.getBlockPos();
        if (!canPlaceCrystalOnObsidian(pos)) {
            return;
        }

        pkmPlacePos = pos;
        pkmCrystalSlot = crystalSlot;
        pkmBlocked = true;
        scheduleCrystalExplosion(pos);
        e.setCancelled(true);
    }

    @EventTarget
    public void onEvent(BlockPlaceEvent e) {
        if (proverkacrystala()) {
            return;
        }

        if (e.getBlock() == Blocks.OBSIDIAN && canPlaceCrystalOnObsidian(e.getPos())) {
            if (mc.player.getItemCooldownManager().isCoolingDown(Items.END_CRYSTAL.getDefaultStack())) {
                return;
            }

            int slot = ItemSwapUtil.getSlot(Items.END_CRYSTAL);
            if (slot == -1) {
                return;
            }

            if (slot < 9) {
                targetPos = e.getPos();
                targetSlot = slot;
                scheduleCrystalExplosion(e.getPos());
                blocked = true;
            }
        }
    }

    @EventTarget
    private void onEvent(PlayerUpdateEvent e) {
        if (!proverkacrystala()) {
            handlePkmPlace();
            handleObsidianPlace();
        }

        if (explodeTicks > 0) {
            explodeTicks--;
        }

        tryAttackPendingCrystal();
        if (crystalArea != null) {
            attackCrystalInArea();
        }
    }

    @EventTarget
    private void onSpawnEntity(EntitySpawnEvent event) {
        if (!fast.get() || crystalArea == null || mc.world == null) {
            return;
        }

        Entity spawned = event.getEntity();
        if (!(spawned instanceof EndCrystalEntity crystal)) {
            return;
        }

        if (!crystalArea.expand(0.5).contains(crystal.getX(), crystal.getY(), crystal.getZ())) {
            return;
        }

        if (shouldNotExplodeBecauseOfResources(crystal)) {
            clearExplosionState();
            return;
        }

        pendingCrystalId = crystal.getId();
        pendingCrystalPos = crystal.getPos();
        pendingCrystalTicks = 8;
        rotateToCrystal(crystal);
        attackCrystal(crystal);
        clearExplosionState();
    }

    @EventTarget
    private void onPacket(PacketSendEvent event) {
        if (!event.isReceive()) {
            return;
        }

        if (!(event.getPacket() instanceof EntitySpawnS2CPacket packet)) {
            return;
        }

        if (packet.getEntityType() != EntityType.END_CRYSTAL || crystalArea == null) {
            return;
        }

        double x = packet.getX();
        double y = packet.getY();
        double z = packet.getZ();
        if (!crystalArea.expand(0.5).contains(x, y, z)) {
            return;
        }

        if (fast.get() && mc.world != null) {
            pendingCrystalId = packet.getEntityId();
            pendingCrystalPos = new Vec3d(x, y, z);
            pendingCrystalTicks = 8;
            tryAttackPendingCrystal();

            Entity spawned = mc.world.getEntityById(packet.getEntityId());
            if (spawned instanceof EndCrystalEntity crystal && !shouldNotExplodeBecauseOfResources(crystal)) {
                rotateToCrystal(crystal);
                attackCrystal(crystal);
                clearExplosionState();
                return;
            }
        }

        explodeTicks = fast.get() ? 7 : 3;
        attackCrystalInArea();
    }

    private boolean proverkacrystala() {
        return CrystalSpam.Rabotaet;
    }

    private void clearExplosionState() {
        crystalArea = null;
        pendingCrystalId = -1;
        pendingCrystalPos = null;
        pendingCrystalTicks = 0;
    }

    private void scheduleCrystalExplosion(BlockPos obsidianPos) {
        BlockPos up = obsidianPos.up();
        crystalArea = new Box(up).expand(fast.get() ? 0.5 : 0.1);
        explodeTicks = fast.get() ? 7 : 5;
        pendingCrystalId = -1;
        pendingCrystalPos = new Vec3d(up.getX() + 0.5, up.getY() + 0.5, up.getZ() + 0.5);
        pendingCrystalTicks = fast.get() ? 8 : 6;
        attackCrystalInArea();
    }

    private boolean shouldNotExplodeBecauseOfResources(Entity crystalEntity) {
        if (!noExplodeResources.get() || mc.world == null) {
            return false;
        }

        return mc.world.getEntitiesByClass(ItemEntity.class, crystalEntity.getBoundingBox().expand(6.0), itemEntity -> true)
                .stream()
                .map(ItemEntity::getStack)
                .map(stack -> stack.getItem())
                .anyMatch(item -> item == Items.TOTEM_OF_UNDYING
                        || item == Items.END_CRYSTAL
                        || item == Items.ENCHANTED_GOLDEN_APPLE
                        || item == Items.NETHERITE_HELMET
                        || item == Items.NETHERITE_CHESTPLATE
                        || item == Items.NETHERITE_LEGGINGS
                        || item == Items.NETHERITE_BOOTS
                        || item == Items.NETHERITE_SWORD
                        || item == Items.DIAMOND_SWORD
                        || item == Items.ELYTRA
                        || item == Items.TRIDENT);
    }

    private void applyRotationToPoint(Vec3d target) {
        if (mc.player == null) {
            return;
        }

        Vec3d eyePos = mc.player.getEyePos();
        Vec3d delta = target.subtract(eyePos);
        float yaw = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, Math.hypot(delta.x, delta.z)));
        RotationManager.update(new Rotation(yaw, pitch), 180.0F, 1, 6);
    }

    private void attackCrystalInArea() {
        if (crystalArea == null || mc.player == null || mc.world == null) {
            return;
        }

        for (EndCrystalEntity crystal : mc.world.getEntitiesByClass(
                EndCrystalEntity.class, crystalArea.expand(0.25), entity -> true)) {
            if (shouldNotExplodeBecauseOfResources(crystal)) {
                continue;
            }

            rotateToCrystal(crystal);
            attackCrystal(crystal);
            clearExplosionState();
            return;
        }
    }

    private void tryAttackPendingCrystal() {
        if (pendingCrystalTicks <= 0 || mc.world == null) {
            return;
        }

        pendingCrystalTicks--;
        Entity entity = pendingCrystalId == -1 ? null : mc.world.getEntityById(pendingCrystalId);
        if (entity instanceof EndCrystalEntity crystal && !shouldNotExplodeBecauseOfResources(crystal)) {
            rotateToCrystal(crystal);
            attackCrystal(crystal);
            clearExplosionState();
            return;
        }

        if (pendingCrystalPos != null) {
            Box searchBox = new Box(
                    pendingCrystalPos.x - 0.8,
                    pendingCrystalPos.y - 0.8,
                    pendingCrystalPos.z - 0.8,
                    pendingCrystalPos.x + 0.8,
                    pendingCrystalPos.y + 1.8,
                    pendingCrystalPos.z + 0.8);
            for (EndCrystalEntity crystal : mc.world.getEntitiesByClass(
                    EndCrystalEntity.class, searchBox, pending -> true)) {
                if (shouldNotExplodeBecauseOfResources(crystal)) {
                    continue;
                }

                rotateToCrystal(crystal);
                attackCrystal(crystal);
                clearExplosionState();
                return;
            }
        }
    }

    private void attackCrystal(Entity entity) {
        if (entity == null || mc.player == null) {
            return;
        }

        AttackPacketUtil.sendFixedAttack(mc.player, entity);
    }

    private void rotateToObsidian(BlockPos obsidianPos) {
        Vec3d eyePos = mc.player.getEyePos();
        Vec3d closest = EntityVectorUtil.getClosestVec(eyePos, new Box(obsidianPos));
        applyRotationToPoint(closest);
    }

    private void placeCrystalOnObsidian(BlockPos obsidianPos, int crystalSlot, Hand hand) {
        rotateToObsidian(obsidianPos);
        oldSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = crystalSlot;
        ItemSwapUtil.syncCurrentPlayItem();

        Vec3d hitPos = new Vec3d(
                obsidianPos.getX() + 0.5,
                obsidianPos.getY() + 0.5,
                obsidianPos.getZ() + 0.5);
        mc.interactionManager.interactBlock(
                mc.player,
                hand,
                new BlockHitResult(hitPos, Direction.UP, obsidianPos, false));
        mc.player.swingHand(hand);
        scheduleCrystalExplosion(obsidianPos);
    }

    private void handleObsidianPlace() {
        if (targetPos == null) {
            return;
        }

        if (mc.world.getBlockState(targetPos).isAir()) {
            targetPos = null;
            return;
        }

        if (blocked) {
            blocked = false;
            return;
        }

        placeCrystalOnObsidian(targetPos, targetSlot, Hand.MAIN_HAND);
        needSync = true;
        targetPos = null;
    }

    private void rotateToCrystal(Entity entity) {
        if (entity == null || mc.player == null) {
            return;
        }

        if (entity.getBoundingBox().contains(mc.player.getEyePos())) {
            return;
        }

        Vec3d vector = EntityVectorUtil.getVector(entity);
        float yaw = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(vector.z, vector.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(vector.y, Math.hypot(vector.x, vector.z)));
        RotationManager.update(new Rotation(yaw, pitch), 180.0F, 1, 6);
    }

    private boolean canPlaceCrystalOnObsidian(BlockPos obsidianPos) {
        if (mc.world == null) {
            return false;
        }

        if (mc.world.getBlockState(obsidianPos).getBlock() != Blocks.OBSIDIAN) {
            return false;
        }

        BlockPos up = obsidianPos.up();
        BlockState above = mc.world.getBlockState(up);
        if (!above.isAir() && !above.isReplaceable()) {
            return false;
        }

        Box crystalBox = new Box(
                up.getX(),
                up.getY(),
                up.getZ(),
                up.getX() + 1.0,
                up.getY() + 2.0,
                up.getZ() + 1.0);
        return mc.world.getOtherEntities(null, crystalBox).isEmpty();
    }

    private void handlePkmPlace() {
        if (!test.get() || pkmPlacePos == null) {
            return;
        }

        if (!canPlaceCrystalOnObsidian(pkmPlacePos)) {
            pkmPlacePos = null;
            pkmCrystalSlot = -1;
            pkmBlocked = false;
            return;
        }

        if (pkmBlocked) {
            pkmBlocked = false;
            return;
        }

        if (pkmCrystalSlot == -1) {
            pkmPlacePos = null;
            return;
        }

        rotateToObsidian(pkmPlacePos);
        Vec3d hitPos = new Vec3d(
                pkmPlacePos.getX() + 0.5,
                pkmPlacePos.getY() + 0.5,
                pkmPlacePos.getZ() + 0.5);
        BlockHitResult hit = new BlockHitResult(hitPos, Direction.UP, pkmPlacePos, false);
        int slot = pkmCrystalSlot < 9 ? pkmCrystalSlot + 36 : pkmCrystalSlot;
        int syncId = mc.player.currentScreenHandler.syncId;
        mc.interactionManager.clickSlot(syncId, slot, 40, SlotActionType.SWAP, mc.player);
        mc.interactionManager.interactBlock(mc.player, Hand.OFF_HAND, hit);
        mc.interactionManager.clickSlot(syncId, slot, 40, SlotActionType.SWAP, mc.player);
        scheduleCrystalExplosion(pkmPlacePos);
        pkmPlacePos = null;
        pkmCrystalSlot = -1;
    }
}
