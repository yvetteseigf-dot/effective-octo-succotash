package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import sky.event.render.GameRendererEvent;
import sky.module.Category;
import sky.module.Module;

public final class NoEntityTrace extends Module {
    public static final NoEntityTrace INSTANCE = new NoEntityTrace();

    private NoEntityTrace() {
        super("NoEntityTrace", "Lets you break blocks and interact through players and mobs", Category.COMBAT);
    }

    @EventTarget
    public void onEntityRayTrace(GameRendererEvent event) {
        event.setCancelled(true);
    }
}
