package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.AmbientEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.FishEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import sky.SkyInit;
import sky.config.BooleanSetting;
import sky.rotation.DatasetRotation;
import sky.prediction.ElytraTargetPredictor;
import sky.camera.FreeLookCamera;
import sky.rotation.HolyWorldRotation;
import sky.rotation.LegitRotation;
import sky.config.ModeSetting;
import sky.misc.MovementBlocker;
import sky.config.MultiBooleanSetting;
import sky.config.NumberSetting;
import sky.rotation.RotationManager;
import sky.scheduler.ScriptTaskQueue;
import sky.rotation.SecondaryRotationManager;
import sky.rotation.SlothRotation;
import sky.rotation.SmoothAimController;
import sky.access.SwingTimerAccess;
import sky.scheduler.TpsTracker;
import sky.rotation.WellMineRotation;
import sky.rotation.WhiteRiseRotation;
import sky.event.player.MotionPostEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.player.RotationTickEvent;
import sky.event.input.StrafeInputEvent;
import sky.event.entity.LandingPredictEvent;
import sky.event.entity.PlayerEntityTickEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.movement.AirStuck;
import sky.module.movement.ElytraMotion;
import sky.module.movement.Speed;
import sky.module.movement.Sprint;
import sky.util.combat.CombatAiHelper;
import sky.util.elytra.ElytraPredictionUtil;
import sky.util.entity.EntityVectorUtil;
import sky.util.inventory.InventoryUtil;
import sky.util.entity.MovementFixUtil;
import sky.util.entity.MovementUtil;
import sky.util.MsTimer;
import sky.util.entity.PlayerUtil;
import sky.util.combat.RaycastUtil;
import sky.util.combat.Rotation;
import sky.util.combat.RotationUtil;

public final class AttackAura extends Module {
    private static final String TARGET_PLAYERS = "Players";
    private static final String TARGET_MOBS = "Mobs";
    private static final String TARGET_ANIMALS = "Animals";
    private static final String MODE_REALLY_WORLD = "ReallyWorld";
    private static final String MODE_HOLYWORLD = "Holyworld";
    private static final String MODE_BMW = "BMW";
    private static final String MODE_WHITERISE = "Whiterise";
    private static final String MODE_SLOTH = "Sloth";
    private static final String MODE_WHITE_RISE = "WhiteRise";
    private static final String MODE_WELLMINE = "WellMine";
    private static final String MODE_TEST = "Test";
    private static final String MODE_LEGIT = "Legit";
    private static final String MODE_DROID = "Droid";
    private static final String BEHAVIOR_SMOOTH = "Smooth";
    private static final String BEHAVIOR_SNAPS = "Snaps";
    private static final String CORRECTION_FREE = "Free";
    private static final String CORRECTION_FOCUSED = "Focused";
    private static final String CORRECTION_TARGET = "Target";

    public static final AttackAura INSTANCE;
    public static final BooleanSetting clientLook;
    public static LivingEntity target;
    public static Vec2f rotate;
    public static float adjYaw;
    public static float adjPitch;
    public static float otvodkaYaw;
    public static float otvodkaPitch;

    public final NumberSetting bmwHitboxExpand;
    public final BooleanSetting tpsSync;
    public final BooleanSetting smartCrits;
    public final BooleanSetting critsOnlyWithSpace;
    public final ModeSetting rotationMode;
    public final ModeSetting rotationBehavior;
    public final BooleanSetting onlyCriticals;
    public float lastYaw;
    public float lastPitch;

    private boolean canCrit;
    private int lastSlot;
    private float smoothLerpPitch;
    private final BooleanSetting raycastEnabled;
    private final BooleanSetting legitSwap;
    private ModeSetting.Value droid;
    private final BooleanSetting bypassWalls;
    private boolean hadTarget;
    private final ModeSetting.Value correctionTarget;
    private final HolyWorldRotation holyWorldRots;
    private final ModeSetting.Value correctionFree;
    private Vec2f lerpRotation;
    private final WellMineRotation wellMineRotation;
    private final ScriptTaskQueue.ScriptTask script;
    private final BooleanSetting shieldBreak;
    private boolean isBack;
    private final MsTimer attackTimer;
    private Vec3d speedTrackPos;
    private int legitSprintResetTicks;
    private final MultiBooleanSetting targetTypeSetting;
    private float lastYawDelta;
    private final SmoothAimController whiteriseRotation;
    private final SlothRotation slothRotation;
    private int ticksToAttack;
    private final WhiteRiseRotation whiteRiseRotation;
    private float acceleration;
    private final MsTimer hurtTimer;
    private Entity speedTrackEntity;
    private float smoothLerpYaw;
    private float visualYawOffset;
    private final ModeSetting correctionType;
    private final ModeSetting.Value correctionFocus;
    private float lastPitchDelta;
    private boolean isPostUpdateAttack;
    private final LegitRotation legitRotation;
    private Vec3d randomOffset;
    private final NumberSetting distance;
    private final DatasetRotation testRotation;
    private int lastRotateTick;
    private boolean isVisuallyTurnedBack;
    private final NumberSetting distanceRotation;
    private int rayTicks;

    static {
        INSTANCE = new AttackAura();
        clientLook = new BooleanSetting("First-person aim", false);
        rotate = Vec2f.ZERO;
    }

    private AttackAura() {
        super("AttackAura", "Automatically attacks the target", Category.COMBAT);
        this.targetTypeSetting = MultiBooleanSetting.create("Attack",
                List.of(TARGET_PLAYERS, TARGET_MOBS, TARGET_ANIMALS));
        this.rotationMode = new ModeSetting("Rotation", "");
        this.bmwHitboxExpand = new NumberSetting("BMW expand", 0.2F, 0.0F, 1.0F, 0.05F,
                () -> rotationMode.is(MODE_BMW));
        this.rotationBehavior = new ModeSetting("Rotation behavior", BEHAVIOR_SMOOTH,
                BEHAVIOR_SMOOTH, BEHAVIOR_SNAPS);
        this.onlyCriticals = new BooleanSetting("Only crits", false);
        this.smartCrits = new BooleanSetting("Smart crits", true);
        this.critsOnlyWithSpace = new BooleanSetting("Crits with space", false);
        this.tpsSync = new BooleanSetting("TPSSync", false);
        this.lastYawDelta = 0.0F;
        this.lastPitchDelta = 0.0F;
        this.randomOffset = Vec3d.ZERO;
        this.visualYawOffset = 0.0F;
        this.isVisuallyTurnedBack = false;
        this.isPostUpdateAttack = false;
        this.lastRotateTick = -1;
        this.lerpRotation = Vec2f.ZERO;
        this.whiteriseRotation = new SmoothAimController();
        this.wellMineRotation = new WellMineRotation();
        this.testRotation = new DatasetRotation();
        this.slothRotation = new SlothRotation();
        this.whiteRiseRotation = new WhiteRiseRotation(this);
        this.legitRotation = new LegitRotation();
        this.holyWorldRots = new HolyWorldRotation();
        new ModeSetting.Value(rotationMode, MODE_REALLY_WORLD).select();
        new ModeSetting.Value(rotationMode, MODE_HOLYWORLD);
        new ModeSetting.Value(rotationMode, MODE_BMW);
        new ModeSetting.Value(rotationMode, MODE_WHITERISE);
        new ModeSetting.Value(rotationMode, MODE_SLOTH);
        new ModeSetting.Value(rotationMode, MODE_WHITE_RISE);
        new ModeSetting.Value(rotationMode, MODE_WELLMINE);
        new ModeSetting.Value(rotationMode, MODE_TEST);
        new ModeSetting.Value(rotationMode, MODE_LEGIT);
        this.droid = new ModeSetting.Value(rotationMode, MODE_DROID);
        this.correctionType = new ModeSetting("Move correction", "");
        this.correctionFree = new ModeSetting.Value(correctionType, CORRECTION_FREE).select();
        this.correctionFocus = new ModeSetting.Value(correctionType, CORRECTION_FOCUSED);
        this.correctionTarget = new ModeSetting.Value(correctionType, CORRECTION_TARGET);
        this.distance = new NumberSetting("Distance", 3.0F, 0.5F, 6.0F, 0.1F);
        this.distanceRotation = new NumberSetting("Aim distance", 0.1F, 0.0F, 6.0F, 0.1F);
        this.shieldBreak = new BooleanSetting("Break shield", true);
        this.legitSwap = new BooleanSetting("Legit break", true, shieldBreak::isEnabled);
        this.raycastEnabled = new BooleanSetting("Raycast", true,
                () -> rotationMode.is(MODE_REALLY_WORLD) || rotationMode.is(MODE_HOLYWORLD));
        this.bypassWalls = new BooleanSetting("RW wall bypass", false,
                () -> rotationMode.is(MODE_REALLY_WORLD));
        target = null;
        this.hurtTimer = new MsTimer();
        this.attackTimer = new MsTimer();
        this.script = new ScriptTaskQueue.ScriptTask();
        this.lastSlot = -1;
        addSettings(targetTypeSetting, rotationMode, rotationBehavior, bmwHitboxExpand, correctionType,
                distance, distanceRotation, shieldBreak, legitSwap, raycastEnabled, bypassWalls,
                onlyCriticals, smartCrits, critsOnlyWithSpace, tpsSync, clientLook);
    }

    public LivingEntity getTarget() {
        return isEnabled() ? target : null;
    }

    public double getAttackReach() {
        return attackDistance();
    }

    public int getWhiteRiseTicksToAttack() {
        return ticksToAttack;
    }

    public float getVisualYawOffset() {
        return visualYawOffset;
    }

    public boolean isVisuallyTurnedBack() {
        return isVisuallyTurnedBack;
    }

    public float getVisualCameraYaw(float yaw) {
        return yaw + visualYawOffset;
    }

    public float getVisualCameraPitch(float pitch) {
        if (visualYawOffset > 90.0F) {
            return MathHelper.lerp((visualYawOffset - 90.0F) / 90.0F, pitch, -pitch);
        }
        return pitch;
    }

    public boolean appliesMovementCorrection() {
        return isEnabled() && target != null && mc.player != null;
    }

    public boolean isRotating() {
        return appliesMovementCorrection() && RotationManager.instance.isRotating();
    }

    public void releaseRotationControl() {
        if (mc.player == null) {
            return;
        }

        float freeYaw = FreeLookCamera.getFreeYaw();
        float freePitch = FreeLookCamera.getFreePitch();
        RotationManager.instance.stopRotation();
        SecondaryRotationManager.instance.stopRotation();
        FreeLookCamera.setActive(false);
        mc.player.setYaw(freeYaw);
        mc.player.setPitch(freePitch);
        mc.player.headYaw = freeYaw;
        mc.player.bodyYaw = freeYaw;
        FreeLookCamera.setFreeYaw(freeYaw);
        FreeLookCamera.setFreePitch(freePitch);
    }

    @Override
    public void onEnable() {
        target = null;
        hadTarget = false;
        isPostUpdateAttack = false;
        attackTimer.setMillis(System.currentTimeMillis() - 500L);
        if (mc.player != null) {
            lastYaw = mc.player.getYaw();
            lastPitch = mc.player.getPitch();
            smoothLerpYaw = lastYaw;
            smoothLerpPitch = lastPitch;
            lerpRotation = new Vec2f(lastYaw, lastPitch);
        }
        resetPineRotations();
        ticksToAttack = 0;
        resetHolyworldState();
        adjPitch = 0.0F;
        adjYaw = 0.0F;
        resetCombatState();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        acceleration = 0.0F;
        isPostUpdateAttack = false;
        rayTicks = 0;
        hadTarget = false;
        target = null;
        legitSprintResetTicks = 0;
        whiteriseRotation.reset();
        resetPineRotations();
        ticksToAttack = 0;
        resetHolyworldState();
        adjPitch = 0.0F;
        adjYaw = 0.0F;
        ElytraTargetPredictor.pos = Vec3d.ZERO;
        releaseRotationControl();
        resetCombatState();
        super.onDisable();
    }

    @EventTarget
    public void onRotationTick(RotationTickEvent event) {
        if (!shouldAimBeforeInput()) {
            return;
        }
        if (target == null) {
            target = isBMW() ? getBMWTarget() : updateTarget();
        }
        if (target == null) {
            return;
        }
        float savedYaw = lastYaw;
        float savedPitch = lastPitch;
        updateRotations();
        lastYaw = savedYaw;
        lastPitch = savedPitch;
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        if (shouldUsePostUpdate()) {
            return;
        }
        isPostUpdateAttack = false;
        handleAuraLogic();
        updateRotations();
        commitLastRotation();
    }

    @EventTarget
    public void onPostUpdate(MotionPostEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        if (!shouldUsePostUpdate()) {
            return;
        }
        isPostUpdateAttack = true;
        handleAuraLogic();
        updateRotations();
        commitLastRotation();
        isPostUpdateAttack = false;
    }

    private boolean shouldAimBeforeInput() {
        return isEnabled()
                && mc.player != null
                && mc.world != null
                && mc.player.isGliding();
    }

    private void commitLastRotation() {
        if (mc.player == null || mc.player.age != lastRotateTick) {
            return;
        }
        lastYaw = mc.player.getYaw();
        lastPitch = mc.player.getPitch();
    }

    @EventTarget
    public void onTickMovement(PlayerEntityTickEvent event) {
        if (mc.player == null || target == null || !target.isBlocking() || !hurtTimer.finished(50L)) {
            return;
        }
        if (!isPostUpdateAttack && mc.player.isSprinting() && !mc.player.isOnGround()
                && !mc.player.isSwimming()) {
            mc.player.setSprinting(false);
            mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player,
                    ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            if (!Sprint.INSTANCE.isEnabled()) {
                mc.options.sprintKey.setPressed(false);
            }
        }
        breakShieldAndAttack();
        hurtTimer.reset();
    }

    private void updateRotations() {
        if (target == null || mc.player == null) {
            return;
        }
        if (isBMW()) {
            return;
        }
        if (!isHolyworld() && rotationBehavior.is(BEHAVIOR_SNAPS)) {
            boolean ready = mc.player.getAttackCooldownProgress(1.0F) >= 0.95F && ticksToAttack <= 1;
            if (!ready) {
                return;
            }
        }
        if (mc.player.age == lastRotateTick) {
            return;
        }
        lastRotateTick = mc.player.age;
        if (isHolyworld()) {
            ElytraTargetPredictor.setVector(ElytraTargetPredictor.getVector3d(mc.player, target));
            holyWorldRots.updateRotations(target);
            rotate = holyWorldRots.rotate;
            return;
        }
        ElytraTargetPredictor.setVector(ElytraTargetPredictor.getVector3d(mc.player, target));
        if (rotationMode.is(MODE_DROID)) {
            handleDroidRotation(target);
            rotate = new Vec2f(mc.player.getYaw(), mc.player.getPitch());
            return;
        }
        if (isPineRotation()) {
            updatePineRotation();
        } else if (isWhiterise()) {
            updateWhiteriseRotation();
        } else {
            updateReallyWorldRotation();
        }
    }

    @EventTarget
    private void onWillLand(LandingPredictEvent event) {
        if (target == null) {
            canCrit = false;
            return;
        }
        if (AirStuck.INSTANCE.isEnabled()) {
            canCrit = true;
            return;
        }
        if (mc.player.fallDistance > 0.1F && event.isWillLand()) {
            canCrit = false;
        } else {
            canCrit = true;
        }
    }

    @EventTarget
    private void setCorrection(StrafeInputEvent event) {
        if (target == null || mc.player == null) {
            return;
        }
        if (RotationManager.instance.isRotating()
                || SecondaryRotationManager.instance.isRotating() && target != null) {
            if (isWhiterise() || correctionFocus.isSelected()) {
                Vec3d closest = EntityVectorUtil.getClosestVec(target);
                float yaw = MathHelper.wrapDegrees(
                        (float) (Math.toDegrees(Math.atan2(closest.z, closest.x)) - 90.0));
                MovementUtil.fixMovementFocus(event, yaw);
            } else if (correctionFree.isSelected()) {
                MovementUtil.fixMovementFree(event);
            } else if (correctionTarget.isSelected()) {
                Vec3d destination = target.getPos();
                if (Speed.INSTANCE.isEnabled() && getEntitySpeed(target) > 5.0) {
                    Vec3d look = Vec3d.fromPolar(0.0F, target.getYaw()).normalize();
                    destination = target.getPos().add(look.multiply(2.0));
                }
                if (!MovementBlocker.isStop()) {
                    MovementFixUtil.moveToPosition(event, destination, mc.player.getYaw());
                }
            }
        }
    }

    public double getEntitySpeed(Entity entity) {
        if (entity == null) {
            return 0.0;
        }
        Vec3d pos = entity.getPos();
        double speed = 0.0;
        if (entity == speedTrackEntity && speedTrackPos != null) {
            double dx = pos.x - speedTrackPos.x;
            double dz = pos.z - speedTrackPos.z;
            speed = Math.sqrt(dx * dx + dz * dz) * 20.0;
        }
        speedTrackEntity = entity;
        speedTrackPos = pos;
        return speed;
    }

    public boolean isValid(LivingEntity entity) {
        if (entity == null || entity == mc.player || !entity.isAlive() || entity.getHealth() <= 0.0F) {
            return false;
        }
        if (mc.player == null || !mc.player.isAlive() || mc.player.getHealth() <= 0.0F) {
            return false;
        }
        if (isWhiterise() && !(entity instanceof PlayerEntity)) {
            return false;
        }
        if (entity instanceof PlayerEntity) {
            if (!isWhiterise() && !targetTypeSetting.isEnable(TARGET_PLAYERS)) {
                return false;
            }
            if (SkyInit.getInstance().getFriendManager().isFriend(entity.getName().getString())) {
                return false;
            }
            if (AntiBot.isBot((PlayerEntity) entity)) {
                return false;
            }
        }
        if ((entity instanceof PassiveEntity || entity instanceof FishEntity)
                && (!targetTypeSetting.isEnable(TARGET_ANIMALS)
                || SkyInit.getInstance().getServerHandler().isPvp())) {
            return false;
        }
        if ((entity instanceof HostileEntity || entity instanceof AmbientEntity)
                && (!targetTypeSetting.isEnable(TARGET_MOBS)
                || SkyInit.getInstance().getServerHandler().isPvp())) {
            return false;
        }
        if (entity.age < 3) {
            return false;
        }
        if (EntityVectorUtil.getStrictDistance(entity) >= getMaxAimRange()) {
            return false;
        }
        return !(entity instanceof ArmorStandEntity);
    }

    private void handleAuraLogic() {
        if (mc.player == null || mc.world == null) {
            return;
        }
        if (isBMW()) {
            target = getBMWTarget();
        } else {
            target = updateTarget();
        }
        if (target != null) {
            if (ticksToAttack > 0) {
                ticksToAttack--;
            }
            hadTarget = true;
            ElytraTargetPredictor.updateTarget(target);
            ElytraTargetPredictor.smartPredict();
            ElytraTargetPredictor.processTargetLogic(ElytraTarget.INSTANCE);
            ElytraTargetPredictor.updateDefensiveState(target);
            if (AirStuck.INSTANCE.isEnabled()) {
                canCrit = true;
            }
            updateVisualReverseState();
            if (isWhiterise()) {
                updateWhiteriseRayTicks();
                boolean rayHit = RaycastUtil.rayTraceSingleEntity(
                        lastYaw, lastPitch, attackDistance(), target);
                boolean inRange = EntityVectorUtil.getStrictDistance(target) <= attackDistance();
                if (mc.player.isGliding()) {
                    if (rayHit || inRange) {
                        updateAttack();
                    }
                } else if (rayHit) {
                    updateAttack();
                } else if (inRange && rayTicks > 0) {
                    updateAttack();
                }
            } else if (isHolyworld()) {
                updateAttack();
            } else if (isReallyWorld()) {
                updateRaycastTicks();
                if (raycastEnabled.isEnabled()) {
                    if (mc.player.isGliding()) {
                        updateAttack();
                    } else if (rayTicks > 1) {
                        updateAttack();
                    } else if (bypassWalls.isEnabled() && isTargetBehindWall()) {
                        updateAttack();
                    }
                } else {
                    updateAttack();
                }
            } else {
                updateAttack();
            }
        } else if (hadTarget) {
            onTargetLost();
            hadTarget = false;
        }
    }

    private LivingEntity updateTarget() {
        if (mc.world == null || mc.player == null) {
            return null;
        }
        if (target != null && isValid(target)) {
            return target;
        }
        return findTarget();
    }

    private LivingEntity findTarget() {
        LivingEntity best = null;
        double bestDistance = Double.MAX_VALUE;
        boolean checkPlayers = isWhiterise() || targetTypeSetting.isEnable(TARGET_PLAYERS);
        if (checkPlayers) {
            for (PlayerEntity player : mc.world.getPlayers()) {
                if (player == mc.player || !isValid(player)) {
                    continue;
                }
                double distanceToPlayer = mc.player.distanceTo(player);
                if (distanceToPlayer < bestDistance) {
                    bestDistance = distanceToPlayer;
                    best = player;
                }
            }
        }
        if (isWhiterise()) {
            return best;
        }
        boolean checkOthers = targetTypeSetting.isEnable(TARGET_MOBS)
                || targetTypeSetting.isEnable(TARGET_ANIMALS);
        if (checkOthers) {
            float range = getMaxAimRange();
            Box searchBox = mc.player.getBoundingBox().expand(range);
            for (LivingEntity entity : mc.world.getEntitiesByClass(LivingEntity.class, searchBox,
                    candidate -> !(candidate instanceof PlayerEntity))) {
                if (!isValid(entity)) {
                    continue;
                }
                double distanceToEntity = mc.player.distanceTo(entity);
                if (distanceToEntity < bestDistance) {
                    bestDistance = distanceToEntity;
                    best = entity;
                }
            }
        }
        return best;
    }

    private LivingEntity getBMWTarget() {
        if (mc.player == null || mc.world == null) {
            return null;
        }
        double reach = distance.getCurrent();
        float expand = bmwHitboxExpand.getCurrent();
        Vec3d eyes = mc.player.getEyePos();
        Vec3d lookEnd = eyes.add(mc.player.getRotationVec(1.0F).multiply(reach));
        LivingEntity best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof LivingEntity living) || living == mc.player
                    || !living.isAlive() || living.isDead()) {
                continue;
            }
            boolean isPlayer = living instanceof PlayerEntity && living != mc.player;
            boolean isHostile = living instanceof HostileEntity;
            boolean isAnimal = (living instanceof PassiveEntity || living instanceof AmbientEntity)
                    && !(living instanceof HostileEntity);
            boolean matches = targetTypeSetting.isEnable(TARGET_PLAYERS) && isPlayer
                    || targetTypeSetting.isEnable(TARGET_MOBS) && isHostile
                    || targetTypeSetting.isEnable(TARGET_ANIMALS) && isAnimal;
            if (!matches) {
                continue;
            }
            Box box = living.getBoundingBox().expand(expand);
            Optional<Vec3d> hit = box.raycast(eyes, lookEnd);
            if (hit.isPresent()) {
                double hitDistance = eyes.distanceTo(hit.get());
                if (hitDistance <= reach && hitDistance < bestDistance) {
                    bestDistance = hitDistance;
                    best = living;
                }
            }
        }
        return best;
    }

    private void onTargetLost() {
        target = null;
        rayTicks = 0;
        legitSprintResetTicks = 0;
        whiteriseRotation.reset();
        holyWorldRots.reset();
        resetPineRotations();
        adjPitch = 0.0F;
        adjYaw = 0.0F;
        ticksToAttack = 0;
        releaseRotationControl();
        resetCombatState();
    }

    private void resetCombatState() {
        visualYawOffset = 0.0F;
        isVisuallyTurnedBack = false;
        canCrit = false;
        ElytraTargetPredictor.resetState();
    }

    private void resetPineRotations() {
        wellMineRotation.reset();
        testRotation.reset();
        slothRotation.reset();
        whiteRiseRotation.reset();
    }

    private void resetHolyworldState() {
        holyWorldRots.reset();
    }

    private void resetTargetRotationState() {
        if (mc.player == null) {
            return;
        }
        RotationManager.instance.stopRotation();
        SecondaryRotationManager.instance.stopRotation();
        FreeLookCamera.setActive(false);
    }

    private void updateVisualReverseState() {
        boolean reverse = ElytraTarget.INSTANCE != null && ElytraTarget.INSTANCE.isReverseActive();
        isVisuallyTurnedBack = reverse;
        visualYawOffset = reverse ? 180.0F : 0.0F;
    }

    private void updateAttack() {
        if (target == null) {
            return;
        }
        if (isWhiterise() && !canWhiteriseAttack()) {
            return;
        }
        if (!canAttack()) {
            return;
        }
        if (EntityVectorUtil.getStrictDistance(target) >= attackDistance()) {
            return;
        }
        boolean sprintingOnLand = mc.player.isSprinting()
                && !mc.player.isTouchingWater()
                && !mc.player.isInLava()
                && !mc.player.isSwimming();
        if (!isHolyworld() && !isPostUpdateAttack && sprintingOnLand) {
            if (Sprint.INSTANCE.isEnabled()) {
                legitSprintResetTicks = 1;
            }
            mc.player.setSprinting(false);
            if (mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player,
                        ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            }
            if (!Sprint.INSTANCE.isEnabled()) {
                mc.options.sprintKey.setPressed(false);
            }
        }
        if (bypassWalls.isEnabled() && !isBypassWallsBlockedByFluid()) {
            Vec3d from = mc.player.getEyePos();
            Vec3d to = target.getEyePos();
            Vec3d delta = to.subtract(from);
            double length = delta.length();
            if (length >= 0.001) {
                Vec3d direction = delta.normalize();
                for (double offset = 0.0; offset < length; offset += 0.5) {
                    Vec3d point = from.add(direction.multiply(offset));
                    BlockPos pos = BlockPos.ofFloored(point);
                    if (!mc.world.getBlockState(pos).isAir()) {
                        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                                PlayerActionC2SPacket.Action.START_DESTROY_BLOCK, pos, Direction.UP));
                        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                                PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, pos, Direction.UP));
                    }
                }
            }
        }
        attackTarget();
    }

    private void attackTarget() {
        if (target == null) {
            return;
        }
        if (target.isBlocking()) {
            return;
        }
        if (isWhiterise()) {
            unpressShield();
        }
        attackTimer.reset();
        if (isWhiterise()) {
            whiteriseRotation.onAttack();
        }
        if (rotationMode.is(MODE_WHITE_RISE)) {
            slothRotation.onAttack();
        }
        if (rotationMode.is(MODE_SLOTH)) {
            whiteRiseRotation.onAttack();
        }
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        if (isHolyworld()) {
            ticksToAttack = holyWorldRots.onAttack();
        } else {
            ticksToAttack = 10;
        }
        canCrit = false;
        hurtTimer.reset();
        if (target instanceof SwingTimerAccess access) {
            access.skycore$getLastSwing().reset();
        }
    }

    private void unpressShield() {
        if (mc.player != null && mc.player.isBlocking()) {
            mc.interactionManager.stopUsingItem(mc.player);
        }
    }

    private void breakShieldAndAttack() {
        boolean swappedHotbar = false;
        boolean swappedInventory = false;
        List<Item> axes = List.of(
                Items.WOODEN_AXE, Items.STONE_AXE, Items.IRON_AXE,
                Items.GOLDEN_AXE, Items.DIAMOND_AXE, Items.NETHERITE_AXE);
        int hotbarSlot = InventoryUtil.find(axes, 0, 8);
        int inventorySlot = InventoryUtil.find(axes, 8, 35);
        if (hotbarSlot != -1 && whiteriseShieldBreak() && target.isBlocking()) {
            if (whiteriseLegitSwap()) {
                lastSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = hotbarSlot;
            } else {
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(hotbarSlot));
            }
            swappedHotbar = true;
        }
        if (hotbarSlot == -1 && inventorySlot != -1 && whiteriseShieldBreak() && target.isBlocking()) {
            if (whiteriseLegitSwap()) {
                mc.interactionManager.clickSlot(0, inventorySlot, 8, SlotActionType.SWAP, mc.player);
                mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
                lastSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = 8;
            } else {
                mc.interactionManager.clickSlot(0, inventorySlot, 8, SlotActionType.SWAP, mc.player);
                mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(hotbarSlot));
            }
            swappedInventory = true;
        }
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        if (swappedHotbar) {
            if (whiteriseLegitSwap()) {
                SkyInit.getInstance().getScriptManager().addTask(script);
                script.schedule(PlayerUpdateEvent.class, ignored -> {
                    mc.player.getInventory().selectedSlot = lastSlot;
                    lastSlot = -1;
                    return true;
                });
            } else {
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(
                        mc.player.getInventory().selectedSlot));
            }
        }
        if (swappedInventory) {
            if (whiteriseLegitSwap()) {
                SkyInit.getInstance().getScriptManager().addTask(script);
                script.schedule(PlayerUpdateEvent.class, ignored -> {
                    mc.player.getInventory().selectedSlot = lastSlot;
                    mc.interactionManager.clickSlot(0, inventorySlot, 8, SlotActionType.SWAP, mc.player);
                    mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
                    lastSlot = -1;
                    return true;
                });
            } else {
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(
                        mc.player.getInventory().selectedSlot));
                mc.interactionManager.clickSlot(0, inventorySlot, 8, SlotActionType.SWAP, mc.player);
                mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
            }
        }
    }

    private boolean canAttack() {
        if (mc.player == null || target == null) {
            return false;
        }
        if (isHolyworld()) {
            if (ticksToAttack > 0) {
                return false;
            }
            if (mc.currentScreen != null) {
                return false;
            }
            if (!CombatAiHelper.cooldownIsReached(false)) {
                return false;
            }
            Vec3d eyes = mc.player.getEyePos();
            Vec3d aim = target.getPos().add(0.0, target.getHeight() * 0.5, 0.0);
            BlockHitResult hit = mc.world.raycast(new RaycastContext(eyes, aim,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
            if (hit.getType() != HitResult.Type.MISS) {
                return false;
            }
            if (raycastEnabled.isEnabled()
                    && !RaycastUtil.rayTrace(mc.player.getRotationVector(), attackDistance(),
                    target.getBoundingBox())) {
                return false;
            }
            if (EntityVectorUtil.getStrictDistance(target) > attackDistance() - 0.2F) {
                return false;
            }
            return passesCriticalGate();
        }
        boolean ready = attackTimer.finished(450L)
                && mc.player.getAttackCooldownProgress(
                whiteriseTpsSync() ? TpsTracker.getAdjustTicks() : 1.5F) > CombatAiHelper.getAICooldown();
        if (!ready) {
            return false;
        }
        return passesCriticalGate();
    }

    private boolean passesCriticalGate() {
        if (AirStuck.INSTANCE.isEnabled()) {
            return true;
        }
        if (mc.player.isGliding() || !isValidAttackCondition()) {
            return true;
        }
        boolean onlyCrits = whiteriseOnlyCriticals();
        if (onlyCrits) {
            if (whiteriseCritsOnlyWithSpace()) {
                return mc.options.jumpKey.isPressed() || !mc.player.isOnGround();
            }
            return canPlayerCritical();
        }
        return smartCrits.isEnabled() || !onlyCrits;
    }

    private boolean canWhiteriseAttack() {
        if (mc.player == null || target == null) {
            return false;
        }
        if (mc.player.isUsingItem() && !mc.player.isBlocking()) {
            return false;
        }
        return mc.player.canSee(target);
    }

    private boolean canPlayerCritical() {
        if (mc.player == null) {
            return false;
        }
        return !mc.player.hasStatusEffect(StatusEffects.LEVITATION)
                && !mc.player.hasStatusEffect(StatusEffects.BLINDNESS)
                && !mc.player.isSubmergedIn(FluidTags.WATER)
                && !mc.player.isSubmergedIn(FluidTags.LAVA)
                && !mc.player.getAbilities().flying
                && !mc.player.isGliding()
                && !mc.player.isClimbing()
                && !mc.player.hasVehicle()
                && mc.player.fallDistance > 0.0F
                && !mc.player.isOnGround();
    }

    private boolean isValidAttackCondition() {
        if (mc.player == null) {
            return false;
        }
        return !mc.player.hasStatusEffect(StatusEffects.LEVITATION)
                && !mc.player.hasStatusEffect(StatusEffects.BLINDNESS)
                && !mc.player.isSubmergedIn(FluidTags.WATER)
                && !mc.player.isSubmergedIn(FluidTags.LAVA)
                && !isPlayerInWeb()
                && !mc.player.getAbilities().flying
                && !mc.player.isGliding()
                && !mc.player.isClimbing()
                && !mc.player.hasVehicle();
    }

    private boolean canGrimSnap() {
        return attackTimer.finished(450L)
                && mc.player.getAttackCooldownProgress(0.5F) >= 0.93F;
    }

    private double attackDistance() {
        float airStuck = AirStuck.INSTANCE.getKillAuraDistance();
        if (airStuck > 0.0F) {
            return airStuck;
        }
        if (isWhiterise()) {
            return 3.1F;
        }
        return Math.max(3.0, distance.getCurrent());
    }

    private float getMaxAimRange() {
        if (isWhiterise()) {
            return 4.6F;
        }
        float attackRange = distance.getCurrent();
        float aimRange = distanceRotation.getCurrent();
        float pursuit = ElytraTarget.INSTANCE.isEnabled()
                ? ElytraTarget.pursuitdistance.getCurrent() : 0.0F;
        if (mc.player != null && mc.player.isGliding()) {
            return attackRange + pursuit;
        }
        return attackRange + aimRange;
    }

    private void updateRaycastTicks() {
        if (!isReallyWorld() || !raycastEnabled.isEnabled() || target == null || mc.player == null) {
            rayTicks = 0;
            return;
        }
        if (mc.player.isGliding()) {
            return;
        }
        if (RaycastUtil.rayTraceSingleEntity(
                lastYaw, lastPitch, attackDistance(), target)) {
            rayTicks++;
        } else {
            rayTicks = 0;
        }
    }

    private void updateWhiteriseRayTicks() {
        if (!isWhiterise() || target == null || mc.player == null) {
            return;
        }
        if (mc.player.isGliding()) {
            return;
        }
        if (RaycastUtil.rayTraceSingleEntity(
                lastYaw, lastPitch, attackDistance(), target)) {
            rayTicks++;
        } else {
            rayTicks = 0;
        }
    }

    private boolean isTargetBehindWall() {
        if (target == null || mc.player == null) {
            return false;
        }
        return !mc.player.canSee(target);
    }

    private boolean isBypassWallsBlockedByFluid() {
        if (mc.player.isTouchingWater() || mc.player.isInLava()
                || mc.player.isSubmergedIn(FluidTags.WATER)
                || mc.player.isSubmergedIn(FluidTags.LAVA)) {
            return true;
        }
        if (target.isTouchingWater() || target.isInLava()
                || target.isSubmergedIn(FluidTags.WATER)
                || target.isSubmergedIn(FluidTags.LAVA)) {
            return true;
        }
        Vec3d from = mc.player.getEyePos();
        Vec3d to = target.getEyePos();
        Vec3d delta = to.subtract(from);
        double length = delta.length();
        if (length < 0.001) {
            return false;
        }
        Vec3d direction = delta.normalize();
        for (double offset = 0.0; offset < length; offset += 0.5) {
            BlockPos pos = BlockPos.ofFloored(from.add(direction.multiply(offset)));
            FluidState fluid = mc.world.getFluidState(pos);
            if (fluid.isIn(FluidTags.WATER) || fluid.isIn(FluidTags.LAVA)) {
                return true;
            }
        }
        return false;
    }

    private boolean isEntityInCobweb(LivingEntity entity) {
        if (entity == null || mc.world == null) {
            return false;
        }
        for (double dx = -0.31; dx <= 0.31; dx += 0.31) {
            for (double dz = -0.31; dz <= 0.31; dz += 0.31) {
                for (double dy = 0.0; dy <= entity.getStandingEyeHeight(); dy += 0.5) {
                    BlockPos pos = BlockPos.ofFloored(entity.getX() + dx, entity.getY() + dy, entity.getZ() + dz);
                    if (mc.world.getBlockState(pos).isOf(Blocks.COBWEB)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean isPlayerInWeb() {
        return PlayerUtil.isPlayerInWeb();
    }

    private boolean shouldUsePostUpdate() {
        return false;
    }

    private boolean shouldUseSharpRotation() {
        return bypassWalls.isEnabled() && isTargetBehindWall();
    }

    private void updateWhiteriseRotation() {
        if (target == null || mc.player == null) {
            return;
        }
        boolean attackReady = canAttack()
                && EntityVectorUtil.getStrictDistance(target) < attackDistance();
        whiteriseRotation.update(target, attackReady);
        rotate = new Vec2f(mc.player.getYaw(), mc.player.getPitch());
    }

    private void updatePineRotation() {
        if (target == null || mc.player == null) {
            return;
        }
        if (rotationMode.is(MODE_WELLMINE)) {
            wellMineRotation.updateRotations(target);
            rotate = new Vec2f(mc.player.getYaw(), mc.player.getPitch());
            return;
        }
        if (rotationMode.is(MODE_TEST)) {
            testRotation.updateRotations(target);
            rotate = new Vec2f(mc.player.getYaw(), mc.player.getPitch());
            return;
        }
        if (rotationMode.is(MODE_SLOTH)) {
            whiteRiseRotation.updateRotations(target);
            rotate = whiteRiseRotation.rotate;
            return;
        }
        if (rotationMode.is(MODE_WHITE_RISE)) {
            Vec3d point = getPredictedRotationPoint(target, target.getLeashPos(1.0F));
            Vec2f rotations = RotationUtil.getRotations(point);
            RotationManager.update(new Rotation(rotations.x, rotations.y),
                    360.0F, 360.0F, 360.0F, 360.0F, 1, 1, clientLook.isEnabled());
            rotate = new Vec2f(mc.player.getYaw(), mc.player.getPitch());
            return;
        }
        if (rotationMode.is(MODE_LEGIT)) {
            legitRotation.updateRotations(target);
            rotate = new Vec2f(mc.player.getYaw(), mc.player.getPitch());
        }
    }

    private void updateReallyWorldRotation() {
        if (target == null || mc.player == null) {
            return;
        }
        double distanceRatio = EntityVectorUtil.getStrictDistance(target) / attackDistance();
        Vec3d direction = target.getPos()
                .add(0.0, MathHelper.clamp(mc.player.getEyePos().y - target.getY(), 0.0, distanceRatio), 0.0)
                .subtract(mc.player.getEyePos())
                .normalize();
        float yaw = (float) Math.toDegrees(Math.atan2(-direction.x, direction.z));
        float pitch = (float) MathHelper.clamp(
                -Math.toDegrees(Math.atan2(direction.y, Math.hypot(direction.x, direction.z))),
                -90.0, 90.0);
        float speed = new SecureRandom().nextBoolean()
                ? randomLerp(0.65F, 0.75F) : randomLerp(0.8F, 0.9F);
        float yawJitter = (float) Math.ceil(randomLerp(1.0F, 3.0F)
                * (float) Math.cos(System.currentTimeMillis() / 70.0));
        float pitchJitter = (float) Math.ceil(randomLerp(1.0F, 2.0F)
                * (float) Math.sin(System.currentTimeMillis() / 115.0));
        lerpRotation = new Vec2f(
                wrapLerp(speed, lerpRotation.x, yaw + yawJitter),
                wrapLerp(speed * 0.8F, lerpRotation.y,
                        MathHelper.clamp(pitch + pitchJitter, -90.0F, 90.0F)));
        if (mc.player.isGliding()) {
            ElytraTargetPredictor.updateRotation(new Vec2f(mc.player.getYaw(), mc.player.getPitch()));
        } else {
            grimSmooth(EntityVectorUtil.getClosestVec(target));
        }
        rotate = new Vec2f(lerpRotation.x, lerpRotation.y);
    }

    private void reallyWorldFastRotation() {
        if (target == null || mc.player == null || mc.world == null) {
            return;
        }
        float yaw = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        float yawDelta = MathHelper.wrapDegrees(lerpRotation.x - yaw);
        float pitchDelta = MathHelper.wrapDegrees(lerpRotation.y - pitch);
        RotationManager.update(new Rotation(yaw + yawDelta, pitch + pitchDelta), 180.0F, 180.0F, 0, 5);
    }

    private void grimSmooth(Vec3d vector) {
        if (target == null || mc.player == null || mc.world == null) {
            return;
        }
        float yaw = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(vector.z, vector.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(vector.y, Math.hypot(vector.x, vector.z)));
        if (shouldUseSharpRotation()) {
            RotationManager.update(new Rotation(yaw, pitch), 255.0F, 1.0F, 6, 1);
            return;
        }
        float nextYaw;
        float nextPitch;
        if (canGrimSnap() && vector.length() <= distance.getCurrent()) {
            nextYaw = yaw;
            nextPitch = pitch;
        } else {
            nextYaw = FreeLookCamera.getFreeYaw();
            nextPitch = FreeLookCamera.getFreePitch();
        }
        RotationManager.update(new Rotation(nextYaw, nextPitch), 255.0F, 1.0F, 6, 1);
    }

    private void fastSmoothRotation() {
        if (mc.player == null) {
            return;
        }
        float yaw = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        float yawDelta = MathHelper.wrapDegrees(smoothLerpYaw - yaw);
        float pitchDelta = MathHelper.wrapDegrees(smoothLerpPitch - pitch);
        Rotation rotation = new Rotation(yaw + yawDelta, pitch + pitchDelta);
        lastYaw = rotation.getYaw();
        lastPitch = rotation.getPitch();
        RotationManager.update(rotation, 180.0F, 180.0F, 0, 5);
    }

    private void applyDirectRotation(Rotation rotation) {
        if (rotation == null) {
            return;
        }
        Rotation clamped = new Rotation(rotation.getYaw(),
                MathHelper.clamp(rotation.getPitch(), -90.0F, 90.0F));
        RotationManager.update(clamped, 360.0F, 360.0F, 360.0F, 360.0F, 0, 1, false);
    }

    private Vec3d getPredictedRotationPoint(LivingEntity entity, Vec3d fallback) {
        if (mc.player != null && entity != null
                && mc.player.isGliding() && entity.isGliding()
                && ElytraTarget.INSTANCE != null
                && ElytraTarget.INSTANCE.isEnabled()
                && ElytraTarget.INSTANCE.target.isEnabled()) {
            return ElytraPredictionUtil.bypasselytrahacking(entity);
        }
        return fallback;
    }

    private void handleDroidRotation(LivingEntity entity) {
        if (entity == null) {
            return;
        }
        Vec3d aim = entity.getBoundingBox().getCenter().add(randomOffset);
        Vec3d eyes = mc.player.getEyePos();
        double dx = aim.x - eyes.x;
        double dy = aim.y - eyes.y;
        double dz = aim.z - eyes.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        float yawDelta = MathHelper.wrapDegrees(yaw - lastYaw);
        float pitchDelta = pitch - lastPitch;
        float wave = (float) (Math.sin(System.currentTimeMillis() / 150.0) * 2.0);
        yawDelta += wave * 0.1F;
        pitchDelta += wave * 0.05F;
        float limit = MathHelper.clamp(Math.max(Math.abs(yawDelta), Math.abs(pitchDelta)), 5.0F, 60.0F);
        limit *= (float) (0.6F + Math.random() * 0.3);
        float smoothedYaw = MathHelper.clamp(lastYawDelta * 0.6F + yawDelta * 0.4F, -limit, limit);
        float smoothedPitch = MathHelper.clamp(lastPitchDelta * 0.6F + pitchDelta * 0.4F, -limit, limit);
        float nextYaw = Rotation.applyGCD(lastYaw + smoothedYaw, lastYaw);
        float nextPitch = Rotation.applyGCD(
                MathHelper.clamp(lastPitch + smoothedPitch, -90.0F, 90.0F), lastPitch);
        lastYawDelta = smoothedYaw;
        lastPitchDelta = smoothedPitch;
        Rotation rotation = new Rotation(nextYaw, nextPitch);
        applyDirectRotation(rotation);
        lastYaw = nextYaw;
        lastPitch = nextPitch;
    }

    private void handleSmoothRotation(LivingEntity entity, Rotation rotation, boolean snap) {
        if (entity == null || mc.player == null || rotation == null) {
            return;
        }
        if (snap || mc.player.isGliding()) {
            applyDirectRotation(rotation);
            return;
        }
        float speed = new SecureRandom().nextBoolean()
                ? randomLerp(0.3F, 0.4F) : randomLerp(0.5F, 0.6F);
        float yawJitter = (float) Math.ceil(randomLerp(1.0F, 3.0F)
                * (float) Math.cos(System.currentTimeMillis() / 70.0));
        float pitchJitter = (float) Math.ceil(randomLerp(1.0F, 2.0F)
                * (float) Math.sin(System.currentTimeMillis() / 115.0));
        smoothLerpYaw = wrapLerp(speed, smoothLerpYaw, rotation.getYaw() + yawJitter);
        smoothLerpPitch = wrapLerp(speed / 2.0F, smoothLerpPitch,
                MathHelper.clamp(rotation.getPitch() + pitchJitter, -90.0F, 90.0F));
        fastSmoothRotation();
    }

    private void handleWellMineRotation(float yawDelta, float pitchDelta, Rotation rotation, boolean unused) {
        boolean onTarget = RaycastUtil.rayTrace(mc.player.getRotationVector(), 999.0,
                target.getBoundingBox());
        if (isBack) {
            float yawDistance = Math.abs(MathHelper.wrapDegrees(rotation.getYaw() - lastYaw));
            float step = yawDistance > 70.0F ? 0.03F : yawDistance > 40.0F ? 0.015F : 0.004F;
            acceleration -= step;
            if (acceleration <= -0.005F) {
                isBack = false;
            }
        } else {
            acceleration += 0.0015F;
            if (acceleration >= 0.1F || onTarget) {
                isBack = true;
            }
        }
        float speed = Math.max(acceleration, 0.02F);
        float nextYaw = lastYaw + yawDelta * speed;
        float nextPitch = lastPitch + pitchDelta * speed * 0.8F;
        nextYaw -= (nextYaw - lastYaw) % Rotation.gcd();
        nextPitch -= (nextPitch - lastPitch) % Rotation.gcd();
        Rotation next = new Rotation(nextYaw, nextPitch);
        applyDirectRotation(next);
        lastYaw = nextYaw;
        lastPitch = nextPitch;
    }

    private void handleLegendsGriefRotation(float yawDelta, float pitchDelta, Rotation rotation, boolean unused) {
        Box box = target.getBoundingBox();
        boolean onTarget = RaycastUtil.rayTrace(mc.player.getRotationVector(), 999.0, box);
        if (mc.player.isGliding() && target.isGliding()) {
            if (isBack) {
                if (acceleration >= -0.02F) {
                    acceleration -= Math.abs(MathHelper.wrapDegrees(rotation.getYaw() - lastYaw)) > 80.0F
                            ? 0.1F : 0.01F;
                }
                if (acceleration <= -0.02F) {
                    isBack = false;
                }
            } else {
                acceleration += 0.004F;
                if (acceleration >= 0.17F || onTarget) {
                    isBack = true;
                }
            }
        } else if (isBack) {
            if (acceleration >= -0.01F) {
                acceleration -= Math.abs(MathHelper.wrapDegrees(rotation.getYaw() - lastYaw)) > 80.0F
                        ? 0.1F : 0.01F;
            }
            if (acceleration <= -0.01F) {
                isBack = false;
            }
        } else {
            acceleration += 0.004F;
            if (acceleration >= 0.18F || onTarget) {
                isBack = true;
            }
        }
        float speed = Math.max(acceleration, 0.0F);
        float nextYaw = lastYaw + yawDelta * Math.min(speed, 1.0F);
        float nextPitch = lastPitch + pitchDelta * Math.min(speed / 2.0F, 1.0F);
        nextYaw -= (nextYaw - lastYaw) % Rotation.gcd();
        nextPitch -= (nextPitch - lastPitch) % Rotation.gcd();
        Rotation next = new Rotation(nextYaw, nextPitch);
        applyDirectRotation(next);
        lastYaw = next.getYaw();
        lastPitch = next.getPitch();
    }

    private void handleLonyGriefRotation(float yawDelta, float pitchDelta, Rotation rotation) {
        if (mc.player.isGliding()) {
            if (!isBack) {
                acceleration += 0.005F;
                if (acceleration >= 0.13F) {
                    isBack = true;
                }
            } else {
                if (acceleration >= -0.02F) {
                    acceleration -= 0.005F;
                }
                if (acceleration <= -0.02F) {
                    isBack = false;
                }
            }
        } else if (!RaycastUtil.rayTrace(mc.player.getRotationVector(), 1488.0, target.getBoundingBox())) {
            acceleration += 0.0015F;
        } else if (acceleration > 0.0F) {
            acceleration -= 0.01F;
        }
        float speed = Math.max(acceleration, 0.0F);
        float nextYaw = lastYaw + yawDelta * Math.min(speed * 0.9F, 1.0F);
        float nextPitch = lastPitch + pitchDelta * Math.min(speed * 0.9F / 2.0F, 1.0F);
        nextYaw += (float) (Math.random() * 15.0 - 10.0);
        nextPitch += (float) (Math.random() * 15.0 - 10.0);
        nextYaw -= (nextYaw - lastYaw) % Rotation.gcd();
        nextPitch -= (nextPitch - lastPitch) % Rotation.gcd();
        Rotation next = new Rotation(nextYaw, nextPitch);
        applyDirectRotation(next);
        lastYaw = next.getYaw();
        lastPitch = next.getPitch();
    }

    private void handleLonyBypassRotation(float yawDelta, float pitchDelta, Rotation rotation) {
        Box box = target.getBoundingBox();
        if (mc.player.isGliding() && target.isGliding()) {
            if (isBack) {
                if (acceleration >= -0.02F) {
                    acceleration -= Math.abs(MathHelper.wrapDegrees(rotation.getYaw() - lastYaw)) > 80.0F
                            ? 0.1F : 0.01F;
                }
                if (acceleration <= -0.02F) {
                    isBack = false;
                }
            } else {
                acceleration += 0.004F;
                if (acceleration >= 0.17F
                        || RaycastUtil.rayTrace(mc.player.getRotationVector(), 1488.0, box)) {
                    isBack = true;
                }
            }
        } else if (isBack) {
            if (acceleration >= -0.01F) {
                acceleration -= Math.abs(MathHelper.wrapDegrees(rotation.getYaw() - lastYaw)) > 80.0F
                        ? 0.1F : 0.01F;
            }
            if (acceleration <= -0.01F) {
                isBack = false;
            }
        } else {
            acceleration += 0.004F;
            if (acceleration >= 0.18F
                    || RaycastUtil.rayTrace(mc.player.getRotationVector(), 999.0, box.expand(-0.5))) {
                isBack = true;
            }
        }
        float speed = Math.max(acceleration, 0.0F);
        float nextYaw = lastYaw + yawDelta * Math.min(speed, 1.0F);
        float nextPitch = lastPitch + pitchDelta * Math.min(speed / 2.0F, 1.0F);
        nextYaw -= (nextYaw - lastYaw) % Rotation.gcd();
        nextPitch -= (nextPitch - lastPitch) % Rotation.gcd();
        Rotation next = new Rotation(nextYaw, nextPitch);
        applyDirectRotation(next);
        lastYaw = next.getYaw();
        lastPitch = next.getPitch();
    }

    private void handleBotinokBypassRotation(Rotation unused, Vec3d eyes) {
        Box box = target.getBoundingBox();
        if (ElytraTargetPredictor.blockPos && !ElytraTarget.INSTANCE.isTestPredict()) {
            Vec3d predicted = ElytraTarget.INSTANCE.isSmartPredict()
                    ? target.getPos().add(ElytraTargetPredictor.smartOffset)
                    : ElytraTargetPredictor.pos.add(
                            target.getRotationVec(1.0F).normalize().multiply(2.0));
            box = target.getBoundingBox().offset(predicted.subtract(target.getPos()));
        }
        Box shrunk = box.expand(-0.15);
        Vec3d look = mc.player.getRotationVector();
        double distanceToCenter = eyes.distanceTo(box.getCenter());
        Vec3d rayEnd = eyes.add(look.multiply(distanceToCenter));
        Vec3d clamped = new Vec3d(
                MathHelper.clamp(rayEnd.x, shrunk.minX, shrunk.maxX),
                MathHelper.clamp(rayEnd.y, shrunk.minY, shrunk.maxY),
                MathHelper.clamp(rayEnd.z, shrunk.minZ, shrunk.maxZ));
        Rotation aim = RotationUtil.fromVec3d(clamped.subtract(eyes));
        float yawDelta = MathHelper.wrapDegrees(aim.getYaw() - lastYaw);
        float pitchDelta = aim.getPitch() - lastPitch;
        float speed = (mc.player.isGliding() ? 0.5F : 0.4F) + (float) Math.random() * 0.3F;
        float nextYaw = lastYaw + yawDelta * speed;
        float nextPitch = lastPitch + pitchDelta * speed;
        long now = System.currentTimeMillis();
        nextYaw += (float) (Math.sin(now / 50.0) * 0.8);
        nextPitch += (float) (Math.cos(now / 65.0) * 0.6);
        nextPitch = MathHelper.clamp(nextPitch, -80.0F, 89.9F);
        float gcd = Rotation.gcd();
        nextYaw -= (nextYaw - lastYaw) % gcd;
        nextPitch -= (nextPitch - lastPitch) % gcd;
        Rotation next = new Rotation(nextYaw, nextPitch);
        applyDirectRotation(next);
        lastYaw = next.getYaw();
        lastPitch = next.getPitch();
    }

    private void handleTestRotation(LivingEntity entity) {
        Vec3d eyes = mc.player.getEyePos();
        Vec3d look = mc.player.getRotationVec(1.0F);
        boolean predict = ElytraTargetPredictor.blockPos && !ElytraTarget.INSTANCE.isTestPredict();
        if (entity instanceof PlayerEntity && mc.player.isGliding() && entity.isGliding() && predict) {
            Vec3d predicted = ElytraTarget.INSTANCE.isSmartPredict()
                    ? entity.getPos().add(ElytraTargetPredictor.smartOffset)
                    : ElytraTargetPredictor.pos.add(
                            entity.getRotationVec(1.0F).normalize().multiply(2.0));
            Vec3d aim = predicted.add(0.0, entity.getEyeHeight(entity.getPose()) * 0.9, 0.0);
            Box box = entity.getBoundingBox()
                    .offset(predicted.subtract(entity.getPos()))
                    .expand(-0.05);
            double distanceToAim = eyes.distanceTo(aim);
            Vec3d rayEnd = eyes.add(look.multiply(distanceToAim));
            Vec3d clamped = new Vec3d(
                    MathHelper.clamp(rayEnd.x, box.minX, box.maxX),
                    MathHelper.clamp(rayEnd.y, box.minY, box.maxY),
                    MathHelper.clamp(rayEnd.z, box.minZ, box.maxZ));
            Rotation rotation = RotationUtil.fromVec3d(clamped.subtract(eyes));
            float yawDelta = MathHelper.wrapDegrees(rotation.getYaw() - lastYaw);
            float pitchDelta = rotation.getPitch() - lastPitch;
            float speed = mc.player.isGliding() ? 0.6F : 0.2F;
            if (ElytraMotion.INSTANCE.isEnabled()) {
                speed += 0.3F;
            }
            float nextYaw = lastYaw + MathHelper.clamp(yawDelta * speed, -80.0F, 80.0F);
            float nextPitch = MathHelper.clamp(
                    lastPitch + MathHelper.clamp(pitchDelta * speed, -60.0F, 60.0F), -90.0F, 90.0F);
            nextYaw = Rotation.applyGCD(nextYaw, lastYaw);
            nextPitch = Rotation.applyGCD(nextPitch, lastPitch);
            Rotation next = new Rotation(nextYaw, nextPitch);
            applyDirectRotation(next);
            lastYaw = nextYaw;
            lastPitch = nextPitch;
        }
    }

    private float wrapLerp(float delta, float from, float to) {
        return from + MathHelper.wrapDegrees(to - from) * delta;
    }

    private float randomLerp(float from, float to) {
        return MathHelper.lerp(new SecureRandom().nextFloat(), from, to);
    }

    private boolean isHolyworld() {
        return rotationMode.is(MODE_HOLYWORLD);
    }

    private boolean isBMW() {
        return rotationMode.is(MODE_BMW);
    }

    private boolean isReallyWorld() {
        return rotationMode.is(MODE_REALLY_WORLD);
    }

    private boolean isWhiterise() {
        return rotationMode.is(MODE_WHITERISE);
    }

    private boolean isPineRotation() {
        return rotationMode.is(MODE_SLOTH)
                || rotationMode.is(MODE_WHITE_RISE)
                || rotationMode.is(MODE_WELLMINE)
                || rotationMode.is(MODE_TEST)
                || rotationMode.is(MODE_LEGIT);
    }

    private boolean whiteriseOnlyCriticals() {
        return onlyCriticals.isEnabled();
    }

    private boolean whiteriseTpsSync() {
        return !isWhiterise() || tpsSync.isEnabled();
    }

    private boolean whiteriseCritsOnlyWithSpace() {
        return critsOnlyWithSpace.isEnabled();
    }

    private boolean whiteriseLegitSwap() {
        return !isWhiterise() || legitSwap.isEnabled();
    }

    private boolean whiteriseShieldBreak() {
        return !isWhiterise() || shieldBreak.isEnabled();
    }
}
