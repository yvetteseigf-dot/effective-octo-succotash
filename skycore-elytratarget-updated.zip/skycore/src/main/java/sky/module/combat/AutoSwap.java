package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.PlayerInput;
import sky.config.BooleanSetting;
import sky.hud.HudManager;
import sky.config.KeybindSetting;
import sky.config.ModeSetting;
import sky.misc.MovementBlocker;
import sky.event.player.PlayerUpdateEvent;
import sky.event.input.StrafeInputEvent;
import sky.event.input.KeyInputEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.movement.Sprint;
import sky.util.CooldownTimer;
import sky.util.inventory.InventoryUtil;
import sky.util.inventory.ItemSwapUtil;
import sky.util.entity.MovementUtil;

import java.util.List;
import sky.module.movement.Speed;

public final class AutoSwap extends Module {
    private static final int STOP_TICKS = 1;
    private static final String ITEM_SHIELD = "Shield";
    private static final String ITEM_GAPPLES = "Gapples";
    private static final String ITEM_TOTEM = "Totem";
    private static final String ITEM_HEAD = "Head";
    private static final String ITEM_HELMET = "Helmet";

    public static final AutoSwap INSTANCE = new AutoSwap();

    private final BooleanSetting handMode;
    private final BooleanSetting headMode;
    private final KeybindSetting swapKey;
    private final ModeSetting itemType;
    private final ModeSetting swapType;
    private final KeybindSetting swapKeyHead;
    private final ModeSetting itemTypeHead;
    private final ModeSetting swapTypeHead;
    private final BooleanSetting totemSwap;
    private final BooleanSetting notif;
    private final CooldownTimer stopWatch;
    private final CooldownTimer attackSpeedTimer;

    private Pending pending;
    private ItemStack lastOffhandStack;
    private int movementStopTicks;
    private int storedAxeSlot;
    private boolean lastAttackSpeedResult;
    private boolean wasSprinting;
    private boolean hadAttackSpeedRecently;

    private AutoSwap() {
        super("AutoSwap", "This module has no description!", Category.COMBAT);
        this.handMode = new BooleanSetting("Hand", true);
        this.headMode = new BooleanSetting("Head", false);
        this.swapKey = new KeybindSetting("Swap (hand)", -98, this.handMode::isEnabled);
        this.itemType = new ModeSetting("Swap from", ITEM_SHIELD, this.handMode::isEnabled,
                ITEM_SHIELD, ITEM_GAPPLES, ITEM_TOTEM, ITEM_HEAD);
        this.swapType = new ModeSetting("Swap to", ITEM_GAPPLES, this.handMode::isEnabled,
                ITEM_GAPPLES, ITEM_SHIELD, ITEM_TOTEM, ITEM_HEAD);
        this.swapKeyHead = new KeybindSetting("Swap (head)", -98, this.headMode::isEnabled);
        this.itemTypeHead = new ModeSetting("Swap from (head)", ITEM_HEAD, this.headMode::isEnabled, ITEM_HEAD, ITEM_HELMET);
        this.swapTypeHead = new ModeSetting("Swap to (head)", ITEM_HELMET, this.headMode::isEnabled, ITEM_HELMET, ITEM_HEAD);
        this.totemSwap = new BooleanSetting("Swap axe to sword", true);
        this.notif = new BooleanSetting("Show item swap", true);
        this.stopWatch = new CooldownTimer();
        this.attackSpeedTimer = new CooldownTimer();
        this.storedAxeSlot = -1;
        this.lastOffhandStack = ItemStack.EMPTY;
        addSettings(this.handMode, this.headMode, this.swapKey, this.itemType, this.swapType, this.swapKeyHead,
                this.itemTypeHead, this.swapTypeHead, this.totemSwap, this.notif);
    }

    @EventTarget
    public void onEvent(KeyInputEvent event) {
        if (mc.player == null || mc.world == null || mc.currentScreen != null || !event.isHold()) {
            return;
        }

        if (pending != null || stopWatch.getElapsedTime() < 300L) {
            return;
        }

        int key = event.getKey();

        if (handMode.isEnabled() && swapKey.getKeyCode() >= 0 && key == swapKey.getKeyCode()) {
            pending = Pending.HAND;
            movementStopTicks = STOP_TICKS;
            return;
        }

        if (headMode.isEnabled() && swapKeyHead.getKeyCode() >= 0 && key == swapKeyHead.getKeyCode()) {
            pending = Pending.HEAD;
            movementStopTicks = STOP_TICKS;
        }
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (movementStopTicks > 0) {
            movementStopTicks--;
        }

        handleAttackSpeedLogic();

        if (pending == null || movementStopTicks > 0) {
            return;
        }

        Pending queued = pending;
        pending = null;
        if (queued == Pending.HAND) {
            handleHandSwap();
        } else {
            handleHelmetSwap();
        }
    }

    @EventTarget
    private void onMoveInput(StrafeInputEvent event) {
        if (movementStopTicks <= 0) {
            return;
        }

        event.setForward(0.0F);
        event.setStrafe(0.0F);
        if (event.getInput() != null) {
            event.setInput(new PlayerInput(false, false, false, false, false, false, event.getInput().sprint()));
        }
    }

    @Override
    public void onDisable() {
        storedAxeSlot = -1;
        hadAttackSpeedRecently = false;
        pending = null;
        movementStopTicks = 0;
        wasSprinting = false;
        lastOffhandStack = ItemStack.EMPTY;
        super.onDisable();
    }

    private void handleHandSwap() {
        ItemStack offHandStack = mc.player.getOffHandStack();
        Item sourceItem = getItemByType(itemType.get());
        Item targetItem = getItemByType(swapType.get());
        Item wanted = matchesSwapType(offHandStack, sourceItem) ? targetItem : sourceItem;

        Slot slot = findSwapSlot(wanted);
        if (slot == null) {
            return;
        }

        ItemStack swapped = slot.getStack().copy();
        prepareSwap();
        ItemSwapUtil.swapToOffHand(slot);
        InventoryUtil.closeScreen(true);
        finishSprintReset();
        notifySwap(swapped);
        stopWatch.reset();
    }

    private void handleHelmetSwap() {
        ItemStack helmetStack = mc.player.getInventory().getArmorStack(3);
        Item sourceItem = getItemByType(itemTypeHead.get());
        Item targetItem = getItemByType(swapTypeHead.get());
        Item wanted = matchesSwapType(helmetStack, sourceItem) ? targetItem : sourceItem;

        Slot slot = findSwapSlot(wanted);
        if (slot == null) {
            return;
        }

        ItemStack swapped = slot.getStack().copy();
        prepareSwap();
        ItemSwapUtil.moveToArmor(slot.id, 5);
        InventoryUtil.closeScreen(true);
        finishSprintReset();
        notifySwap(swapped);
        stopWatch.reset();
    }

    private void handleAttackSpeedLogic() {
        ItemStack offHandStack = mc.player.getOffHandStack();
        if (!ItemStack.areEqual(offHandStack, lastOffhandStack)) {
            lastAttackSpeedResult = hasAttackSpeedDescription(offHandStack);
            lastOffhandStack = offHandStack.copy();
        }

        if (lastAttackSpeedResult) {
            hadAttackSpeedRecently = true;
            attackSpeedTimer.reset();
        } else if (attackSpeedTimer.getElapsedTime() >= 500L) {
            hadAttackSpeedRecently = false;
        }

        if (!totemSwap.isEnabled() || stopWatch.getElapsedTime() < 300L) {
            return;
        }

        ItemStack mainHandStack = mc.player.getMainHandStack();
        if (mainHandStack.getItem() instanceof SwordItem && ItemSwapUtil.isBall(offHandStack)
                && lastAttackSpeedResult) {
            int axeSlot = getAxeSlot();
            if (axeSlot != -1) {
                ItemSwapUtil.switchToHotbarSlot(axeSlot);
                stopWatch.reset();
            }
        }

        boolean hasAxe = getAxeSlot() != -1;
        boolean hasSword = getSwordSlot() != -1;
        if (hasAxe && hasSword) {
            if (!lastAttackSpeedResult && hadAttackSpeedRecently && mainHandStack.getItem() instanceof AxeItem) {
                storedAxeSlot = mc.player.getInventory().selectedSlot;
                int swordSlot = getSwordSlot();
                if (swordSlot != -1) {
                    ItemSwapUtil.switchToHotbarSlot(swordSlot);
                    stopWatch.reset();
                }
            } else if (lastAttackSpeedResult && mainHandStack.getItem() instanceof SwordItem
                    && storedAxeSlot != -1) {
                int axeSlot = getAxeSlot();
                if (axeSlot != -1) {
                    ItemSwapUtil.switchToHotbarSlot(axeSlot);
                    storedAxeSlot = -1;
                    stopWatch.reset();
                }
            }
        }
    }

    private void prepareSwap() {
        if (MovementUtil.hasPlayerMovement()) {
            MovementBlocker.stopTicks = 3;
        }

        wasSprinting = false;
        if (mc.player.isSprinting() && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(
                    new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
            mc.player.setSprinting(false);
            mc.getNetworkHandler().sendPacket(
                    new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            if (!Sprint.INSTANCE.isEnabled()) {
                mc.options.sprintKey.setPressed(false);
            }
            wasSprinting = true;
        }
    }

    private void finishSprintReset() {
        if (wasSprinting && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
        }
        wasSprinting = false;
    }

    private Slot findSwapSlot(Item item) {
        if (item == Items.AIR) {
            return null;
        }
        if (item == Items.PLAYER_HEAD) {
            return ItemSwapUtil.findBallSlot();
        }
        return InventoryUtil.getSlot(item, slot -> slot.id != 45);
    }

    private Item getItemByType(String itemTypeName) {
        String name = Formatting.strip(itemTypeName.trim());
        if (name == null) {
            name = itemTypeName.trim();
        }

        if (name.equalsIgnoreCase(ITEM_HEAD)) {
            return Items.PLAYER_HEAD;
        }

        return switch (name) {
            case ITEM_SHIELD -> Items.SHIELD;
            case ITEM_TOTEM -> Items.TOTEM_OF_UNDYING;
            case ITEM_GAPPLES -> Items.GOLDEN_APPLE;
            case ITEM_HELMET -> Items.NETHERITE_HELMET;
            default -> Items.AIR;
        };
    }

    private boolean matchesSwapType(ItemStack stack, Item item) {
        if (stack.isEmpty() || item == Items.AIR) {
            return false;
        }
        if (item == Items.PLAYER_HEAD) {
            return ItemSwapUtil.isBall(stack);
        }
        return stack.getItem() == item;
    }

    private int getAxeSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).getItem() instanceof AxeItem) {
                return slot;
            }
        }
        return -1;
    }

    private int getSwordSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).getItem() instanceof SwordItem) {
                return slot;
            }
        }
        return -1;
    }

    private boolean hasAttackSpeedDescription(ItemStack itemStack) {
        if (itemStack.isEmpty()) {
            return false;
        }

        if (itemStack.contains(DataComponentTypes.CUSTOM_NAME)
                && itemStack.getName().getString().contains("Кобры")) {
            return true;
        }

        List<Text> tooltip = itemStack.getTooltip(Item.TooltipContext.create(mc.world), mc.player, TooltipType.BASIC);
        for (Text line : tooltip) {
            String text = line.getString();
            if (text.contains("Скорости Атаки") || text.contains("Скорость атаки")
                    || text.contains("Attack Speed")) {
                return true;
            }
        }

        return false;
    }

    private void notifySwap(ItemStack stack) {
        if (!notif.isEnabled() || stack.isEmpty()) {
            return;
        }
        HudManager.getInstance().notifications.pushItemSwap(getSwapDisplayName(stack));
    }

    private String getSwapDisplayName(ItemStack stack) {
        return stack.getName().getString();
    }

    private enum Pending {
        HAND,
        HEAD
    }
}
