package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.AxeItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import sky.SkyInit;
import sky.config.MultiBooleanSetting;
import sky.config.NumberSetting;
import sky.event.player.PlayerUpdateEvent;
import sky.event.input.StrafeInputEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.player.AutoEat;
import sky.util.combat.CombatAiHelper;
import sky.util.MsTimer;

import java.util.Comparator;
import java.util.List;

public final class TriggerBot extends Module {
    private static final String TARGET_PLAYERS = "Players";
    private static final String TARGET_FRIENDS = "Friends";
    private static final String TARGET_NAKED = "Unarmored";
    private static final String TARGET_ANIMALS = "Animals";
    private static final String TARGET_MOBS = "Mobs";
    private static final String OPT_SMART_CRITS = "Only crits";
    private static final String OPT_SPRINT_RESET = "Sprint reset";
    private static final String OPT_WALLS = "Hit through walls";
    private static final String OPT_SHIELD = "Break shield";
    private static final String OPT_SPACE = "Only with space";

    public static final TriggerBot INSTANCE = new TriggerBot();

    private final NumberSetting range;
    private final MultiBooleanSetting targets;
    private final MultiBooleanSetting options;
    private final MsTimer attackTimer;

    private LivingEntity target;
    private boolean needSprintReset;
    private boolean sprintResetDone;
    private int sprintResetTicks;

    private TriggerBot() {
        super("TriggerBot", "Automatically hits the enemy when they are in range", Category.COMBAT);
        this.range = new NumberSetting("Attack distance", 3.0F, 2.0F, 5.0F, 0.1F);
        this.targets = MultiBooleanSetting.create("Targets",
                List.of(TARGET_PLAYERS, TARGET_FRIENDS, TARGET_NAKED, TARGET_ANIMALS, TARGET_MOBS));
        this.options = MultiBooleanSetting.create("Settings",
                List.of(OPT_SMART_CRITS, OPT_SPRINT_RESET, OPT_WALLS, OPT_SHIELD, OPT_SPACE));
        this.attackTimer = new MsTimer();
        addSettings(this.range, this.targets, this.options);
    }

    public LivingEntity getTarget() {
        return target;
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.world == null) {
            target = null;
            return;
        }

        if (AutoEat.shouldSuppressCombat()) {
            target = null;
            resetSprintState();
            return;
        }

        if (sprintResetDone) {
            sprintResetTicks++;
        }

        target = getTargetUnderCrosshair();
        if (target != null) {
            processAttack();
        } else {
            resetSprintState();
        }
    }

    @EventTarget
    public void onMoveInput(StrafeInputEvent event) {
        if (needSprintReset) {
            event.setForward(0.0F);
            event.setStrafe(0.0F);
            needSprintReset = false;
            sprintResetDone = true;
            sprintResetTicks = 0;
        }
    }

    @Override
    public void onDisable() {
        target = null;
        needSprintReset = false;
        resetSprintState();
        super.onDisable();
    }

    private LivingEntity getTargetUnderCrosshair() {
        float reach = range.get();
        Vec3d cameraPos = mc.player.getCameraPosVec(1.0F);
        Vec3d rotationVec = mc.player.getRotationVec(1.0F);
        Vec3d reachEnd = cameraPos.add(rotationVec.multiply(reach));

        EntityHitResult hitResult = ProjectileUtil.raycast(mc.player, cameraPos, reachEnd,
                mc.player.getBoundingBox().expand(reach),
                entity -> entity != mc.player && entity.isAlive() && entity instanceof LivingEntity,
                reach * reach);

        if (hitResult != null && hitResult.getEntity() instanceof LivingEntity hitEntity && isValidTarget(hitEntity)) {
            return hitEntity;
        }

        return findNearestTarget();
    }

    private LivingEntity findNearestTarget() {
        float reach = range.get();
        Vec3d cameraPos = mc.player.getCameraPosVec(1.0F);
        Vec3d reachEnd = cameraPos.add(mc.player.getRotationVec(1.0F).multiply(reach));
        return mc.world.getEntitiesByClass(LivingEntity.class,
                        mc.player.getBoundingBox().expand(reach), this::isValidTarget)
                .stream()
                .filter(entity -> {
                    Box box = entity.getBoundingBox().expand(entity.getTargetingMargin());
                    return box.raycast(cameraPos, reachEnd).isPresent();
                })
                .min(Comparator.comparingDouble(entity -> entity.distanceTo(mc.player)))
                .orElse(null);
    }

    private boolean isValidTarget(LivingEntity entity) {
        if (entity == null || entity == mc.player || !entity.isAlive() || entity instanceof ArmorStandEntity) {
            return false;
        }

        if (entity instanceof PlayerEntity player) {
            if (AntiBot.isBot(player)) {
                return false;
            }
            if (!targets.is(TARGET_PLAYERS)) {
                return false;
            }
            if (SkyInit.getInstance().getFriendManager().isFriend(entity.getName().getString())
                    && !targets.is(TARGET_FRIENDS)) {
                return false;
            }
            if (isNaked(player) && !targets.is(TARGET_NAKED)) {
                return false;
            }
        } else if (entity instanceof PassiveEntity) {
            if (!targets.is(TARGET_ANIMALS)) {
                return false;
            }
        } else if (entity instanceof HostileEntity && !targets.is(TARGET_MOBS)) {
            return false;
        }

        if (mc.player.getEyePos().distanceTo(entity.getBoundingBox().getCenter()) > range.get()) {
            return false;
        }

        return options.is(OPT_WALLS) || mc.player.canSee(entity);
    }

    private boolean isNaked(PlayerEntity player) {
        return player.getInventory().armor.stream().allMatch(stack -> stack == null || stack.isEmpty());
    }

    private void processAttack() {
        if (!shouldAttack()) {
            return;
        }

        if (options.is(OPT_SPRINT_RESET) && mc.player.isSprinting() && !sprintResetDone) {
            needSprintReset = true;
            return;
        }

        if (options.is(OPT_SPRINT_RESET) && sprintResetDone && sprintResetTicks < 1) {
            return;
        }

        attack();
        sprintResetDone = false;
        sprintResetTicks = 0;
    }

    private boolean shouldAttack() {
        if (options.is(OPT_SPACE) && (mc.options == null || !mc.options.jumpKey.isPressed())) {
            return false;
        }

        if (mc.player.getAttackCooldownProgress(1.5F) < CombatAiHelper.getAICooldown()) {
            return false;
        }

        return !options.is(OPT_SMART_CRITS) || CombatAiHelper.canCritical(target);
    }

    private void attack() {
        LivingEntity current = target;
        if (current instanceof PlayerEntity player && player.isBlocking() && options.is(OPT_SHIELD)) {
            shieldBreak(player);
        } else {
            mc.interactionManager.attackEntity(mc.player, target);
        }

        mc.player.swingHand(Hand.MAIN_HAND);
        attackTimer.reset();
    }

    private void shieldBreak(PlayerEntity entity) {
        int axeSlot = findAxeSlot();
        if (axeSlot == -1) {
            mc.interactionManager.attackEntity(mc.player, entity);
            return;
        }

        int previousSlot = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = axeSlot;
        mc.interactionManager.attackEntity(mc.player, entity);
        mc.player.swingHand(Hand.MAIN_HAND);
        mc.player.getInventory().selectedSlot = previousSlot;
    }

    private int findAxeSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).getItem() instanceof AxeItem) {
                return slot;
            }
        }
        return -1;
    }

    private void resetSprintState() {
        sprintResetDone = false;
        sprintResetTicks = 0;
    }
}
