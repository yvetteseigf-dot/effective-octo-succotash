package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityAnimationS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import sky.SkyInit;
import sky.config.BooleanSetting;
import sky.config.NumberSetting;
import sky.rotation.RotationManager;
import sky.rotation.TargetRotationTracker;
import sky.event.network.PacketSendEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.input.StrafeInputEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.inventory.ItemSwapUtil;
import sky.util.entity.MovementFixUtil;
import sky.util.combat.Rotation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class TargetPearl extends Module {
    private static final long TARGET_MEMORY_DURATION = 10000L;
    private static final int ROTATION_PRIORITY = 50;
    private static final int MAX_SIM_TICKS = 160;
    private static final float ROTATION_SPEED = 360.0f;
    private static final float ROTATION_EPSILON = 4.0f;
    private static final double MAX_DISTANCE_FROM_TARGET = 1.5d;
    private static final int THROW_COOLDOWN = 2000;
    private static final double MAX_ACCEPTABLE_ERROR = 2.0d;
    private static final int PEARL_SCAN_INTERVAL = 35;

    public static final TargetPearl INSTANCE = new TargetPearl();

    public Entity rememberedTarget = null;

    private final BooleanSetting onlyTarget = new BooleanSetting("Only follow target", false);
    private final NumberSetting distance = new NumberSetting("Min distance", 10.0f, 8.0f, 20.0f, 1.0f);

    private EnderPearlEntity targetPearl = null;
    private Vec3d cachedLanding = null;
    private long lastPearlScan = 0L;
    private long lastThrowTime = 0L;
    private long rotationHoldUntil = 0L;
    private boolean isThrowing = false;
    private Vec2f server = null;
    private boolean awaitingThrow = false;
    private int rotationWaitTicks = 0;
    private long rememberedTargetTime = 0L;
    private final Map<Integer, Integer> pearlOwnerById = new HashMap<>();
    private final Map<Integer, Integer> recentThrowers = new HashMap<>();

    private float pendingYaw;
    private float pendingPitch;

    private TargetPearl() {
        super("TargetPearl", "Throws a pearl exactly after the enemy's pearl (through everything)", Category.COMBAT);
        addSettings(onlyTarget, distance);
    }

    public static boolean isRotationActive() {
        TargetPearl module = SkyInit.getInstance().getModuleManager().getModule(TargetPearl.class);
        return module != null && module.isManagingRotation();
    }

    public boolean isManagingRotation() {
        if (!isEnabled()) {
            return false;
        }
        return awaitingThrow
                || isThrowing
                || (rotationHoldUntil > 0L && System.currentTimeMillis() < rotationHoldUntil);
    }

    @EventTarget
    public void onEvent(PlayerUpdateEvent event) {
        if (event == null || mc.player == null || mc.world == null || mc.player.isGliding()) {
            return;
        }

        if (awaitingThrow) {
            processPendingThrow();
            return;
        }

        tryThrow();
    }

    @EventTarget
    public void onEvent(StrafeInputEvent event) {
        if (event == null || mc.player == null || mc.world == null || mc.player.isGliding()) {
            return;
        }

        if (rotationHoldUntil > 0L && System.currentTimeMillis() >= rotationHoldUntil) {
            isThrowing = false;
            server = null;
            rotationHoldUntil = 0L;
        }

        if (check()) {
            MovementFixUtil.fixMovement(event, server.x);
        }
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (!isEnabled() || event == null || !event.isReceive() || mc.world == null) {
            return;
        }

        Packet<?> packet = event.getPacket();
        int age = mc.player != null ? mc.player.age : 0;

        if (packet instanceof EntityAnimationS2CPacket animation) {
            if (animation.getAnimationId() == 0) {
                recentThrowers.put(animation.getEntityId(), age + 12);
            }
            return;
        }

        if (packet instanceof EntitySpawnS2CPacket spawn && spawn.getEntityType() == EntityType.ENDER_PEARL) {
            int ownerIdFromPacket = spawn.getEntityData();
            if (ownerIdFromPacket != 0) {
                pearlOwnerById.put(spawn.getEntityId(), ownerIdFromPacket);
                return;
            }

            for (Map.Entry<Integer, Integer> thrower : recentThrowers.entrySet()) {
                if (thrower.getValue() >= age) {
                    pearlOwnerById.put(spawn.getEntityId(), thrower.getKey());
                    break;
                }
            }

            Entity nearestThrower = findNearestThrower(spawn.getX(), spawn.getY(), spawn.getZ(), 4.5);
            if (nearestThrower != null) {
                pearlOwnerById.put(spawn.getEntityId(), nearestThrower.getId());
            }
        }
    }

    @Override
    public void onDisable() {
        awaitingThrow = false;
        isThrowing = false;
        targetPearl = null;
        cachedLanding = null;
        server = null;
        rotationHoldUntil = 0L;
        rememberedTarget = null;
        rememberedTargetTime = 0L;
        rotationWaitTicks = 0;
        pearlOwnerById.clear();
        recentThrowers.clear();

        AttackAura attackAura = AttackAura.INSTANCE;
        if (attackAura == null || !attackAura.isEnabled()) {
            if (attackAura != null) {
                attackAura.releaseRotationControl();
            } else {
                RotationManager.instance.stopRotation();
            }
        }

        super.onDisable();
    }

    private void tryThrow() {
        if (System.currentTimeMillis() - lastThrowTime < THROW_COOLDOWN) {
            return;
        }

        if (!canThrow()) {
            return;
        }

        updateTargetPearl();
        if (cachedLanding == null) {
            return;
        }

        float[] rotation = calculateYawPitch(cachedLanding);
        if (rotation == null) {
            rotation = findAnyWorkingRotation(cachedLanding);
            if (rotation == null) {
                return;
            }
        }

        Vec3d simulated = simulateTrajectory(rotation[0], rotation[1]);
        if (simulated != null) {
            double error = cachedLanding.distanceTo(simulated);
            Vec3d eyePos = mc.player.getEyePos();
            double landingDistance = eyePos.distanceTo(cachedLanding);
            double heightDifference = cachedLanding.y - eyePos.y;
            boolean highTarget = heightDifference > 5.0;

            double tolerance = landingDistance > 60.0 ? 3.0 : 2.25;
            if (highTarget) {
                tolerance = 4.5;
            }
            if (hasObstacleBetween(eyePos, cachedLanding)) {
                tolerance = highTarget ? 6.0 : 3.75;
            }

            if (error > tolerance) {
                rotation = findAnyWorkingRotation(cachedLanding);
                if (rotation == null) {
                    return;
                }
            }
        }

        pendingYaw = rotation[0];
        pendingPitch = rotation[1];
        isThrowing = true;
        server = new Vec2f(pendingYaw, pendingPitch);
        awaitingThrow = true;
        applyThrowRotation(pendingYaw, pendingPitch);
    }

    private void processPendingThrow() {
        if (!canThrow() || cachedLanding == null) {
            cancelPendingThrow();
            return;
        }

        if (!applyThrowRotation(pendingYaw, pendingPitch)) {
            rotationWaitTicks++;
            if (rotationWaitTicks < 10) {
                return;
            }
        }

        rotationWaitTicks = 0;
        if (!mc.player.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL.getDefaultStack())
                && ItemSwapUtil.getItemSlot(Items.ENDER_PEARL) != -1) {
            ItemSwapUtil.findItemAndThrow(Items.ENDER_PEARL);
            lastThrowTime = System.currentTimeMillis();
        }

        awaitingThrow = false;
        rotationHoldUntil = System.currentTimeMillis() + 50L;
    }

    private void cancelPendingThrow() {
        awaitingThrow = false;
        isThrowing = false;
        server = null;
    }

    private boolean canThrow() {
        return !mc.player.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL.getDefaultStack());
    }

    private boolean check() {
        return isEnabled() && isThrowing && server != null;
    }

    private boolean applyThrowRotation(float yaw, float pitch) {
        float clampedPitch = MathHelper.clamp(pitch, -90.0f, 90.0f);
        Rotation rotation = new Rotation(yaw, clampedPitch);
        RotationManager.update(rotation, ROTATION_SPEED, ROTATION_SPEED, ROTATION_SPEED, ROTATION_SPEED,
                8, ROTATION_PRIORITY, false);
        return new Rotation(mc.player.getYaw(), mc.player.getPitch()).getDelta(rotation) <= ROTATION_EPSILON;
    }

    private void updateTargetPearl() {
        cleanupPearlTracking();

        long now = System.currentTimeMillis();
        if (now - lastPearlScan < PEARL_SCAN_INTERVAL) {
            if (targetPearl != null && targetPearl.isAlive() && cachedLanding != null) {
                return;
            }
            if (now - lastPearlScan < 17L) {
                return;
            }
        }

        lastPearlScan = now;
        cachedLanding = null;
        targetPearl = findBestPearl();

        if (targetPearl != null && targetPearl.isAlive()) {
            cachedLanding = predictLanding(targetPearl);
            if (cachedLanding != null && !isValidLanding(cachedLanding)) {
                cachedLanding = null;
            }
        }
    }

    private EnderPearlEntity findBestPearl() {
        List<Entity> pearls = mc.world.getOtherEntities(mc.player,
                mc.player.getBoundingBox().expand(130.0),
                entity -> entity instanceof EnderPearlEntity);

        EnderPearlEntity best = null;
        double bestDistance = Double.MAX_VALUE;
        double minDistance = distance.get().floatValue();
        LivingEntity auraTarget = onlyTarget.isEnabled() ? resolveAuraTarget() : null;

        if (onlyTarget.isEnabled() && auraTarget == null) {
            return null;
        }

        for (Entity entity : pearls) {
            if (!(entity instanceof EnderPearlEntity pearl)) {
                continue;
            }
            if (!pearl.isAlive()) {
                continue;
            }

            assignPearlOwner(pearl);
            Entity shooter = getPearlShooter(pearl);
            if (shooter != null && isSameEntity(shooter, mc.player)) {
                continue;
            }
            if (onlyTarget.isEnabled() && !isPearlFromEntity(pearl, auraTarget)) {
                continue;
            }

            Vec3d landing = predictLanding(pearl);
            if (landing == null) {
                continue;
            }

            double landingDistance = mc.player.getPos().distanceTo(landing);
            if (landingDistance >= minDistance && landingDistance <= 120.0 && landingDistance < bestDistance) {
                best = pearl;
                bestDistance = landingDistance;
            }
        }

        return best;
    }

    private LivingEntity resolveAuraTarget() {
        long now = System.currentTimeMillis();

        LivingEntity target = AttackAura.INSTANCE.getTarget();
        if (target == null) {
            target = TargetRotationTracker.target;
        }

        if (target != null && target.isAlive() && !target.isRemoved()) {
            rememberedTarget = target;
            rememberedTargetTime = now;
            return target;
        }

        if (rememberedTarget != null) {
            if (!rememberedTarget.isAlive() || rememberedTarget.isRemoved()) {
                rememberedTarget = null;
                rememberedTargetTime = 0L;
                return null;
            }
            if (now - rememberedTargetTime < TARGET_MEMORY_DURATION) {
                return (LivingEntity) rememberedTarget;
            }
            rememberedTarget = null;
            rememberedTargetTime = 0L;
        }

        return null;
    }

    private float[] calculateYawPitch(Vec3d landing) {
        Vec3d eyePos = mc.player.getEyePos();
        double deltaX = landing.x - eyePos.x;
        double deltaZ = landing.z - eyePos.z;
        float yaw = (float) Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0f;
        double landingDistance = eyePos.distanceTo(landing);
        double heightDifference = landing.y - eyePos.y;
        boolean highTarget = heightDifference > 5.0;

        float maxPitch = highTarget ? 89.0f : 85.0f;
        float minPitch = landingDistance > 60.0 ? -50.0f : -30.0f;
        if (highTarget) {
            minPitch = -80.0f;
        }
        float pitchStep = landingDistance > 60.0 ? 0.5f : 0.42f;
        if (highTarget) {
            pitchStep = 0.3f;
        }

        float bestPitch = 0.0f;
        int bestTicks = Integer.MAX_VALUE;
        double bestError = Double.MAX_VALUE;
        double maxError = highTarget ? 4.0 : MAX_ACCEPTABLE_ERROR;

        for (float pitch = maxPitch; pitch >= minPitch; pitch -= pitchStep) {
            SimulationResult result = simulateWithTicks(yaw, pitch, landing);
            if (result != null && result.error <= maxError
                    && (result.ticks < bestTicks || (result.ticks == bestTicks && result.error < bestError))) {
                bestTicks = result.ticks;
                bestPitch = pitch;
                bestError = result.error;
            }
        }

        if (bestTicks != Integer.MAX_VALUE) {
            return new float[]{yaw, MathHelper.clamp(bestPitch, -90.0f, 90.0f)};
        }
        return null;
    }

    private float[] findAnyWorkingRotation(Vec3d landing) {
        Vec3d eyePos = mc.player.getEyePos();
        double deltaX = landing.x - eyePos.x;
        double deltaZ = landing.z - eyePos.z;
        float yaw = (float) Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0f;
        double landingDistance = eyePos.distanceTo(landing);
        double heightDifference = landing.y - eyePos.y;
        boolean highTarget = heightDifference > 5.0;

        float maxPitch = highTarget ? 89.0f : 85.0f;
        float minPitch = landingDistance > 60.0 ? -70.0f : -50.0f;
        if (highTarget) {
            minPitch = -85.0f;
        }
        float pitchStep = landingDistance > 60.0 ? 1.2f : 1.5f;
        if (highTarget) {
            pitchStep = 1.0f;
        }
        float yawRange = landingDistance > 60.0 ? 30.0f : 20.0f;
        if (highTarget) {
            yawRange = 40.0f;
        }
        float yawStep = landingDistance > 60.0 ? 3.0f : 2.5f;
        if (highTarget) {
            yawStep = 2.0f;
        }
        double tolerance = landingDistance > 60.0 ? 3.0 : 2.25;
        if (highTarget) {
            tolerance = 4.5;
        }

        for (float pitch = maxPitch; pitch >= minPitch; pitch -= pitchStep) {
            Vec3d simulated = simulateTrajectory(yaw, pitch);
            if (simulated != null && landing.distanceTo(simulated) <= tolerance) {
                return new float[]{yaw, MathHelper.clamp(pitch, -90.0f, 90.0f)};
            }
        }

        for (float yawOffset = -yawRange; yawOffset <= yawRange; yawOffset += yawStep) {
            if (yawOffset == 0.0f) {
                continue;
            }
            float testYaw = yaw + yawOffset;
            for (float pitch = maxPitch; pitch >= minPitch; pitch -= pitchStep) {
                Vec3d simulated = simulateTrajectory(testYaw, pitch);
                if (simulated != null && landing.distanceTo(simulated) <= tolerance) {
                    return new float[]{testYaw, MathHelper.clamp(pitch, -90.0f, 90.0f)};
                }
            }
        }

        if (highTarget) {
            for (float pitch = 89.0f; pitch >= 75.0f; pitch -= 1.5f) {
                for (float yawOffset = -yawRange; yawOffset <= yawRange; yawOffset += yawStep) {
                    float testYaw = yaw + yawOffset;
                    Vec3d simulated = simulateTrajectory(testYaw, pitch);
                    if (simulated != null && landing.distanceTo(simulated) <= tolerance * 1.5) {
                        return new float[]{testYaw, MathHelper.clamp(pitch, -90.0f, 90.0f)};
                    }
                }
            }
        }

        for (float pitch = maxPitch; pitch >= 70.0f; pitch -= 2.0f) {
            for (float yawOffset = -yawRange; yawOffset <= yawRange; yawOffset += yawStep * 2.0f) {
                float testYaw = yaw + yawOffset;
                Vec3d simulated = simulateTrajectory(testYaw, pitch);
                double relaxedTolerance = highTarget ? 6.0 : 3.75;
                if (simulated != null && landing.distanceTo(simulated) <= relaxedTolerance) {
                    return new float[]{testYaw, MathHelper.clamp(pitch, -90.0f, 90.0f)};
                }
            }
        }

        return null;
    }

    private Vec3d simulateTrajectory(float yaw, float pitch) {
        Vec3d position = getThrowPos(yaw, pitch);
        Vec3d motion = getThrowMotion(yaw, pitch);

        for (int tick = 0; tick < MAX_SIM_TICKS; tick++) {
            position = position.add(motion);
            motion = motion.multiply(0.99).add(0.0, -0.03, 0.0);

            if (position.y <= 0.0) {
                return snapToBlockCenter(position);
            }

            BlockPos blockPos = BlockPos.ofFloored(position);
            if (!mc.world.getBlockState(blockPos).getCollisionShape(mc.world, blockPos).isEmpty()) {
                return snapToBlockCenter(position);
            }
        }

        return null;
    }

    private SimulationResult simulateWithTicks(float yaw, float pitch, Vec3d target) {
        Vec3d position = getThrowPos(yaw, pitch);
        Vec3d motion = getThrowMotion(yaw, pitch);

        for (int tick = 0; tick < MAX_SIM_TICKS; tick++) {
            position = position.add(motion);
            motion = motion.multiply(0.99).add(0.0, -0.03, 0.0);

            if (position.y <= 0.0) {
                return new SimulationResult(snapToBlockCenter(position).distanceTo(target), tick + 1);
            }

            BlockPos blockPos = BlockPos.ofFloored(position);
            if (!mc.world.getBlockState(blockPos).getCollisionShape(mc.world, blockPos).isEmpty()) {
                return new SimulationResult(snapToBlockCenter(position).distanceTo(target), tick + 1);
            }
        }

        return null;
    }

    private Vec3d predictLanding(EnderPearlEntity pearl) {
        Vec3d position = pearl.getPos();
        Vec3d motion = pearl.getVelocity();

        for (int tick = 0; tick < MAX_SIM_TICKS; tick++) {
            Vec3d next = position.add(motion);
            motion = motion.multiply(0.99).add(0.0, -0.03, 0.0);

            if (next.y <= 0.0) {
                return snapToBlockCenter(next);
            }

            BlockPos blockPos = BlockPos.ofFloored(next);
            if (!mc.world.getBlockState(blockPos).getCollisionShape(mc.world, blockPos).isEmpty()) {
                return snapToBlockCenter(next);
            }

            position = next;
        }

        return null;
    }

    private Vec3d getThrowPos(float yaw, float pitch) {
        float yawRadians = (float) Math.toRadians(yaw);
        return new Vec3d(
                mc.player.getX() - MathHelper.cos(yawRadians) * 0.16,
                mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()) - 0.1,
                mc.player.getZ() - MathHelper.sin(yawRadians) * 0.16);
    }

    private Vec3d getThrowMotion(float yaw, float pitch) {
        float yawRadians = (float) Math.toRadians(yaw);
        float pitchRadians = (float) Math.toRadians(pitch);

        double motionX = -MathHelper.sin(yawRadians) * MathHelper.cos(pitchRadians) * 1.5;
        double motionY = -MathHelper.sin(pitchRadians) * 1.5;
        double motionZ = MathHelper.cos(yawRadians) * MathHelper.cos(pitchRadians) * 1.5;
        motionY += mc.player.getVelocity().y;

        return new Vec3d(motionX, motionY, motionZ);
    }

    private Vec3d snapToBlockCenter(Vec3d position) {
        return new Vec3d(
                MathHelper.floor(position.x) + 0.5,
                MathHelper.floor(position.y),
                MathHelper.floor(position.z) + 0.5);
    }

    private boolean isValidLanding(Vec3d landing) {
        BlockPos blockPos = BlockPos.ofFloored(landing);
        for (int depth = 1; depth <= 4; depth++) {
            if (!mc.world.getBlockState(blockPos.down(depth))
                    .getCollisionShape(mc.world, blockPos.down(depth)).isEmpty()) {
                return true;
            }
        }
        return landing.y <= 1.0;
    }

    private boolean hasObstacleBetween(Vec3d from, Vec3d to) {
        Vec3d delta = to.subtract(from);
        double length = delta.length();
        Vec3d direction = delta.normalize();
        int steps = (int) (length / 0.5) + 1;

        for (int step = 1; step < steps; step++) {
            Vec3d point = from.add(direction.multiply(step * 0.5));
            BlockPos blockPos = BlockPos.ofFloored(point);
            if (!mc.world.getBlockState(blockPos).getCollisionShape(mc.world, blockPos).isEmpty()) {
                return true;
            }
        }

        return false;
    }

    private void assignPearlOwner(EnderPearlEntity pearl) {
        if (pearl == null || mc.world == null) {
            return;
        }

        Entity knownShooter = getPearlShooterWithoutAssign(pearl);
        if (knownShooter != null) {
            if (pearl.getOwner() == null) {
                pearl.setOwner(knownShooter);
            }
            return;
        }

        if (pearl.age > 8) {
            return;
        }

        Entity thrower = findNearestThrower(pearl.getX(), pearl.getY(), pearl.getZ(), 4.0);
        if (thrower != null) {
            pearl.setOwner(thrower);
            pearlOwnerById.put(pearl.getId(), thrower.getId());
        }
    }

    private Entity getPearlShooter(EnderPearlEntity pearl) {
        assignPearlOwner(pearl);

        Entity owner = pearl.getOwner();
        if (owner != null && owner.isAlive()) {
            return owner;
        }

        Integer trackedOwnerId = pearlOwnerById.get(pearl.getId());
        if (trackedOwnerId != null && mc.world != null) {
            return mc.world.getEntityById(trackedOwnerId);
        }

        int ownerId = getPearlOwnerEntityId(pearl);
        if (ownerId != 0 && mc.world != null) {
            return mc.world.getEntityById(ownerId);
        }

        return null;
    }

    private Entity getPearlShooterWithoutAssign(EnderPearlEntity pearl) {
        Entity owner = pearl.getOwner();
        if (owner != null && owner.isAlive()) {
            return owner;
        }

        Integer trackedOwnerId = pearlOwnerById.get(pearl.getId());
        if (trackedOwnerId != null) {
            return mc.world.getEntityById(trackedOwnerId);
        }

        int ownerId = getPearlOwnerEntityId(pearl);
        if (ownerId != 0) {
            return mc.world.getEntityById(ownerId);
        }

        return null;
    }

    private int getPearlOwnerEntityId(EnderPearlEntity pearl) {
        Entity owner = pearl.getOwner();
        return owner != null ? owner.getId() : 0;
    }

    private UUID getPearlOwnerUuid(EnderPearlEntity pearl) {
        Entity owner = pearl.getOwner();
        return owner != null ? owner.getUuid() : null;
    }

    private boolean isPearlFromEntity(EnderPearlEntity pearl, Entity entity) {
        if (pearl == null || entity == null) {
            return false;
        }

        Entity shooter = getPearlShooter(pearl);
        if (shooter != null) {
            return isSameEntity(shooter, entity);
        }

        int ownerId = getPearlOwnerEntityId(pearl);
        if (ownerId != 0 && ownerId == entity.getId()) {
            return true;
        }

        UUID ownerUuid = getPearlOwnerUuid(pearl);
        return ownerUuid != null && ownerUuid.equals(entity.getUuid());
    }

    private boolean isSameEntity(Entity first, Entity second) {
        if (first == null || second == null) {
            return false;
        }
        return first == second
                || first.getId() == second.getId()
                || first.getUuid().equals(second.getUuid());
    }

    private Entity findNearestThrower(double x, double y, double z, double radius) {
        Entity nearest = null;
        double bestSquaredDistance = radius * radius;

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player) {
                continue;
            }

            double eyeDistance = player.getEyePos().squaredDistanceTo(x, y, z);
            double feetDistance = player.getPos().squaredDistanceTo(x, y, z);
            double squaredDistance = Math.min(eyeDistance, feetDistance);

            if (squaredDistance < bestSquaredDistance) {
                bestSquaredDistance = squaredDistance;
                nearest = player;
            }
        }

        return nearest;
    }

    private void cleanupPearlTracking() {
        if (mc.player == null) {
            return;
        }

        int age = mc.player.age;
        recentThrowers.entrySet().removeIf(entry -> entry.getValue() < age);
        pearlOwnerById.entrySet().removeIf(entry -> mc.world.getEntityById(entry.getKey()) == null);
    }

    static final class SimulationResult {
        final int ticks;
        final double error;

        SimulationResult(double error, int ticks) {
            this.error = error;
            this.ticks = ticks;
        }
    }
}
