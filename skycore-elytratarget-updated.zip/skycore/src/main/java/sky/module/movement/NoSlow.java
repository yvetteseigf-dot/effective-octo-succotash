package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.math.Vec3d;
import sky.config.ModeSetting;
import sky.config.NumberSetting;
import sky.event.player.PlayerUpdateEvent;
import sky.event.player.NoSlowEvent;
import sky.module.Category;
import sky.module.Module;

public final class NoSlow extends Module {
    public static final NoSlow INSTANCE = new NoSlow();

    public static int ticks;

    private static int cycleCounter;

    private final ModeSetting mode;
    private final NumberSetting vanillaSpeed;

    private NoSlow() {
        super("No Slow", "Removes slowdown while using an item", Category.MOVEMENT);
        mode = new ModeSetting("Mode", "ReallyWorld", "ReallyWorld", "Spooky", "BravoHvH");
        vanillaSpeed = new NumberSetting("Speed", 0.6F, 0.1F, 1.0F, 0.05F, () -> mode.is("BravoHvH"));
        addSettings(mode, vanillaSpeed);
    }

    @EventTarget
    public void onNoSlow(NoSlowEvent event) {
        applyMode(event);
    }

    @EventTarget
    public void onEvent(PlayerUpdateEvent event) {
        if ((!mode.is("ReallyWorld") && !mode.is("Spooky"))
                || mc.player == null
                || mc.player.isGliding()) {
            return;
        }

        if (mc.player.isUsingItem()) {
            ticks++;
        } else {
            ticks = 0;
            cycleCounter = 0;
        }
    }

    private void applyMode(NoSlowEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        if (mc.player.isGliding()) {
            return;
        }
        if (!mc.player.isUsingItem()) {
            return;
        }

        switch (mode.get()) {
            case "BravoHvH" -> handleBravo(event);
            case "ReallyWorld" -> handleReallyWorld(event);
            case "Spooky" -> handleSpooky(event);
        }
    }

    private void handleBravo(NoSlowEvent eventNoSlow) {
        eventNoSlow.setCancelled(true);
        Vec3d velocity = mc.player.getVelocity();
        double motionX = velocity.x * vanillaSpeed.getCurrent();
        double motionZ = velocity.z * vanillaSpeed.getCurrent();
        mc.player.setVelocity(motionX, velocity.y, motionZ);
    }

    private void handleReallyWorld(NoSlowEvent eventNoSlow) {
        int[] cycle = { 2, 3, 3 };
        int threshold = cycle[cycleCounter % 3];
        if (ticks >= threshold) {
            eventNoSlow.setCancelled(true);
            ticks = 0;
            cycleCounter++;
        }
    }

    private void handleSpooky(NoSlowEvent eventNoSlow) {
        int[] cycle = { 2, 2 };
        int threshold = cycle[cycleCounter % 2];
        if (ticks >= threshold) {
            eventNoSlow.setCancelled(true);
            ticks = 0;
            cycleCounter++;
        }
    }
}
