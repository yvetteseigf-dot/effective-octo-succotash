package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.math.MathHelper;
import sky.config.BooleanSetting;
import sky.config.ModeSetting;
import sky.config.MultiBooleanSetting;
import sky.config.NumberSetting;
import sky.event.entity.FireworkRocketEntityTickEvent;
import sky.event.render.OverlayRenderEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.combat.AttackAura;
import sky.module.combat.ElytraTarget;

public final class SuperFirework extends Module {
    public static final SuperFirework INSTANCE = new SuperFirework();

    private static final int ACCELERATION_PHASE_TICKS = 30;
    private static final int Y_DEGREE_COUNT = 56;

    private static final float[] BRAVO_GRIEF_XZ = {1.67F, 1.68F, 1.69F, 1.72F, 1.72F, 1.73F, 1.74F, 1.75F, 1.76F};
    private static final float[] BRAVO_GRIEF_Y = {1.72F, 1.72F, 1.72F, 1.72F, 1.72F, 1.73F, 1.74F, 1.76F, 1.8F};
    private static final float[] REALLY_WORLD_XZ = {1.6F, 1.63F, 1.66F, 1.71F, 1.73F, 1.81F, 1.81F, 1.81F, 1.81F};
    private static final float[] REALLY_WORLD_Y = {1.6F, 1.62F, 1.6F, 1.62F, 1.64F, 1.68F, 1.75F, 1.9F, 2.16F};

    public final MultiBooleanSetting render;

    private final BooleanSetting boost;
    private final ModeSetting mode;
    private final BooleanSetting renderAngles;
    private final BooleanSetting individualY;
    private final BooleanSetting customAcceleration;

    private final NumberSetting xz0_5;
    private final NumberSetting xz5_10;
    private final NumberSetting xz10_15;
    private final NumberSetting xz15_20;
    private final NumberSetting xz20_25;
    private final NumberSetting xz25_30;
    private final NumberSetting xz30_35;
    private final NumberSetting xz35_40;
    private final NumberSetting xz40_45;

    private final NumberSetting y0_5;
    private final NumberSetting y5_10;
    private final NumberSetting y10_15;
    private final NumberSetting y15_20;
    private final NumberSetting y20_25;
    private final NumberSetting y25_30;
    private final NumberSetting y30_35;
    private final NumberSetting y35_40;
    private final NumberSetting y40_45;
    private final NumberSetting y45_50;
    private final NumberSetting y50_55;

    private final NumberSetting[] xzSliders;
    private final NumberSetting[] yGroupSliders;
    private final NumberSetting[] individualYSettings;
    private final NumberSetting[] yStartDegreeSliders;
    private final NumberSetting[] yFurtherDegreeSliders;

    private SuperFirework() {
        super("Super Firework", "Speeds up elytra flight", Category.MOVEMENT);
        this.boost = new BooleanSetting("Boost", true);
        this.mode = new ModeSetting("Boost mode", "ReallyWorld", boost::isEnabled,
                "ReallyWorld", "Bravo", "BravoGrief", "Custom");
        this.renderAngles = new BooleanSetting("Angles", false);
        this.render = new MultiBooleanSetting("Display", () -> mode.is("Custom"), renderAngles);
        this.individualY = new BooleanSetting("Individual Y", false,
                () -> boost.isEnabled() && mode.is("Custom"));
        this.customAcceleration = new BooleanSetting("Custom acceleration", false,
                () -> boost.isEnabled() && mode.is("Custom") && individualY.isEnabled());

        this.xz0_5 = new NumberSetting("XZ 0-5°", 1.52F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom"));
        this.xz5_10 = new NumberSetting("XZ 5-10°", 1.53F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom"));
        this.xz10_15 = new NumberSetting("XZ 10-15°", 1.54F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom"));
        this.xz15_20 = new NumberSetting("XZ 15-20°", 1.55F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom"));
        this.xz20_25 = new NumberSetting("XZ 20-25°", 1.56F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom"));
        this.xz25_30 = new NumberSetting("XZ 25-30°", 1.57F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom"));
        this.xz30_35 = new NumberSetting("XZ 30-35°", 1.58F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom"));
        this.xz35_40 = new NumberSetting("XZ 35-40°", 1.59F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom"));
        this.xz40_45 = new NumberSetting("XZ 40-45°", 1.6F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom"));

        this.y0_5 = new NumberSetting("Y 0-5°", 1.51F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());
        this.y5_10 = new NumberSetting("Y 5-10°", 1.52F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());
        this.y10_15 = new NumberSetting("Y 10-15°", 1.53F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());
        this.y15_20 = new NumberSetting("Y 15-20°", 1.54F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());
        this.y20_25 = new NumberSetting("Y 20-25°", 1.55F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());
        this.y25_30 = new NumberSetting("Y 25-30°", 1.56F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());
        this.y30_35 = new NumberSetting("Y 30-35°", 1.57F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());
        this.y35_40 = new NumberSetting("Y 35-40°", 1.58F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());
        this.y40_45 = new NumberSetting("Y 40-45°", 1.59F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());
        this.y45_50 = new NumberSetting("Y 45-50°", 1.6F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());
        this.y50_55 = new NumberSetting("Y 50-55°", 1.61F, 1.5F, 3.0F, 0.01F,
                () -> boost.isEnabled() && mode.is("Custom") && !individualY.isEnabled());

        this.individualYSettings = new NumberSetting[Y_DEGREE_COUNT];
        this.yStartDegreeSliders = new NumberSetting[Y_DEGREE_COUNT];
        this.yFurtherDegreeSliders = new NumberSetting[Y_DEGREE_COUNT];

        this.xzSliders = new NumberSetting[]{
                xz0_5, xz5_10, xz10_15, xz15_20, xz20_25, xz25_30, xz30_35, xz35_40, xz40_45
        };
        this.yGroupSliders = new NumberSetting[]{
                y0_5, y5_10, y10_15, y15_20, y20_25, y25_30, y30_35, y35_40, y40_45, y45_50, y50_55
        };

        for (int i = 0; i < Y_DEGREE_COUNT; i++) {
            float defaultSpeed = 1.5F + (i / 55.0F) * 0.11F;
            int degree = i;
            individualYSettings[i] = new NumberSetting("Y " + degree + "°", defaultSpeed, 1.5F, 3.0F, 0.01F,
                    () -> boost.isEnabled() && mode.is("Custom")
                            && individualY.isEnabled() && !customAcceleration.isEnabled());
            yStartDegreeSliders[i] = new NumberSetting("Y start " + degree + "°", defaultSpeed, 1.5F, 3.0F, 0.01F,
                    () -> boost.isEnabled() && mode.is("Custom")
                            && individualY.isEnabled() && customAcceleration.isEnabled());
            yFurtherDegreeSliders[i] = new NumberSetting("Y further " + degree + "°", defaultSpeed, 1.5F, 3.0F, 0.01F,
                    () -> boost.isEnabled() && mode.is("Custom")
                            && individualY.isEnabled() && customAcceleration.isEnabled());
        }

        addSettings(boost, mode, individualY, customAcceleration);
        addSettings(xzSliders);
        addSettings(yGroupSliders);
        addSettings(individualYSettings);
        for (int i = 0; i < Y_DEGREE_COUNT; i++) {
            addSettings(yStartDegreeSliders[i], yFurtherDegreeSliders[i]);
        }
        addSettings(render);
    }

    private void addSettings(NumberSetting[] settings) {
        for (NumberSetting setting : settings) {
            addSettings(setting);
        }
    }

    @EventTarget
    public void onFirework(FireworkRocketEntityTickEvent event) {
        if (!boost.isEnabled() || mc.player == null || !mc.player.isGliding()) {
            return;
        }
        if (ElytraTarget.INSTANCE.slowdownActive) {
            return;
        }

        AttackAura aura = AttackAura.INSTANCE;
        float yaw = MathHelper.wrapDegrees(mc.player.getYaw());
        float pitch = mc.player.getPitch();

        if (aura != null && aura.isEnabled() && aura.getTarget() != null) {
            yaw = MathHelper.wrapDegrees(AttackAura.rotate.x);
            pitch = AttackAura.rotate.y;
        }

        if (mode.is("Custom")) {
            boolean startPhase = customAcceleration.isEnabled()
                    && event.getFireworkAge() < ACCELERATION_PHASE_TICKS;
            float xzSpeed = getCustomSpeed(yaw, xzSliders);
            float ySpeed;
            if (individualY.isEnabled()) {
                ySpeed = getIndividualYSpeed(pitch, startPhase);
            } else {
                ySpeed = getCustomSpeed(pitch, yGroupSliders);
            }
            if (ySpeed > xzSpeed) {
                xzSpeed = ySpeed;
            }
            event.setSpeed(xzSpeed);
            event.setYSpeed(ySpeed);
        } else if (mode.is("Bravo")) {
            event.setSpeed(getBravoSpeedXZ(pitch, yaw));
            event.setYSpeed(getBravoSpeedY(pitch));
        } else if (mode.is("BravoGrief")) {
            event.setSpeed(getTableSpeed(BRAVO_GRIEF_XZ, yaw, 9));
            event.setYSpeed(getTableSpeed(BRAVO_GRIEF_Y, pitch, 9));
        } else if (mode.is("ReallyWorld")) {
            float xzSpeed = getTableSpeed(REALLY_WORLD_XZ, yaw, 9);
            float ySpeed = getTableSpeed(REALLY_WORLD_Y, pitch, 9);
            if (ySpeed > xzSpeed) {
                xzSpeed = ySpeed;
            }
            event.setSpeed(xzSpeed);
            event.setYSpeed(ySpeed);
        }
    }

    @EventTarget
    private void onRender(OverlayRenderEvent event) {
        if (mc.player == null || mc.world == null
                || (mc.getDebugHud() != null && mc.getDebugHud().shouldShowDebugHud())) {
            return;
        }

        if (!mode.is("Custom") || !render.is("Angles")) {
            return;
        }

        int centerX = mc.getWindow().getScaledWidth() / 2;
        String pitch = String.valueOf((int) mc.player.getPitch());
        String label = "Pitch: " + pitch;
        int labelWidth = mc.textRenderer.getWidth(label);
        int x = centerX - labelWidth / 2;
        int y = mc.getWindow().getScaledHeight() / 2 + 25;
        event.getContext().drawText(mc.textRenderer, label, x, y, -1, true);
    }

    private void syncAccelerationFromIndividualY() {
        if (!individualY.isEnabled() || !customAcceleration.isEnabled()) {
            return;
        }

        for (int degree = 0; degree < Y_DEGREE_COUNT; degree++) {
            float value = individualYSettings[degree].getCurrent();
            yStartDegreeSliders[degree].set(value);
            yFurtherDegreeSliders[degree].set(value);
        }
    }

    private float getIndividualYSpeed(float pitch, boolean startPhase) {
        float angle = convertAngleForIndividual(pitch);
        int degree = Math.round(angle);
        if (degree < 0) {
            degree = 0;
        }
        if (degree > Y_DEGREE_COUNT - 1) {
            degree = Y_DEGREE_COUNT - 1;
        }

        if (customAcceleration.isEnabled()) {
            return startPhase
                    ? yStartDegreeSliders[degree].getCurrent()
                    : yFurtherDegreeSliders[degree].getCurrent();
        }
        return individualYSettings[degree].getCurrent();
    }

    private float getCustomSpeed(float angle, NumberSetting[] sliders) {
        float converted = convertAngle(angle);
        int index = (int) (converted / 5.0F);
        if (index >= sliders.length) {
            index = sliders.length - 1;
        }
        if (index < 0) {
            index = 0;
        }
        return sliders[index].getCurrent();
    }

    private static float getTableSpeed(float[] table, float angle, int tableLength) {
        int index = (int) (convertAngleStatic(angle) / 5.0F);
        if (index >= tableLength) {
            index = tableLength - 1;
        }
        if (index < 0) {
            index = 0;
        }
        return table[index];
    }

    private float getBravoSpeedXZ(float pitch, float yaw) {
        float absPitch = Math.abs(pitch);
        float yawOffset = Math.abs(MathHelper.wrapDegrees(yaw) % 90.0F);

        float speed = absPitch >= 38.0F && absPitch <= 52.0F ? 2.0F
                : absPitch >= 32.0F && absPitch <= 58.0F ? 1.96F
                : absPitch >= 28.0F && absPitch <= 62.0F ? 1.95F
                : (yawOffset >= 29.0F && yawOffset <= 61.0F) || (absPitch >= 29.0F && absPitch <= 61.0F) ? 1.963F
                : (yawOffset >= 28.0F && yawOffset <= 60.0F) || (absPitch >= 28.0F && absPitch <= 60.0F) ? 1.954F
                : (yawOffset >= 26.0F && yawOffset <= 64.0F) || (absPitch >= 26.0F && absPitch <= 64.0F) ? 1.874F
                : (yawOffset >= 24.0F && yawOffset <= 66.0F) || (absPitch >= 24.0F && absPitch <= 66.0F) ? 1.75F
                : (yawOffset >= 15.0F && yawOffset <= 75.0F) || (absPitch >= 15.0F && absPitch <= 75.0F) ? 1.75F
                : (yawOffset >= 13.0F && yawOffset <= 77.0F) || (absPitch >= 13.0F && absPitch <= 77.0F) ? 1.75F
                : (yawOffset >= 12.0F && yawOffset <= 78.0F) || (absPitch >= 12.0F && absPitch <= 78.0F) ? 1.75F
                : (yawOffset >= 8.0F && yawOffset <= 82.0F) || (absPitch >= 11.0F && absPitch <= 79.0F) ? 1.75F
                : (yawOffset >= 5.0F && yawOffset <= 85.0F) || (absPitch >= 8.0F && absPitch <= 82.0F) ? 1.67F
                : yawOffset <= 90.0F || absPitch <= 90.0F ? 1.67F
                : 1.66F;

        return pitch > 15.0F ? speed - 0.068F : speed;
    }

    private float getBravoSpeedY(float pitch) {
        float absPitch = Math.abs(pitch);
        if (absPitch >= 37.0F && absPitch <= 38.0F) {
            return 2.03F;
        }
        if (absPitch >= 25.0F && absPitch <= 30.0F) {
            return 2.0F;
        }
        if (absPitch >= 35.0F && absPitch <= 45.0F) {
            return 1.99F;
        }
        if (absPitch >= 40.0F && absPitch <= 50.0F) {
            return 1.97F;
        }
        if (absPitch >= 50.0F && absPitch <= 60.0F) {
            return 1.96F;
        }
        if (absPitch >= 51.0F && absPitch <= 61.0F) {
            return 1.85F;
        }
        if (absPitch >= 52.0F && absPitch <= 65.0F) {
            return 1.8F;
        }
        return 1.59F;
    }

    private float convertAngle(float angle) {
        float converted = Math.abs(angle);
        if (converted > 90.0F) {
            converted = 180.0F - converted;
        }
        if (converted > 45.0F) {
            converted = 90.0F - converted;
        }
        return converted;
    }

    private static float convertAngleStatic(float angle) {
        float converted = Math.abs(angle);
        if (converted > 90.0F) {
            converted = 180.0F - converted;
        }
        if (converted > 45.0F) {
            converted = 90.0F - converted;
        }
        return converted;
    }

    private float convertAngleForIndividual(float angle) {
        float converted = Math.abs(angle);
        if (converted > 90.0F) {
            converted = 180.0F - converted;
        }
        return converted;
    }
}
