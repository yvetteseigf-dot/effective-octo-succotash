package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;

public final class AirJump extends Module {
    public static final AirJump INSTANCE = new AirJump();

    private boolean wasJumpPressed;

    private AirJump() {
        super("Air Jump", "Lets you jump multiple times without touching the ground", Category.MOVEMENT);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.options == null) {
            return;
        }

        boolean jumpPressed = mc.options.jumpKey.isPressed();
        if (jumpPressed && !wasJumpPressed && !mc.player.isOnGround()) {
            mc.player.jump();
        }

        wasJumpPressed = jumpPressed;
    }

    @Override
    public void onDisable() {
        wasJumpPressed = false;
        super.onDisable();
    }
}
