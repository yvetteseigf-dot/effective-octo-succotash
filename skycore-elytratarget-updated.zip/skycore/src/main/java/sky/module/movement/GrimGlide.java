package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;
import sky.scheduler.TickRateLimiter;
import sky.event.player.MotionEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.CooldownTimer;
import sky.util.combat.HealthUtil;
import sky.util.math.MathUtil;
import sky.util.entity.PlayerUtil;

public final class GrimGlide extends Module {
    public static final GrimGlide INSTANCE = new GrimGlide();

    private final CooldownTimer ticks;

    private GrimGlide() {
        super("GrimGlide", "Elytra acceleration without fireworks", Category.MOVEMENT);
        ticks = new CooldownTimer();
    }

    public static boolean isGlideFlyActive() {
        return INSTANCE.isEnabled() && mc.player != null && mc.player.isGliding();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        TickRateLimiter.reset();
        ticks.reset();
    }

    @Override
    public void onDisable() {
        TickRateLimiter.reset();
        super.onDisable();
    }

    @EventTarget
    public void onMotion(MotionEvent event) {
        if (mc.player == null || mc.world == null || !mc.player.isGliding()) {
            return;
        }

        Vec3d position = mc.player.getPos();
        float yaw = mc.player.getYaw();
        double step = 0.087D;

        double bps = MathUtil.getBps(mc.player, 1);
        float speedLimit = isReallyWorldServer() ? 40.0F : 100.0F;
        if (bps >= speedLimit) {
            step = 0.0D;
        }

        double motionX = -Math.sin(Math.toRadians(yaw)) * step;
        double motionZ = Math.cos(Math.toRadians(yaw)) * step;
        float boost = MathUtil.randomtest(1.1F, 1.21F);

        if (step > 0.0D) {
            mc.player.setVelocity(motionX * boost, mc.player.getVelocity().y - 0.02D, motionZ * boost);
        }

        double targetY = event.getY();
        double targetX;
        double targetZ;
        if (step > 0.0D && ticks.finished(50.0D)) {
            targetX = position.x + motionX;
            targetZ = position.z + motionZ;
            ticks.reset();
        } else if (step > 0.0D) {
            targetX = event.getX() + motionX;
            targetZ = event.getZ() + motionZ;
        } else {
            targetX = event.getX();
            targetZ = event.getZ();
        }

        if (step > 0.0D) {
            mc.player.setVelocity(motionX * boost, mc.player.getVelocity().y + 0.016D, motionZ * boost);
        }

        mc.player.setPosition(targetX, targetY, targetZ);
        event.setX(targetX);
        event.setY(targetY);
        event.setZ(targetZ);
        event.setCancelled(true);

        PlayerUtil.sendPacketWithOutEvent(new PlayerMoveC2SPacket.Full(
                targetX,
                targetY,
                targetZ,
                event.getYaw(),
                event.getPitch(),
                event.isOnGround(),
                mc.player.horizontalCollision));
    }

    private boolean isReallyWorldServer() {
        return HealthUtil.isConnectedToServer("reallyworld") || HealthUtil.isConnectedToServer("playrw");
    }
}
