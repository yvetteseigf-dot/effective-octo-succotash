package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.shape.VoxelShapes;
import sky.config.ModeSetting;
import sky.config.NumberSetting;
import sky.event.entity.NoPushEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.world.BlockCollideShapeEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.entity.MovementUtil;

public final class Jesus extends Module {
    public static final Jesus INSTANCE = new Jesus();

    private static final String MODE_CUSTOM = "Custom";
    private static final String MODE_RW_JUMP = "RW Jump";

    private final ModeSetting mode;
    private final NumberSetting speed;

    private Jesus() {
        super("Jesus", "Lets you walk and run on the water surface", Category.MOVEMENT);
        mode = new ModeSetting("Mode", MODE_CUSTOM, MODE_CUSTOM, MODE_RW_JUMP);
        speed = new NumberSetting("Speed", 0.2F, 0.05F, 1.05F, 0.01F, () -> mode.is(MODE_CUSTOM));
        addSettings(mode, speed);
    }

    @EventTarget
    public void onBlockCollide(BlockCollideShapeEvent event) {
        if (!mode.is(MODE_CUSTOM) || mc.player == null || mc.world == null || mc.options == null) {
            return;
        }
        if (mc.options.sneakKey.isPressed() || event.getPos() == null) {
            return;
        }
        if (!mc.world.getBlockState(event.getPos()).isOf(Blocks.WATER)) {
            return;
        }
        if (mc.player.getY() < event.getPos().getY() + 0.99D) {
            return;
        }

        event.setVoxelShape(VoxelShapes.cuboid(0.0D, 0.0D, 0.0D, 1.0D, 0.99D, 1.0D));
    }

    @EventTarget
    public void onNoPush(NoPushEvent event) {
        if (mode.is(MODE_CUSTOM) && event.getNoPushType() == NoPushEvent.NoPushType.Water) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.world == null || mc.options == null) {
            return;
        }

        if (!mc.player.isTouchingWater() && !mc.player.isSubmergedInWater()) {
            return;
        }

        if (mode.is(MODE_RW_JUMP)) {
            if (mc.options.jumpKey.isPressed()) {
                mc.player.setVelocity(mc.player.getVelocity().x, 0.13D, mc.player.getVelocity().z);
            }
            return;
        }

        float currentSpeed = speed.get();
        if (mc.player.hasStatusEffect(StatusEffects.DOLPHINS_GRACE)) {
            currentSpeed *= 1.15F;
        }

        if (!MovementUtil.hasPlayerMovement()) {
            mc.player.setVelocity(0.0D, mc.player.getVelocity().y, 0.0D);
            return;
        }

        double[] direction = MovementUtil.calculateDirection(currentSpeed);
        mc.player.setVelocity(direction[0], mc.options.jumpKey.isPressed() ? 0.1D : 0.02D, direction[1]);
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            mc.options.jumpKey.setPressed(false);
        }
        super.onDisable();
    }
}
