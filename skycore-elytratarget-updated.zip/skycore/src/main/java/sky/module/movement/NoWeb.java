package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.Vec3d;
import sky.config.ModeSetting;
import sky.config.NumberSetting;
import sky.event.entity.WebCollisionEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.entity.MovementUtil;
import sky.util.entity.PlayerUtil;

public final class NoWeb extends Module {
    public static final NoWeb INSTANCE = new NoWeb();

    private final ModeSetting mode;
    private final NumberSetting speedXZ;
    private final NumberSetting speedY;

    private NoWeb() {
        super("NoWeb", "Removes slowdown in cobwebs", Category.MOVEMENT);
        mode = new ModeSetting("Mode", "Custom", "Custom", "ReallyWorld");
        speedXZ = new NumberSetting("XZ Speed", 0.1F, 0.1F, 1.0F, 0.1F);
        speedY = new NumberSetting("Y Speed", 0.1F, 0.1F, 4.0F, 0.1F);
        addSettings(mode, speedXZ, speedY);
    }

    @EventTarget
    public void onWebCollision(WebCollisionEvent event) {
        event.setCancelled(true);
    }

    @EventTarget
    private void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (mode.is("Custom")) {
            customMode();
        } else if (mode.is("ReallyWorld")) {
            reallyWorldMode();
        }
    }

    private void customMode() {
        if (!PlayerUtil.isPlayerInBlock(Blocks.COBWEB)) {
            return;
        }

        Vec3d velocity = mc.player.getVelocity();
        mc.player.setVelocity(velocity.x, 0.0D, velocity.z);

        if (mc.options.jumpKey.isPressed()) {
            mc.player.setVelocity(velocity.x, speedY.getCurrent(), velocity.z);
        }
        if (mc.options.sneakKey.isPressed()) {
            mc.player.setVelocity(velocity.x, -speedY.getCurrent(), velocity.z);
        }

        MovementUtil.setVelocity(speedXZ.getCurrent());
    }

    private void reallyWorldMode() {
        if (!PlayerUtil.isPlayerInBlock(Blocks.COBWEB)) {
            return;
        }

        Vec3d velocity = mc.player.getVelocity();
        mc.player.setVelocity(velocity.x, 0.0D, velocity.z);

        if (mc.options.jumpKey.isPressed()) {
            mc.player.setVelocity(velocity.x, 0.9D, velocity.z);
        }
        if (mc.options.sneakKey.isPressed()) {
            mc.player.setVelocity(velocity.x, -0.9D, velocity.z);
        }

        MovementUtil.setVelocity(0.21D);
    }
}
