package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.config.ModeSetting;
import sky.config.NumberSetting;
import sky.event.entity.NoPushEvent;
import sky.event.entity.TravelPostEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.entity.MovementUtil;

public final class WaterSpeed extends Module {
    public static final WaterSpeed INSTANCE = new WaterSpeed();

    private static final String MODE_MOTION = "Speed";
    private static final String MODE_LEGIT = "Legit";
    private static final String MODE_SWIM_BOOST = "Swim Boost";

    private final ModeSetting mode;
    private final NumberSetting speed;
    private final BooleanSetting autoKeys;

    private boolean wasInWater;
    private int tickCounter;

    private WaterSpeed() {
        super("WaterSpeed", "Speeds up movement in water in different ways", Category.MOVEMENT);
        this.mode = new ModeSetting("Mode", MODE_MOTION, MODE_MOTION, MODE_LEGIT, MODE_SWIM_BOOST);
        this.speed = new NumberSetting("Speed", 0.5F, 0.1F, 2.0F, 0.05F, () -> mode.is(MODE_MOTION));
        this.autoKeys = new BooleanSetting("Auto jump/sneak", false, () -> mode.is(MODE_LEGIT));
        addSettings(mode, speed, autoKeys);
    }

    @Override
    public void onDisable() {
        tickCounter = 0;
        if (mc.options != null) {
            mc.options.jumpKey.setPressed(false);
            mc.options.sneakKey.setPressed(false);
        }
        super.onDisable();
    }

    @EventTarget
    public void onNoPush(NoPushEvent event) {
        if (event.getNoPushType() == NoPushEvent.NoPushType.Water) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onTravelPost(TravelPostEvent event) {
        if (mc.player == null || mc.world == null || mc.options == null || !mc.player.isTouchingWater()) {
            return;
        }

        Vec3d velocity = event.getOldVelocity();
        if (velocity == null) {
            velocity = mc.player.getVelocity();
        }

        if (mode.is(MODE_SWIM_BOOST) && mc.options.jumpKey.isPressed()) {
            double x = velocity.x;
            double z = velocity.z;
            double horizontal = Math.sqrt(x * x + z * z);
            if (horizontal > 0.01D) {
                x *= 1.05D;
                z *= 1.05D;
            }
            event.setOldVelocity(new Vec3d(x, 0.12D, z));
            return;
        }

        if (mode.is(MODE_MOTION) && MovementUtil.hasPlayerMovement()) {
            double[] direction = MovementUtil.calculateDirection(speed.get());
            event.setOldVelocity(new Vec3d(direction[0], velocity.y, direction[1]));
        }
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null || mc.options == null) {
            return;
        }

        if (!mc.player.isTouchingWater()) {
            if (wasInWater) {
                wasInWater = false;
            }
            tickCounter = 0;
            return;
        }

        wasInWater = true;

        if (mode.is(MODE_LEGIT) && autoKeys.isEnabled()) {
            tickCounter++;
            boolean pressJump = tickCounter % 10 < 5;
            mc.options.jumpKey.setPressed(pressJump);
            mc.options.sneakKey.setPressed(!pressJump);
        }
    }
}
