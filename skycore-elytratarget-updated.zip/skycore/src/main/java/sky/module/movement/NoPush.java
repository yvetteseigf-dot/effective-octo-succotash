package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import sky.config.BooleanSetting;
import sky.config.MultiBooleanSetting;
import sky.event.entity.NoPushEvent;
import sky.module.Category;
import sky.module.Module;

public final class NoPush extends Module {
    public static final NoPush INSTANCE = new NoPush();

    public final MultiBooleanSetting mode;
    public final BooleanSetting blocksVisibility;

    private NoPush() {
        super("No Push", "Prevents knockback under certain conditions, keeping movement stable", Category.MOVEMENT);
        mode = new MultiBooleanSetting("Type",
                new BooleanSetting("Players", true),
                new BooleanSetting("Blocks", true),
                new BooleanSetting("Water", true),
                new BooleanSetting("Fishing rods", true));
        blocksVisibility = new BooleanSetting("Visibility in blocks", true, () -> mode.is("Blocks"));
        addSettings(mode, blocksVisibility);
    }

    public static boolean allowsBlockVisibility() {
        return INSTANCE.isEnabled() && INSTANCE.mode.is("Blocks") && INSTANCE.blocksVisibility.isEnabled();
    }

    @EventTarget
    public void onEvent(NoPushEvent event) {
        boolean ignorePush = switch (event.getNoPushType()) {
            case Block -> mode.is("Blocks");
            case Water -> mode.is("Water");
            case Player -> mode.is("Players");
            case FishingRod -> mode.is("Fishing rods");
        };

        if (ignorePush) {
            event.setCancelled(true);
        }
    }
}
