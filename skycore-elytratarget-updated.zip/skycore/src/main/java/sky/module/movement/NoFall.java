package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;

public final class NoFall extends Module {
    public static final NoFall INSTANCE = new NoFall();

    private NoFall() {
        super("No Fall", "Cancels fall damage from height", Category.MOVEMENT);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.getNetworkHandler() == null) {
            return;
        }

        if (!mc.player.isOnGround() && mc.player.fallDistance > 1.0F) {
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
                    mc.player.getX(),
                    mc.player.getY() + 1.0E-9D,
                    mc.player.getZ(),
                    mc.player.getYaw(),
                    mc.player.getPitch(),
                    true,
                    mc.player.horizontalCollision));
            mc.player.onLanding();
        }
    }
}
