package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.config.ModeSetting;
import sky.config.NumberSetting;
import sky.event.player.PlayerMoveEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.MsTimer;

public final class Strafe extends Module {
    public static final Strafe INSTANCE = new Strafe();

    private final ModeSetting mode;
    private final NumberSetting boostSpeed;
    private final MsTimer timer;
    private final BooleanSetting dmgBoost;

    private double prevSpeed;

    private Strafe() {
        super("Strafe", "Improved strafe movement with anti-cheat bypasses", Category.MOVEMENT);
        this.mode = new ModeSetting("Mode", "Default", "Default", "Matrix", "MetaHVH");
        this.dmgBoost = new BooleanSetting("Damage Boost", false);
        this.boostSpeed = new NumberSetting("Boost Speed", 0.7F, 0.1F, 5.0F, 0.1F, () -> dmgBoost.isEnabled());
        this.timer = new MsTimer();
        addSettings(mode, dmgBoost, boostSpeed);
    }

    @EventTarget
    public void onMove(PlayerMoveEvent event) {
        if (mc.player == null) {
            return;
        }

        if (!isMove()) {
            prevSpeed = 0.0D;
            return;
        }

        double speed = getBaseSpeed();
        if (dmgBoost.isEnabled() && timer.finished(700L)) {
            speed += boostSpeed.getCurrent();
            timer.reset();
        }

        if (mode.is("Matrix")) {
            applyMatrix(event);
            return;
        }

        if (mode.is("MetaHVH")) {
            speed *= 1.2D;
        }

        applyMove(event, speed);
        prevSpeed = speed;
    }

    private void applyMatrix(PlayerMoveEvent event) {
        double speed = 0.25D - Math.random() * 0.001D;
        applyMove(event, speed);
        prevSpeed = speed;
    }

    private void applyMove(PlayerMoveEvent event, double speed) {
        float yaw = mc.player.getYaw();
        float forward = getForward();
        float strafe = getStrafe();

        if (forward == 0.0F && strafe == 0.0F) {
            return;
        }

        double yawRadians = Math.toRadians(yaw);
        double moveX = (strafe * Math.cos(yawRadians) - forward * Math.sin(yawRadians)) * speed;
        double moveZ = (strafe * Math.sin(yawRadians) + forward * Math.cos(yawRadians)) * speed;
        event.setMovePos(new Vec3d(moveX, event.getMovePos().y, moveZ));
    }

    private double getBaseSpeed() {
        double speed = 0.2873D;
        StatusEffectInstance speedEffect = mc.player.getStatusEffect(StatusEffects.SPEED);
        if (speedEffect != null) {
            speed = 0.2873D * (1.0D + 0.2D * (speedEffect.getAmplifier() + 1));
        }
        return speed;
    }

    private boolean isMove() {
        return mc.options.forwardKey.isPressed()
                || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed()
                || mc.options.rightKey.isPressed();
    }

    private float getForward() {
        KeyBinding forwardKey = mc.options.forwardKey;
        KeyBinding backKey = mc.options.backKey;
        return (forwardKey.isPressed() ? 1.0F : 0.0F) - (backKey.isPressed() ? 1.0F : 0.0F);
    }

    private float getStrafe() {
        KeyBinding leftKey = mc.options.leftKey;
        KeyBinding rightKey = mc.options.rightKey;
        return (leftKey.isPressed() ? 1.0F : 0.0F) - (rightKey.isPressed() ? 1.0F : 0.0F);
    }

    @Override
    public void onDisable() {
        prevSpeed = 0.0D;
        super.onDisable();
    }
}
