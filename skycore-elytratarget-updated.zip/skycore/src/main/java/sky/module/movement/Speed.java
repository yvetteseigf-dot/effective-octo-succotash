package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.math.Vec3d;
import sky.config.ModeSetting;
import sky.scheduler.TimerSpeedController;
import sky.event.network.PacketSendEvent;
import sky.event.player.MotionPostEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.entity.MovePostEvent;
import sky.event.input.StrafeInputEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.entity.MovementUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Speed extends Module {
    public static final Speed INSTANCE = new Speed();

    private static final double STRONG_GROUND_BOOST = 0.055D;
    private static final double NORMAL_GROUND_BOOST = 0.03D;
    private static final double BOOST_STRAFE_SPEED = 0.05D;
    private static final double BOOST_VERTICAL_OFFSET = 0.015D;

    private final ModeSetting mode;
    private final Map<Entity, Vec3d> previousPositions;

    private int ticks;
    private int groundTicks;
    private int setbackBoostTicks;

    private Speed() {
        super("Speed", "Lets you boost off collisions", Category.MOVEMENT);
        mode = new ModeSetting("Mode", "RW", "RW", "Collision");
        previousPositions = new HashMap<>();
        addSettings(mode);
    }

    @Override
    public void onEnable() {
        resetRWState(true);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        previousPositions.clear();
        resetRWState(true);
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mode.is("RW")) {
            if (setbackBoostTicks > 0) {
                setbackBoostTicks--;
            }
            return;
        }

        if (mc.player == null || mc.world == null) {
            return;
        }

        previousPositions.keySet().removeIf(entity -> entity.isRemoved() || !entity.isAlive());

        if (!MovementUtil.hasPlayerMovement()) {
            return;
        }

        List<Entity> nearbyPlayers = mc.world.getOtherEntities(mc.player, mc.player.getBoundingBox().expand(1.25D));
        for (Entity entity : nearbyPlayers) {
            if (entity == mc.player) {
                continue;
            }
            if (!(entity instanceof PlayerEntity)) {
                continue;
            }

            double offsetX = Math.abs(mc.player.getX() - entity.getX());
            double offsetZ = Math.abs(mc.player.getZ() - entity.getZ());
            if (offsetX > 2.1D || offsetZ > 1.3D) {
                continue;
            }

            double entitySpeed = getEntitySpeed(entity);
            if (entitySpeed < 5.0D) {
                List<Entity> touching = mc.world.getOtherEntities(mc.player, mc.player.getBoundingBox().expand(0.1D));
                int touchingCount = 0;
                for (Entity other : touching) {
                    if (other != mc.player
                            && (!(other instanceof ArmorStandEntity) || other instanceof BoatEntity)) {
                        touchingCount++;
                    }
                }

                if (touchingCount > 0) {
                    double[] motion = forward(0.02D);
                    mc.player.addVelocity(motion[0], 0.0D, motion[1]);
                }
                return;
            }

            List<Entity> colliding = mc.world.getOtherEntities(mc.player, mc.player.getBoundingBox().expand(1.25D));
            int collidingCount = 0;
            for (Entity other : colliding) {
                if (other != mc.player
                        && (!(other instanceof ArmorStandEntity) || other instanceof BoatEntity)
                        && mc.player.distanceTo(other) <= 1.25D) {
                    collidingCount++;
                }
            }

            if (collidingCount > 0) {
                double[] motion = forward(0.032D);
                mc.player.addVelocity(motion[0], 0.0D, motion[1]);
            }
            return;
        }
    }

    @EventTarget
    public void onMovePost(MovePostEvent event) {
        if (!mode.is("RW") || !canUseRW() || mc.player == null) {
            resetRWState(true);
            return;
        }

        TimerSpeedController.setSpeed(1.7F);

        if (ticks > 3) {
            if (setbackBoostTicks >= 1) {
                applyGroundBoost(BOOST_STRAFE_SPEED, BOOST_VERTICAL_OFFSET);
            } else {
                double boost = NORMAL_GROUND_BOOST;
                if (ticks % 2 == 0) {
                    boost = mc.player.isOnGround() ? STRONG_GROUND_BOOST : NORMAL_GROUND_BOOST;
                }
                applyGroundBoost(boost, 0.0D);
            }
        }

        ticks++;
    }

    @EventTarget
    public void onPostUpdate(MotionPostEvent event) {
        if (!mode.is("RW")) {
            return;
        }

        if (!canUseRW()) {
            resetRWState(true);
            return;
        }

        if (ticks % 2 == 0) {
            TimerSpeedController.setSpeed(0.3F);
            mc.player.networkHandler.sendPacket(
                    new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        }
    }

    @EventTarget
    public void onMoveInput(StrafeInputEvent event) {
        if (!mode.is("RW") || mc.player == null || !MovementUtil.hasPlayerMovement()) {
            groundTicks = 0;
            return;
        }

        if (mc.player.verticalCollision) {
            groundTicks++;
        } else {
            groundTicks = 0;
        }

        if (groundTicks >= 1) {
            mc.player.jump();
        }
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (!mode.is("RW") || mc.player == null || !event.isReceive()) {
            return;
        }

        Packet<?> packet = event.getPacket();
        if (packet instanceof PlayerPositionLookS2CPacket) {
            setbackBoostTicks = 20;
            if (ticks % 3 == 1) {
                ticks++;
            }
            TimerSpeedController.setSpeed(1.9F);
        }
    }

    private boolean canUseRW() {
        return mc.player != null
                && mc.world != null
                && mc.player.networkHandler != null
                && MovementUtil.hasPlayerMovement()
                && !mc.player.hasVehicle()
                && !mc.player.getAbilities().flying;
    }

    private void resetRWState(boolean resetTimer) {
        ticks = 0;
        groundTicks = 0;
        setbackBoostTicks = 0;
        if (resetTimer) {
            TimerSpeedController.resetSpeed();
        }
    }

    private void applyGroundBoost(double horizontalBoost, double verticalBoost) {
        if (mc.player == null) {
            return;
        }
        double[] motion = forward(horizontalBoost);
        mc.player.addVelocity(motion[0], verticalBoost, motion[1]);
    }

    private double getEntitySpeed(Entity entity) {
        Vec3d position = entity.getPos();
        Vec3d previous = previousPositions.getOrDefault(entity, position);

        double deltaX = position.x - previous.x;
        double deltaZ = position.z - previous.z;
        double blocksPerSecond = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ) * 20.0D;

        previousPositions.put(entity, position);
        return blocksPerSecond;
    }

    private double[] forward(double speedValue) {
        float forward = mc.player.input.movementForward;
        float sideways = mc.player.input.movementSideways;
        float yaw = mc.player.getYaw();

        if (forward != 0.0F) {
            if (sideways > 0.0F) {
                yaw += forward > 0.0F ? -45.0F : 45.0F;
            } else if (sideways < 0.0F) {
                yaw += forward > 0.0F ? 45.0F : -45.0F;
            }
            sideways = 0.0F;
            forward = forward > 0.0F ? 1.0F : -1.0F;
        }

        double sin = Math.sin(Math.toRadians(yaw + 90.0F));
        double cos = Math.cos(Math.toRadians(yaw + 90.0F));

        return new double[] {
                forward * speedValue * cos + sideways * speedValue * sin,
                forward * speedValue * sin - sideways * speedValue * cos
        };
    }
}
