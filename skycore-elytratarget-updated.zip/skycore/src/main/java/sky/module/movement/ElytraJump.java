package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.event.camera.CameraUpdateEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.combat.ElytraTarget;
import sky.util.inventory.ItemSwapUtil;

public final class ElytraJump extends Module {
    public static final ElytraJump INSTANCE = new ElytraJump();

    private final BooleanSetting autoSwap;

    private ElytraJump() {
        super("Elytra Jump", "Takes off upward on an elytra without horizontal flight", Category.MOVEMENT);
        autoSwap = new BooleanSetting("Auto-equip elytra", false);
        addSettings(autoSwap);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.world == null || mc.options == null) {
            return;
        }
        if (mc.player.getAbilities().flying) {
            return;
        }

        if (mc.player.isOnGround()
                && !mc.player.isTouchingWater()
                && !mc.player.isSubmergedInWater()
                && isWearingElytra()
                && !mc.options.jumpKey.isPressed()) {
            mc.player.jump();
        }

        if (!mc.player.isOnGround()
                && !mc.player.isTouchingWater()
                && !mc.player.isSubmergedInWater()
                && !mc.player.isGliding()
                && canStartGlide()) {
            if (mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendPacket(
                        new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            }
            mc.player.startGliding();
        }

        if (mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isSubmergedInWater()) {
            mc.options.jumpKey.setPressed(false);
        }

        if (isWearingElytra()) {
            boolean elytraTargetActive = ElytraTarget.INSTANCE.isOvertakeEnabled() && mc.player.isGliding();
            if (!elytraTargetActive) {
                mc.options.jumpKey.setPressed(true);
                if (mc.player.isGliding()) {
                    applyVerticalBoost();
                }
            }
        } else if (autoSwap.isEnabled()) {
            swapElytraToChest();
        }
    }

    @EventTarget
    public void onRotation(CameraUpdateEvent event) {
        if (mc.player == null || !mc.player.isGliding() || !isWearingElytra()) {
            return;
        }

        if (event.getPitch() < -45.0F || event.getPitch() > 45.0F) {
            event.setPitch(0.0F);
        }
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            mc.options.jumpKey.setPressed(false);
        }

        if (autoSwap.isEnabled() && isWearingElytra()) {
            int chestSlot = ItemSwapUtil.getChestPlateSlot();
            if (chestSlot != -1) {
                ItemSwapUtil.moveToArmor(chestSlot, 6);
            }
        }

        super.onDisable();
    }

    private void applyVerticalBoost() {
        Vec3d velocity = mc.player.getVelocity();
        if (velocity.y > 0.05D || mc.player.fallDistance > 0.5F) {
            return;
        }

        mc.player.setVelocity(velocity.x, velocity.y + 0.08D, velocity.z);
    }

    private void swapElytraToChest() {
        int elytraSlot = ItemSwapUtil.getSlot(Items.ELYTRA);
        if (elytraSlot == -1) {
            return;
        }

        ItemSwapUtil.moveToArmor(elytraSlot, 6);
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
        }
    }

    private boolean isWearingElytra() {
        return mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
    }

    private boolean canStartGlide() {
        return isWearingElytra()
                && !mc.player.hasVehicle()
                && !mc.player.hasStatusEffect(StatusEffects.LEVITATION)
                && mc.player.getVelocity().y < 0.0D
                && mc.player.getEquippedStack(EquipmentSlot.CHEST).getDamage()
                        < mc.player.getEquippedStack(EquipmentSlot.CHEST).getMaxDamage() - 1;
    }
}
