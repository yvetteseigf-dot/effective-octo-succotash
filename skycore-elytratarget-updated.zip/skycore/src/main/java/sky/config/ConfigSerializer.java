package sky.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import sky.SkyInit;
import sky.module.Module;
import sky.hud.HudEditor;

import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;

/** Converts module state and HUD layout to and from the JSON stored in config files. */
public final class ConfigSerializer {
    private ConfigSerializer() {
    }

    public static JsonObject saveModules() {
        JsonObject modules = new JsonObject();
        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            JsonObject moduleData = new JsonObject();
            moduleData.addProperty("key", module.getBind());
            moduleData.addProperty("enabled", module.isEnabled());
            moduleData.addProperty("togglemode", module.getToggleMode().name());
            moduleData.addProperty("keybindvisible", module.isKeybindVisible());
            for (Setting<?> setting : module.getSettings()) {
                if (setting != null) {
                    saveSetting(moduleData, setting);
                }
            }
            modules.add(module.getName().toLowerCase(Locale.ROOT), moduleData);
        }
        return modules;
    }

    public static void loadModules(JsonObject modules) {
        if (modules == null) {
            return;
        }
        boolean suppressed = Module.isSuppressToggleEffects();
        Module.setSuppressToggleEffects(true);
        try {
            for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
                try {
                    JsonObject moduleData = getModuleData(modules, module);
                    if (moduleData == null) {
                        continue;
                    }
                    module.settoggled(false);
                    loadProperty(moduleData, "key", value -> module.setBind(value.getAsInt()));
                    loadProperty(moduleData, "togglemode", value -> {
                        try {
                            module.setToggleMode(Module.ToggleMode.valueOf(value.getAsString()));
                        } catch (Exception unknownMode) {
                            module.setToggleMode(Module.ToggleMode.TOGGLE);
                        }
                    });
                    loadProperty(moduleData, "keybindvisible", value -> module.setKeybindVisible(value.getAsBoolean()));
                    for (Setting<?> setting : module.getSettings()) {
                        if (setting != null) {
                            loadSetting(moduleData, setting);
                        }
                    }
                    loadLegacyTagSettings(module, moduleData);
                    loadProperty(moduleData, "enabled", value -> module.settoggled(value.getAsBoolean()));
                } catch (Exception exception) {
                    System.err.println("Failed to load module " + module.getName() + ": " + exception.getMessage());
                }
            }
        } finally {
            Module.setSuppressToggleEffects(suppressed);
        }
    }

    public static JsonObject saveHud() {
        return HudEditor.getInstance().savePositions();
    }

    public static void loadHud(JsonObject hud) {
        if (hud != null) {
            HudEditor.getInstance().loadPositions(hud);
        }
    }

    public static void resetToDefaults() {
        boolean suppressed = Module.isSuppressToggleEffects();
        Module.setSuppressToggleEffects(true);
        try {
            for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
                module.settoggled(false);
                module.setBind(-1);
                module.setToggleMode(Module.ToggleMode.TOGGLE);
                module.setKeybindVisible(true);
                for (Setting<?> setting : module.getSettings()) {
                    if (setting != null) {
                        setting.reset();
                    }
                }
            }
        } finally {
            Module.setSuppressToggleEffects(suppressed);
        }
    }

    public static void saveSetting(JsonObject moduleData, Setting<?> setting) {
        try {
            if (setting instanceof BooleanSetting booleanSetting) {
                JsonObject data = new JsonObject();
                data.addProperty("value", booleanSetting.get());
                data.addProperty("bind", -100);
                data.addProperty("keybindvisible", true);
                data.addProperty("togglemode", Module.ToggleMode.TOGGLE.name());
                moduleData.add(setting.getName(), data);
            } else if (setting instanceof MultiBooleanSetting multiSetting) {
                JsonObject data = new JsonObject();
                for (BooleanSetting option : multiSetting.getOptions()) {
                    data.addProperty(option.getName(), option.get());
                }
                moduleData.add(setting.getName(), data);
            } else if (setting instanceof NumberSetting numberSetting) {
                moduleData.addProperty(setting.getName(), numberSetting.get());
            } else if (setting instanceof ModeSetting modeSetting) {
                moduleData.addProperty(setting.getName(), modeSetting.get());
            } else if (setting instanceof ColorSetting colorSetting) {
                moduleData.addProperty(setting.getName(), colorSetting.get());
            } else if (setting instanceof KeybindSetting keybindSetting) {
                moduleData.addProperty(setting.getName(), keybindSetting.getKeyCode());
            }
        } catch (Exception exception) {
            System.err.println("Failed to save setting " + setting.getName() + ": " + exception.getMessage());
        }
    }

    public static void loadSetting(JsonObject moduleData, Setting<?> setting) {
        if (setting == null) {
            return;
        }
        JsonElement element = findSettingElement(moduleData, setting.getName());
        if (element == null || element.isJsonNull()) {
            return;
        }
        try {
            if (setting instanceof BooleanSetting booleanSetting) {
                booleanSetting.set(readBooleanValue(element));
            } else if (setting instanceof MultiBooleanSetting multiSetting) {
                if (!element.isJsonObject()) {
                    return;
                }
                JsonObject values = element.getAsJsonObject();
                for (Map.Entry<String, JsonElement> entry : values.entrySet()) {
                    String optionName = ConfigAliasRegistry.resolveOptionName(entry.getKey());
                    for (BooleanSetting option : multiSetting.getOptions()) {
                        if (option.getName().equals(optionName) || option.getName().equals(entry.getKey())) {
                            option.set(entry.getValue().getAsBoolean());
                            break;
                        }
                    }
                }
            } else if (setting instanceof NumberSetting numberSetting) {
                numberSetting.setClamped(element.getAsFloat());
            } else if (setting instanceof ModeSetting modeSetting) {
                String mode = element.getAsString();
                modeSetting.select(mode);
                if (!modeSetting.is(mode)) {
                    modeSetting.set(mode);
                }
            } else if (setting instanceof ColorSetting colorSetting) {
                colorSetting.set(element.getAsInt());
            } else if (setting instanceof KeybindSetting keybindSetting) {
                keybindSetting.setKeyCode(element.getAsInt());
            }
        } catch (Exception exception) {
            System.err.println("Failed to load setting " + setting.getName() + ": " + exception.getMessage());
        }
    }

    public static void loadProperty(JsonObject object, String key, Consumer<JsonElement> consumer) {
        JsonElement element = object.get(key);
        if (element != null && !element.isJsonNull()) {
            consumer.accept(element);
        }
    }

    private static JsonObject getModuleData(JsonObject modules, Module module) {
        JsonElement element = modules.get(module.getName().toLowerCase(Locale.ROOT));
        if (element != null && element.isJsonObject()) {
            return element.getAsJsonObject();
        }
        return findModuleData(modules, module);
    }

    private static JsonObject findModuleData(JsonObject modules, Module module) {
        String key = ConfigAliasRegistry.compactKey(module.getName());
        if (modules.has(key)) {
            return modules.getAsJsonObject(key);
        }
        for (Map.Entry<String, JsonElement> entry : modules.entrySet()) {
            if (!entry.getValue().isJsonObject()) {
                continue;
            }
            if (ConfigAliasRegistry.compactKey(entry.getKey()).equals(key)
                    || ConfigAliasRegistry.resolveModuleKey(entry.getKey()).equals(key)) {
                return entry.getValue().getAsJsonObject();
            }
        }
        return null;
    }

    private static JsonElement findSettingElement(JsonObject moduleData, String settingName) {
        if (moduleData.has(settingName)) {
            return moduleData.get(settingName);
        }
        String resolved = ConfigAliasRegistry.resolveSettingName(settingName);
        if (resolved != null && !resolved.equals(settingName) && moduleData.has(resolved)) {
            return moduleData.get(resolved);
        }
        for (Map.Entry<String, JsonElement> entry : moduleData.entrySet()) {
            String key = entry.getKey();
            if (key.equalsIgnoreCase(settingName)) {
                return entry.getValue();
            }
            String aliased = ConfigAliasRegistry.resolveSettingName(key);
            if (aliased != null && (aliased.equals(settingName) || aliased.equalsIgnoreCase(settingName))) {
                return entry.getValue();
            }
        }
        return null;
    }

    /**
     * Older configs stored the "tags" module options as flat booleans next to the module data
     * instead of nesting them under the setting they now belong to.
     */
    private static void loadLegacyTagSettings(Module module, JsonObject moduleData) {
        if (!ConfigAliasRegistry.compactKey(module.getName()).equals("tags")) {
            return;
        }
        for (Setting<?> setting : module.getSettings()) {
            if (setting == null) {
                continue;
            }
            if (setting instanceof MultiBooleanSetting multiSetting) {
                applyLegacyBoolean(moduleData, "rendering", multiSetting);
            }
            if (setting instanceof BooleanSetting booleanSetting) {
                switch (booleanSetting.getName()) {
                    case "Show effects" -> applyLegacyBoolean(moduleData, "vieweffects", booleanSetting);
                    case "Show armor" -> applyLegacyBoolean(moduleData, "viewarmor", booleanSetting);
                    case "Show enchantments" -> applyLegacyBoolean(moduleData, "viewenchants", booleanSetting);
                    case "Show offhand" -> applyLegacyBoolean(moduleData, "viewitem", booleanSetting);
                    case "Show item display name" ->
                            applyLegacyBoolean(moduleData, "viewdisplayname", booleanSetting);
                    case "Show item icon" -> applyLegacyBoolean(moduleData, "viewitemicon", booleanSetting);
                    case "Show head" -> applyLegacyBoolean(moduleData, "viewhead", booleanSetting);
                }
            }
        }
    }

    private static void applyLegacyBoolean(JsonObject moduleData, String legacyKey, BooleanSetting setting) {
        JsonElement element = moduleData.get(legacyKey);
        if (element == null || element.isJsonNull()) {
            return;
        }
        setting.set(readBooleanValue(element));
    }

    private static void applyLegacyBoolean(JsonObject moduleData, String legacyKey, MultiBooleanSetting multi) {
        JsonElement element = moduleData.get(legacyKey);
        if (element == null || element.isJsonNull() || !element.isJsonObject()) {
            return;
        }
        JsonObject values = element.getAsJsonObject();
        for (Map.Entry<String, JsonElement> entry : values.entrySet()) {
            String optionName = ConfigAliasRegistry.resolveOptionName(entry.getKey());
            for (BooleanSetting option : multi.getOptions()) {
                if (option.getName().equals(optionName) || option.getName().equals(entry.getKey())) {
                    option.set(entry.getValue().getAsBoolean());
                    break;
                }
            }
        }
    }

    private static boolean readBooleanValue(JsonElement element) {
        if (element.isJsonObject()) {
            JsonObject object = element.getAsJsonObject();
            if (object.has("value")) {
                return object.get("value").getAsBoolean();
            }
        }
        return element.getAsBoolean();
    }
}
