package sky.config;

import sky.util.input.KeyNameUtil;

import java.util.function.Supplier;

public final class KeybindSetting extends Setting<Integer> {
    private String nameKey;

    public KeybindSetting(String name) {
        this(name, -1);
    }

    public KeybindSetting(String name, Supplier<Boolean> visibleSupplier) {
        this(name, -1, visibleSupplier);
    }

    public KeybindSetting(String name, int keyCode) {
        super(name, keyCode);
        nameKey = KeyNameUtil.getKey(keyCode);
    }

    public KeybindSetting(String name, int keyCode, Supplier<Boolean> visibleSupplier) {
        this(name, keyCode);
        visible(visibleSupplier);
    }

    public int getKeyCode() {
        return get();
    }

    public String getNameKey() {
        return nameKey;
    }

    public void setKeyCode(int keyCode) {
        set(keyCode);
        nameKey = KeyNameUtil.getKey(keyCode);
    }
}
