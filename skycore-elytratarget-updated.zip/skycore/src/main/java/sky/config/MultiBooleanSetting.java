package sky.config;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

public final class MultiBooleanSetting extends Setting<Boolean> {
    private final List<BooleanSetting> options;

    public MultiBooleanSetting(String name, BooleanSetting... options) {
        super(name, false);
        this.options = Collections.unmodifiableList(Arrays.asList(options));
    }

    public MultiBooleanSetting(String name, Supplier<Boolean> visibleSupplier, BooleanSetting... options) {
        this(name, options);
        visible(visibleSupplier);
    }

    public List<BooleanSetting> getOptions() {
        return options;
    }

    public boolean is(String name) {
        for (BooleanSetting option : options) {
            if (option.getName().equalsIgnoreCase(name)) {
                return option.get();
            }
        }
        return false;
    }

    public boolean isEnable(String name) {
        return is(name);
    }

    public static MultiBooleanSetting create(String name, List<String> options) {
        BooleanSetting[] settings = options.stream()
                .map(option -> new BooleanSetting(option, true))
                .toArray(BooleanSetting[]::new);
        return new MultiBooleanSetting(name, settings);
    }

    @Override
    public void reset() {
        for (BooleanSetting option : options) {
            option.reset();
        }
    }
}
