package sky.config;

import java.util.function.Supplier;

public final class ColorSetting extends Setting<Integer> {
    private final int defaultColor;
    private final boolean alphaBar;

    public ColorSetting(String name, boolean alphaBar, int defaultColor) {
        super(name, defaultColor);
        this.defaultColor = defaultColor;
        this.alphaBar = alphaBar;
    }

    public ColorSetting(String name, boolean alphaBar, int defaultColor, Supplier<Boolean> visibleSupplier) {
        this(name, alphaBar, defaultColor);
        visible(visibleSupplier);
    }

    public float getAlpha() {
        return (get() >>> 24) & 0xFF;
    }

    public int getDefaultColor() {
        return defaultColor;
    }

    public boolean hasAlphaBar() {
        return alphaBar;
    }
}
