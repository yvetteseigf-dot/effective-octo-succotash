package sky.config;

import sky.SkyInit;
import sky.module.Module;

/** Shared state for assigning a module or setting keybind from the UI. */
public final class BindCapture {
    private static final String LISTENING_LABEL = "Press key...";

    private static KeybindSetting activeSetting;
    private static Module activeModule;

    private BindCapture() {
    }

    public static void cancel() {
        activeSetting = null;
        activeModule = null;
    }

    public static Module getActiveModule() {
        return activeModule;
    }

    public static void begin(KeybindSetting setting) {
        activeSetting = setting;
        activeModule = null;
    }

    public static void beginModule(Module module) {
        activeModule = module;
        activeSetting = null;
    }

    public static boolean isActive(Module module) {
        return activeModule == module;
    }

    public static boolean isActive(KeybindSetting setting) {
        return activeSetting == setting;
    }

    public static boolean hasActive() {
        return activeSetting != null || activeModule != null;
    }

    public static String getListeningLabel() {
        return LISTENING_LABEL;
    }

    public static void applyKey(int keyCode) {
        if (activeSetting != null) {
            activeSetting.setKeyCode(keyCode);
            SkyInit.getInstance().getClientConfig().saveCurrentSettings();
        } else if (activeModule != null) {
            activeModule.setKeyBind(keyCode);
            SkyInit.getInstance().getClientConfig().saveCurrentSettings();
        }
        cancel();
    }
}
