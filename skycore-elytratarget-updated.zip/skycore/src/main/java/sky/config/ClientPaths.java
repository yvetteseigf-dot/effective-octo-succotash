package sky.config;

public final class ClientPaths {
    public static final String BLOCKESP_FILE_REL = "temp\\blockesp.file";
    public static final String ACCOUNTS_FILE_REL = "temp\\accounts.file";
    public static final String THEMES_DIR_REL = "themes\\";
    public static final String NUKER_FILE_REL = "temp\\nuker.file";
    public static final String CUSTOM_META_FILE_REL = "custom\\meta.file";
    public static final String WAYPOINTS_FILE_REL = "temp\\waypoints.file";
    public static final String MACROS_FILE_REL = "temp\\macros.file";
    public static final String FRIENDS_FILE_REL = "temp\\friends.file";
    public static final String CLIENT_CONFIG_FILE_REL = "temp\\client_config.file";
    public static final String DRAGS_FILE_REL = "temp\\drags.file";
    public static final String STAFF_FILE_REL = "temp\\staff.file";
    public static final String NEURO_FILE_REL = "temp\\neuro.file";
    public static final String CUSTOM_DIR_REL = "custom\\";

    public static final String BASE_PATH = System.getenv("SystemDrive")
            + "\\SkyCore\\beta\\SkyCore\\";

    private ClientPaths() {
    }
}
