package sky.config;

import java.util.function.Supplier;

/** A configurable value owned by a module. */
public class Setting<T> {
    private final String name;
    private final T defaultValue;
    private T value;
    private Supplier<Boolean> visibleSupplier;

    public Setting(String name, T defaultValue) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public T getDefault() {
        return defaultValue;
    }

    public Setting<T> visible(Supplier<Boolean> visibleSupplier) {
        this.visibleSupplier = visibleSupplier;
        return this;
    }

    public boolean isVisible() {
        return visibleSupplier == null || Boolean.TRUE.equals(visibleSupplier.get());
    }

    public T get() {
        return value;
    }

    public String getName() {
        return name;
    }

    public void reset() {
        value = defaultValue;
    }

    public void set(T value) {
        this.value = value;
    }
}
