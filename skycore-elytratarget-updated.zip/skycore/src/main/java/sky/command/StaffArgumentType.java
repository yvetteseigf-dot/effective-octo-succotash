package sky.command;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import sky.SkyInit;

/** Command argument that only accepts names already present in the staff list. */
public final class StaffArgumentType implements ArgumentType<String> {
    public static StaffArgumentType create() {
        return new StaffArgumentType();
    }

    @Override
    public String parse(StringReader reader) throws CommandSyntaxException {
        String name = reader.readString();
        if (!SkyInit.getInstance().getStaffManager().contains(name)) {
            throw new DynamicCommandExceptionType(staff -> Text.literal(name + " is not in the staff list")).create(name);
        }
        return name;
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return CommandSource.suggestMatching(SkyInit.getInstance().getStaffManager().getItems(), builder);
    }

    @Override
    public Collection<String> getExamples() {
        return List.of();
    }
}
