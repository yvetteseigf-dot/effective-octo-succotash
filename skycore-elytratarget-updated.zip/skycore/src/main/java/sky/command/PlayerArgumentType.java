package sky.command;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.command.CommandSource;
import sky.access.SkyClientAccess;

/** Command argument that completes against the names on the current server's player list. */
public final class PlayerArgumentType implements ArgumentType<String>, SkyClientAccess {
    public static PlayerArgumentType create() {
        return new PlayerArgumentType();
    }

    @Override
    public String parse(StringReader reader) throws CommandSyntaxException {
        return reader.readUnquotedString();
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        if (mc.getNetworkHandler() == null) {
            return Suggestions.empty();
        }
        return CommandSource.suggestMatching(
            mc.getNetworkHandler().getPlayerList().stream().map(entry -> entry.getProfile().getName()),
            builder
        );
    }

    @Override
    public Collection<String> getExamples() {
        return List.of("Player");
    }
}
