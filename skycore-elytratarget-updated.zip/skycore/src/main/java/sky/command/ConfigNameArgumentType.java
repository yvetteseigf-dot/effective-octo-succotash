package sky.command;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import sky.SkyInit;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Brigadier argument that only accepts the name of a config that is already on disk. */
public class ConfigNameArgumentType implements ArgumentType<String> {
    private static final Collection<String> EXAMPLES = List.of("current_config");

    public static ConfigNameArgumentType create() {
        return new ConfigNameArgumentType();
    }

    @Override
    public String parse(StringReader reader) throws CommandSyntaxException {
        String configName = reader.readString();
        if (SkyInit.getInstance().getConfigManager().getConfigInfo(configName) == null) {
            throw new DynamicCommandExceptionType(
                    name -> Text.literal("Config " + name.toString() + " does not exist.")).create(configName);
        }
        return configName;
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return CommandSource.suggestMatching(SkyInit.getInstance().getConfigManager().getConfigNames(), builder);
    }

    @Override
    public Collection<String> getExamples() {
        return EXAMPLES;
    }
}
