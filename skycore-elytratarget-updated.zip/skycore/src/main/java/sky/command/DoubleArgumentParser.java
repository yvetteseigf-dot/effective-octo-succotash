package sky.command;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandExceptionType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class DoubleArgumentParser implements ArgumentType<Double> {
    public static DoubleArgumentParser create() {
        return new DoubleArgumentParser();
    }

    @Override
    public Double parse(StringReader reader) throws CommandSyntaxException {
        try {
            return Double.parseDouble(reader.readString());
        } catch (NumberFormatException ignored) {
            throw new CommandSyntaxException((CommandExceptionType) null, () -> "That's not a valid number");
        }
    }

    @Override
    public Collection<String> getExamples() {
        return List.of();
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return Suggestions.empty();
    }
}
