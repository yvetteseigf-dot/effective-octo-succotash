package sky.misc;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import sky.event.input.StrafeInputEvent;
import sky.access.SkyClientAccess;

public class MovementBlocker implements SkyClientAccess {
    public static boolean stop;
    public static int stopTicks;

    public MovementBlocker() {
        EventManager.register(this);
    }

    public static boolean isStop() {
        return stop;
    }

    @EventTarget
    public void onMoveInput(StrafeInputEvent event) {
        if (stopTicks > 0) {
            if (stop) {
                event.setStrafe(0.0F);
                event.setForward(0.0F);
            }
            mc.options.sprintKey.setPressed(false);
            mc.player.setSprinting(false);
            stopTicks--;
        } else if (stop) {
            stop = false;
        }
    }
}
