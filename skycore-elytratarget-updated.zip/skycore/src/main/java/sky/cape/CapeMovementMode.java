package sky.cape;

public enum CapeMovementMode {
    VANILLA,
    BASIC_SIMULATION
}
