package sky.cape;

public class CapeManager {
    public static final String DEFAULT_CAPE_TEXTURE = "skycore:textures/cape.png";

    public static CapeManager INSTANCE;
    public static CapeConfig config = new CapeConfig();

    public CapeManager start() {
        INSTANCE = this;
        config = new CapeConfig();
        return this;
    }
}
