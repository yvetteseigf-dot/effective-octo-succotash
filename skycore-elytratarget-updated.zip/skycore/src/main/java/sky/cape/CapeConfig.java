package sky.cape;

public class CapeConfig {
    public CapeStyle capeStyle;
    public int gravity;
    public int straveMultiplier;
    public int heightMultiplier;
    public CapeMovementMode capeMovement;
    public CapeWindMode windMode;

    public CapeConfig() {
        windMode = CapeWindMode.NONE;
        capeStyle = CapeStyle.SMOOTH;
        capeMovement = CapeMovementMode.BASIC_SIMULATION;
        gravity = 25;
        heightMultiplier = 6;
        straveMultiplier = 2;
    }
}
