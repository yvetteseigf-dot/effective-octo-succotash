package sky.access;

import net.minecraft.client.util.Window;

public interface WindowAccess extends MinecraftAccess {
    Window mw = mc.getWindow();
}
