package sky.access;

import net.minecraft.client.MinecraftClient;

public interface MinecraftAccess {
    MinecraftClient mc = MinecraftClient.getInstance();
}
