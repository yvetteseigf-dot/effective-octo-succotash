package sky.render.shader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sky.util.StreamUtil;

import java.io.InputStream;

public final class ManagedShaderBuilder {
    private static final Logger LOGGER = LoggerFactory.getLogger("Skycore");

    private final ManagedShader program;

    private ManagedShaderBuilder() {
        this.program = new ManagedShader();
    }

    public static ManagedShaderBuilder create() {
        return new ManagedShaderBuilder();
    }

    public ManagedShaderBuilder attach(String path, int type) {
        InputStream stream = ManagedShaderBuilder.class.getResourceAsStream("/assets/skycore/shaders/" + path);
        if (stream == null) {
            LOGGER.error("Shader not found: /assets/skycore/shaders/{}", path);
            return this;
        }

        program.attachSource(StreamUtil.readText(stream), type);
        return this;
    }

    public ManagedShaderBuilder link() {
        program.link();
        return this;
    }

    public ManagedShader build() {
        return program;
    }
}
