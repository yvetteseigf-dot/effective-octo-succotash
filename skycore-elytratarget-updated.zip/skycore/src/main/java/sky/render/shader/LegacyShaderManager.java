package sky.render.shader;

import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL20;
import org.lwjgl.system.MemoryStack;
import sky.debug.BlurDebugLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.FloatBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.stream.Collectors;

public final class LegacyShaderManager {
    private static LegacyGlProgram blockOutlineGlProgram;
    private static LegacyGlProgram crystalOutlineGlProgram;
    private static LegacyGlProgram saturationGlProgram;
    private static LegacyGlProgram fogBlurGlProgram;
    private static LegacyGlProgram depthPackGlProgram;
    private static LegacyGlProgram kawaseDownGlProgram;
    private static LegacyGlProgram kawaseUpGlProgram;
    private static LegacyGlProgram handsGlProgram;
    private static LegacyGlProgram glowEspGlProgram;
    private static LegacyGlProgram outlineGlowEspGlProgram;
    private static LegacyGlProgram entityFillGlProgram;
    private static LegacyGlProgram entityTintGlProgram;
    private static LegacyGlProgram chamsPlasmaGlProgram;
    private static LegacyGlProgram chamsNebulaGlProgram;
    private static LegacyGlProgram chamsSpaceGlProgram;
    private static LegacyGlProgram chamsSakuraGlProgram;
    private static LegacyGlProgram chamsEtherealGlProgram;
    private static LegacyGlProgram chamsSummerGlProgram;
    private static boolean kawaseLoadAttempted;

    private LegacyShaderManager() {
    }

    public static void reload(ResourceManager resourceManager) {
        dispose();

        try {
            blockOutlineGlProgram = LegacyGlProgram.link(resourceManager, "ovbew");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            crystalOutlineGlProgram = LegacyGlProgram.link(resourceManager, "crystal_outline");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            saturationGlProgram = LegacyGlProgram.link(resourceManager, "saturation");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            fogBlurGlProgram = LegacyGlProgram.link(resourceManager, "fog_blur");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            depthPackGlProgram = LegacyGlProgram.link(resourceManager, "depth_pack");
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        thisLoadKawase(resourceManager);

        try {
            handsGlProgram = LegacyGlProgram.linkWithVertex(resourceManager, "hands", "hands_vertex");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            glowEspGlProgram = LegacyGlProgram.link(resourceManager, "glow_esp");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            outlineGlowEspGlProgram = LegacyGlProgram.link(resourceManager, "outline_glow_esp");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            entityFillGlProgram = LegacyGlProgram.link(resourceManager, "entity_fill_shader");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            entityTintGlProgram = LegacyGlProgram.link(resourceManager, "entity_tint");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            chamsPlasmaGlProgram = LegacyGlProgram.linkChams(resourceManager, "chams_plasma");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            chamsNebulaGlProgram = LegacyGlProgram.linkChams(resourceManager, "chams_nebula");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            chamsSpaceGlProgram = LegacyGlProgram.linkChams(resourceManager, "chams_space");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            chamsSakuraGlProgram = LegacyGlProgram.linkChams(resourceManager, "chams_sakura");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            chamsEtherealGlProgram = LegacyGlProgram.linkChams(resourceManager, "chams_ethereal");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            chamsSummerGlProgram = LegacyGlProgram.linkChams(resourceManager, "chams_summer");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static void dispose() {
        if (blockOutlineGlProgram != null) {
            blockOutlineGlProgram.delete();
            blockOutlineGlProgram = null;
        }
        if (crystalOutlineGlProgram != null) {
            crystalOutlineGlProgram.delete();
            crystalOutlineGlProgram = null;
        }
        if (saturationGlProgram != null) {
            saturationGlProgram.delete();
            saturationGlProgram = null;
        }
        if (fogBlurGlProgram != null) {
            fogBlurGlProgram.delete();
            fogBlurGlProgram = null;
        }
        if (depthPackGlProgram != null) {
            depthPackGlProgram.delete();
            depthPackGlProgram = null;
        }
        if (kawaseDownGlProgram != null) {
            kawaseDownGlProgram.delete();
            kawaseDownGlProgram = null;
        }
        if (kawaseUpGlProgram != null) {
            kawaseUpGlProgram.delete();
            kawaseUpGlProgram = null;
        }
        if (handsGlProgram != null) {
            handsGlProgram.delete();
            handsGlProgram = null;
        }
        if (glowEspGlProgram != null) {
            glowEspGlProgram.delete();
            glowEspGlProgram = null;
        }
        if (outlineGlowEspGlProgram != null) {
            outlineGlowEspGlProgram.delete();
            outlineGlowEspGlProgram = null;
        }
        if (entityFillGlProgram != null) {
            entityFillGlProgram.delete();
            entityFillGlProgram = null;
        }
        if (entityTintGlProgram != null) {
            entityTintGlProgram.delete();
            entityTintGlProgram = null;
        }
        if (chamsPlasmaGlProgram != null) {
            chamsPlasmaGlProgram.delete();
            chamsPlasmaGlProgram = null;
        }
        if (chamsNebulaGlProgram != null) {
            chamsNebulaGlProgram.delete();
            chamsNebulaGlProgram = null;
        }
        if (chamsSpaceGlProgram != null) {
            chamsSpaceGlProgram.delete();
            chamsSpaceGlProgram = null;
        }
        if (chamsSakuraGlProgram != null) {
            chamsSakuraGlProgram.delete();
            chamsSakuraGlProgram = null;
        }
        if (chamsEtherealGlProgram != null) {
            chamsEtherealGlProgram.delete();
            chamsEtherealGlProgram = null;
        }
        if (chamsSummerGlProgram != null) {
            chamsSummerGlProgram.delete();
            chamsSummerGlProgram = null;
        }
        kawaseLoadAttempted = false;
    }

    public static void reloadKawaseIfNeeded() {
        if (kawaseLoadAttempted && isKawaseReady()) {
            return;
        }
        BlurDebugLogger.log("ShaderUtil", "reloadKawaseIfNeeded() loading... attempted=" + kawaseLoadAttempted);
        kawaseLoadAttempted = true;
        if (MinecraftClient.getInstance().getResourceManager() != null) {
            loadKawase(MinecraftClient.getInstance().getResourceManager());
        } else {
            BlurDebugLogger.log("ShaderUtil", "reloadKawaseIfNeeded() ABORT resourceManager is null");
        }
    }

    private static void thisLoadKawase(ResourceManager resourceManager) {
        kawaseLoadAttempted = true;
        loadKawase(resourceManager);
    }

    private static void loadKawase(ResourceManager resourceManager) {
        BlurDebugLogger.log("ShaderUtil", "loadKawase() start");
        try {
            if (kawaseDownGlProgram != null) {
                kawaseDownGlProgram.delete();
            }
            if (kawaseUpGlProgram != null) {
                kawaseUpGlProgram.delete();
            }
            kawaseDownGlProgram = LegacyGlProgram.linkFragment(resourceManager, "light_kawase_down");
            kawaseUpGlProgram = LegacyGlProgram.linkFragment(resourceManager, "light_kawase_up");
            BlurDebugLogger.log("ShaderUtil", "loadKawase() done -> " + BlurDebugLogger.describeKawasePrograms());
        } catch (Exception exception) {
            BlurDebugLogger.log("ShaderUtil", "loadKawase() FAILED: " + exception.getMessage());
            exception.printStackTrace();
        }
    }

    public static LegacyGlProgram blockOutlineProgram() {
        return blockOutlineGlProgram;
    }

    public static LegacyGlProgram crystalOutlineProgram() {
        return crystalOutlineGlProgram;
    }

    public static LegacyGlProgram saturationProgram() {
        return saturationGlProgram;
    }

    public static LegacyGlProgram fogBlurProgram() {
        return fogBlurGlProgram;
    }

    public static LegacyGlProgram depthPackProgram() {
        return depthPackGlProgram;
    }

    public static LegacyGlProgram kawaseDownProgram() {
        return kawaseDownGlProgram;
    }

    public static LegacyGlProgram kawaseUpProgram() {
        return kawaseUpGlProgram;
    }

    public static LegacyGlProgram handsProgram() {
        return handsGlProgram;
    }

    public static LegacyGlProgram glowEspProgram() {
        return glowEspGlProgram;
    }

    public static LegacyGlProgram outlineGlowEspProgram() {
        return outlineGlowEspGlProgram;
    }

    public static LegacyGlProgram entityFillProgram() {
        return entityFillGlProgram;
    }

    public static LegacyGlProgram entityTintProgram() {
        return entityTintGlProgram;
    }

    public static LegacyGlProgram chamsProgram(String mode) {
        if (mode == null) {
            return chamsPlasmaGlProgram;
        }
        return switch (mode) {
            case "Space", "Космос" -> chamsSpaceGlProgram;
            case "Nebula", "Туманность" -> chamsNebulaGlProgram;
            case "Sakura", "Сакура" -> chamsSakuraGlProgram;
            case "Ethereal", "Эфир" -> chamsEtherealGlProgram;
            case "Summer", "Лето" -> chamsSummerGlProgram;
            default -> chamsPlasmaGlProgram;
        };
    }

    public static boolean isBlockOutlineReady() {
        return blockOutlineGlProgram != null && blockOutlineGlProgram.programId != 0;
    }

    public static boolean isCrystalOutlineReady() {
        return crystalOutlineGlProgram != null && crystalOutlineGlProgram.programId != 0;
    }

    public static boolean isSaturationReady() {
        return saturationGlProgram != null && saturationGlProgram.programId != 0;
    }

    public static boolean isFogBlurReady() {
        return fogBlurGlProgram != null && fogBlurGlProgram.programId != 0
                && depthPackGlProgram != null && depthPackGlProgram.programId != 0;
    }

    public static boolean isKawaseReady() {
        return kawaseDownGlProgram != null && kawaseUpGlProgram != null
                && kawaseDownGlProgram.programId != 0 && kawaseUpGlProgram.programId != 0;
    }

    public static boolean isHandsMirrorReady() {
        return handsGlProgram != null && handsGlProgram.programId != 0;
    }

    public static boolean isGlowEspReady() {
        return glowEspGlProgram != null && outlineGlowEspGlProgram != null
                && glowEspGlProgram.programId != 0 && outlineGlowEspGlProgram.programId != 0;
    }

    public static boolean isGlowEspBlurReady() {
        return glowEspGlProgram != null && glowEspGlProgram.programId != 0;
    }

    public static boolean isGlowEspOutlineReady() {
        return outlineGlowEspGlProgram != null && outlineGlowEspGlProgram.programId != 0;
    }

    public static boolean isEntityFillReady() {
        return entityFillGlProgram != null && entityFillGlProgram.programId != 0;
    }

    public static boolean isEntityTintReady() {
        return entityTintGlProgram != null && entityTintGlProgram.programId != 0;
    }

    public static boolean isChamsShaderReady(String mode) {
        LegacyGlProgram program = chamsProgram(mode);
        return program != null && program.programId != 0;
    }

    public static final class LegacyGlProgram {
        public final int programId;

        LegacyGlProgram(int programId) {
            this.programId = programId;
        }

        static LegacyGlProgram link(ResourceManager resourceManager, String name) throws IOException {
            String vertexSource = load(resourceManager, "vertex");
            String fragmentSource = load(resourceManager, name);
            return compileLinked(vertexSource, fragmentSource, name);
        }

        static LegacyGlProgram linkWithVertex(ResourceManager resourceManager, String name, String vertexName) throws IOException {
            String vertexSource = load(resourceManager, vertexName);
            String fragmentSource = load(resourceManager, name);
            return compileLinked(vertexSource, fragmentSource, name, false);
        }

        static LegacyGlProgram linkFragment(ResourceManager resourceManager, String name) throws IOException {
            String vertexSource = load(resourceManager, "vertex");
            String fragmentSource = loadFragment(resourceManager, name);
            return compileLinked(vertexSource, fragmentSource, name);
        }

        static LegacyGlProgram linkChams(ResourceManager resourceManager, String name) throws IOException {
            String vertexSource = load(resourceManager, "chams_vertex");
            String fragmentSource = load(resourceManager, name);
            return compileLinkedChams(vertexSource, fragmentSource, name);
        }

        public void attach() {
            GL20.glUseProgram(programId);
        }

        public void detach() {
            GL20.glUseProgram(0);
        }

        public void delete() {
            if (programId != 0) {
                GL20.glDeleteProgram(programId);
            }
        }

        public void uniform1i(String name, int value) {
            int location = GL20.glGetUniformLocation(programId, name);
            if (location >= 0) {
                GL20.glUniform1i(location, value);
            }
        }

        public void uniform1f(String name, float value) {
            int location = GL20.glGetUniformLocation(programId, name);
            if (location >= 0) {
                GL20.glUniform1f(location, value);
            }
        }

        public void uniform2f(String name, float x, float y) {
            int location = GL20.glGetUniformLocation(programId, name);
            if (location >= 0) {
                GL20.glUniform2f(location, x, y);
            }
        }

        public void uniform3f(String name, float x, float y, float z) {
            int location = GL20.glGetUniformLocation(programId, name);
            if (location >= 0) {
                GL20.glUniform3f(location, x, y, z);
            }
        }

        public void uniform4f(String name, float x, float y, float z, float w) {
            int location = GL20.glGetUniformLocation(programId, name);
            if (location >= 0) {
                GL20.glUniform4f(location, x, y, z, w);
            }
        }

        public void uniform1fv(String name, FloatBuffer values) {
            int location = GL20.glGetUniformLocation(programId, name);
            if (location >= 0) {
                GL20.glUniform1fv(location, values);
            }
        }

        public void uniformMatrix4f(String name, Matrix4f matrix) {
            int location = GL20.glGetUniformLocation(programId, name);
            if (location < 0) {
                return;
            }
            try (MemoryStack stack = MemoryStack.stackPush()) {
                FloatBuffer buffer = stack.mallocFloat(16);
                matrix.get(buffer);
                GL20.glUniformMatrix4fv(location, false, buffer);
            }
        }

        private static LegacyGlProgram compileLinked(String vertexSource, String fragmentSource, String name) {
            return compileLinked(vertexSource, fragmentSource, name, true);
        }

        private static LegacyGlProgram compileLinked(String vertexSource, String fragmentSource, String name, boolean bindTextureAttributes) {
            int vertexShader = compile(GL20.GL_VERTEX_SHADER, vertexSource);
            int fragmentShader = compile(GL20.GL_FRAGMENT_SHADER, fragmentSource);
            int program = GL20.glCreateProgram();
            GL20.glAttachShader(program, vertexShader);
            GL20.glAttachShader(program, fragmentShader);
            if (bindTextureAttributes) {
                GL20.glBindAttribLocation(program, 0, "Position");
                GL20.glBindAttribLocation(program, 1, "UV0");
            }
            GL20.glLinkProgram(program);
            GL20.glDeleteShader(vertexShader);
            GL20.glDeleteShader(fragmentShader);
            if (GL20.glGetProgrami(program, GL20.GL_LINK_STATUS) == 0) {
                String infoLog = GL20.glGetProgramInfoLog(program);
                GL20.glDeleteProgram(program);
                throw new IllegalStateException("Program link failed (" + name + "): " + infoLog);
            }
            return new LegacyGlProgram(program);
        }

        private static LegacyGlProgram compileLinkedChams(String vertexSource, String fragmentSource, String name) {
            int vertexShader = compile(GL20.GL_VERTEX_SHADER, vertexSource);
            int fragmentShader = compile(GL20.GL_FRAGMENT_SHADER, fragmentSource);
            int program = GL20.glCreateProgram();
            GL20.glAttachShader(program, vertexShader);
            GL20.glAttachShader(program, fragmentShader);
            GL20.glBindAttribLocation(program, 0, "Position");
            GL20.glBindAttribLocation(program, 1, "Color");
            GL20.glLinkProgram(program);
            GL20.glDeleteShader(vertexShader);
            GL20.glDeleteShader(fragmentShader);
            if (GL20.glGetProgrami(program, GL20.GL_LINK_STATUS) == 0) {
                String infoLog = GL20.glGetProgramInfoLog(program);
                GL20.glDeleteProgram(program);
                throw new IllegalStateException("Program link failed (" + name + "): " + infoLog);
            }
            return new LegacyGlProgram(program);
        }

        private static int compile(int type, String source) {
            int shader = GL20.glCreateShader(type);
            GL20.glShaderSource(shader, source);
            GL20.glCompileShader(shader);
            if (GL20.glGetShaderi(shader, GL20.GL_COMPILE_STATUS) == 0) {
                String infoLog = GL20.glGetShaderInfoLog(shader);
                GL20.glDeleteShader(shader);
                throw new IllegalStateException("Shader compile failed: " + infoLog);
            }
            return shader;
        }

        private static String load(ResourceManager resourceManager, String name) throws IOException {
            Identifier identifier = Identifier.of("skycore", "shaders/shadersystem/" + name + ".glsl");
            Optional<Resource> resource = resourceManager.getResource(identifier);
            if (resource.isEmpty()) {
                throw new IOException("Shader resource not found: " + identifier);
            }
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(resource.get().getInputStream(), StandardCharsets.UTF_8))) {
                return reader.lines().collect(Collectors.joining("\n"));
            }
        }

        private static String loadFragment(ResourceManager resourceManager, String name) throws IOException {
            Identifier identifier = Identifier.of("skycore", "shaders/fragment/" + name + ".fsh");
            Optional<Resource> resource = resourceManager.getResource(identifier);
            if (resource.isEmpty()) {
                throw new IOException("Shader resource not found: " + identifier);
            }
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(resource.get().getInputStream(), StandardCharsets.UTF_8))) {
                return reader.lines().collect(Collectors.joining("\n"));
            }
        }
    }
}
