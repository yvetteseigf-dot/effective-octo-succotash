package sky.render.shader;

import com.google.common.collect.Maps;

import java.util.Map;
import java.util.Optional;

public class ShaderRegistry {
    private final Map<String, ManagedShader> programs;

    public ShaderRegistry() {
        this.programs = Maps.newLinkedHashMap();
    }

    public Optional<ManagedShader> find(String name) {
        return Optional.ofNullable(programs.get(name));
    }

    public void register(String name, ManagedShader program) {
        programs.put(name, program);
    }
}
