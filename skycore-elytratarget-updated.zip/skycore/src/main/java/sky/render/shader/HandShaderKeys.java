package sky.render.shader;

import net.minecraft.client.gl.Defines;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

public final class HandShaderKeys {
    public static final ShaderProgramKey MASK_DIFF = key("hands_mask_diff");
    public static final ShaderProgramKey OVERLAY = key("hands_overlay");
    public static final ShaderProgramKey GLOW = key("hands_glow");
    public static final ShaderProgramKey KAWASE_DOWN = key("hands_kawase_down");
    public static final ShaderProgramKey KAWASE_UP = key("hands_kawase_up");

    private HandShaderKeys() {
    }

    private static ShaderProgramKey key(String name) {
        return new ShaderProgramKey(Identifier.of("skycore", "core/hands/" + name),
                VertexFormats.POSITION_TEXTURE_COLOR, Defines.EMPTY);
    }
}
