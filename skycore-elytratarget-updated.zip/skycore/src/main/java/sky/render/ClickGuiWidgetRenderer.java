package sky.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.util.math.MatrixStack;
import sky.theme.GuiTheme;
import sky.clickgui.ClickGuiLayout;
import sky.util.render.ColorUtil;
import sky.util.math.CornerRadii;
import sky.util.animation.FadeAnimation;
import sky.config.Setting;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;

public final class ClickGuiWidgetRenderer {
    public static final String SETTING_HINT = "Setting description";

    private static final Color WHITE = Color.WHITE;

    private static float settingHintAlpha = -1.0F;

    private ClickGuiWidgetRenderer() {
    }

    public static Color moduleOutlineColor(float enableProgress) {
        return ColorUtil.lerp(new Color(255, 255, 255, ClickGuiLayout.opacity(2)),
                new Color(255, 255, 255, ClickGuiLayout.opacity(13)), enableProgress);
    }

    public static Color moduleOutlineColor(boolean enabled) {
        return moduleOutlineColor(enabled ? 1.0F : 0.0F);
    }

    public static void drawModuleCardFill(DrawHelper renderer, float x, float y, float width, float height,
                                          float enableProgress, float alpha, CornerRadii radii, MatrixStack matrices) {
        Color fill = ColorUtil.lerp(new Color(255, 255, 255, ClickGuiLayout.opacity(2)),
                new Color(255, 255, 255, ClickGuiLayout.opacity(7)), enableProgress);
        renderer.drawRoundedRect(x, y, width, height, radii, ColorUtil.withAlpha(fill, alpha), matrices);
    }

    public static void drawModuleCardFill(DrawHelper renderer, float x, float y, float width, float height,
                                          boolean enabled, float alpha, CornerRadii radii, MatrixStack matrices) {
        drawModuleCardFill(renderer, x, y, width, height, enabled ? 1.0F : 0.0F, alpha, radii, matrices);
    }

    public static void drawModuleCardOutline(DrawHelper renderer, float x, float y, float width, float height,
                                             float enableProgress, float alpha, CornerRadii radii, MatrixStack matrices) {
        renderer.drawRoundedOutline(x, y, width, height, radii, 1.5F,
                ColorUtil.withAlpha(moduleOutlineColor(enableProgress), alpha), matrices);
    }

    public static void drawModuleCardOutline(DrawHelper renderer, float x, float y, float width, float height,
                                             boolean enabled, float alpha, CornerRadii radii, MatrixStack matrices) {
        drawModuleCardOutline(renderer, x, y, width, height, enabled ? 1.0F : 0.0F, alpha, radii, matrices);
    }

    public static void drawModuleCardBackground(DrawHelper renderer, float x, float y, float width, float height,
                                                float enableProgress, float alpha, CornerRadii radii, MatrixStack matrices) {
        drawModuleCardFill(renderer, x, y, width, height, enableProgress, alpha, radii, matrices);
        drawModuleCardOutline(renderer, x, y, width, height, enableProgress, alpha, radii, matrices);
    }

    public static void drawModuleCardBackground(DrawHelper renderer, float x, float y, float width, float height,
                                                boolean enabled, float alpha, CornerRadii radii, MatrixStack matrices) {
        drawModuleCardBackground(renderer, x, y, width, height, enabled ? 1.0F : 0.0F, alpha, radii, matrices);
    }

    public static void drawModuleCardBackground(DrawHelper renderer, float x, float y, float width, float height,
                                                float enableProgress, float alpha, MatrixStack matrices) {
        drawModuleCardBackground(renderer, x, y, width, height, enableProgress, alpha, CornerRadii.all(19.0F), matrices);
    }

    public static void drawModuleCardBackground(DrawHelper renderer, float x, float y, float width, float height,
                                                boolean enabled, float alpha, MatrixStack matrices) {
        drawModuleCardBackground(renderer, x, y, width, height, enabled ? 1.0F : 0.0F, alpha,
                CornerRadii.all(19.0F), matrices);
    }

    public static void drawModuleSettingsFill(DrawHelper renderer, float x, float y, float width, float height,
                                              float alpha, MatrixStack matrices) {
        if (height <= 0.5F) {
            return;
        }

        Color fill = new Color(255, 255, 255, ClickGuiLayout.opacity(1));
        renderer.drawRoundedRect(x, y, width, height, CornerRadii.bottom(19.0F),
                ColorUtil.withAlpha(fill, alpha), matrices);
    }

    public static void drawModuleSettingsOutline(DrawHelper renderer, float x, float y, float width, float height,
                                                 float alpha, MatrixStack matrices) {
        if (height <= 0.5F) {
            return;
        }

        Color outline = new Color(255, 255, 255, ClickGuiLayout.opacity(3));
        renderer.drawRoundedOutline(x, y, width, height, CornerRadii.bottom(19.0F), 1.5F,
                ColorUtil.withAlpha(outline, alpha), matrices);
    }

    public static void drawExpandedModuleChrome(DrawHelper renderer, float x, float y, float width, float headerH,
                                                float settingsH, float enableProgress, float alpha, MatrixStack matrices) {
        CornerRadii headerRadii = CornerRadii.top(19.0F);
        float settingsY = y + headerH - 1.5F;
        float settingsHeight = settingsH + 1.5F;

        drawModuleCardFill(renderer, x, y, width, headerH, enableProgress, alpha, headerRadii, matrices);
        drawModuleCardOutline(renderer, x, y, width, headerH, enableProgress, alpha, headerRadii, matrices);

        if (settingsHeight > 0.5F) {
            drawModuleSettingsFill(renderer, x, settingsY, width, settingsHeight, alpha, matrices);
            drawModuleSettingsOutline(renderer, x, settingsY, width, settingsHeight, alpha, matrices);
        }
    }

    public static void drawExpandedModuleChrome(DrawHelper renderer, float x, float y, float width, float headerH,
                                                float settingsH, boolean enabled, float alpha, MatrixStack matrices) {
        drawExpandedModuleChrome(renderer, x, y, width, headerH, settingsH, enabled ? 1.0F : 0.0F, alpha, matrices);
    }

    public static void drawToggle(DrawHelper renderer, FadeAnimation animation, float x, float y, float alpha,
                                  MatrixStack matrices) {
        GuiTheme theme = GuiTheme.theme;
        animation.update();

        float progress = animation.getAlpha();
        Color track = ColorUtil.lerp(theme.getToggleOff(), theme.getToggleOn(), progress);
        renderer.drawRoundedRect(x, y, 10.0F, 6.5F, 6.5F, ColorUtil.withAlpha(track, alpha), matrices);

        float knobX = x + 4.5F * progress;
        float knobY = y + 1.0F;
        renderer.drawRoundedRect(knobX, knobY, 4.5F, 4.5F, 4.5F, ColorUtil.withAlpha(WHITE, alpha), matrices);
    }

    public static float drawSettingHeader(String name, float x, float y, float width, float alpha,
                                          MatrixStack matrices) {
        FontRenderer font = FontRegistry.getClickGuiMedium(12);
        if (font == null) {
            return 11.5F;
        }

        float textX = x + 8.0F;
        float textY = y + (11.5F - font.getLineHeight(name)) / 2.0F;
        font.draw(name, textX, textY, ColorUtil.withAlpha(WHITE, alpha), matrices);
        return 11.5F;
    }

    public static float estimateBindChipWidth(FontRenderer font, String label) {
        if (label == null || label.isEmpty() || "NONE".equalsIgnoreCase(label) || "-1".equals(label)) {
            label = "None";
        }

        FontRenderer icons = FontRegistry.getClickGuiIcons(9);
        float iconWidth = icons != null ? icons.getWidth("k") : 0.0F;
        float labelWidth = font != null ? font.getWidth(label) : 24.0F;
        return Math.max(20.0F, 5.0F + iconWidth + 3.0F + labelWidth + 5.0F) - 6.0F;
    }

    public static float drawBindChip(FontRenderer font, String label, float rightX, float centerY, boolean active,
                                     boolean moduleEnabled, float alpha, MatrixStack matrices) {
        GuiTheme theme = GuiTheme.theme;
        if (label == null || label.isEmpty() || "NONE".equalsIgnoreCase(label) || "-1".equals(label)) {
            label = "None";
        }

        FontRenderer icons = FontRegistry.getClickGuiIcons(9);
        float iconWidth = icons != null ? icons.getWidth("k") : 0.0F;
        font.getWidth(label);

        float chipWidth = estimateBindChipWidth(font, label) - 0.5F;
        float chipX = rightX - chipWidth;
        float chipY = centerY - 6.5F / 2.0F;

        Color background = active ? theme.getAccent() : new Color(255, 255, 255, ClickGuiLayout.opacity(7));
        float textAlpha = moduleEnabled ? 1.0F : ClickGuiLayout.opacity(25) / 255.0F;
        Color textColor = active ? WHITE : Color.WHITE;

        DrawHelper.get().drawRoundedRect(chipX, chipY, chipWidth, 6.5F, 3.25F,
                ColorUtil.withAlpha(background, alpha), matrices);

        Color outline = moduleEnabled
                ? new Color(255, 255, 255, ClickGuiLayout.opacity(13))
                : new Color(255, 255, 255, ClickGuiLayout.opacity(2));
        DrawHelper.get().drawRoundedOutline(chipX, chipY, chipWidth, 6.5F, 3.25F, 1.0F,
                ColorUtil.withAlpha(outline, alpha), matrices);

        float textX = chipX + 5.0F;
        if (icons != null) {
            icons.draw("k", textX - 3.0F, chipY + (6.5F - icons.getLineHeight("k")) / 2.0F - 1.0F,
                    ColorUtil.withAlpha(textColor, alpha * textAlpha), matrices);
            textX += iconWidth + 3.0F;
        }

        font.draw(label, textX - 4.0F, chipY + (6.5F - font.getLineHeight(label)) / 2.0F,
                ColorUtil.withAlpha(textColor, alpha * textAlpha), matrices);
        return chipX;
    }

    public static void drawClippedText(FontRenderer font, String text, float x, float y, float maxWidth, Color color,
                                       MatrixStack matrices) {
        if (maxWidth <= 1.0F) {
            return;
        }

        float textWidth = font.getWidth(text);
        if (textWidth <= maxWidth) {
            font.draw(text, x, y, color, matrices);
            return;
        }

        ScissorStack.enable(x, y - 1.0F, maxWidth, font.getLineHeight(text) + 2.0F);
        font.draw(text, x, y, color, matrices);
        ScissorStack.disable();
    }

    public static void drawWrappedDescription(FontRenderer font, String text, float x, float y, float maxWidth,
                                              int maxLines, Color color, MatrixStack matrices) {
        if (text == null || text.isBlank()) {
            return;
        }

        List<String> lines = wrapText(font, text.trim(), maxWidth, maxLines);
        float lineHeight = font.getLineHeight("Ag");

        for (int line = 0; line < lines.size(); line++) {
            drawClippedText(font, lines.get(line), x, y + line * (lineHeight + 1.0F), maxWidth, color, matrices);
        }
    }

    public static int countWrappedLines(FontRenderer font, String text, float maxWidth, int maxLines) {
        if (text == null || text.isBlank() || font == null) {
            return 0;
        }

        return wrapText(font, text.trim(), maxWidth, maxLines).size();
    }

    public static float measureDescriptionHeight(FontRenderer font, int lineCount) {
        if (lineCount <= 0 || font == null) {
            return 0.0F;
        }

        float lineHeight = font.getLineHeight("Ag");
        return lineCount * lineHeight + (lineCount - 1) * 1.0F;
    }

    public static void beginSettingHints(float hintAlpha) {
        settingHintAlpha = hintAlpha;
    }

    public static void endSettingHints() {
        settingHintAlpha = -1.0F;
    }

    private static List<String> wrapText(FontRenderer font, String text, float maxWidth, int maxLines) {
        List<String> lines = new ArrayList<>();
        if (maxWidth <= 1.0F) {
            lines.add(text);
            return lines;
        }

        String[] words = text.split("\\s+");
        StringBuilder current = new StringBuilder();

        for (String word : words) {
            if (word.isEmpty()) {
                continue;
            }

            String candidate = current.isEmpty() ? word : current + " " + word;
            if (font.getWidth(candidate) <= maxWidth) {
                current = new StringBuilder(candidate);
                continue;
            }

            if (!current.isEmpty()) {
                lines.add(current.toString());
                current = new StringBuilder(word);
            } else {
                lines.add(word);
                current = new StringBuilder();
            }

            if (lines.size() >= maxLines) {
                return lines;
            }
        }

        if (!current.isEmpty() && lines.size() < maxLines) {
            lines.add(current.toString());
        }

        return lines.isEmpty() ? List.of(text) : lines;
    }
}
