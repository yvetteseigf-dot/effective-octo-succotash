package sky.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4i;
import sky.access.MinecraftAccess;
import sky.util.render.ArgbUtil;
import sky.util.render.ProjectionUtil;

public final class WorldDrawHelper implements MinecraftAccess {
    public static final List<Texture> TEXTURE_DEPTH = new ArrayList<>();
    public static final List<Texture> TEXTURE = new ArrayList<>();

    private static final List<ShapeOutline> SHAPE_OUTLINES = new ArrayList<>();
    private static final List<ShapeBoxes> SHAPE_BOXES = new ArrayList<>();

    public static final List<Line> LINE_DEPTH = new ArrayList<>();
    public static final List<Line> LINE = new ArrayList<>();
    public static final List<Quad> QUAD_DEPTH = new ArrayList<>();
    public static final List<Quad> QUAD = new ArrayList<>();

    private static final List<Image3DQuad> IMAGE3D_QUADS = new ArrayList<>();
    private static final int SHAPE_CACHE_LIMIT = 256;

    private static Tessellator tessellator = Tessellator.getInstance();
    private static Matrix4f lastProjMat = new Matrix4f();
    private static Matrix4f lastModMat = new Matrix4f();
    private static Matrix4f lastWorldSpaceMatrix = new Matrix4f();

    private static final Identifier captureId = Identifier.of("skycore", "icons/world_render/bloom.png");
    private static final Identifier bloom = Identifier.of("skycore", "icons/world_render/bloom.png");

    private static float espValue = 1.0F;
    private static float espSpeed = 1.0F;
    private static float prevEspValue;
    private static float prevCircleStep;
    private static float circleStep;
    private static boolean flipSpeed;

    private WorldDrawHelper() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Matrix4f getLastProjMat() {
        return lastProjMat;
    }

    public static void setLastProjMat(Matrix4f matrix) {
        lastProjMat = matrix;
    }

    public static Matrix4f getLastModMat() {
        return lastModMat;
    }

    public static void setLastModMat(Matrix4f matrix) {
        lastModMat = matrix;
    }

    public static Matrix4f getLastWorldSpaceMatrix() {
        return lastWorldSpaceMatrix;
    }

    public static void setLastWorldSpaceMatrix(Matrix4f matrix) {
        lastWorldSpaceMatrix = matrix;
    }

    public static float getTickDelta() {
        return mc.getRenderTickCounter().getTickDelta(false);
    }

    public static void updateTargetEsp() {
        prevEspValue = espValue;
        espValue += espSpeed;

        if (espSpeed > 25.0F) {
            flipSpeed = true;
        }
        if (espSpeed < -25.0F) {
            flipSpeed = false;
        }
        espSpeed = flipSpeed ? espSpeed - 0.5F : espSpeed + 0.5F;

        prevCircleStep = circleStep;
        circleStep += 0.15F;
    }

    public static void drawLine(Vec3d start, Vec3d end, int colorStart, int colorEnd, float width, boolean depth) {
        Vec3d camera = mc.getEntityRenderDispatcher().camera.getPos();
        Line line = new Line(start.subtract(camera), end.subtract(camera), colorStart, colorEnd, width);

        if (depth) {
            LINE_DEPTH.add(line);
        } else {
            LINE.add(line);
        }
    }

    public static void drawLine(Vec3d start, Vec3d end, int color, float width, boolean depth) {
        drawLine(start, end, color, color, width, depth);
    }

    public static void drawLine(double startX, double startY, double startZ, double endX, double endY, double endZ,
                                int color, float width, boolean depth) {
        drawLine(new Vec3d(startX, startY, startZ), new Vec3d(endX, endY, endZ), color, width, depth);
    }

    public static void drawGradientQuad(Vec3d first, Vec3d second, Vec3d third, Vec3d fourth, int color1, int color2,
                                        boolean depth) {
        Vec3d camera = mc.getEntityRenderDispatcher().camera.getPos();
        Quad quad = new Quad(first.subtract(camera), second.subtract(camera), third.subtract(camera),
                fourth.subtract(camera), color1, color2, color1 != color2);

        if (depth) {
            QUAD_DEPTH.add(quad);
        } else {
            QUAD.add(quad);
        }
    }

    public static void drawQuad(Vec3d first, Vec3d second, Vec3d third, Vec3d fourth, int color, boolean depth) {
        drawGradientQuad(first, second, third, fourth, color, color, depth);
    }

    public static void drawTexture(MatrixStack.Entry entry, Identifier id, float x, float y, float width,
                                   float height, Vector4i color, boolean depth) {
        Texture texture = new Texture(entry, id, x, y, width, height, color);

        if (depth) {
            TEXTURE_DEPTH.add(texture);
        } else {
            TEXTURE.add(texture);
        }
    }

    public static void drawImage3DQuadInternal(Identifier texture, float x0, float y0, float z0, float x1, float y1,
                                               float z1, float x2, float y2, float z2, float x3, float y3, float z3,
                                               int color0, int color1, int color2, int color3, float u0, float v0,
                                               float u1, float v1, float u2, float v2, float u3, float v3) {
        IMAGE3D_QUADS.add(new Image3DQuad(texture, x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3,
                color0, color1, color2, color3, u0, v0, u1, v1, u2, v2, u3, v3));
    }

    public static void drawBox(Box box, int color, float lineWidth, boolean outline, boolean filled, boolean depth) {
        box = box.expand(0.001);
        if (!ProjectionUtil.canSee(box)) {
            return;
        }

        double minX = box.minX;
        double minY = box.minY;
        double minZ = box.minZ;
        double maxX = box.maxX;
        double maxY = box.maxY;
        double maxZ = box.maxZ;

        if (filled) {
            int fillColor = ArgbUtil.multAlpha(color, 0.1F);

            drawQuad(new Vec3d(minX, minY, minZ), new Vec3d(maxX, minY, minZ), new Vec3d(maxX, minY, maxZ),
                    new Vec3d(minX, minY, maxZ), fillColor, depth);
            drawQuad(new Vec3d(minX, minY, minZ), new Vec3d(minX, maxY, minZ), new Vec3d(maxX, maxY, minZ),
                    new Vec3d(maxX, minY, minZ), fillColor, depth);
            drawQuad(new Vec3d(maxX, minY, minZ), new Vec3d(maxX, maxY, minZ), new Vec3d(maxX, maxY, maxZ),
                    new Vec3d(maxX, minY, maxZ), fillColor, depth);
            drawQuad(new Vec3d(minX, minY, maxZ), new Vec3d(maxX, minY, maxZ), new Vec3d(maxX, maxY, maxZ),
                    new Vec3d(minX, maxY, maxZ), fillColor, depth);
            drawQuad(new Vec3d(minX, minY, minZ), new Vec3d(minX, minY, maxZ), new Vec3d(minX, maxY, maxZ),
                    new Vec3d(minX, maxY, minZ), fillColor, depth);
            drawQuad(new Vec3d(minX, maxY, minZ), new Vec3d(minX, maxY, maxZ), new Vec3d(maxX, maxY, maxZ),
                    new Vec3d(maxX, maxY, minZ), fillColor, depth);
        }

        if (outline) {
            drawLine(minX, minY, minZ, maxX, minY, minZ, color, lineWidth, depth);
            drawLine(maxX, minY, minZ, maxX, minY, maxZ, color, lineWidth, depth);
            drawLine(maxX, minY, maxZ, minX, minY, maxZ, color, lineWidth, depth);
            drawLine(minX, minY, maxZ, minX, minY, minZ, color, lineWidth, depth);
            drawLine(minX, minY, maxZ, minX, maxY, maxZ, color, lineWidth, depth);
            drawLine(minX, minY, minZ, minX, maxY, minZ, color, lineWidth, depth);
            drawLine(maxX, minY, maxZ, maxX, maxY, maxZ, color, lineWidth, depth);
            drawLine(maxX, minY, minZ, maxX, maxY, minZ, color, lineWidth, depth);
            drawLine(minX, maxY, minZ, maxX, maxY, minZ, color, lineWidth, depth);
            drawLine(maxX, maxY, minZ, maxX, maxY, maxZ, color, lineWidth, depth);
            drawLine(maxX, maxY, maxZ, minX, maxY, maxZ, color, lineWidth, depth);
            drawLine(minX, maxY, maxZ, minX, maxY, minZ, color, lineWidth, depth);
        }
    }

    public static void drawBox(Box box, int color, float lineWidth) {
        drawBox(box, color, lineWidth, true, true, false);
    }

    public static void drawShape(BlockPos pos, VoxelShape shape, int color, float lineWidth, boolean filled,
                                 boolean depth) {
        if (!ProjectionUtil.canSee(shape.getBoundingBox().offset(pos))) {
            return;
        }

        SHAPE_BOXES.stream()
                .filter(cached -> cached.shape.equals(shape))
                .findFirst()
                .ifPresentOrElse(
                        cached -> cached.boxes.forEach(box ->
                                drawBox(box.offset(pos), color, lineWidth, true, filled, depth)),
                        () -> {
                            if (SHAPE_BOXES.size() >= SHAPE_CACHE_LIMIT) {
                                SHAPE_BOXES.clear();
                            }
                            SHAPE_BOXES.add(new ShapeBoxes(shape, shape.getBoundingBoxes()));
                        });
    }

    public static void drawShape(BlockPos pos, VoxelShape shape, int color, float lineWidth) {
        drawShape(pos, shape, color, lineWidth, true, false);
    }

    public static void drawShapeAlternative(BlockPos pos, VoxelShape shape, int color, float lineWidth,
                                            boolean filled, boolean depth) {
        Vec3d origin = Vec3d.of(pos);
        if (!ProjectionUtil.canSee(shape.getBoundingBox().offset(origin))) {
            return;
        }

        List<Box> boxes = shape.getBoundingBoxes();
        SHAPE_OUTLINES.stream()
                .filter(cached -> cached.boxes.equals(boxes))
                .findFirst()
                .ifPresentOrElse(
                        cached -> {
                            cached.boxes.forEach(box ->
                                    drawBox(box.offset(origin), color, lineWidth, false, filled, depth));
                            cached.lines.forEach(line ->
                                    drawLine(line.start.add(origin), line.end.add(origin), color, lineWidth, depth));
                        },
                        () -> {
                            if (SHAPE_OUTLINES.size() >= SHAPE_CACHE_LIMIT) {
                                SHAPE_OUTLINES.clear();
                            }
                            List<Line> lines = new ArrayList<>();
                            shape.forEachEdge((x1, y1, z1, x2, y2, z2) -> lines.add(
                                    new Line(new Vec3d(x1, y1, z1), new Vec3d(x2, y2, z2), 0, 0, 0.0F)));
                            SHAPE_OUTLINES.add(new ShapeOutline(shape, lines, shape.getBoundingBoxes()));
                        });
    }

    public static void onEventRender3D(MatrixStack matrices) {
        trimShapeCaches();
        MatrixStack.Entry entry = matrices.peek();

        if (!QUAD.isEmpty()) {
            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            RenderSystem.disableDepthTest();
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA,
                    GlStateManager.DstFactor.ONE_MINUS_CONSTANT_ALPHA);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

            BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            QUAD.forEach(quad -> {
                if (quad.gradient()) {
                    vertexGradientQuad(entry, buffer, quad.x(), quad.y(), quad.w(), quad.z(), quad.color1(),
                            quad.color2());
                } else {
                    vertexQuad(entry, buffer, quad.x(), quad.y(), quad.w(), quad.z(), quad.color1());
                }
            });
            BufferRenderer.drawWithGlobalProgram(buffer.end());

            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            QUAD.clear();
        }

        if (!LINE.isEmpty()) {
            Set<Float> widths = LINE.stream()
                    .map(line -> line.width)
                    .collect(Collectors.toCollection(LinkedHashSet::new));

            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            RenderSystem.disableDepthTest();
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA,
                    GlStateManager.DstFactor.ONE_MINUS_CONSTANT_ALPHA);
            RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);

            widths.forEach(width -> {
                RenderSystem.lineWidth(width);
                BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.LINES,
                        VertexFormats.LINES);
                LINE.stream()
                        .filter(line -> line.width == width)
                        .forEach(line -> vertexLine(matrices, buffer, line.start, line.end, line.colorStart,
                                line.colorEnd));
                BufferRenderer.drawWithGlobalProgram(buffer.end());
            });

            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            LINE.clear();
        }

        if (!LINE_DEPTH.isEmpty()) {
            Set<Float> widths = LINE_DEPTH.stream()
                    .map(line -> line.width)
                    .collect(Collectors.toCollection(LinkedHashSet::new));

            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA,
                    GlStateManager.DstFactor.ONE_MINUS_CONSTANT_ALPHA);
            RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);

            widths.forEach(width -> {
                RenderSystem.lineWidth(width);
                BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.LINES,
                        VertexFormats.LINES);
                LINE_DEPTH.stream()
                        .filter(line -> line.width == width)
                        .forEach(line -> vertexLine(matrices, buffer, line.start, line.end, line.colorStart,
                                line.colorEnd));
                BufferRenderer.drawWithGlobalProgram(buffer.end());
            });

            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            LINE_DEPTH.clear();
        }

        if (!QUAD_DEPTH.isEmpty()) {
            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA,
                    GlStateManager.DstFactor.ONE_MINUS_CONSTANT_ALPHA);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

            BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            QUAD_DEPTH.forEach(quad -> {
                if (quad.gradient()) {
                    vertexGradientQuad(entry, buffer, quad.x(), quad.y(), quad.w(), quad.z(), quad.color1(),
                            quad.color2());
                } else {
                    vertexQuad(entry, buffer, quad.x(), quad.y(), quad.w(), quad.z(), quad.color1());
                }
            });
            BufferRenderer.drawWithGlobalProgram(buffer.end());

            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            QUAD_DEPTH.clear();
        }

        if (!TEXTURE.isEmpty()) {
            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            RenderSystem.disableDepthTest();
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

            TEXTURE.forEach(texture -> {
                RenderSystem.setShaderTexture(0, texture.id);
                BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.QUADS,
                        VertexFormats.POSITION_TEXTURE_COLOR);
                renderTexture(texture, buffer);
                BufferRenderer.drawWithGlobalProgram(buffer.end());
            });

            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            TEXTURE.clear();
        }

        if (!TEXTURE_DEPTH.isEmpty()) {
            RenderSystem.enableBlend();
            RenderSystem.disableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

            TEXTURE_DEPTH.forEach(texture -> {
                RenderSystem.setShaderTexture(0, texture.id);
                BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.QUADS,
                        VertexFormats.POSITION_TEXTURE_COLOR);
                renderTexture(texture, buffer);
                BufferRenderer.drawWithGlobalProgram(buffer.end());
            });

            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            TEXTURE_DEPTH.clear();
        }

        flushImage3DBatch(matrices.peek());
    }

    public static void flushImage3DBatch(MatrixStack.Entry entry) {
        if (IMAGE3D_QUADS.isEmpty()) {
            return;
        }

        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

        Identifier boundTexture = null;
        BufferBuilder buffer = null;

        for (Image3DQuad quad : IMAGE3D_QUADS) {
            if (!quad.texture.equals(boundTexture)) {
                if (buffer != null) {
                    BufferRenderer.drawWithGlobalProgram(buffer.end());
                }

                boundTexture = quad.texture;
                RenderSystem.setShaderTexture(0, boundTexture);
                buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            }

            appendImage3DVertex(entry, buffer, quad.x0, quad.y0, quad.z0, quad.u0, quad.v0, quad.color0);
            appendImage3DVertex(entry, buffer, quad.x1, quad.y1, quad.z1, quad.u1, quad.v1, quad.color1);
            appendImage3DVertex(entry, buffer, quad.x2, quad.y2, quad.z2, quad.u2, quad.v2, quad.color2);
            appendImage3DVertex(entry, buffer, quad.x3, quad.y3, quad.z3, quad.u3, quad.v3, quad.color3);
        }

        if (buffer != null) {
            BufferRenderer.drawWithGlobalProgram(buffer.end());
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        IMAGE3D_QUADS.clear();
    }

    public static void vertexLine(MatrixStack matrices, VertexConsumer consumer, Vector3f start, Vector3f end,
                                  int colorStart, int colorEnd) {
        matrices.push();
        MatrixStack.Entry entry = matrices.peek();
        Vector3f normal = getNormal(start.x, start.y, start.z, end.x, end.y, end.z);

        consumer.vertex(entry, start).color(colorStart).normal(entry, normal.x(), normal.y(), normal.z());
        consumer.vertex(entry, end).color(colorEnd).normal(entry, normal.x(), normal.y(), normal.z());

        matrices.pop();
    }

    public static void vertexLine(MatrixStack matrices, VertexConsumer consumer, Vec3d start, Vec3d end,
                                  int colorStart, int colorEnd) {
        vertexLine(matrices, consumer, start.toVector3f(), end.toVector3f(), colorStart, colorEnd);
    }

    public static void vertexLine(MatrixStack matrices, VertexConsumer consumer, Vec3d start, Vec3d end, int color) {
        vertexLine(matrices, consumer, start.toVector3f(), end.toVector3f(), color, color);
    }

    public static void vertexQuad(MatrixStack.Entry entry, VertexConsumer consumer, Vector3f first, Vector3f second,
                                  Vector3f third, Vector3f fourth, int color) {
        consumer.vertex(entry, first).color(color);
        consumer.vertex(entry, second).color(color);
        consumer.vertex(entry, third).color(color);
        consumer.vertex(entry, fourth).color(color);
    }

    public static void vertexQuad(MatrixStack.Entry entry, VertexConsumer consumer, Vec3d first, Vec3d second,
                                  Vec3d third, Vec3d fourth, int color) {
        vertexQuad(entry, consumer, first.toVector3f(), second.toVector3f(), third.toVector3f(), fourth.toVector3f(),
                color);
    }

    public static void vertexGradientQuad(MatrixStack.Entry entry, VertexConsumer consumer, Vector3f first,
                                          Vector3f second, Vector3f third, Vector3f fourth, int color1, int color2) {
        consumer.vertex(entry, first).color(color1);
        consumer.vertex(entry, second).color(color2);
        consumer.vertex(entry, third).color(color2);
        consumer.vertex(entry, fourth).color(color1);
    }

    public static void vertexGradientQuad(MatrixStack.Entry entry, VertexConsumer consumer, Vec3d first, Vec3d second,
                                          Vec3d third, Vec3d fourth, int color1, int color2) {
        vertexGradientQuad(entry, consumer, first.toVector3f(), second.toVector3f(), third.toVector3f(),
                fourth.toVector3f(), color1, color2);
    }

    public static Vector3f getNormal(float startX, float startY, float startZ, float endX, float endY, float endZ) {
        float deltaX = endX - startX;
        float deltaY = endY - startY;
        float deltaZ = endZ - startZ;
        float length = MathHelper.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
        return new Vector3f(deltaX / length, deltaY / length, deltaZ / length);
    }

    private static void renderTexture(Texture texture, BufferBuilder buffer) {
        MatrixStack.Entry entry = texture.entry;
        float x = texture.x;
        float y = texture.y;
        float width = texture.width;
        float height = texture.height;
        Vector4i color = texture.color;

        buffer.vertex(entry, x, y, 0.0F).color(color.x).texture(0.0F, 0.0F);
        buffer.vertex(entry, x, y + height, 0.0F).color(color.y).texture(0.0F, 1.0F);
        buffer.vertex(entry, x + width, y + height, 0.0F).color(color.z).texture(1.0F, 1.0F);
        buffer.vertex(entry, x + width, y, 0.0F).color(color.w).texture(1.0F, 0.0F);
    }

    private static void appendImage3DVertex(MatrixStack.Entry entry, BufferBuilder buffer, float x, float y, float z,
                                            float u, float v, int color) {
        buffer.vertex(entry, x, y, z)
                .texture(u, v)
                .color(color >> 16 & 255, color >> 8 & 255, color & 255, color >>> 24);
    }

    private static void trimShapeCaches() {
        if (SHAPE_BOXES.size() > SHAPE_CACHE_LIMIT) {
            SHAPE_BOXES.subList(0, SHAPE_BOXES.size() - SHAPE_CACHE_LIMIT).clear();
        }
        if (SHAPE_OUTLINES.size() > SHAPE_CACHE_LIMIT) {
            SHAPE_OUTLINES.subList(0, SHAPE_OUTLINES.size() - SHAPE_CACHE_LIMIT).clear();
        }
    }

    public record Line(Vec3d start, Vec3d end, int colorStart, int colorEnd, float width) {
    }

    public record Quad(Vec3d x, Vec3d y, Vec3d w, Vec3d z, int color1, int color2, boolean gradient) {
    }

    public record ShapeBoxes(VoxelShape shape, List<Box> boxes) {
    }

    public record ShapeOutline(VoxelShape shape, List<Line> lines, List<Box> boxes) {
    }

    public record Texture(MatrixStack.Entry entry, Identifier id, float x, float y, float width, float height,
                          Vector4i color) {
    }

    private static final class Image3DQuad {
        private final Identifier texture;
        private final float x0;
        private final float y0;
        private final float z0;
        private final float x1;
        private final float y1;
        private final float z1;
        private final float x2;
        private final float y2;
        private final float z2;
        private final float x3;
        private final float y3;
        private final float z3;
        private final int color0;
        private final int color1;
        private final int color2;
        private final int color3;
        private final float u0;
        private final float v0;
        private final float u1;
        private final float v1;
        private final float u2;
        private final float v2;
        private final float u3;
        private final float v3;

        private Image3DQuad(Identifier texture, float x0, float y0, float z0, float x1, float y1, float z1, float x2,
                            float y2, float z2, float x3, float y3, float z3, int color0, int color1, int color2,
                            int color3, float u0, float v0, float u1, float v1, float u2, float v2, float u3,
                            float v3) {
            this.texture = texture;
            this.x0 = x0;
            this.y0 = y0;
            this.z0 = z0;
            this.x1 = x1;
            this.y1 = y1;
            this.z1 = z1;
            this.x2 = x2;
            this.y2 = y2;
            this.z2 = z2;
            this.x3 = x3;
            this.y3 = y3;
            this.z3 = z3;
            this.color0 = color0;
            this.color1 = color1;
            this.color2 = color2;
            this.color3 = color3;
            this.u0 = u0;
            this.v0 = v0;
            this.u1 = u1;
            this.v1 = v1;
            this.u2 = u2;
            this.v2 = v2;
            this.u3 = u3;
            this.v3 = v3;
        }
    }
}
