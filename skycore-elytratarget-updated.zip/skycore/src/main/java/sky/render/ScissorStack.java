package sky.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import sky.util.render.HudScaleUtil;

import java.util.ArrayDeque;
import java.util.Deque;

public final class ScissorStack {
    private static int[] current;
    private static final Deque<int[]> STACK = new ArrayDeque<>();

    private ScissorStack() {
    }

    public static void reset() {
        STACK.clear();
        current = null;
        RenderSystem.disableScissor();
    }

    public static void enable(float x, float y, float width, float height) {
        Window window = MinecraftClient.getInstance().getWindow();
        double scale = HudScaleUtil.getScale();
        if (scale <= 0.0D) {
            scale = 2.0D;
        }
        int framebufferHeight = window.getFramebufferHeight();
        int scaledX = (int) Math.floor(x * scale);
        int scaledY = (int) Math.floor(framebufferHeight - (y + height) * scale);
        int scaledWidth = (int) Math.ceil(width * scale);
        int scaledHeight = (int) Math.ceil(height * scale);
        scaledX = Math.max(0, scaledX);
        scaledY = Math.max(0, scaledY);
        scaledWidth = Math.max(0, Math.min(scaledWidth, window.getFramebufferWidth() - scaledX));
        scaledHeight = Math.max(0, Math.min(scaledHeight, window.getFramebufferHeight() - scaledY));
        if (current != null) {
            STACK.push(current);
            int left = Math.max(scaledX, current[0]);
            int top = Math.max(scaledY, current[1]);
            int right = Math.min(scaledX + scaledWidth, current[0] + current[2]);
            int bottom = Math.min(scaledY + scaledHeight, current[1] + current[3]);
            scaledX = left;
            scaledY = top;
            scaledWidth = Math.max(0, right - left);
            scaledHeight = Math.max(0, bottom - top);
        }
        current = new int[]{scaledX, scaledY, scaledWidth, scaledHeight};
        RenderSystem.enableScissor(current[0], current[1], current[2], current[3]);
    }

    public static void disable() {
        if (!STACK.isEmpty()) {
            current = STACK.pop();
            RenderSystem.enableScissor(current[0], current[1], current[2], current[3]);
            return;
        }
        current = null;
        RenderSystem.disableScissor();
    }
}
