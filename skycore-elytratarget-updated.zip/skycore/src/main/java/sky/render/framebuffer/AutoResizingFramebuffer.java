package sky.render.framebuffer;

import net.minecraft.client.gl.Framebuffer;
import sky.access.MinecraftAccess;

public final class AutoResizingFramebuffer extends Framebuffer implements MinecraftAccess {
    public AutoResizingFramebuffer(boolean useDepth) {
        super(useDepth);
    }

    public void setup(boolean clear) {
        resizeFramebuffer();
        setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
        if (clear) {
            clear();
        }
        beginWrite(false);
    }

    public void stop() {
        endWrite();
        mc.getFramebuffer().beginWrite(false);
    }

    public void resizeTo(int width, int height) {
        int framebufferWidth = Math.max(1, width);
        int framebufferHeight = Math.max(1, height);
        if (textureWidth == framebufferWidth && textureHeight == framebufferHeight) {
            return;
        }

        resize(framebufferWidth, framebufferHeight);
    }

    private void resizeFramebuffer() {
        if (!needsNewFramebuffer()) {
            return;
        }

        Framebuffer mainFramebuffer = mc.getFramebuffer();
        initFbo(
                Math.max(1, mainFramebuffer.textureWidth),
                Math.max(1, mainFramebuffer.textureHeight)
        );
    }

    private boolean needsNewFramebuffer() {
        Framebuffer mainFramebuffer = mc.getFramebuffer();
        return textureWidth != mainFramebuffer.textureWidth || textureHeight != mainFramebuffer.textureHeight;
    }
}
