package sky.render.framebuffer;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gl.SimpleFramebuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL30;
import sky.access.MinecraftAccess;

public final class BlurManager implements MinecraftAccess {
    public static final BlurManager BLUR = new BlurManager();

    private boolean kawaseApplied;
    private long lastUpdateFrame;
    private Framebuffer half;
    public Framebuffer blurred;
    private Framebuffer additional;
    private Framebuffer quarter;

    private BlurManager() {
        this.lastUpdateFrame = -1L;
    }

    private void setLinear(Framebuffer framebuffer) {
        RenderSystem.bindTexture(framebuffer.getColorAttachment());
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        RenderSystem.bindTexture(0);
    }

    public int getSampleTexture() {
        if (this.kawaseApplied && this.blurred != null) {
            return this.blurred.getColorAttachment();
        }

        return this.additional == null ? 0 : this.additional.getColorAttachment();
    }

    public boolean hasCapturedFrame() {
        return this.additional != null || this.blurred != null;
    }

    private Framebuffer resize(Framebuffer framebuffer, int width, int height) {
        if (framebuffer != null && framebuffer.textureWidth == width && framebuffer.textureHeight == height) {
            return framebuffer;
        }

        if (framebuffer != null) {
            framebuffer.delete();
        }

        Framebuffer resized = new SimpleFramebuffer(width, height, false);
        setLinear(resized);
        return resized;
    }

    public boolean isKawaseApplied() {
        return this.kawaseApplied;
    }

    private void ensureBuffers(int width, int height, int halfWidth, int halfHeight, int quarterWidth, int quarterHeight) {
        this.blurred = resize(this.blurred, width, height);
        this.additional = resize(this.additional, width, height);
        this.half = resize(this.half, halfWidth, halfHeight);
        this.quarter = resize(this.quarter, quarterWidth, quarterHeight);
    }

    private void restoreMainFramebuffer() {
        mc.getFramebuffer().beginWrite(true);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
    }

    public void updateBlur(float radius, int passes, boolean force) {
        if (mc.getFramebuffer() == null) {
            return;
        }

        RenderSystem.assertOnRenderThread();

        long frame = System.nanoTime() / 16666666L;
        if (!force && frame == this.lastUpdateFrame && this.kawaseApplied) {
            return;
        }

        this.lastUpdateFrame = frame;

        int width = mc.getWindow().getFramebufferWidth();
        int height = mc.getWindow().getFramebufferHeight();
        int halfWidth = Math.max(1, width / 2);
        int halfHeight = Math.max(1, height / 2);
        int quarterWidth = Math.max(1, width / 4);
        int quarterHeight = Math.max(1, height / 4);
        int passCount = Math.max(1, Math.min(passes, 8));

        ensureBuffers(width, height, halfWidth, halfHeight, quarterWidth, quarterHeight);
        this.kawaseApplied = false;
        blit(mc.getFramebuffer(), this.additional, width, height, width, height);

        Framebuffer source = this.additional;
        for (int pass = 0; pass < passCount; pass++) {
            blit(source, this.half, source.textureWidth, source.textureHeight, halfWidth, halfHeight);
            blit(this.half, this.quarter, halfWidth, halfHeight, quarterWidth, quarterHeight);
            blit(this.quarter, this.half, quarterWidth, quarterHeight, halfWidth, halfHeight);
            blit(this.half, this.blurred, halfWidth, halfHeight, width, height);
            source = this.blurred;
        }

        this.kawaseApplied = true;
        restoreMainFramebuffer();
    }

    public void updateBlur(float radius, int passes) {
        updateBlur(radius, passes, false);
    }

    private void blit(Framebuffer source, Framebuffer destination, int sourceWidth, int sourceHeight, int destinationWidth, int destinationHeight) {
        int previousRead = GL30.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int previousDraw = GL30.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, source.fbo);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, destination.fbo);
        GL30.glBlitFramebuffer(0, 0, sourceWidth, sourceHeight, 0, 0, destinationWidth, destinationHeight,
                GL11.GL_COLOR_BUFFER_BIT, GL11.GL_LINEAR);
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, previousRead);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, previousDraw);
    }
}
