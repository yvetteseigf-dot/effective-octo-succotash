package sky.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import sky.theme.GuiTheme;
import sky.theme.ThemePreset;
import sky.theme.ThemeRegistry;
import sky.screen.ClickGuiScreen;
import sky.clickgui.ClickGuiLayout;
import sky.clickgui.GuiStyle;
import sky.util.render.ColorUtil;
import sky.util.math.CornerRadii;

import java.awt.Color;
import sky.render.framebuffer.BlurManager;
import sky.render.shader.ShaderLibrary;

public final class GuiSurfaceRenderer {
    private static final Color BLUR_TINT = new Color(255, 255, 255, 0);
    private static final Color BLUR_WINDOW_OVERLAY = new Color(21, 21, 21, 217);
    private static final Color BLUR2_OVERLAY = new Color(0, 0, 0, 255);
    private static final Color MODULES_PANEL_BLUR = new Color(0, 0, 0, ClickGuiLayout.opacity(15));
    private static final float GUI_BLUR_STRENGTH = 22.0F;
    private static final float HUD_BLUR_STRENGTH = 10.0F;
    private static final float BLUR2_GUI_BLUR_STRENGTH = 36.0F;
    private static final float BLUR2_HUD_BLUR_STRENGTH = 18.0F;
    private static final int BLUR_KAWASE_STEPS = 5;
    private static final int BLUR2_KAWASE_STEPS = 5;

    private GuiSurfaceRenderer() {
    }

    public static void drawWindowBackground(DrawHelper renderer, float x, float y, float width, float height,
                                            float radius, float alpha, MatrixStack matrices) {
        drawSurface(renderer, x, y, width, height, radius, alpha, matrices);
    }

    public static void drawSurface(DrawHelper renderer, float x, float y, float width, float height,
                                   float radius, float alpha, MatrixStack matrices) {
        drawSurface(renderer, x, y, width, height, CornerRadii.all(radius), alpha, matrices, false);
    }

    public static void drawSurface(DrawHelper renderer, float x, float y, float width, float height,
                                   CornerRadii radii, float alpha, MatrixStack matrices) {
        drawSurface(renderer, x, y, width, height, radii, alpha, matrices, false);
    }

    public static void drawHudSurface(DrawHelper renderer, float x, float y, float width, float height,
                                      float radius, float alpha, MatrixStack matrices) {
        drawSurface(renderer, x, y, width, height, CornerRadii.all(radius), alpha, matrices, true);
    }

    public static void drawPanelBackground(DrawHelper renderer, float x, float y, float width, float height,
                                           float radius, float alpha, MatrixStack matrices) {
        GuiTheme theme = GuiTheme.theme;
        switch (theme.getGuiStyle()) {
            case BLUR -> renderer.drawRoundedRect(x, y, width, height, radius,
                    ColorUtil.withAlpha(MODULES_PANEL_BLUR, alpha), matrices);
            case KAWASE -> {
                float opacity = surfaceOpacity(theme);
                ThemePreset preset = ThemeRegistry.getCurrent();
                Color overlay = preset.isReleasePreset() ? preset.getClientColor() : BLUR2_OVERLAY;
                Color tinted = ColorUtil.withAlpha(overlay, alpha * opacity * 0.85F);
                renderer.drawRoundedRect(x, y, width, height, radius, tinted, matrices);
            }
            case MATTE -> renderer.drawRoundedRect(x, y, width, height, radius,
                    opaque(theme.getPanelBottom(), alpha), matrices);
            case GRADIENT -> {
                float opacity = surfaceOpacity(theme);
                Color card = ColorUtil.withAlpha(opaque(theme.getCardBottom(), 1.0F), alpha * opacity * 0.85F);
                renderer.drawRoundedRect(x, y, width, height, radius, card, matrices);
            }
        }
    }

    public static void captureBackground() {
        if (!GuiTheme.theme.getGuiStyle().usesKawaseBlur()) {
            return;
        }
        GuiStyle style = GuiTheme.theme.getGuiStyle();
        if (style == GuiStyle.KAWASE) {
            if (BlurManager.BLUR.isKawaseApplied()) {
                return;
            }
            ShaderLibrary.loadBlurShaders();
            BlurManager.BLUR.updateBlur(3.0F, BLUR2_KAWASE_STEPS, false);
        } else {
            if (BlurManager.BLUR.isKawaseApplied()) {
                return;
            }
            ShaderLibrary.loadBlurShaders();
            BlurManager.BLUR.updateBlur(3.0F, BLUR_KAWASE_STEPS, false);
        }
    }

    public static void captureHudBackground() {
        if (!GuiTheme.theme.getGuiStyle().usesKawaseBlur()) {
            return;
        }
        if (isClickGuiOpen()) {
            return;
        }
        if (!BlurManager.BLUR.isKawaseApplied()) {
            ShaderLibrary.loadBlurShaders();
            int steps = GuiTheme.theme.getGuiStyle() == GuiStyle.KAWASE ? BLUR2_KAWASE_STEPS : 2;
            BlurManager.BLUR.updateBlur(3.0F, steps, false);
        }
    }

    private static void drawSurface(DrawHelper renderer, float x, float y, float width, float height,
                                    CornerRadii radii, float alpha, MatrixStack matrices, boolean hud) {
        GuiTheme theme = GuiTheme.theme;
        switch (theme.getGuiStyle()) {
            case BLUR -> drawBlurSurface(renderer, x, y, width, height, radii, alpha, matrices, hud,
                    BLUR_WINDOW_OVERLAY, 1.0F);
            case KAWASE -> {
                float opacity = surfaceOpacity(theme);
                ThemePreset preset = ThemeRegistry.getCurrent();
                Color overlay = preset.isReleasePreset() ? preset.getClientColor() : BLUR2_OVERLAY;
                if (hud) {
                    drawBlur2HudSurface(renderer, x, y, width, height, radii, alpha, matrices, overlay, opacity);
                } else {
                    drawBlurSurface(renderer, x, y, width, height, radii, alpha, matrices, false, overlay, opacity);
                }
            }
            case MATTE -> {
                Color panel = opaque(theme.getPanelBottom(), alpha);
                renderer.drawRoundedRect(x, y, width, height, radii, panel, matrices);
            }
            case GRADIENT -> {
                float opacity = surfaceOpacity(theme);
                Color top = ColorUtil.withAlpha(opaque(theme.getPanelTop(), 1.0F), alpha * opacity);
                Color bottom = ColorUtil.withAlpha(opaque(theme.getPanelBottom(), 1.0F), alpha * opacity);
                float radius = Math.max(radii.topLeft(),
                        Math.max(radii.topRight(), Math.max(radii.bottomLeft(), radii.bottomRight())));
                theme.drawGradient(renderer, x, y, width, height, radius, top, bottom, matrices);
            }
        }
    }

    private static void drawBlurSurface(DrawHelper renderer, float x, float y, float width, float height,
                                        CornerRadii radii, float alpha, MatrixStack matrices, boolean hud,
                                        Color overlay, float overlayOpacity) {
        if (hud) {
            captureHudBackground();
        } else {
            captureBackground();
        }
        float radius = Math.max(radii.topLeft(),
                Math.max(radii.topRight(), Math.max(radii.bottomLeft(), radii.bottomRight())));
        float strength = resolveBlurStrength(hud);
        renderer.drawBlurredRoundedRect(x, y, width, height, radius, BLUR_TINT, alpha, matrices, strength);
        renderer.drawRoundedRect(x, y, width, height, radii,
                ColorUtil.withAlpha(overlay, alpha * overlayOpacity), matrices);
    }

    private static void drawBlur2HudSurface(DrawHelper renderer, float x, float y, float width, float height,
                                            CornerRadii radii, float alpha, MatrixStack matrices,
                                            Color overlay, float overlayOpacity) {
        captureHudBackground();
        int overlayAlpha = Math.round(overlay.getAlpha() * overlayOpacity);
        Color tinted = new Color(overlay.getRed(), overlay.getGreen(), overlay.getBlue(),
                Math.max(0, Math.min(255, overlayAlpha)));
        renderer.drawBlurredHudPanel(x, y, width, height, radii, tinted, alpha, matrices, BLUR2_GUI_BLUR_STRENGTH);
    }

    private static float resolveBlurStrength(boolean hud) {
        if (GuiTheme.theme.getGuiStyle() == GuiStyle.KAWASE) {
            return hud ? BLUR2_HUD_BLUR_STRENGTH : BLUR2_GUI_BLUR_STRENGTH;
        }
        return hud ? HUD_BLUR_STRENGTH : GUI_BLUR_STRENGTH;
    }

    private static float surfaceOpacity(GuiTheme theme) {
        return Math.min(1.0F, theme.getGradientOpacity() / 100.0F);
    }

    private static Color opaque(Color source, float alpha) {
        return new Color(source.getRed(), source.getGreen(), source.getBlue(),
                Math.max(0, Math.min(255, Math.round(255.0F * alpha))));
    }

    private static boolean isClickGuiOpen() {
        return MinecraftClient.getInstance().currentScreen instanceof ClickGuiScreen;
    }
}
