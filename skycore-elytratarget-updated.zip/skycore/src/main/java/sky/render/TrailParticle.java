package sky.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4f;
import sky.access.MinecraftAccess;
import sky.event.render.RenderWorldEvent;

public final class TrailParticle implements MinecraftAccess {
    private static final float TAIL_LENGTH = 15.0F;

    private final List<Vector4f> tail;
    private Vec3d position;
    private Vec3d motion;

    public TrailParticle(Vec3d position, Vec3d motion) {
        this.tail = new ArrayList<>();
        this.position = position;
        this.motion = motion;
    }

    public Vec3d getPosition() {
        return this.position;
    }

    public void setMotion(Vec3d motion) {
        this.motion = motion;
    }

    public void update() {
        this.motion = this.motion.multiply(0.97D);
    }

    public void render(RenderWorldEvent event, Identifier texture, Color color, float size,
                       float renderAlpha) {
        this.position = this.position.add(this.motion);
        this.tail.add(new Vector4f((float) this.position.x, (float) this.position.y + 0.4F, (float) this.position.z,
                TAIL_LENGTH));

        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();
        MatrixStack matrices = event.getMatrixStack();
        List<Vector4f> expired = new ArrayList<>();

        for (Vector4f point : this.tail) {
            if (point.w <= 0.0F) {
                expired.add(point);
                continue;
            }

            float scale = size * point.w / TAIL_LENGTH;
            int alpha = (int) (point.w / TAIL_LENGTH * renderAlpha * 255.0F);
            if (alpha <= 0) {
                expired.add(point);
                continue;
            }

            matrices.push();
            matrices.translate(point.x - cameraPos.x, point.y - cameraPos.y, point.z - cameraPos.z);
            matrices.multiply(mc.gameRenderer.getCamera().getRotation());

            Color tint = new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
            WorldTextureRenderer.drawTexture(matrices, texture, -scale / 2.0F, -scale / 2.0F, scale, scale, tint);

            matrices.pop();

            point.y += 0.022F;
            point.w -= 0.4F;
        }

        this.tail.removeAll(expired);
    }
}
