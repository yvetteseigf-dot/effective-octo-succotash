package sky.render.font;

import java.util.Objects;

public final class Glyph {
    private final int height;
    private final FontAtlas atlas;
    private final float advance;
    private final int v;
    private final int u;
    private final int width;
    private final char value;

    public Glyph(int u, int v, int width, int height, float advance, char value, FontAtlas atlas) {
        this.u = u;
        this.v = v;
        this.width = width;
        this.height = height;
        this.advance = advance;
        this.value = value;
        this.atlas = atlas;
    }

    public FontAtlas atlas() {
        return atlas;
    }

    public float advance() {
        return advance;
    }

    public int width() {
        return width;
    }

    public int height() {
        return height;
    }

    public char value() {
        return value;
    }

    public int v() {
        return v;
    }

    public int u() {
        return u;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Glyph glyph)) {
            return false;
        }
        return u == glyph.u
                && v == glyph.v
                && width == glyph.width
                && height == glyph.height
                && Float.compare(advance, glyph.advance) == 0
                && value == glyph.value
                && Objects.equals(atlas, glyph.atlas);
    }

    @Override
    public int hashCode() {
        return Objects.hash(u, v, width, height, advance, value, atlas);
    }
}
