package sky.render.font;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.WritableRaster;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

public final class FontAtlas {
    private final Map<Character, Glyph> glyphs;
    private final char lastCharExclusive;
    private final char firstChar;
    public int width;
    public int height;
    private final Font baseFont;
    private boolean built;
    private final int padding;
    public final Identifier textureId;

    public FontAtlas(char firstChar, char lastCharExclusive, Font baseFont, Identifier textureId, int padding) {
        this.glyphs = new HashMap<>();
        this.firstChar = firstChar;
        this.lastCharExclusive = lastCharExclusive;
        this.baseFont = baseFont;
        this.textureId = textureId;
        this.padding = padding;
    }

    public static void uploadTexture(Identifier textureId, BufferedImage image) {
        int imageWidth = image.getWidth();
        int imageHeight = image.getHeight();
        NativeImage nativeImage = new NativeImage(NativeImage.Format.RGBA, imageWidth, imageHeight, false);
        WritableRaster raster = image.getRaster();
        ColorModel colorModel = image.getColorModel();
        Object data = createRasterDataBuffer(raster);
        for (int y = 0; y < imageHeight; y++) {
            for (int x = 0; x < imageWidth; x++) {
                raster.getDataElements(x, y, data);
                int alpha = colorModel.getAlpha(data);
                int red = colorModel.getRed(data);
                int green = colorModel.getGreen(data);
                int blue = colorModel.getBlue(data);
                nativeImage.setColorArgb(x, y, alpha << 24 | red << 16 | green << 8 | blue);
            }
        }
        NativeImageBackedTexture texture = new NativeImageBackedTexture(nativeImage);
        texture.upload();
        if (RenderSystem.isOnRenderThread()) {
            MinecraftClient.getInstance().getTextureManager().registerTexture(textureId, texture);
        } else {
            RenderSystem.recordRenderCall(() -> MinecraftClient.getInstance().getTextureManager()
                    .registerTexture(textureId, texture));
        }
    }

    private static Object createRasterDataBuffer(WritableRaster raster) {
        switch (raster.getDataBuffer().getDataType()) {
            case DataBuffer.TYPE_BYTE:
                return new byte[raster.getNumDataElements()];
            case DataBuffer.TYPE_USHORT:
                return new short[raster.getNumDataElements()];
            case DataBuffer.TYPE_INT:
                return new int[raster.getNumDataElements()];
            default:
                throw new IllegalArgumentException("Unsupported raster data type");
        }
    }

    public void build() {
        if (built) {
            return;
        }
        int count = Math.max(lastCharExclusive - firstChar, 1);
        int columns = Math.max((int) (Math.ceil(Math.sqrt(count)) * 1.5), 1);
        glyphs.clear();
        int atlasWidth = 0;
        int atlasHeight = 0;
        int cursorX = 0;
        int cursorY = 0;
        int rowHeight = 0;
        int column = 0;
        List<Glyph> packed = new ArrayList<>();
        FontRenderContext context = new FontRenderContext(new AffineTransform(), true, true);
        for (int i = 0; i < count; i++) {
            char value = (char) (firstChar + i);
            Font font = fontFor(value);
            GlyphVector vector = font.createGlyphVector(context, new char[] {value});
            float advance = vector.getGlyphMetrics(0).getAdvance();
            Rectangle2D bounds = font.getStringBounds(String.valueOf(value), context);
            int glyphWidth = Math.max(1, (int) Math.ceil(Math.max(bounds.getWidth(), (double) advance)));
            int glyphHeight = Math.max(1, (int) Math.ceil(bounds.getHeight()));
            atlasWidth = Math.max(atlasWidth, cursorX + glyphWidth);
            atlasHeight = Math.max(atlasHeight, cursorY + glyphHeight);
            if (column >= columns) {
                cursorX = 0;
                cursorY = cursorY + rowHeight + padding;
                column = 0;
                rowHeight = 0;
            }
            rowHeight = Math.max(rowHeight, glyphHeight);
            packed.add(new Glyph(cursorX, cursorY, glyphWidth, glyphHeight, advance, value, this));
            cursorX = cursorX + glyphWidth + padding;
            column++;
        }
        BufferedImage image = new BufferedImage(
                Math.max(atlasWidth + padding, 1),
                Math.max(atlasHeight + padding, 1),
                BufferedImage.TYPE_INT_ARGB);
        width = image.getWidth();
        height = image.getHeight();
        Graphics2D graphics = image.createGraphics();
        try {
            graphics.setColor(new Color(255, 255, 255, 0));
            graphics.fillRect(0, 0, width, height);
            graphics.setColor(Color.WHITE);
            graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            for (Glyph glyph : packed) {
                graphics.setFont(fontFor(glyph.value()));
                FontMetrics metrics = graphics.getFontMetrics();
                graphics.drawString(String.valueOf(glyph.value()), glyph.u(), glyph.v() + metrics.getAscent());
                glyphs.put(glyph.value(), glyph);
            }
        } finally {
            graphics.dispose();
        }
        uploadTexture(textureId, image);
        built = true;
    }

    public boolean contains(char value) {
        return value >= firstChar && value < lastCharExclusive;
    }

    public Glyph glyph(char value) {
        if (!built) {
            build();
        }
        return glyphs.get(value);
    }

    private Font fontFor(char value) {
        if (baseFont.canDisplay(value)) {
            return baseFont;
        }
        Font dialog = new Font("Dialog", baseFont.getStyle(), baseFont.getSize());
        if (dialog.canDisplay(value)) {
            return dialog;
        }
        return new Font("Segoe UI", baseFont.getStyle(), baseFont.getSize());
    }
}
