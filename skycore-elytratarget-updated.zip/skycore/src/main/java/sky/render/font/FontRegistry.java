package sky.render.font;

import java.awt.Font;
import java.awt.FontFormatException;
import java.io.IOException;
import java.io.InputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sky.debug.BlurDebugLogger;

public final class FontRegistry {
    private static final FontRenderer[] KRISA_REGULAR;
    private static final FontRenderer[] SKYCORE;
    private static final FontRenderer[] REGULAR;
    private static final FontRenderer[] NOTIFICATION_ICONS;
    private static final FontRenderer[] KRISA_MEDIUM;
    private static final int MIN_SIZE = 6;
    private static final int MAX_SIZE = 256;
    private static final FontRenderer[] ICONS;
    private static final Logger LOGGER;
    private static final FontRenderer[] MEDIUM;
    private static final FontRenderer[] CLICKGUI_ICONS;
    private static final FontRenderer[] WATERMARK_ICONS;

    static {
        LOGGER = LoggerFactory.getLogger("Skycore");
        REGULAR = new FontRenderer[257];
        MEDIUM = new FontRenderer[257];
        ICONS = new FontRenderer[257];
        SKYCORE = new FontRenderer[257];
        WATERMARK_ICONS = new FontRenderer[257];
        NOTIFICATION_ICONS = new FontRenderer[257];
        CLICKGUI_ICONS = new FontRenderer[257];
        KRISA_REGULAR = new FontRenderer[257];
        KRISA_MEDIUM = new FontRenderer[257];
    }

    private FontRegistry() {
    }

    public static FontRenderer getIcons(int size) {
        int clamped = Math.clamp((long) size, MIN_SIZE, MAX_SIZE);
        if (ICONS[clamped] == null) {
            Font font = loadFont("icons.ttf", null);
            if (font != null) {
                ICONS[clamped] = new FontRenderer(font, (float) clamped / 2.0F);
            } else {
                ICONS[clamped] = getRegular(size);
            }
        }
        return ICONS[clamped];
    }

    public static FontRenderer getClickGuiIcons(int size) {
        int clamped = Math.clamp((long) size, MIN_SIZE, MAX_SIZE);
        if (CLICKGUI_ICONS[clamped] == null) {
            Font font = loadFont("clickgui-icons.ttf", null);
            if (font != null) {
                CLICKGUI_ICONS[clamped] = new FontRenderer(font, (float) clamped / 2.0F);
            } else {
                CLICKGUI_ICONS[clamped] = getSkycore(clamped);
            }
        }
        return CLICKGUI_ICONS[clamped];
    }

    private static Font loadFont(String fileName, String fallbackName) {
        Font font = readAssetFont(fileName);
        if (font != null) {
            return font;
        }
        String alias = fontAlias(fileName);
        if (alias != null) {
            font = readAssetFont(alias);
            if (font != null) {
                return font;
            }
        }
        if (fallbackName == null) {
            return null;
        }
        BlurDebugLogger.log("Font", "loadFont(" + fileName + ") fallback -> " + fallbackName);
        LOGGER.warn("Font asset missing: assets/skycore/font/{}. Using {}", fileName, fallbackName);
        return new Font(fallbackName, Font.PLAIN, 12);
    }

    private static String fontAlias(String fileName) {
        return switch (fileName) {
            case "suisse_regular.ttf", "krisa_regular.ttf" -> "plus_jakarta_sans_regular.ttf";
            case "suisse_medium.ttf" -> "plus_jakarta_sans_medium.ttf";
            case "krisa_medium.ttf" -> "plus_jakarta_sans_semibold.ttf";
            default -> null;
        };
    }

    private static Font readAssetFont(String fileName) {
        BlurDebugLogger.log("Font", "loadFont(" + fileName + ") start");
        try (InputStream stream = FontRegistry.class.getResourceAsStream("/assets/skycore/font/" + fileName)) {
            if (stream != null) {
                Font font = Font.createFont(Font.TRUETYPE_FONT, stream);
                BlurDebugLogger.log("Font", "loadFont(" + fileName + ") OK family=" + font.getFamily()
                        + " name=" + font.getFontName());
                return font;
            }
            BlurDebugLogger.log("Font", "loadFont(" + fileName + ") stream=null");
        } catch (IOException | FontFormatException exception) {
            BlurDebugLogger.log("Font", "loadFont(" + fileName + ") FAILED " + exception.getMessage());
            LOGGER.warn("Failed to load font {} from assets", fileName, exception);
        }
        return null;
    }

    public static FontRenderer getWatermarkIcons(int size) {
        int clamped = Math.clamp((long) size, MIN_SIZE, MAX_SIZE);
        if (WATERMARK_ICONS[clamped] == null) {
            Font font = loadFont("watermark-icons.ttf", null);
            if (font != null) {
                WATERMARK_ICONS[clamped] = new FontRenderer(font, (float) clamped / 2.0F);
            } else {
                WATERMARK_ICONS[clamped] = getSkycore(clamped);
            }
        }
        return WATERMARK_ICONS[clamped];
    }

    public static FontRenderer getKrisaRegular(int size) {
        return getOrLoad(KRISA_REGULAR, size, "krisa_regular.ttf", "Segoe UI");
    }

    private static FontRenderer getOrLoad(FontRenderer[] cache, int size, String fileName, String fallbackName) {
        int clamped = Math.clamp((long) size, MIN_SIZE, MAX_SIZE);
        if (cache[clamped] == null) {
            FontRenderer renderer = load((float) clamped, fileName, fallbackName);
            if (renderer == null) {
                renderer = new FontRenderer(new Font(fallbackName, Font.PLAIN, 12), (float) clamped / 2.0F);
            }
            cache[clamped] = renderer;
        }
        return cache[clamped];
    }

    public static FontRenderer getNotificationIcons(int size) {
        int clamped = Math.clamp((long) size, MIN_SIZE, MAX_SIZE);
        if (NOTIFICATION_ICONS[clamped] == null) {
            Font font = loadFont("notification-icons.ttf", null);
            if (font != null) {
                NOTIFICATION_ICONS[clamped] = new FontRenderer(font, (float) clamped / 2.0F);
            } else {
                NOTIFICATION_ICONS[clamped] = getWatermarkIcons(clamped);
            }
        }
        return NOTIFICATION_ICONS[clamped];
    }

    public static FontRenderer getKrisaMedium(int size) {
        return getOrLoad(KRISA_MEDIUM, size, "krisa_medium.ttf", "Segoe UI Semibold");
    }

    public static FontRenderer getRegular(int size) {
        return getOrLoad(REGULAR, size, "suisse_regular.ttf", "Segoe UI");
    }

    public static FontRenderer getClickGuiMedium(int size) {
        return getMedium(size);
    }

    public static FontRenderer getMedium(int size) {
        return getOrLoad(MEDIUM, size, "suisse_medium.ttf", "Segoe UI");
    }

    public static FontRenderer getClickGuiRegular(int size) {
        return getRegular(size);
    }

    public static FontRenderer getSkycore(int size) {
        int clamped = Math.clamp((long) size, MIN_SIZE, MAX_SIZE);
        if (SKYCORE[clamped] == null) {
            Font font = loadFont("skycore.ttf", null);
            if (font != null) {
                SKYCORE[clamped] = new FontRenderer(font, (float) clamped / 2.0F);
            } else {
                SKYCORE[clamped] = getIcons(clamped);
            }
        }
        return SKYCORE[clamped];
    }

    private static FontRenderer load(float size, String fileName, String fallbackName) {
        Font font = loadFont(fileName, fallbackName);
        if (font == null) {
            BlurDebugLogger.log("Font", "FontRenderer null for " + fileName + " size=" + size);
            return null;
        }
        BlurDebugLogger.log("Font", "loaded " + fileName + " size=" + size + " family=" + font.getFamily());
        return new FontRenderer(font, size / 2.0F);
    }
}
