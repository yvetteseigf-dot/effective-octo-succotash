package sky.render.font;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import sky.util.text.TextUtil;
import sky.util.render.TextureFilterUtil;

public final class FontRenderer {
    private final List<FontAtlas> atlases;
    private float size;
    private final Map<Identifier, List<QueuedGlyph>> drawQueue;
    private Font font;

    public FontRenderer(Font baseFont, float halfSize) {
        this.drawQueue = new HashMap<>();
        this.atlases = new ArrayList<>();
        this.size = halfSize;
        this.font = baseFont.deriveFont(halfSize * 2.0F);
    }

    private int resolveStyleColor(Style style, int defaultColor) {
        if (style.getColor() != null) {
            int rgb = style.getColor().getRgb();
            int alpha = defaultColor >> 24 & 255;
            if (alpha == 0) {
                alpha = 255;
            }
            return alpha << 24 | rgb & 16777215;
        }
        return defaultColor == -1 ? Color.WHITE.getRGB() : defaultColor;
    }

    private static Identifier createAtlasId() {
        Random random = new Random();
        String id = IntStream.range(0, 32)
                .mapToObj(index -> String.valueOf((char) ('a' + random.nextInt(26))))
                .collect(Collectors.joining());
        return Identifier.of("skycore", "font_atlas/" + id);
    }

    public float getTextWidth(Text text) {
        if (text == null) {
            return 0.0F;
        }
        float[] width = new float[] {0.0F};
        text.asOrderedText().accept((index, style, codePoint) -> {
            if (!TextUtil.isDisplayChar(codePoint)) {
                return true;
            }
            String replacement = TextUtil.replaceCodePoint(codePoint);
            if (replacement != null) {
                if (!replacement.isEmpty()) {
                    width[0] += getWidth(replacement);
                }
                return true;
            }
            width[0] += getWidth(new String(Character.toChars(codePoint)));
            return true;
        });
        return width[0];
    }

    public void draw(String text, double x, double y, Color color, MatrixStack matrices) {
        draw(matrices, text, x, y, color.getRGB());
    }

    private void flush(Matrix4f matrix) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        for (Map.Entry<Identifier, List<QueuedGlyph>> entry : drawQueue.entrySet()) {
            Identifier atlasId = entry.getKey();
            int glId = MinecraftClient.getInstance().getTextureManager().getTexture(atlasId).getGlId();
            TextureFilterUtil.drawWithTexture(glId, false, () -> {
                RenderSystem.setShaderTexture(0, atlasId);
                BufferBuilder buffer = Tessellator.getInstance()
                        .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
                for (QueuedGlyph queued : entry.getValue()) {
                    float glyphX = queued.x();
                    float glyphY = queued.y();
                    Glyph glyph = queued.glyph();
                    FontAtlas atlas = glyph.atlas();
                    float glyphWidth = glyph.width();
                    float glyphHeight = glyph.height();
                    float u0 = (float) glyph.u() / (float) atlas.width;
                    float v0 = (float) glyph.v() / (float) atlas.height;
                    float u1 = (float) (glyph.u() + glyph.width()) / (float) atlas.width;
                    float v1 = (float) (glyph.v() + glyph.height()) / (float) atlas.height;
                    int color = queued.color();
                    buffer.vertex(matrix, glyphX, glyphY + glyphHeight, 0.0F)
                            .texture(u0, v1)
                            .color(color);
                    buffer.vertex(matrix, glyphX + glyphWidth, glyphY + glyphHeight, 0.0F)
                            .texture(u1, v1)
                            .color(color);
                    buffer.vertex(matrix, glyphX + glyphWidth, glyphY, 0.0F)
                            .texture(u1, v0)
                            .color(color);
                    buffer.vertex(matrix, glyphX, glyphY, 0.0F)
                            .texture(u0, v0)
                            .color(color);
                }
                BufferRenderer.drawWithGlobalProgram(buffer.end());
            });
        }
    }

    public void drawCentered(String text, double centerX, double y, Color color, MatrixStack matrices) {
        draw(text, centerX - (double) getWidth(text) / 2.0, y, color, matrices);
    }

    public float getWidth(String text) {
        if (text == null || text.isEmpty()) {
            return 0.0F;
        }
        text = TextUtil.replaceSymbols(text);
        float maxWidth = 0.0F;
        for (String line : text.split("\n")) {
            float lineWidth = 0.0F;
            for (int i = 0; i < line.length(); i++) {
                Glyph glyph = getGlyph(line.charAt(i));
                if (glyph != null) {
                    lineWidth += glyph.advance();
                }
            }
            maxWidth = Math.max(maxWidth, lineWidth);
        }
        return maxWidth / 2.0F;
    }

    public float getSize() {
        return size;
    }

    public void drawText(MatrixStack matrices, Text text, double x, double y, int defaultColor) {
        if (text == null) {
            return;
        }
        double drawY = y - 1.5;
        float[] cursor = new float[] {(float) x};
        text.asOrderedText().accept((index, style, codePoint) -> {
            if (!TextUtil.isDisplayChar(codePoint)) {
                return true;
            }
            String replacement = TextUtil.replaceCodePoint(codePoint);
            if (replacement != null) {
                if (!replacement.isEmpty()) {
                    float alpha = (float) (defaultColor >> 24 & 255) / 255.0F;
                    if (alpha <= 0.0F) {
                        alpha = 1.0F;
                    }
                    for (int i = 0; i < replacement.length(); i++) {
                        char ch = replacement.charAt(i);
                        int color = TextUtil.getGradientColorForReplacement(
                                codePoint, i, replacement.length(), alpha, resolveStyleColor(style, defaultColor));
                        String piece = String.valueOf(ch);
                        draw(matrices, piece, cursor[0], drawY, color);
                        cursor[0] += getWidth(piece);
                    }
                }
                return true;
            }
            int color = resolveStyleColor(style, defaultColor);
            String piece = new String(Character.toChars(codePoint));
            draw(matrices, piece, cursor[0], drawY, color);
            cursor[0] += getWidth(piece);
            return true;
        });
    }

    public void draw(MatrixStack matrices, String text, double x, double y, int color) {
        if (text == null || text.isEmpty()) {
            return;
        }
        text = TextUtil.replaceSymbols(text);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        matrices.push();
        x = Math.round(x * 2.0) / 2.0;
        y = Math.round(y * 2.0) / 2.0;
        matrices.translate(x, y, 0.0);
        matrices.scale(0.5F, 0.5F, 0.5F);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        char[] chars = text.toCharArray();
        float[] positions = getGlyphPositions(text);
        float lineY = 0.0F;
        int lineStart = 0;
        for (int i = 0; i < chars.length; i++) {
            char ch = chars[i];
            if (ch == '\n') {
                lineY += getLineHeight(text.substring(lineStart, i)) - 2.0F;
                lineStart = i + 1;
                if (lineStart < chars.length) {
                    positions = getGlyphPositions(text.substring(lineStart));
                }
            } else {
                Glyph glyph = getGlyph(ch);
                if (glyph != null && ch != ' ') {
                    Identifier textureId = glyph.atlas().textureId;
                    float glyphX = positions[i - lineStart];
                    drawQueue.computeIfAbsent(textureId, key -> new ArrayList<>())
                            .add(new QueuedGlyph(glyphX, lineY, color, glyph));
                }
            }
        }
        flush(matrix);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        drawQueue.clear();
        matrices.pop();
    }

    private Glyph getGlyph(char value) {
        for (FontAtlas atlas : atlases) {
            if (atlas.contains(value)) {
                return atlas.glyph(value);
            }
        }
        char start = (char) (256 * (int) Math.floor((double) value / 256.0));
        FontAtlas atlas = new FontAtlas(start, (char) (start + 256), font, createAtlasId(), 5);
        atlases.add(atlas);
        return atlas.glyph(value);
    }

    public float getLineHeight(String text) {
        if (text == null) {
            text = "";
        }
        float current = 0.0F;
        float total = 0.0F;
        char[] chars = (text.isEmpty() ? "" : text).toCharArray();
        for (char ch : chars) {
            if (ch == '\n') {
                total += current == 0.0F ? (float) getGlyph(' ').height() : current;
                current = 0.0F;
            } else {
                Glyph glyph = getGlyph(ch);
                current = Math.max(glyph == null ? 0.0F : (float) glyph.height(), current);
            }
        }
        return (float) (Math.round((double) ((current + total) / 2.0F) * 2.0) / 2.0);
    }

    public void drawText(MatrixStack matrices, Text text, double x, double y, Color color) {
        drawText(matrices, text, x, y, color.getRGB());
    }

    private float[] getGlyphPositions(String text) {
        if (text.isEmpty()) {
            return new float[0];
        }
        String line = text.split("\n", 2)[0];
        float[] positions = new float[line.length()];
        float cursor = 0.0F;
        for (int i = 0; i < line.length(); i++) {
            positions[i] = cursor;
            char ch = line.charAt(i);
            Glyph glyph = getGlyph(ch == '\n' ? ' ' : ch);
            if (glyph != null) {
                cursor += glyph.advance();
            }
        }
        return positions;
    }
}
