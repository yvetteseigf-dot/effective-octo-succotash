package sky.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sky.theme.GuiTheme;
import sky.access.MinecraftAccess;
import sky.module.visuals.Ambience;
import sky.render.framebuffer.AutoResizingFramebuffer;

public final class AmbienceSkyRenderer implements MinecraftAccess {
    private static final Logger LOGGER = LoggerFactory.getLogger("Skycore");
    private static final int SKY_SLICES = 32;
    private static final int SKY_STACKS = 32;
    private static final float SKY_RADIUS = 100.0F;

    private static AmbienceSkyShader plasmaShader;
    private static AmbienceSkyShader summerShader;
    private static AmbienceSkyShader spaceShader;
    private static AmbienceSkyShader sakuraShader;
    private static AmbienceSkyShader etherealShader;
    private static AmbienceSkyShader nebulaShader;
    private static AutoResizingFramebuffer skyTextureFramebuffer;
    private static boolean disabledDueToDriverError;

    private AmbienceSkyRenderer() {
    }

    public static boolean shouldReplaceVanillaSky() {
        if (disabledDueToDriverError) {
            return false;
        }

        if (!Ambience.INSTANCE.isEnabled() || Ambience.INSTANCE.skyMode.is("Default") || mc.world == null) {
            return false;
        }

        return Ambience.INSTANCE.isShaderSky();
    }

    public static void renderSky(float red, float green, float blue, MatrixStack matrices) {
        if (disabledDueToDriverError) {
            return;
        }

        RenderSystem.assertOnRenderThread();

        try {
            renderSkyInternal(red, green, blue, matrices);
        } catch (Throwable error) {
            disabledDueToDriverError = true;
            LOGGER.error("Ambience sky rendering disabled after driver error", error);
            mc.getFramebuffer().beginWrite(false);
            GL20.glUseProgram(0);
        }
    }

    private static void renderSkyInternal(float red, float green, float blue, MatrixStack matrices) {
        ensureResources();

        AmbienceSkyShader shader = getActiveShader();
        if (shader == null || skyTextureFramebuffer == null) {
            return;
        }

        Color accent = GuiTheme.theme.getAccent();
        float[] primary = new float[]{
                accent.getRed() / 255.0F,
                accent.getGreen() / 255.0F,
                accent.getBlue() / 255.0F
        };
        Color shaded = darken(accent, 0.65F);
        float[] secondary = new float[]{
                shaded.getRed() / 255.0F,
                shaded.getGreen() / 255.0F,
                shaded.getBlue() / 255.0F
        };

        int width = Math.max(1, mc.getFramebuffer().textureWidth);
        int height = Math.max(1, mc.getFramebuffer().textureHeight);
        skyTextureFramebuffer.resizeTo(width, height);
        skyTextureFramebuffer.setup(true);

        Matrix4f transform = createFullscreenTransform(width, height);
        boolean night = Ambience.INSTANCE.summerMode.is("Night");
        float time = System.currentTimeMillis() % 100000L / 1000.0F * Ambience.INSTANCE.skySpeed.getCurrent();

        shader.use();
        shader.setVec4("u_Color", primary[0], primary[1], primary[2], 1.0F);
        shader.setVec3("u_Color2", secondary[0], secondary[1], secondary[2]);
        shader.setFloat("u_Scale", Ambience.INSTANCE.skyScale.getCurrent());
        shader.setFloat("u_Time", time);
        shader.setFloat("u_Night", night ? 1.0F : 0.0F);
        shader.setMatrix4f("Transform", transform);

        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
        drawFullscreenQuad(width, height);
        shader.stop();
        skyTextureFramebuffer.stop();
        mc.getFramebuffer().beginWrite(false);

        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.defaultBlendFunc();

        Matrix4f skyMatrix = new Matrix4f();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, skyTextureFramebuffer.getColorAttachment());
        drawSkySphere(skyMatrix);

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        GL20.glUseProgram(0);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    private static AmbienceSkyShader getActiveShader() {
        ensureResources();

        if (Ambience.INSTANCE.skyMode.is("Cosmos")) {
            return spaceShader;
        }

        if (Ambience.INSTANCE.skyMode.is("Nebula")) {
            return nebulaShader;
        }

        if (Ambience.INSTANCE.skyMode.is("Sakura")) {
            return sakuraShader;
        }

        if (Ambience.INSTANCE.skyMode.is("Ethereal")) {
            return etherealShader;
        }

        if (Ambience.INSTANCE.skyMode.is("Summer")) {
            return summerShader;
        }

        return plasmaShader;
    }

    private static void ensureResources() {
        if (plasmaShader == null) {
            plasmaShader = AmbienceSkyShader.load("shadersystem/sky_plasma.glsl", "shadersystem/sky_vertex.glsl");
            if (plasmaShader == null) {
                LOGGER.error("Failed to load Ambience plasma sky shader");
            }
        }

        if (summerShader == null) {
            summerShader = AmbienceSkyShader.load("shadersystem/sky_summer.glsl", "shadersystem/sky_vertex.glsl");
            if (summerShader == null) {
                LOGGER.error("Failed to load Ambience summer sky shader");
            }
        }

        if (spaceShader == null) {
            spaceShader = AmbienceSkyShader.load("shadersystem/space_sky.glsl", "shadersystem/sky_vertex.glsl");
            if (spaceShader == null) {
                LOGGER.error("Failed to load Ambience space sky shader");
            }
        }

        if (sakuraShader == null) {
            sakuraShader = AmbienceSkyShader.load("shadersystem/sky_sakura.glsl", "shadersystem/sky_vertex.glsl");
            if (sakuraShader == null) {
                LOGGER.error("Failed to load Ambience sakura sky shader");
            }
        }

        if (etherealShader == null) {
            etherealShader = AmbienceSkyShader.load("shadersystem/sky_ethereal.glsl", "shadersystem/sky_vertex.glsl");
            if (etherealShader == null) {
                LOGGER.error("Failed to load Ambience ethereal sky shader");
            }
        }

        if (nebulaShader == null) {
            nebulaShader = AmbienceSkyShader.load("shadersystem/sky_nebula.glsl", "shadersystem/sky_vertex.glsl");
            if (nebulaShader == null) {
                LOGGER.error("Failed to load Ambience nebula sky shader");
            }
        }

        if (skyTextureFramebuffer == null) {
            skyTextureFramebuffer = new AutoResizingFramebuffer(false);
        }
    }

    private static Matrix4f createFullscreenTransform(int width, int height) {
        Matrix4f projection = new Matrix4f().setOrtho(0.0F, width, height, 0.0F, 1000.0F, 3000.0F);
        Matrix4f modelView = new Matrix4f().translation(0.0F, 0.0F, -2000.0F);
        return projection.mul(modelView);
    }

    private static void drawFullscreenQuad(int fbW, int fbH) {
        DrawHelper.drawPreparedLegacyTexturedQuad(fbW, fbH);
    }

    private static void drawSkySphere(Matrix4f matrix) {
        BufferBuilder buffer = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        for (int stack = 0; stack < SKY_STACKS; stack++) {
            float theta = 3.1415927F * stack / SKY_STACKS;
            float nextTheta = 3.1415927F * (stack + 1) / SKY_STACKS;
            float sinTheta = (float) Math.sin(theta);
            float cosTheta = (float) Math.cos(theta);
            float nextSinTheta = (float) Math.sin(nextTheta);
            float nextCosTheta = (float) Math.cos(nextTheta);
            float v = (float) stack / SKY_STACKS;
            float nextV = (float) (stack + 1) / SKY_STACKS;

            for (int slice = 0; slice < SKY_SLICES; slice++) {
                float phi = 6.2831855F * slice / SKY_SLICES;
                float nextPhi = 6.2831855F * (slice + 1) / SKY_SLICES;
                float sinPhi = (float) Math.sin(phi);
                float cosPhi = (float) Math.cos(phi);
                float nextSinPhi = (float) Math.sin(nextPhi);
                float nextCosPhi = (float) Math.cos(nextPhi);
                float u = (float) slice / SKY_SLICES;
                float nextU = (float) (slice + 1) / SKY_SLICES;

                addVertex(buffer, matrix, SKY_RADIUS, sinTheta, cosTheta, sinPhi, cosPhi, u, v);
                addVertex(buffer, matrix, SKY_RADIUS, nextSinTheta, nextCosTheta, sinPhi, cosPhi, u, nextV);
                addVertex(buffer, matrix, SKY_RADIUS, nextSinTheta, nextCosTheta, nextSinPhi, nextCosPhi, nextU, nextV);
                addVertex(buffer, matrix, SKY_RADIUS, sinTheta, cosTheta, nextSinPhi, nextCosPhi, nextU, v);
            }
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private static void addVertex(BufferBuilder buffer, Matrix4f matrix, float radius, float sinTheta,
                                  float cosTheta, float sinPhi, float cosPhi, float u, float v) {
        float x = radius * sinTheta * cosPhi;
        float y = radius * cosTheta;
        float z = radius * sinTheta * sinPhi;
        buffer.vertex(matrix, x, y, z).texture(u, v).color(255, 255, 255, 255);
    }

    private static Color darken(Color color, float factor) {
        factor = Math.max(0.0F, Math.min(1.0F, factor));
        return new Color((int) (color.getRed() * factor), (int) (color.getGreen() * factor),
                (int) (color.getBlue() * factor), color.getAlpha());
    }

    private static final class AmbienceSkyShader {
        private final int program;

        private AmbienceSkyShader(int program) {
            this.program = program;
        }

        static AmbienceSkyShader load(String fragmentPath, String vertexPath) {
            try {
                int program = GL20.glCreateProgram();
                int vertexShader = compile(GL20.GL_VERTEX_SHADER, readShader(vertexPath));
                int fragmentShader = compile(GL20.GL_FRAGMENT_SHADER, readShader(fragmentPath));

                GL20.glAttachShader(program, vertexShader);
                GL20.glAttachShader(program, fragmentShader);
                GL20.glBindAttribLocation(program, 0, "Position");
                GL20.glBindAttribLocation(program, 1, "UV0");
                GL20.glLinkProgram(program);
                GL20.glDeleteShader(vertexShader);
                GL20.glDeleteShader(fragmentShader);

                if (GL20.glGetProgrami(program, GL20.GL_LINK_STATUS) == 0) {
                    LOGGER.error("Ambience sky shader link failed: {}", GL20.glGetProgramInfoLog(program));
                    GL20.glDeleteProgram(program);
                    return null;
                }

                return new AmbienceSkyShader(program);
            } catch (Exception error) {
                LOGGER.error("Ambience sky shader load failed", error);
                return null;
            }
        }

        private static int compile(int type, String source) {
            int shader = GL20.glCreateShader(type);
            GL20.glShaderSource(shader, source);
            GL20.glCompileShader(shader);

            if (GL20.glGetShaderi(shader, GL20.GL_COMPILE_STATUS) == 0) {
                LOGGER.error("Ambience sky shader compile failed: {}", GL20.glGetShaderInfoLog(shader));
            }

            return shader;
        }

        private static String readShader(String path) throws Exception {
            String resourcePath = "/assets/skycore/shaders/" + path;
            InputStream stream = AmbienceSkyRenderer.class.getResourceAsStream(resourcePath);
            if (stream == null) {
                throw new IllegalStateException("Missing shader " + resourcePath);
            }

            StringBuilder source = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    source.append(line).append('\n');
                }
            }

            return source.toString();
        }

        void use() {
            GL20.glUseProgram(this.program);
        }

        void stop() {
            GL20.glUseProgram(0);
        }

        void setInt(String name, int value) {
            GL20.glUniform1i(GL20.glGetUniformLocation(this.program, name), value);
        }

        void setFloat(String name, float value) {
            GL20.glUniform1f(GL20.glGetUniformLocation(this.program, name), value);
        }

        void setVec2(String name, float x, float y) {
            GL20.glUniform2f(GL20.glGetUniformLocation(this.program, name), x, y);
        }

        void setVec3(String name, float x, float y, float z) {
            GL20.glUniform3f(GL20.glGetUniformLocation(this.program, name), x, y, z);
        }

        void setVec4(String name, float x, float y, float z, float w) {
            GL20.glUniform4f(GL20.glGetUniformLocation(this.program, name), x, y, z, w);
        }

        void setMatrix4f(String name, Matrix4f matrix) {
            float[] values = new float[16];
            matrix.get(values);
            GL20.glUniformMatrix4fv(GL20.glGetUniformLocation(this.program, name), false, values);
        }
    }
}
