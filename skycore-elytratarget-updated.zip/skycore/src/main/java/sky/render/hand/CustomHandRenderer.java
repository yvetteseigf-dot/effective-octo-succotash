package sky.render.hand;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.Block;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.FilledMapItem;
import net.minecraft.item.Item;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.consume.UseAction;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import sky.access.MinecraftAccess;
import sky.event.render.SwingAnimationEvent;
import sky.mixin.render.HeldItemRendererAccessor;
import sky.module.combat.AttackAura;
import sky.module.visuals.SwingAnimation;
import sky.module.visuals.ViewModel;

public final class CustomHandRenderer implements MinecraftAccess {
    private CustomHandRenderer() {
    }

    public static boolean tryRender(HeldItemRenderer heldItemRenderer, AbstractClientPlayerEntity player,
                                    float tickDelta, float pitch, Hand hand, float swingProgress, ItemStack stack,
                                    float equipProgress, MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                    int light) {
        SwingAnimation swingAnimation = SwingAnimation.INSTANCE;
        if (swingAnimation.isEnabled() && swingAnimation.animationMode.is("HMI New")) {
            return HmiHandRenderer.tryRender(heldItemRenderer, player, tickDelta, hand, swingProgress, stack,
                    equipProgress, matrices, vertexConsumers, light);
        }

        SwingAnimation module = get3DModule();
        if (module == null) {
            return false;
        }

        if (player.isUsingRiptide()) {
            return false;
        }

        matrices.push();

        Arm arm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        if (swingAnimation.hasCustomViewModel()) {
            swingAnimation.applyViewModel(matrices, arm);
        } else {
            ViewModel.INSTANCE.applyHandPosition(matrices, arm);
        }

        ItemRenderer itemRenderer = ((HeldItemRendererAccessor) heldItemRenderer).skycore$getItemRenderer();

        boolean rendered;
        if (hand == Hand.OFF_HAND) {
            rendered = renderOffHand(heldItemRenderer, itemRenderer, module, player, tickDelta, swingProgress, stack,
                    equipProgress, matrices, vertexConsumers, light);
        } else if (stack.isEmpty()) {
            rendered = renderEmptyHand(heldItemRenderer, player, player.getMainArm(), swingProgress,
                    equipProgress, matrices, vertexConsumers, light);
        } else if (stack.getItem() instanceof FilledMapItem || stack.getItem() instanceof CrossbowItem) {
            matrices.pop();
            return false;
        } else {
            rendered = renderMainHand(heldItemRenderer, itemRenderer, module, player, tickDelta, hand, swingProgress,
                    stack, equipProgress, matrices, vertexConsumers, light);
        }

        if (rendered) {
            matrices.pop();
            return true;
        }

        matrices.pop();
        return false;
    }

    private static boolean renderMainHand(HeldItemRenderer heldItemRenderer, ItemRenderer itemRenderer,
                                          SwingAnimation module, AbstractClientPlayerEntity player, float tickDelta,
                                          Hand hand, float swingProgress, ItemStack stack, float equipProgress,
                                          MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        Arm arm = player.getMainArm();
        boolean leftHanded = arm == Arm.LEFT;
        boolean usingItem = player.isUsingItem() && player.getActiveHand() == hand;

        if (usingItem) {
            float useTicks = getUseTicks(player, stack, tickDelta);
            switch (stack.getUseAction()) {
                case EAT, DRINK -> {
                    renderArmHoldingItem(heldItemRenderer, matrices, vertexConsumers, light, arm,
                            equipProgress, swingProgress);
                    applyEatDrinkHandPose(matrices, arm, useTicks);
                }
                case BLOCK -> {
                    renderArmHoldingItem(heldItemRenderer, matrices, vertexConsumers, light, arm,
                            equipProgress, swingProgress);
                    applyBlockHandPose(matrices, arm, useTicks);
                }
                default -> {
                    return false;
                }
            }
        } else {
            renderArmHoldingItem(heldItemRenderer, matrices, vertexConsumers, light, arm,
                    equipProgress, swingProgress);
            applyHandBase(matrices, module.get3DEquipProgress(equipProgress, arm), arm);
            if (!module.onlyWithAura.isEnabled() || AttackAura.target != null) {
                SwingAnimationEvent event =
                        new SwingAnimationEvent(player, swingProgress, hand, matrices);
                module.apply3DMode(event, leftHanded);
            }
        }

        applyCommonItemAnchor(matrices, arm);
        applyItemPose(matrices, arm, stack);
        renderHeldItem(itemRenderer, player, stack, arm, matrices, vertexConsumers, light);
        return true;
    }

    private static boolean renderOffHand(HeldItemRenderer heldItemRenderer, ItemRenderer itemRenderer,
                                         SwingAnimation module, AbstractClientPlayerEntity player, float tickDelta,
                                         float swingProgress, ItemStack stack, float equipProgress,
                                         MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        if (!shouldRenderLeftArm(module, player)) {
            return false;
        }

        Arm arm = player.getMainArm().getOpposite();
        boolean usingOffHand = player.isUsingItem() && player.getActiveHand() == Hand.OFF_HAND;

        if (stack.isEmpty()) {
            return renderEmptyHand(heldItemRenderer, player, arm, swingProgress, equipProgress, matrices,
                    vertexConsumers, light);
        }

        if (stack.getItem() instanceof FilledMapItem || stack.getItem() instanceof CrossbowItem) {
            return false;
        }

        renderArmHoldingItem(heldItemRenderer, matrices, vertexConsumers, light, arm,
                equipProgress, swingProgress);
        if (usingOffHand) {
            float useTicks = getUseTicks(player, stack, tickDelta);
            switch (stack.getUseAction()) {
                case EAT, DRINK -> {
                    applyEatDrinkHandPose(matrices, arm, useTicks);
                }
                case BLOCK -> {
                    applyBlockHandPose(matrices, arm, useTicks);
                }
                default -> {
                    applyHandBase(matrices, module.get3DEquipProgress(equipProgress, arm), arm);
                }
            }
        } else {
            applyHandBase(matrices, module.get3DEquipProgress(equipProgress, arm), arm);
        }

        applyCommonItemAnchor(matrices, arm);
        applyItemPose(matrices, arm, stack);
        renderHeldItem(itemRenderer, player, stack, arm, matrices, vertexConsumers, light);
        return true;
    }

    private static boolean renderEmptyHand(HeldItemRenderer heldItemRenderer,
                                           AbstractClientPlayerEntity player, Arm arm, float swingProgress,
                                           float equipProgress, MatrixStack matrices,
                                           VertexConsumerProvider vertexConsumers, int light) {
        if (player.isInvisible()) {
            return false;
        }

        renderArmHoldingItem(heldItemRenderer, matrices, vertexConsumers, light, arm,
                equipProgress, swingProgress);
        return true;
    }

    private static void renderArmHoldingItem(HeldItemRenderer heldItemRenderer, MatrixStack matrices,
                                             VertexConsumerProvider vertexConsumers, int light, Arm arm,
                                             float equipProgress, float swingProgress) {
        matrices.push();
        ((HeldItemRendererAccessor) heldItemRenderer)
                .skycore$renderArmHoldingItem(
                        matrices, vertexConsumers, light, equipProgress, swingProgress, arm);
        matrices.pop();
    }

    private static void renderHeldItem(ItemRenderer itemRenderer, AbstractClientPlayerEntity player, ItemStack stack,
                                       Arm arm, MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                       int light) {
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        itemRenderer.renderItem(player, stack, ModelTransformationMode.FIRST_PERSON_RIGHT_HAND, arm == Arm.LEFT, matrices,
                vertexConsumers, player.getWorld(), light, OverlayTexture.DEFAULT_UV, player.getId());
    }

    private static void applyHandBase(MatrixStack matrices, float equipProgress, Arm arm) {
        int side = arm == Arm.RIGHT ? 1 : -1;
        matrices.translate(side * 0.56F, -0.52F - equipProgress * 0.6F, -0.72F);
    }

    private static void applyCommonItemAnchor(MatrixStack matrices, Arm arm) {
        int side = arm == Arm.RIGHT ? 1 : -1;
        matrices.translate(-0.06F * side, 0.08F, 0.02F);
    }

    private static void applyEatDrinkHandPose(MatrixStack matrices, Arm arm, float useTicks) {
        int side = arm == Arm.RIGHT ? 1 : -1;
        float progress = MathHelper.clamp(useTicks / 5.0F, 0.0F, 1.0F);
        float wobble = MathHelper.sin(useTicks / 2.0F * 3.1415927F) / 10.0F;

        matrices.translate(side * 0.56F, -0.42F, -0.72F);
        matrices.translate(0.2F * side * progress, -0.7F * progress, -0.2F * progress);
        matrices.translate(0.0F, -0.2F * wobble, -0.2F * wobble);
        matrices.translate(0.0F, 0.1F * easeInOutBack(MathHelper.sin(progress * 3.1415927F)), 0.0F);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(45.0F * side));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-40.0F * side));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(30.0F));
        matrices.scale(0.9F, 0.9F, 0.9F);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(45.0F * progress * side));
    }

    private static void applyBlockHandPose(MatrixStack matrices, Arm arm, float useTicks) {
        int side = arm == Arm.RIGHT ? 1 : -1;
        float raise = MathHelper.clamp(useTicks / 4.0F, 0.0F, 1.0F);
        float settle = MathHelper.clamp(useTicks / 6.0F, 0.0F, 1.0F);

        matrices.translate(0.0F, -0.2F, 0.0F);
        matrices.translate(side * 0.56F, -0.52F, -0.72F);
        matrices.translate(0.7F * raise * side, 0.0F, -1.3F * raise);
        matrices.translate(-0.2F * side * settle, 0.0F, 0.0F);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(10.0F * MathHelper.sin(settle * 3.1415927F)));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(70.0F * raise * side));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(45.0F * side));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-40.0F * side));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(30.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(5.0F * side * raise));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-10.0F * raise));
        matrices.translate(0.0F, 0.0F, -0.2F * raise);
        matrices.scale(0.9F, 0.9F, 0.9F);
    }

    private static void applyItemPose(MatrixStack matrices, Arm arm, ItemStack stack) {
        int side = arm == Arm.RIGHT ? 1 : -1;
        Item item = stack.getItem();

        if (isTorch(stack)) {
            matrices.scale(1.5F, 1.5F, 1.5F);
            matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(25.0F * side));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(5.0F));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(75.0F * side));
            matrices.translate(0.2F * side, 0.2F, 0.05F);
            return;
        }

        if (isSmallItem(stack)) {
            matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(5.0F * side));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(15.0F));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(75.0F * side));
            matrices.translate(0.0F, -0.05F, -0.1F);
            matrices.scale(0.7F, 0.7F, 0.7F);
            return;
        }

        if (isThinItem(stack)) {
            matrices.translate(0.0F, 0.0F, -0.1F);
            matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(5.0F * side));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(15.0F));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(75.0F * side));
            return;
        }

        if (item instanceof BlockItem) {
            matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(25.0F * side));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(5.0F));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(75.0F * side));
            matrices.translate(0.2F * side, 0.2F, 0.05F);
            return;
        }

        if (stack.getUseAction() == UseAction.BLOCK) {
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(160.0F * side));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-60.0F * side));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-70.0F));
            matrices.scale(0.75F, 0.75F, 0.75F);
            matrices.translate(0.15F * side, arm == Arm.RIGHT ? 0.35F : 0.45F, arm == Arm.RIGHT ? -0.15F : -0.1F);
            matrices.translate(0.17F * side, 0.0F, 0.3F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90.0F * side));
            return;
        }

        if (stack.getUseAction() == UseAction.SPEAR) {
            matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(20.0F * side));
            matrices.translate(-0.1F * side, 0.0F, 0.0F);
        }

        if (stack.getUseAction() == UseAction.BOW) {
            matrices.translate(-0.1F * side, -0.2F, 0.0F);
        }
    }

    private static boolean shouldRenderLeftArm(SwingAnimation module, AbstractClientPlayerEntity player) {
        return module.showLeftArm.isEnabled() && !player.isInvisible();
    }

    private static SwingAnimation get3DModule() {
        SwingAnimation module = SwingAnimation.INSTANCE;
        if (!module.isEnabled() || !module.animationMode.is("3D")) {
            return null;
        }

        return module;
    }

    private static float getUseTicks(AbstractClientPlayerEntity player, ItemStack stack, float tickDelta) {
        return stack.getItem().getMaxUseTime(stack, player) - (player.getItemUseTimeLeft() - tickDelta + 1.0F);
    }

    private static float easeInOutBack(float progress) {
        float overshoot = 1.70158F * 1.525F;
        if (progress < 0.5F) {
            return (float) (Math.pow(2.0F * progress, 2.0)
                    * ((overshoot + 1.0F) * 2.0F * progress - overshoot) / 2.0);
        }

        return (float) ((Math.pow(2.0F * progress - 2.0F, 2.0)
                * ((overshoot + 1.0F) * (progress * 2.0F - 2.0F) + overshoot) + 2.0) / 2.0);
    }

    private static boolean isTorch(ItemStack stack) {
        Item item = stack.getItem();
        return item == Items.TORCH || item == Items.SOUL_TORCH || item == Items.REDSTONE_TORCH;
    }

    private static boolean isSmallItem(ItemStack stack) {
        Item item = stack.getItem();
        return stack.contains(DataComponentTypes.FOOD)
                || item instanceof BucketItem
                || (!isWeaponLike(stack) && !(item instanceof BlockItem));
    }

    private static boolean isThinItem(ItemStack stack) {
        Item item = stack.getItem();
        Block block = item instanceof BlockItem blockItem ? blockItem.getBlock() : null;
        return item == Items.STRING
                || item == Items.REDSTONE
                || item == Items.LEVER
                || item == Items.TRIPWIRE_HOOK
                || (block != null
                    && (block.getDefaultState().isIn(BlockTags.RAILS)
                        || block.getDefaultState().isIn(BlockTags.CLIMBABLE)
                        || block.getDefaultState().isIn(BlockTags.DOORS)
                        || block.getDefaultState().isIn(BlockTags.BUTTONS)
                        || block.getDefaultState().isIn(BlockTags.PRESSURE_PLATES)));
    }

    private static boolean isWeaponLike(ItemStack stack) {
        Item item = stack.getItem();
        UseAction useAction = stack.getUseAction();
        return item instanceof SwordItem
                || item instanceof AxeItem
                || item instanceof MiningToolItem
                || useAction == UseAction.BOW
                || useAction == UseAction.BLOCK
                || useAction == UseAction.SPEAR
                || item == Items.SHIELD
                || item == Items.TRIDENT
                || item == Items.FISHING_ROD
                || item == Items.SHEARS
                || item == Items.CARROT_ON_A_STICK
                || item == Items.WARPED_FUNGUS_ON_A_STICK;
    }
}
