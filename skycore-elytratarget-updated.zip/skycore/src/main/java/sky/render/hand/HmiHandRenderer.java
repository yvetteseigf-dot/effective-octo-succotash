package sky.render.hand;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.Block;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.SwordItem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.FilledMapItem;
import net.minecraft.item.FishingRodItem;
import net.minecraft.item.Item;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.consume.UseAction;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import sky.mixin.render.HeldItemRendererAccessor;
import sky.module.combat.AttackAura;
import sky.module.visuals.SwingAnimation;
import sky.module.visuals.ViewModel;

public final class HmiHandRenderer {
    private static float fallCounter;
    private static long lastFrameNanos;
    private static float verticalAngle;
    private static float crawlCounter;
    private static boolean previousAttack;
    private static float climbCounter;
    private static float waterCounter;
    private static float verticalVelocity;
    private static float lastStateAge = -1.0F;
    private static boolean reverseSlash;

    private HmiHandRenderer() {
    }

    public static boolean tryRender(HeldItemRenderer heldItemRenderer, AbstractClientPlayerEntity player, float tickDelta,
                                    Hand hand, float swingProgress, ItemStack stack, float equipProgress,
                                    MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        SwingAnimation module = SwingAnimation.INSTANCE;
        if (!module.isEnabled() || !module.animationMode.is("HMI New") || player.isUsingRiptide()) {
            return false;
        }
        if (module.onlyWithAura.isEnabled() && AttackAura.target == null) {
            return false;
        }
        if (stack.getItem() instanceof FilledMapItem) {
            return false;
        }
        if (player.isUsingItem() && player.getActiveHand() == hand && !stack.isEmpty()) {
            return false;
        }

        matrices.push();
        Arm arm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        if (module.hasCustomViewModel()) {
            module.applyViewModel(matrices, arm);
        } else {
            ViewModel.INSTANCE.applyHandPosition(matrices, arm);
        }
        updateState(module, player, tickDelta, swingProgress);

        HeldItemRendererAccessor accessor = (HeldItemRendererAccessor) heldItemRenderer;
        ItemRenderer itemRenderer = accessor.skycore$getItemRenderer();
        boolean rendered = renderHandPath(heldItemRenderer, itemRenderer, module, player, hand, arm, swingProgress,
                stack, equipProgress, matrices, vertexConsumers, light);
        matrices.pop();
        return rendered;
    }

    private static boolean renderHandPath(HeldItemRenderer heldItemRenderer, ItemRenderer itemRenderer, SwingAnimation module,
                                          AbstractClientPlayerEntity player, Hand hand, Arm arm, float swingProgress,
                                          ItemStack stack, float equipProgress, MatrixStack matrices,
                                          VertexConsumerProvider vertexConsumers, int light) {
        boolean leftHanded = arm == Arm.LEFT;
        int armSign = leftHanded ? -1 : 1;
        boolean usingItem = player.isUsingItem() && player.getActiveHand() == hand;
        float adjustedSwing = adjustSwingProgress(module, swingProgress);

        if (stack.isEmpty()) {
            if (player.isInvisible()) {
                return false;
            }
            renderArmHoldingItem(heldItemRenderer, matrices, vertexConsumers, light, arm,
                    equipProgress, swingProgress);
            return true;
        }

        renderArmHoldingItem(heldItemRenderer, matrices, vertexConsumers, light, arm,
                equipProgress, swingProgress);
        if (usingItem) {
            applyUsePose(player, stack, arm, matrices);
        } else {
            applyBasePose(matrices, arm, equipProgress);
            applyMotionPose(player, matrices, armSign);
            applyAttackPose(stack, matrices, armSign, adjustedSwing);
        }

        applyItemAnchor(matrices, arm);
        applyItemPose(stack, matrices, armSign);
        renderHeldItem(itemRenderer, player, stack, arm, matrices, vertexConsumers, light);
        return true;
    }

    private static void updateState(SwingAnimation module, AbstractClientPlayerEntity player, float tickDelta, float swingProgress) {
        float age = player.age + tickDelta;
        if (Math.abs(age - lastStateAge) < 1.0E-4F) {
            return;
        }
        lastStateAge = age;

        float delta = getHmiDelta(module);
        boolean attacking = MinecraftClient.getInstance().options.attackKey.isPressed();
        if (attacking && !previousAttack && swingProgress == 0.0F) {
            reverseSlash = !reverseSlash;
        }
        previousAttack = attacking;

        verticalVelocity += (float) player.getVelocity().y * 0.015F * delta;
        verticalVelocity -= 0.1F * verticalAngle * delta;
        verticalVelocity *= (float) Math.pow(player.getVelocity().y < -0.08 ? 0.82F : 0.55F, delta);
        verticalAngle = MathHelper.clamp(verticalAngle + verticalVelocity * delta, -0.08F, 0.08F);

        if (player.isOnGround() || player.getVelocity().y > -0.04) {
            verticalAngle = approach(verticalAngle, 0.0F, 0.035F * delta);
            verticalVelocity *= (float) Math.pow(0.35F, delta);
        }

        waterCounter = approach(waterCounter,
                player.isTouchingWater() || player.isSubmergedInWater() ? 1.0F : 0.0F, 0.08F * delta);
        climbCounter = approach(climbCounter,
                player.isClimbing() || player.isHoldingOntoLadder() ? 1.0F : 0.0F, 0.1F * delta);
        crawlCounter = approach(crawlCounter,
                player.isInSwimmingPose() && !player.isSwimming() ? 1.0F : 0.0F, 0.1F * delta);
        fallCounter = approach(fallCounter,
                !player.isOnGround() && !player.isSwimming() && !player.isGliding() ? 1.0F : 0.0F, 0.06F * delta);
    }

    private static float getHmiDelta(SwingAnimation module) {
        long now = System.nanoTime();
        float delta = lastFrameNanos == 0L ? 0.016F : (now - lastFrameNanos) / 1.0E9F;
        lastFrameNanos = now;
        if (MinecraftClient.getInstance().isPaused()) {
            return 0.0F;
        }
        return Math.min(0.05F, Math.max(0.0F, delta)) * module.hmiHandSmoothness.getCurrent();
    }

    private static void applyBasePose(MatrixStack matrices, Arm arm, float equipProgress) {
        int armSign = arm == Arm.RIGHT ? 1 : -1;
        matrices.translate(armSign * 0.56F, -0.52F - equipProgress * 0.6F, -0.72F);
    }

    private static void applyMotionPose(AbstractClientPlayerEntity player, MatrixStack matrices, int armSign) {
        float age = lastStateAge > 0.0F ? lastStateAge : player.age;
        matrices.translate(0.0F, -verticalAngle, 0.0F);

        if (waterCounter > 0.01F) {
            float wave = MathHelper.sin(age * 0.32F) * waterCounter;
            matrices.translate(0.0F, -0.08F * waterCounter, -0.18F * waterCounter);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-28.0F * waterCounter + wave * 5.0F));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(8.0F * wave * armSign));
        }

        if (climbCounter > 0.01F) {
            float wave = MathHelper.sin(age * 0.42F) * climbCounter;
            matrices.translate(0.08F * armSign * wave, -0.1F * climbCounter, -0.18F * climbCounter);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-22.0F * climbCounter));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-14.0F * wave * armSign));
        }

        if (crawlCounter > 0.01F) {
            matrices.translate(0.0F, -0.17F * crawlCounter, -0.25F * crawlCounter);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-32.0F * crawlCounter));
        }

        if (fallCounter > 0.01F) {
            matrices.translate(0.0F, 0.05F * fallCounter, -0.12F * fallCounter);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(12.0F * fallCounter));
        }
    }

    private static void applyUsePose(AbstractClientPlayerEntity player, ItemStack stack, Arm arm, MatrixStack matrices) {
        int armSign = arm == Arm.RIGHT ? 1 : -1;
        float useTicks = stack.getItem().getMaxUseTime(stack, player) - player.getItemUseTimeLeft();
        float progress = MathHelper.clamp(useTicks / 6.0F, 0.0F, 1.0F);
        applyBasePose(matrices, arm, 0.0F);

        if (stack.getUseAction() == UseAction.EAT || stack.getUseAction() == UseAction.DRINK) {
            float bob = MathHelper.sin(useTicks * 0.7F) * 0.05F;
            matrices.translate(0.22F * armSign * progress, -0.58F * progress + bob, -0.22F * progress);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(42.0F * progress * armSign));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(12.0F * progress));
        } else if (stack.getUseAction() == UseAction.BLOCK) {
            matrices.translate(0.58F * armSign * progress, -0.05F * progress, -0.95F * progress);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(68.0F * progress * armSign));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-10.0F * progress));
        } else if (stack.getUseAction() == UseAction.BOW) {
            matrices.translate(-0.05F * armSign, -0.05F, -0.28F * progress);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-18.0F * progress * armSign));
        } else if (stack.getUseAction() == UseAction.SPEAR) {
            matrices.translate(-0.18F * armSign * progress, -0.18F * progress, -0.62F * progress);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-42.0F * progress));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(22.0F * progress * armSign));
        }
    }

    private static void applyAttackPose(ItemStack stack, MatrixStack matrices, int armSign, float swingProgress) {
        float swingRot = getSwingRot(swingProgress);
        float ease = easeInOutBack(MathHelper.sin(swingProgress * 3.1415927F));
        if (ease <= 0.001F && swingRot <= 0.001F) {
            return;
        }

        boolean isSword = stack.getItem() instanceof SwordItem;
        boolean isAxe = stack.getItem() instanceof AxeItem;
        boolean isShovel = stack.getItem() instanceof ShovelItem;
        boolean isMiningTool = stack.getItem() instanceof MiningToolItem;
        boolean isSpear = stack.getUseAction() == UseAction.SPEAR;
        boolean isBlocking = stack.getUseAction() == UseAction.BLOCK;
        boolean slash = (reverseSlash || isAxe || isSpear || isBlocking) && !isShovel;

        if (slash) {
            if (isSword || isAxe) {
                matrices.translate(0.8F * armSign * swingRot, 0.3F * swingRot, -0.5F * ease);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(15.0F * swingRot * armSign));
                matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(-20.0F * swingRot));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-70.0F * swingRot * armSign));
                matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees((isSword ? 40.0F : 30.0F) * ease));
                return;
            }
            if (isSpear) {
                matrices.translate(0.0F, 0.0F, 0.45F * swingRot);
                matrices.translate(-0.25F * armSign * ease, -0.35F * swingRot, -0.6F * ease);
                matrices.translate(0.0F, 0.1F * ease, 0.0F);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(15.0F * swingRot * armSign));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(30.0F * swingRot * armSign));
                return;
            }
            if (isMiningTool && !isBlocking) {
                matrices.translate(0.1F * armSign * swingRot, 0.1F * swingRot, -0.5F * ease);
                matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(-30.0F * swingRot));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-20.0F * swingRot * armSign));
                matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(40.0F * ease));
                return;
            }
            if (!isBlocking) {
                matrices.translate(0.1F * armSign * swingRot, 0.1F * swingRot, -0.1F * ease);
                matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(-30.0F * swingRot));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-10.0F * swingRot * armSign));
                matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(40.0F * ease));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(10.0F * ease * armSign));
                return;
            }
            matrices.translate(0.1F * armSign * swingRot, 0.1F * swingRot, -0.2F * ease);
            matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(-10.0F * swingRot));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-10.0F * swingRot * armSign));
            matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(20.0F * ease));
            return;
        }

        if (isShovel) {
            matrices.translate(0.0F, 0.15F * swingRot, -0.25F * swingRot);
            matrices.translate(0.0F, 0.0F, -0.2F * ease);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(15.0F * swingRot));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-35.0F * swingRot));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(30.0F * ease));
        } else if (isSword) {
            matrices.translate(-0.55F * armSign * swingRot, -0.8F * swingRot, -0.77F * ease);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(5.0F * swingRot * armSign));
            matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(-30.0F * swingRot));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(70.0F * swingRot * armSign));
            matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(50.0F * ease));
        } else if (isMiningTool) {
            matrices.translate(0.1F * armSign * swingRot, 0.1F * swingRot, -0.5F * ease);
            matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(-30.0F * swingRot));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-20.0F * swingRot * armSign));
            matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(40.0F * ease));
        } else {
            matrices.translate(0.1F * armSign * swingRot, 0.1F * swingRot, -0.1F * ease);
            matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(-30.0F * swingRot));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-10.0F * swingRot * armSign));
            matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(40.0F * ease));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(10.0F * ease * armSign));
        }
    }

    private static void applyItemAnchor(MatrixStack matrices, Arm arm) {
        int armSign = arm == Arm.RIGHT ? 1 : -1;
        matrices.translate(-0.06F * armSign, 0.08F, 0.02F);
    }

    private static void applyItemPose(ItemStack stack, MatrixStack matrices, int armSign) {
        Item item = stack.getItem();

        if (isTorch(stack) || isLantern(stack)) {
            matrices.scale(1.15F, 1.15F, 1.15F);
            matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(25.0F * armSign));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(5.0F));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(75.0F * armSign));
            matrices.translate(0.2F * armSign, 0.2F, 0.05F);
            return;
        }

        if (isSmallItem(stack) || item instanceof BucketItem) {
            matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(5.0F * armSign));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(15.0F));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(75.0F * armSign));
            matrices.translate(0.0F, -0.05F, -0.1F);
            matrices.scale(0.72F, 0.72F, 0.72F);
            return;
        }

        if (isThinItem(stack)) {
            matrices.translate(0.0F, 0.0F, -0.1F);
            matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(5.0F * armSign));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(15.0F));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(75.0F * armSign));
            return;
        }

        if (item instanceof BlockItem) {
            matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(25.0F * armSign));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(5.0F));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(75.0F * armSign));
            matrices.translate(0.2F * armSign, 0.2F, 0.05F);
            return;
        }

        if (stack.getUseAction() == UseAction.BLOCK || item == Items.SHIELD) {
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(160.0F * armSign));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-60.0F * armSign));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-70.0F));
            matrices.scale(0.75F, 0.75F, 0.75F);
            matrices.translate(0.32F * armSign, 0.35F, 0.15F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90.0F * armSign));
            return;
        }

        if (stack.getUseAction() == UseAction.SPEAR || item == Items.TRIDENT) {
            matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(20.0F * armSign));
            matrices.translate(-0.1F * armSign, 0.0F, 0.0F);
        }

        if (stack.getUseAction() == UseAction.BOW) {
            matrices.translate(-0.1F * armSign, -0.2F, 0.0F);
        }
    }

    private static void renderArmHoldingItem(HeldItemRenderer heldItemRenderer, MatrixStack matrices,
                                             VertexConsumerProvider vertexConsumers, int light, Arm arm,
                                             float equipProgress, float swingProgress) {
        matrices.push();
        ((HeldItemRendererAccessor) heldItemRenderer)
                .skycore$renderArmHoldingItem(
                        matrices, vertexConsumers, light, equipProgress, swingProgress, arm);
        matrices.pop();
    }

    private static void renderHeldItem(ItemRenderer itemRenderer, AbstractClientPlayerEntity player, ItemStack stack, Arm arm,
                                       MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        itemRenderer.renderItem(player, stack, ModelTransformationMode.FIRST_PERSON_RIGHT_HAND, arm == Arm.LEFT, matrices,
                vertexConsumers, player.getWorld(), light, OverlayTexture.DEFAULT_UV, player.getId());
    }

    private static float adjustSwingProgress(SwingAnimation module, float swingProgress) {
        float speed = MathHelper.clamp(module.speed.getCurrent(), 1.0F, 20.0F);
        return MathHelper.clamp(swingProgress * speed / 11.0F, 0.0F, 1.0F);
    }

    private static float getSwingRot(float swingProgress) {
        if (swingProgress < 0.6F) {
            return MathHelper.sin(MathHelper.clamp(swingProgress, 0.0F, 0.12506F) * 12.56F);
        }
        return MathHelper.sin(MathHelper.clamp(swingProgress, 0.62532F, 0.75038F) * 12.56F);
    }

    private static float easeInOutBack(float progress) {
        float overshoot = 1.70158F * 1.525F;
        if (progress < 0.5F) {
            return (float) (Math.pow(2.0F * progress, 2.0) * ((overshoot + 1.0F) * 2.0F * progress - overshoot) / 2.0);
        }
        return (float) ((Math.pow(2.0F * progress - 2.0F, 2.0)
                * ((overshoot + 1.0F) * (progress * 2.0F - 2.0F) + overshoot) + 2.0) / 2.0);
    }

    private static float approach(float current, float target, float step) {
        if (current < target) {
            return Math.min(target, current + step);
        }
        return Math.max(target, current - step);
    }

    private static boolean isWeaponLike(ItemStack stack) {
        Item item = stack.getItem();
        UseAction useAction = stack.getUseAction();
        return item instanceof SwordItem
                || item instanceof AxeItem
                || item instanceof MiningToolItem
                || item instanceof CrossbowItem
                || item instanceof FishingRodItem
                || useAction == UseAction.BOW
                || useAction == UseAction.BLOCK
                || useAction == UseAction.SPEAR
                || item == Items.SHIELD
                || item == Items.TRIDENT
                || item == Items.SHEARS
                || item == Items.FLINT_AND_STEEL
                || item == Items.CARROT_ON_A_STICK
                || item == Items.WARPED_FUNGUS_ON_A_STICK;
    }

    private static boolean isSmallItem(ItemStack stack) {
        Item item = stack.getItem();
        return stack.contains(DataComponentTypes.FOOD)
                || item instanceof BucketItem
                || (!isWeaponLike(stack) && !(item instanceof BlockItem));
    }

    private static boolean isThinItem(ItemStack stack) {
        Item item = stack.getItem();
        Block block = item instanceof BlockItem blockItem ? blockItem.getBlock() : null;
        String itemName = item.toString();
        return item == Items.STRING
                || item == Items.REDSTONE
                || item == Items.LEVER
                || item == Items.TRIPWIRE_HOOK
                || itemName.contains("glass_pane")
                || (block != null
                && (block.getDefaultState().isIn(BlockTags.RAILS)
                || block.getDefaultState().isIn(BlockTags.CLIMBABLE)
                || block.getDefaultState().isIn(BlockTags.DOORS)
                || block.getDefaultState().isIn(BlockTags.BUTTONS)
                || block.getDefaultState().isIn(BlockTags.PRESSURE_PLATES)));
    }

    private static boolean isTorch(ItemStack stack) {
        Item item = stack.getItem();
        return item == Items.TORCH || item == Items.SOUL_TORCH || item == Items.REDSTONE_TORCH;
    }

    private static boolean isLantern(ItemStack stack) {
        Item item = stack.getItem();
        return item == Items.LANTERN || item == Items.SOUL_LANTERN;
    }
}
