package sky.render;

import java.awt.Color;
import net.minecraft.client.util.math.MatrixStack;

public enum GradientMode {
    SOLID_TOP("solid_top", "Top only"),
    SOLID_BOTTOM("solid_bottom", "Bottom only"),
    TOP_TO_BOTTOM("top_to_bottom", "Top to bottom"),
    BOTTOM_TO_TOP("bottom_to_top", "Bottom to top"),
    LEFT_TO_RIGHT("left_to_right", "Left to right"),
    RIGHT_TO_LEFT("right_to_left", "Right to left"),
    TOP_LEFT_TO_BOTTOM_RIGHT("top_left_to_bottom_right", "TL → BR"),
    TOP_RIGHT_TO_BOTTOM_LEFT("top_right_to_bottom_left", "TR → BL"),
    BOTTOM_LEFT_TO_TOP_RIGHT("bottom_left_to_top_right", "BL → TR"),
    BOTTOM_RIGHT_TO_TOP_LEFT("bottom_right_to_top_left", "BR → TL");

    private final String id;
    private final String displayName;

    GradientMode(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    private static Color mix(Color first, Color second) {
        return new Color(
                (first.getRed() + second.getRed()) / 2,
                (first.getGreen() + second.getGreen()) / 2,
                (first.getBlue() + second.getBlue()) / 2,
                (first.getAlpha() + second.getAlpha()) / 2
        );
    }

    public String getId() {
        return id;
    }

    public static GradientMode byId(String id) {
        if (id == null) {
            return TOP_TO_BOTTOM;
        }

        for (GradientMode mode : values()) {
            if (mode.id.equalsIgnoreCase(id)) {
                return mode;
            }
        }

        return TOP_TO_BOTTOM;
    }

    public void draw(
            DrawHelper renderer,
            float x,
            float y,
            float width,
            float height,
            float radius,
            Color firstColor,
            Color secondColor,
            MatrixStack matrices
    ) {
        switch (this) {
            case SOLID_TOP -> renderer.drawRoundedRect(x, y, width, height, radius, firstColor, matrices);
            case SOLID_BOTTOM -> renderer.drawRoundedRect(x, y, width, height, radius, secondColor, matrices);
            case BOTTOM_TO_TOP -> renderer.drawGradientRoundedRect(
                    x, y, width, height, radius,
                    firstColor, firstColor, secondColor, secondColor, matrices
            );
            case LEFT_TO_RIGHT -> renderer.drawGradientRoundedRect(
                    x, y, width, height, radius,
                    firstColor, secondColor, firstColor, secondColor, matrices
            );
            case RIGHT_TO_LEFT -> renderer.drawGradientRoundedRect(
                    x, y, width, height, radius,
                    secondColor, firstColor, secondColor, firstColor, matrices
            );
            case TOP_LEFT_TO_BOTTOM_RIGHT -> renderer.drawGradientRoundedRect(
                    x, y, width, height, radius,
                    firstColor, mix(firstColor, secondColor), mix(firstColor, secondColor), secondColor, matrices
            );
            case TOP_RIGHT_TO_BOTTOM_LEFT -> renderer.drawGradientRoundedRect(
                    x, y, width, height, radius,
                    mix(firstColor, secondColor), firstColor, secondColor, mix(firstColor, secondColor), matrices
            );
            case BOTTOM_LEFT_TO_TOP_RIGHT -> renderer.drawGradientRoundedRect(
                    x, y, width, height, radius,
                    mix(firstColor, secondColor), secondColor, firstColor, mix(firstColor, secondColor), matrices
            );
            case BOTTOM_RIGHT_TO_TOP_LEFT -> renderer.drawGradientRoundedRect(
                    x, y, width, height, radius,
                    secondColor, mix(firstColor, secondColor), mix(firstColor, secondColor), firstColor, matrices
            );
            case TOP_TO_BOTTOM -> renderer.drawGradientRoundedRect(
                    x, y, width, height, radius,
                    secondColor, secondColor, firstColor, firstColor, matrices
            );
            default -> renderer.drawGradientRoundedRect(
                    x, y, width, height, radius,
                    secondColor, secondColor, firstColor, firstColor, matrices
            );
        }
    }
}
