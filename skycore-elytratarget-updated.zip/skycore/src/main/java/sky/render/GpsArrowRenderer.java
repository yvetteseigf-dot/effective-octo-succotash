package sky.render;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import sky.SkyInit;
import sky.access.MinecraftAccess;
import sky.waypoint.Waypoint;
import sky.waypoint.WaypointManager;
import sky.event.render.OverlayRenderEvent;
import sky.util.render.BlendStateUtil;

import java.awt.Color;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;

public final class GpsArrowRenderer implements MinecraftAccess {
    private static final Identifier ARROW_TEXTURE = Identifier.of("skycore", "icons/world_render/arrow_gps.png");
    private static final float ARROW_SIZE = 52.0F;

    @EventTarget
    public void onRender(OverlayRenderEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        Waypoint waypoint = resolveWaypoint();
        if (waypoint == null) {
            return;
        }
        MatrixStack matrices = event.getStack();
        FontRenderer font = FontRegistry.getRegular(13);
        if (font == null) {
            return;
        }

        double cameraX = mc.gameRenderer.getCamera().getPos().x;
        double cameraZ = mc.gameRenderer.getCamera().getPos().z;
        double offsetX = waypoint.getX() - cameraX;
        double offsetZ = waypoint.getZ() - cameraZ;

        float yaw = mc.player.getYaw();
        double cos = MathHelper.cos((float) Math.toRadians(yaw));
        double sin = MathHelper.sin((float) Math.toRadians(yaw));
        double relativeX = -(offsetZ * cos - offsetX * sin);
        double relativeZ = -(offsetX * cos + offsetZ * sin);
        float angle = (float) (Math.atan2(relativeX, relativeZ) * 180.0 / Math.PI);

        double distance = Math.sqrt(Math.pow(waypoint.getX() - mc.player.getX(), 2.0)
                + Math.pow(waypoint.getZ() - mc.player.getZ(), 2.0));

        float centerX = mc.getWindow().getScaledWidth() / 2.0F;
        float centerY = mc.getWindow().getScaledHeight() / 2.0F;
        float arrowX = centerX;
        float arrowY = centerY - 75.0F;

        matrices.push();
        matrices.translate(arrowX, arrowY, 0.0F);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(angle));
        BlendStateUtil.runBlended(() -> {
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            DrawHelper.get().drawTexture(ARROW_TEXTURE, -26.0F, -26.0F, ARROW_SIZE, ARROW_SIZE, Color.WHITE, matrices);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        });
        matrices.pop();

        String label = (int) distance + "m";
        font.drawCentered(label, arrowX + 1.0F, arrowY - 15.0F, Color.WHITE, matrices);
    }

    private Waypoint resolveWaypoint() {
        WaypointManager waypoints = SkyInit.getInstance().getWaypointManager();
        if (!waypoints.isEmpty()) {
            return waypoints.getActiveWaypoint();
        }
        if (!waypoints.isEmptyPlayerWaypoint()) {
            return waypoints.getActivePlayerWaypoint();
        }
        return null;
    }
}
