package sky.theme;

import sky.clickgui.GuiStyle;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Catalogue of the selectable colour presets.
 *
 * <p>Presets are split into the legacy palette and the release palette; only one
 * of the two sets is offered at a time, depending on the active GUI style.</p>
 */
public final class ThemeRegistry {
    public static final String DEFAULT_ID = "default";
    public static final String RAINBOW_ID = "rainbow";
    public static final String NEBULA_ID = "nebula";
    public static final String PRISM_ID = "prism";
    public static final String LAGOON_ID = "lagoon";
    public static final String HORIZON_ID = "horizon";

    private static final long RAINBOW_CYCLE_MS = 7000L;

    private static final ThemePreset DEFAULT = ThemePreset.legacy(DEFAULT_ID, "Default",
            new Color(142, 187, 255, 255),
            new Color(32, 24, 41, 255),
            new Color(9, 9, 18, 255),
            new Color(28, 24, 42, 255),
            new Color(14, 12, 22, 255),
            new Color(31, 25, 50, 255),
            new Color(22, 16, 36, 255),
            new Color(45, 42, 58, 180),
            new Color(40, 38, 52, 255),
            new Color(55, 55, 65, 255),
            new Color(28, 28, 28, 255));

    private static final ThemePreset RED = ThemePreset.legacy("red", "Red",
            new Color(255, 118, 118, 255),
            new Color(38, 22, 26, 255),
            new Color(14, 8, 10, 255),
            new Color(34, 20, 24, 255),
            new Color(18, 10, 12, 255),
            new Color(42, 22, 28, 255),
            new Color(28, 14, 18, 255),
            new Color(58, 38, 42, 180),
            new Color(52, 34, 38, 255),
            new Color(62, 40, 44, 255),
            new Color(36, 22, 24, 255));

    private static final ThemePreset GREEN = ThemePreset.legacy("green", "Green",
            new Color(142, 230, 118, 255),
            new Color(24, 34, 26, 255),
            new Color(9, 14, 11, 255),
            new Color(22, 32, 24, 255),
            new Color(11, 16, 13, 255),
            new Color(26, 38, 28, 255),
            new Color(16, 24, 18, 255),
            new Color(38, 52, 40, 180),
            new Color(34, 46, 36, 255),
            new Color(44, 58, 46, 255),
            new Color(24, 34, 26, 255));

    private static final ThemePreset PINK = ThemePreset.legacy("pink", "Pink",
            new Color(255, 130, 195, 255),
            new Color(36, 22, 34, 255),
            new Color(13, 8, 12, 255),
            new Color(32, 20, 30, 255),
            new Color(16, 10, 15, 255),
            new Color(40, 22, 36, 255),
            new Color(26, 14, 24, 255),
            new Color(56, 36, 50, 180),
            new Color(48, 32, 44, 255),
            new Color(58, 38, 52, 255),
            new Color(32, 20, 28, 255));

    private static final ThemePreset WHITE = ThemePreset.legacy("white", "White",
            new Color(232, 232, 238, 255),
            new Color(28, 28, 32, 255),
            new Color(10, 10, 12, 255),
            new Color(24, 24, 28, 255),
            new Color(12, 12, 14, 255),
            new Color(30, 30, 34, 255),
            new Color(18, 18, 22, 255),
            new Color(42, 42, 48, 180),
            new Color(36, 36, 42, 255),
            new Color(48, 48, 54, 255),
            new Color(26, 26, 30, 255));

    private static final ThemePreset RAINBOW = ThemePreset.legacy(RAINBOW_ID, "Rainbow",
            new Color(255, 80, 120, 255),
            new Color(30, 24, 38, 255),
            new Color(10, 9, 16, 255),
            new Color(26, 22, 36, 255),
            new Color(13, 11, 20, 255),
            new Color(30, 24, 42, 255),
            new Color(20, 16, 30, 255),
            new Color(44, 40, 56, 180),
            new Color(38, 34, 50, 255),
            new Color(52, 48, 62, 255),
            new Color(28, 24, 34, 255),
            true);

    private static final ThemePreset OCEAN = ThemePreset.legacy("ocean", "Ocean",
            new Color(88, 210, 255, 255),
            new Color(18, 31, 42, 255),
            new Color(7, 12, 18, 255),
            new Color(16, 28, 38, 255),
            new Color(8, 14, 20, 255),
            new Color(20, 38, 52, 255),
            new Color(10, 22, 32, 255),
            new Color(28, 48, 62, 180),
            new Color(24, 42, 54, 255),
            new Color(32, 58, 72, 255),
            new Color(18, 32, 42, 255));

    private static final ThemePreset AMBER = ThemePreset.legacy("amber", "Amber",
            new Color(255, 190, 92, 255),
            new Color(40, 29, 18, 255),
            new Color(15, 10, 6, 255),
            new Color(35, 25, 16, 255),
            new Color(18, 12, 8, 255),
            new Color(46, 32, 18, 255),
            new Color(28, 18, 10, 255),
            new Color(58, 46, 32, 180),
            new Color(54, 40, 24, 255),
            new Color(68, 48, 28, 255),
            new Color(38, 26, 15, 255));

    private static final ThemePreset CYBER = ThemePreset.legacy("cyber", "Cyber",
            new Color(86, 255, 198, 255),
            new Color(19, 30, 34, 255),
            new Color(6, 10, 13, 255),
            new Color(17, 27, 30, 255),
            new Color(8, 14, 16, 255),
            new Color(18, 38, 36, 255),
            new Color(10, 24, 24, 255),
            new Color(26, 52, 48, 180),
            new Color(24, 44, 42, 255),
            new Color(30, 58, 52, 255),
            new Color(16, 34, 32, 255));

    private static final ThemePreset FROST = ThemePreset.legacy("frost", "Frost",
            new Color(178, 218, 255, 255),
            new Color(28, 32, 42, 255),
            new Color(10, 12, 17, 255),
            new Color(24, 28, 38, 255),
            new Color(12, 14, 20, 255),
            new Color(32, 38, 50, 255),
            new Color(18, 22, 30, 255),
            new Color(42, 48, 58, 180),
            new Color(36, 42, 54, 255),
            new Color(48, 56, 68, 255),
            new Color(26, 30, 38, 255));

    private static final ThemePreset VIOLET = ThemePreset.legacy("violet", "Violet",
            new Color(176, 118, 255, 255),
            new Color(33, 23, 43, 255),
            new Color(11, 8, 16, 255),
            new Color(30, 22, 40, 255),
            new Color(15, 10, 22, 255),
            new Color(40, 26, 58, 255),
            new Color(25, 16, 38, 255),
            new Color(50, 38, 66, 180),
            new Color(44, 34, 58, 255),
            new Color(58, 42, 76, 255),
            new Color(30, 22, 42, 255));

    private static final ThemePreset SKYCORE = ThemePreset.legacy("skycore", "Skycore",
            new Color(104, 174, 255, 255),
            new Color(20, 17, 28, 255),
            new Color(15, 13, 22, 255),
            new Color(18, 15, 26, 255),
            new Color(12, 10, 18, 255),
            new Color(24, 20, 34, 255),
            new Color(16, 13, 24, 255),
            new Color(40, 38, 52, 180),
            new Color(28, 26, 38, 255),
            new Color(42, 40, 52, 255),
            new Color(22, 20, 30, 255));

    private static final ThemePreset NEBULA = ThemePreset.release(NEBULA_ID, "Nebula",
            releaseColor("#130C19E1"), releaseColor("#AD73FF"));

    private static final ThemePreset PRISM = ThemePreset.release(PRISM_ID, "Prism",
            releaseColor("#03030460"), releaseColor("#5F71BF"));

    private static final ThemePreset LAGOON = ThemePreset.release(LAGOON_ID, "Lagoon",
            releaseColor("#1A1B28BC"), releaseColor("#A5ADFF"));

    private static final ThemePreset HORIZON = ThemePreset.release(HORIZON_ID, "Horizon",
            releaseColor("#101224A7"), releaseColor("#7387FF"));

    private static final List<ThemePreset> LEGACY = Arrays.asList(
            DEFAULT, RED, GREEN, PINK, WHITE, RAINBOW, OCEAN, AMBER, CYBER, FROST, VIOLET, SKYCORE);

    private static final List<ThemePreset> RELEASE = Arrays.asList(NEBULA, PRISM, LAGOON, HORIZON);

    private static final List<ThemePreset> ALL = concat(LEGACY, RELEASE);

    private static ThemePreset current = HORIZON;

    private ThemeRegistry() {
    }

    public static void init() {
        GuiStyle style = GuiTheme.theme.getGuiStyle();
        if (!isVisibleForStyle(current, style)) {
            current = defaultForStyle(style);
        }
        apply(current);
    }

    /** Falls back to the style's default preset when the active one is not offered for it. */
    public static void syncForStyle(GuiStyle style) {
        if (isVisibleForStyle(current, style)) {
            return;
        }
        apply(defaultForStyle(style));
    }

    public static List<ThemePreset> getVisible(GuiStyle style) {
        return style == GuiStyle.KAWASE ? RELEASE : LEGACY;
    }

    public static List<ThemePreset> getAll() {
        return getVisible(GuiTheme.theme.getGuiStyle());
    }

    public static ThemePreset getCurrent() {
        return current;
    }

    public static ThemePreset getById(String id) {
        if (id == null || id.isEmpty()) {
            return DEFAULT;
        }
        for (ThemePreset preset : ALL) {
            if (preset.getId().equalsIgnoreCase(id)) {
                return preset;
            }
        }
        return DEFAULT;
    }

    public static void apply(String id) {
        apply(getById(id));
    }

    public static void apply(ThemePreset preset) {
        current = preset;
        if (preset.isAnimated()) {
            applyRainbowTheme();
        } else {
            preset.apply();
        }
    }

    public static void update() {
        if (current.isAnimated()) {
            applyRainbowTheme();
        }
    }

    public static float getRainbowHue() {
        return System.currentTimeMillis() % RAINBOW_CYCLE_MS / (float) RAINBOW_CYCLE_MS;
    }

    public static Color getRainbowColor() {
        return fromHue(getRainbowHue(), 0.4F, 0.94F);
    }

    public static void applyRainbowTheme() {
        float hue = getRainbowHue();
        GuiTheme theme = GuiTheme.theme;
        theme.setWindowBg(GuiTheme.DEFAULT_WINDOW_BG);
        theme.setPanelTop(fromHue(hue, 0.16F, 0.2F));
        theme.setPanelBottom(fromHue(hue, 0.18F, 0.09F));
        theme.setCardTop(fromHue(hue, 0.14F, 0.17F));
        theme.setCardBottom(fromHue(hue, 0.16F, 0.1F));
        theme.setCardActiveTop(fromHue(hue, 0.2F, 0.22F));
        theme.setCardActiveBottom(fromHue(hue, 0.22F, 0.14F));

        Color accent = fromHue(hue, 0.4F, 0.94F);
        theme.setAccent(accent);
        theme.setToggleOn(accent);
        theme.setModeOn(accent);
        theme.setSliderFill(accent);

        theme.setModeOff(withAlpha(fromHue(hue, 0.12F, 0.26F), 180));
        theme.setSliderTrack(fromHue(hue, 0.1F, 0.22F));
        theme.setToggleOff(fromHue(hue, 0.08F, 0.3F));
        theme.setHudSeparator(fromHue(hue, 0.1F, 0.18F));
    }

    private static ThemePreset defaultForStyle(GuiStyle style) {
        return style == GuiStyle.KAWASE ? HORIZON : DEFAULT;
    }

    private static boolean isVisibleForStyle(ThemePreset preset, GuiStyle style) {
        for (ThemePreset visible : getVisible(style)) {
            if (visible.getId().equals(preset.getId())) {
                return true;
            }
        }
        return false;
    }

    private static List<ThemePreset> concat(List<ThemePreset> first, List<ThemePreset> second) {
        List<ThemePreset> combined = new ArrayList<>(first.size() + second.size());
        combined.addAll(first);
        combined.addAll(second);
        return combined;
    }

    private static Color releaseColor(String hex) {
        String value = hex.startsWith("#") ? hex.substring(1) : hex;

        int red;
        int green;
        int blue;
        int alpha;
        if (value.length() == 6) {
            red = Integer.parseInt(value.substring(0, 2), 16);
            green = Integer.parseInt(value.substring(2, 4), 16);
            blue = Integer.parseInt(value.substring(4, 6), 16);
            alpha = 255;
        } else if (value.length() == 8) {
            red = Integer.parseInt(value.substring(0, 2), 16);
            green = Integer.parseInt(value.substring(2, 4), 16);
            blue = Integer.parseInt(value.substring(4, 6), 16);
            alpha = Integer.parseInt(value.substring(6, 8), 16);
        } else {
            throw new IllegalArgumentException("Expected #RRGGBB or #RRGGBBAA: " + hex);
        }
        return new Color(red, green, blue, alpha);
    }

    private static Color fromHue(float hue, float saturation, float brightness) {
        Color color = Color.getHSBColor(hue, saturation, brightness);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), 255);
    }

    private static Color withAlpha(Color color, int alpha) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    }
}
