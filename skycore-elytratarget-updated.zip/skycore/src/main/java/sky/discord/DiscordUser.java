package sky.discord;

import com.sun.jna.Structure;

import java.util.Arrays;
import java.util.List;

public class DiscordUser extends Structure {
    public String avatar;
    public String userId;
    @Deprecated
    public String discriminator;
    public String username;

    @Override
    protected List<String> getFieldOrder() {
        return Arrays.asList("userId", "username", "discriminator", "avatar");
    }
}
