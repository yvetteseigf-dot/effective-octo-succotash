package sky.discord;

import com.sun.jna.Callback;

public interface DiscordJoinGameCallback extends Callback {
    void apply(String joinSecret);
}
