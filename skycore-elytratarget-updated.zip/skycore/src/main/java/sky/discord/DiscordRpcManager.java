package sky.discord;

import net.minecraft.client.MinecraftClient;

/** Optional Discord integration driven by a daemon thread that pumps the native callbacks. */
public final class DiscordRpcManager {
    private DiscordDaemonThread discordDaemonThread;
    private boolean running;
    private String image;
    private String site;
    private String telegram;
    private long applicationId;

    public DiscordRpcManager() {
        applicationId = 1516934170486505592L;
        image = "skycore";
        telegram = "https://t.me/skycoredll";
        site = "https://skycoredlc.ru";
    }

    public DiscordRpcManager start() {
        return this;
    }

    public void stopRpc() {
    }

    private void init() {
        discordDaemonThread = new DiscordDaemonThread();
        running = true;

        DiscordRichPresence.Builder presence = new DiscordRichPresence.Builder();
        DiscordEventHandlers handlers = new DiscordEventHandlers.Builder().build();
        DiscordRpcLibrary.getInstance().Discord_Initialize(String.valueOf(applicationId), handlers, true, "");
        presence.setStartTimestamp(System.currentTimeMillis() / 1000L);

        MinecraftClient client = MinecraftClient.getInstance();

        presence.setDetails("User: " + client.getSession().getUsername());
        presence.setState("Uid: " + client.getSession().getUuidOrNull());
        presence.setLargeImage(image, "https://skycoredlc.ru");
        presence.setButtons(
                DiscordRpcButton.create("News", telegram),
                DiscordRpcButton.create("Website", site));

        DiscordRpcLibrary.getInstance().Discord_UpdatePresence(presence.build());
        discordDaemonThread.start();
    }

    final class DiscordDaemonThread extends Thread {
        private DiscordDaemonThread() {
            setName("Discord-RPC");
            setDaemon(true);
        }

        @Override
        public void run() {
            try {
                while (running) {
                    DiscordRpcLibrary.getInstance().Discord_RunCallbacks();
                    Thread.sleep(2000L);
                }
            } catch (Throwable ignored) {
                running = false;
            }
        }
    }
}
