package sky.discord;

import com.sun.jna.Callback;

public interface DiscordDisconnectedCallback extends Callback {
    void apply(int errorCode, String message);
}
