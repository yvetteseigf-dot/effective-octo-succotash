package sky.discord;

import com.sun.jna.Callback;

public interface DiscordSpectateGameCallback extends Callback {
    void apply(String spectateSecret);
}
