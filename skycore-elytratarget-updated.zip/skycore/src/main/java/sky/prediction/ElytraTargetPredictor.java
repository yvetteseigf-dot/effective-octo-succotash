package sky.prediction;

import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import sky.event.render.RenderWorldEvent;
import sky.module.combat.AttackAura;
import sky.module.combat.ElytraTarget;
import sky.module.movement.FreeCamera;
import sky.render.WorldDrawHelper;
import sky.util.render.ArgbUtil;
import sky.util.MsTimer;
import sky.util.combat.Rotation;
import sky.access.SkyClientAccess;
import sky.rotation.RotationManager;
import sky.theme.GuiTheme;

public final class ElytraTargetPredictor implements SkyClientAccess {
    public static Vec3d leaveVec;
    public static Vec3d lastVec;
    public static LivingEntity target;
    private static final MsTimer tickStopWatch;
    private static boolean prePredictCondition;
    public static double value2;
    public static Vec3d pos;
    public static boolean predictCondition;
    public static boolean defensiveActive;
    public static Vec3d vector;
    public static boolean blockPos;
    private static int movementTicks;
    /** displacement (blocks) the Smart mode predicts the target will travel; zero when unused */
    public static Vec3d smartOffset = Vec3d.ZERO;
    private static Vec3d smartVel = Vec3d.ZERO;
    private static Vec3d smartLastVel = Vec3d.ZERO;
    private static Vec3d smartAccel = Vec3d.ZERO;

    static {
        defensiveActive = false;
        leaveVec = Vec3d.ZERO;
        lastVec = Vec3d.ZERO;
        predictCondition = false;
        movementTicks = 0;
        prePredictCondition = false;
        tickStopWatch = new MsTimer();
        pos = Vec3d.ZERO;
        value2 = 0.0;
        vector = Vec3d.ZERO;
    }

    private ElytraTargetPredictor() {
    }

    public static void updateDefensiveState(LivingEntity entity) {
        defensiveActive = false;
    }

    public static void updateTarget(LivingEntity entity) {
        if (entity != target) {
            resetSmart();
        }
        target = entity;
    }

    private static void resetSmart() {
        smartOffset = Vec3d.ZERO;
        smartVel = Vec3d.ZERO;
        smartLastVel = Vec3d.ZERO;
        smartAccel = Vec3d.ZERO;
    }

    /**
     * Smart mode: measured velocity (+ a bit of acceleration), smoothed. When the target runs away the aim point is
     * placed ahead of him on his flight path (blocks ahead = Predict strength + speed bonus, capped), so we end up
     * in front of him. Returns the predicted chest position.
     */
    private static Vec3d computeSmartPosition(ElytraTarget elytraTarget) {
        Vec3d vel = new Vec3d(target.getX() - target.prevX, target.getY() - target.prevY,
                target.getZ() - target.prevZ);
        Vec3d accel = vel.subtract(smartLastVel);
        smartLastVel = vel;
        smartVel = smartVel.lerp(vel, 0.5);
        smartAccel = smartAccel.lerp(accel, 0.3);
        if (smartAccel.length() > 0.15) {
            smartAccel = smartAccel.normalize().multiply(0.15);
        }

        double strength = elytraTarget.distance.getCurrent();

        // short lead (used while the target is slow / not running away)
        double ticks = MathHelper.clamp(strength * 0.55, 0.6, 2.8);
        Vec3d tickOffset = smartVel.multiply(ticks).add(smartAccel.multiply(0.25 * ticks * ticks));

        // running away: aim at a point IN FRONT of the target (along his flight path) so we come out ahead of him
        double speed = smartVel.length();
        Vec3d offset = tickOffset;
        if (speed > 0.3) {
            Vec3d look = target.getRotationVec(1.0F).normalize();
            Vec3d dir = smartVel.normalize().multiply(0.6).add(look.multiply(0.4));
            dir = dir.lengthSquared() < 1.0E-6 ? smartVel.normalize() : dir.normalize();
            double lead = MathHelper.clamp(strength + speed * 2.0, 1.0, 7.0);
            Vec3d frontOffset = dir.multiply(lead);
            double f = MathHelper.clamp((speed - 0.3) / 0.5, 0.0, 1.0);
            offset = tickOffset.lerp(frontOffset, f);
        }
        if (offset.length() > 7.0) {
            offset = offset.normalize().multiply(7.0);
        }
        smartOffset = offset;
        return target.getPos().add(0.0, target.getHeight() * 0.6, 0.0).add(offset);
    }

    public static void setVector(Vec3d vector1) {
        vector = vector1;
    }

    public static void resetState() {
        defensiveActive = false;
        leaveVec = Vec3d.ZERO;
        lastVec = Vec3d.ZERO;
        pos = Vec3d.ZERO;
        vector = Vec3d.ZERO;
        resetSmart();
        blockPos = false;
        predictCondition = false;
        movementTicks = 0;
        prePredictCondition = false;
    }

    public static void updateDistances(Vec3d point) {
        if (mc.player == null || target == null) {
            return;
        }

        float distanceToPoint = (float) point.distanceTo(mc.player.getEyePos());
        float distanceToTarget = mc.player.distanceTo(target);
        value2 = blockPos ? distanceToPoint : distanceToTarget;
    }

    public static void updateRotation(Vec2f current) {
        Vec3d direction = vector;
        if (direction == null || direction.lengthSquared() < 1.0E-12) {
            return;
        }
        float targetYaw = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(direction.z, direction.x)) - 90.0);
        float targetPitch = (float) MathHelper.wrapDegrees(
                Math.toDegrees(-Math.atan2(direction.y, Math.hypot(direction.x, direction.z))));

        float currentYaw = current.x;
        float currentPitch = current.y;
        float yawDelta = MathHelper.wrapDegrees(targetYaw - currentYaw);
        float pitchDelta = MathHelper.wrapDegrees(targetPitch - currentPitch);

        if (Math.abs(yawDelta) > 180.0F && mc.player.isSwimming()) {
            yawDelta -= Math.signum(yawDelta) * 360.0F;
        }

        float clampedYawDelta = MathHelper.clamp(yawDelta, -180.0F, 180.0F);
        float clampedPitchDelta = MathHelper.clamp(pitchDelta, -90.0F, 90.0F);
        float finalYaw = currentYaw + clampedYawDelta;
        float finalPitch = MathHelper.clamp(currentPitch + clampedPitchDelta, -89.9F, 89.9F);

        float yawSpeed = 150.0F;
        float pitchSpeed = 150.0F;
        if (blockPos) {
            yawSpeed = 9999.0F;
            pitchSpeed = 9999.0F;
        }

        RotationManager.update(new Rotation(finalYaw, finalPitch), yawSpeed, pitchSpeed, 360.0F, 360.0F, 0, 1, false);
    }

    public static void smartPredict() {
        if (!tickStopWatch.finished(50L)) {
            return;
        }

        if (target != null) {
            float deltaX = (float) (target.getX() - target.lastRenderX);
            float deltaY = (float) (target.getY() - target.lastRenderY);
            float deltaZ = (float) (target.getZ() - target.lastRenderZ);
            float delta = (float) Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
            float blocksPerSecond = delta * 20.0F;

            if (blocksPerSecond > 20.0F) {
                movementTicks = 0;
                prePredictCondition = false;
                predictCondition = true;
            } else {
                movementTicks++;
                if (predictCondition) {
                    prePredictCondition = true;
                }

                if (movementTicks >= 3) {
                    predictCondition = false;
                    movementTicks = 0;
                    prePredictCondition = false;
                } else {
                    predictCondition = prePredictCondition;
                }
            }
        }

        tickStopWatch.reset();
    }

    public static void processTargetLogic(ElytraTarget elytraTarget) {
        if (target == null || elytraTarget == null) {
            return;
        }

        float distance = elytraTarget.distance.getCurrent();
        Vec3d eyePos = target.getEyePos();

        if (elytraTarget.isSmartPredict()) {
            Vec3d predicted = computeSmartPosition(elytraTarget);
            pos = predicted;
            updateDistances(predicted);
        } else if (elytraTarget.isTestPredict()) {
            float trailDistance = distance < 4.0F ? 0.0F : distance - 3.0F;
            Vec3d rotationVec = target.getRotationVec(1.0F);
            pos = eyePos.add(rotationVec.normalize().multiply(distance));
            Vec3d trailPoint = eyePos.add(rotationVec.normalize().multiply(trailDistance));
            updateDistances(trailPoint);
        } else if (elytraTarget.isForwardPredict()) {
            Vec3d direction = target.getRotationVec(1.0F).normalize();
            pos = eyePos.add(direction.multiply(distance));
            float trailDistance = distance < 4.0F ? 0.0F : distance - 3.0F;
            updateDistances(eyePos.add(direction.multiply(trailDistance)));
        } else if (elytraTarget.isPedikPredict()) {
            Vec3d heightOffset = new Vec3d(0.0,
                    MathHelper.clamp(target.getY() - target.getHeight(), 0.0, target.getHeight() / 2.0),
                    0.0);
            Vec3d basePos = target.getPos().add(heightOffset);
            Vec3d velocity = target.getVelocity().multiply(distance, distance, distance);
            Vec3d predictedPos = basePos.add(velocity);
            pos = predictedPos;
            updateDistances(predictedPos);
        } else {
            pos = eyePos;
            updateDistances(eyePos);
        }
    }

    public static Vec3d getVector3d(LivingEntity me, LivingEntity to) {
        ElytraTarget elytraTarget = ElytraTarget.INSTANCE;
        FreeCamera freeCamera = FreeCamera.INSTANCE;

        if (me == null || to == null || elytraTarget == null || !elytraTarget.isEnabled()) {
            blockPos = false;
            return Vec3d.ZERO;
        }

        boolean forwardPredict = elytraTarget.isForwardPredict();
        boolean pedikPredict = elytraTarget.isPedikPredict();
        boolean testPredict = elytraTarget.isTestPredict();
        boolean smartPredict = elytraTarget.isSmartPredict();
        boolean freeCameraIdle = freeCamera == null || !freeCamera.isEnabled();

        boolean testPredictActive = testPredict
                && elytraTarget.target.isEnabled()
                && (predictCondition || elytraTarget.isTestPredict())
                && mc.player.isGliding()
                && to.isGliding()
                && freeCameraIdle;
        boolean bothGliding = elytraTarget.target.isEnabled()
                && mc.player.isGliding()
                && to.isGliding()
                && freeCameraIdle;

        Vec3d result;
        boolean predicted;

        if (bothGliding && smartPredict) {
            predicted = true;
            Vec3d aim = pos.equals(Vec3d.ZERO) ? to.getEyePos() : pos;
            result = aim.subtract(me.getEyePos());
        } else if (testPredictActive) {
            predicted = true;
            Vec3d predictedPos = pos.add(to.getRotationVec(1.0F).normalize().multiply(2.0));
            result = new Vec3d(predictedPos.x - me.getX(), predictedPos.y - me.getY(), predictedPos.z - me.getZ());
        } else if (bothGliding && forwardPredict) {
            predicted = true;
            Vec3d predictedPos = pos.add(to.getRotationVec(1.0F).normalize().multiply(2.0));
            result = new Vec3d(predictedPos.x - me.getX(), predictedPos.y - me.getY(), predictedPos.z - me.getZ());
        } else if (bothGliding && pedikPredict) {
            predicted = true;
            double distance = elytraTarget.distance.getCurrent();
            Vec3d heightOffset = new Vec3d(0.0,
                    MathHelper.clamp(to.getY() - to.getHeight(), 0.0, to.getHeight() / 2.0),
                    0.0);
            Vec3d basePos = to.getPos().add(heightOffset);
            Vec3d eyePos = me.getEyePos();
            Vec3d velocity = to.getVelocity().multiply(distance, distance, distance);
            result = basePos.subtract(eyePos).add(velocity);
        } else if (bothGliding && predictCondition) {
            predicted = true;
            Vec3d predictedPos = pos.add(to.getRotationVec(1.0F).normalize().multiply(2.0));
            result = new Vec3d(predictedPos.x - me.getX(), predictedPos.y - me.getY(), predictedPos.z - me.getZ());
        } else {
            predicted = false;
            double halfWidth = to.getWidth() / 2.0F;
            double yOffset = MathHelper.clamp(to.getEyeY() - to.getY(), 0.0,
                    to.getHeight() - (mc.player.isGliding() ? 0.0 : 0.5));
            double xOffset = MathHelper.clamp(mc.player.getX() - to.getX(), -halfWidth, halfWidth);
            double zOffset = MathHelper.clamp(mc.player.getZ() - to.getZ(), -halfWidth, halfWidth);
            result = new Vec3d(
                    to.getX() - mc.player.getX() + xOffset,
                    to.getY() - mc.player.getEyeY() + yOffset,
                    to.getZ() - mc.player.getZ() + zOffset);
        }

        blockPos = predicted;
        return result;
    }

    public static void renderPredictCube(RenderWorldEvent event, ElytraTarget elytraTarget) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        if (elytraTarget == null || !elytraTarget.isEnabled()) {
            return;
        }
        if (!elytraTarget.target.isEnabled()) {
            return;
        }
        if (!elytraTarget.predictCube.isEnabled()) {
            return;
        }
        if (!elytraTarget.supportsPredictCube()) {
            return;
        }
        if (!mc.player.isGliding()) {
            return;
        }

        AttackAura attackAura = AttackAura.INSTANCE;
        if (attackAura == null) {
            return;
        }

        LivingEntity auraTarget = attackAura.getTarget();
        if (auraTarget == null || !auraTarget.isGliding()) {
            return;
        }
        if (pos == null || pos.equals(Vec3d.ZERO)) {
            return;
        }

        Box cube = new Box(
                pos.x - 0.35, pos.y - 0.35, pos.z - 0.35,
                pos.x + 0.35, pos.y + 0.35, pos.z + 0.35);
        int color = elytraTarget.predictFromTheme.isEnabled()
                ? GuiTheme.theme.getAccent().getRGB() | 0xFF000000
                : -1;
        int fillColor = ArgbUtil.multAlpha(color, elytraTarget.predictFillAlpha.getCurrent() / 255.0F);
        WorldDrawHelper.drawBox(cube, fillColor, 1.5F, true, true, false);
    }
}
