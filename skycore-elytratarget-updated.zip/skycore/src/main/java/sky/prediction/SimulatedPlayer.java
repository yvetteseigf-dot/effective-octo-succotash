package sky.prediction;

import it.unimi.dsi.fastutil.objects.Object2DoubleArrayMap;
import it.unimi.dsi.fastutil.objects.Object2DoubleMap;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.PowderSnowBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import sky.util.entity.MovementUtil;
import sky.access.SkyClientAccess;

/**
 * Off-world copy of a player that can be ticked forward to predict where they will end up.
 *
 * <p>The instance owns its own position, velocity and collision state, so ticking it never touches
 * the real entity. Everything that cannot change over the short prediction window - attributes,
 * dimensions, world access - is read straight off the backing player.</p>
 */
public class SimulatedPlayer implements SkyClientAccess {
    private static final double STEP_HEIGHT = 0.5D;

    public final PlayerEntity player;
    public final SimulatedPlayerInput input;

    public Vec3d pos;
    public Vec3d velocity;
    public Box boundingBox;
    public float yaw;
    public float pitch;
    public boolean sprinting;
    public float fallDistance;
    public int jumpingCooldown;
    public boolean isJumping;
    public boolean isFallFlying;
    public boolean onGround;
    public boolean horizontalCollision;
    public boolean verticalCollision;
    public boolean touchingWater;
    public boolean isSwimming;
    public boolean submergedInWater;

    private final Object2DoubleMap<TagKey<Fluid>> fluidHeight;
    private final HashSet<TagKey<Fluid>> submergedFluidTag;
    private int simulatedTicks = 0;
    private boolean clipLedged = false;

    public SimulatedPlayer(PlayerEntity player, SimulatedPlayerInput input, Vec3d pos, Vec3d velocity,
                           Box boundingBox, float yaw, float pitch, boolean sprinting, float fallDistance,
                           int jumpingCooldown, boolean isJumping, boolean isFallFlying, boolean onGround,
                           boolean horizontalCollision, boolean verticalCollision, boolean touchingWater,
                           boolean isSwimming, boolean submergedInWater,
                           Object2DoubleMap<TagKey<Fluid>> fluidHeight,
                           HashSet<TagKey<Fluid>> submergedFluidTag) {
        this.player = player;
        this.input = input;
        this.pos = pos;
        this.velocity = velocity;
        this.boundingBox = boundingBox;
        this.yaw = yaw;
        this.pitch = pitch;
        this.sprinting = sprinting;
        this.fallDistance = fallDistance;
        this.jumpingCooldown = jumpingCooldown;
        this.isJumping = isJumping;
        this.isFallFlying = isFallFlying;
        this.onGround = onGround;
        this.horizontalCollision = horizontalCollision;
        this.verticalCollision = verticalCollision;
        this.touchingWater = touchingWater;
        this.isSwimming = isSwimming;
        this.submergedInWater = submergedInWater;
        this.fluidHeight = fluidHeight;
        this.submergedFluidTag = submergedFluidTag;
    }

    public static SimulatedPlayer simulateLocalPlayer(int ticks) {
        SimulatedPlayer simulated =
            fromClientPlayer(SimulatedPlayerInput.fromClientPlayer(mc.player.input.playerInput));
        for (int tick = 0; tick < ticks; tick++) {
            simulated.tick();
        }
        return simulated;
    }

    public static SimulatedPlayer simulateOtherPlayer(PlayerEntity player, int ticks) {
        SimulatedPlayer simulated = fromOtherPlayer(player, SimulatedPlayerInput.guessInput(player));
        for (int tick = 0; tick < ticks; tick++) {
            simulated.tick();
        }
        return simulated;
    }

    public static SimulatedPlayer fromClientPlayer(SimulatedPlayerInput input) {
        ClientPlayerEntity localPlayer = mc.player;
        return new SimulatedPlayer(
            localPlayer,
            input,
            localPlayer.getPos(),
            localPlayer.getVelocity(),
            localPlayer.getBoundingBox(),
            localPlayer.getYaw(),
            localPlayer.getPitch(),
            localPlayer.isSprinting(),
            localPlayer.fallDistance,
            localPlayer.jumpingCooldown,
            localPlayer.jumping,
            localPlayer.isGliding(),
            localPlayer.isOnGround(),
            localPlayer.horizontalCollision,
            localPlayer.verticalCollision,
            localPlayer.isTouchingWater(),
            localPlayer.isSwimming(),
            localPlayer.isSubmergedInWater(),
            new Object2DoubleArrayMap<>(localPlayer.fluidHeight),
            new HashSet<>(localPlayer.submergedFluidTag)
        );
    }

    /**
     * Builds a simulation for a remote player. Their velocity is not synced, so it is derived from
     * the distance covered since the previous tick.
     */
    public static SimulatedPlayer fromOtherPlayer(PlayerEntity player, SimulatedPlayerInput input) {
        return new SimulatedPlayer(
            player,
            input,
            player.getPos(),
            player.getPos().subtract(new Vec3d(player.lastRenderX, player.lastRenderY, player.lastRenderZ)),
            player.getBoundingBox(),
            player.getYaw(),
            player.getPitch(),
            player.isSprinting(),
            player.fallDistance,
            player.jumpingCooldown,
            player.jumping,
            player.isGliding(),
            player.isOnGround(),
            player.horizontalCollision,
            player.verticalCollision,
            player.isTouchingWater(),
            player.isSwimming(),
            player.isSubmergedInWater(),
            new Object2DoubleArrayMap<>(player.fluidHeight),
            new HashSet<>(player.submergedFluidTag)
        );
    }

    @Override
    public SimulatedPlayer clone() {
        return new SimulatedPlayer(
            player,
            input,
            pos,
            velocity,
            boundingBox,
            yaw,
            pitch,
            sprinting,
            fallDistance,
            jumpingCooldown,
            isJumping,
            isFallFlying,
            onGround,
            horizontalCollision,
            verticalCollision,
            touchingWater,
            isSwimming,
            submergedInWater,
            new Object2DoubleArrayMap<>(fluidHeight),
            new HashSet<>(submergedFluidTag)
        );
    }

    public void tick() {
        simulatedTicks++;
        clipLedged = false;
        if (pos.y <= -70.0D) {
            return;
        }

        input.tick();
        checkWaterState();
        updateSubmergedInWaterState();
        updateSwimming();

        if (jumpingCooldown > 0) {
            jumpingCooldown--;
        }
        isJumping = input.playerInput.jump();

        double velocityX = velocity.x;
        double velocityY = velocity.y;
        double velocityZ = velocity.z;
        if (Math.abs(velocity.x) < 0.003D) {
            velocityX = 0.0D;
        }
        if (Math.abs(velocity.y) < 0.003D) {
            velocityY = 0.0D;
        }
        if (Math.abs(velocity.z) < 0.003D) {
            velocityZ = 0.0D;
        }
        if (onGround) {
            isFallFlying = false;
        }
        velocity = new Vec3d(velocityX, velocityY, velocityZ);

        if (isJumping) {
            double fluidDepth = isInLava() ? getFluidHeight(FluidTags.LAVA) : getFluidHeight(FluidTags.WATER);
            boolean inWater = isTouchingWater() && fluidDepth > 0.0D;
            double swimHeight = getSwimHeight();

            if (inWater && (!onGround || fluidDepth > swimHeight)) {
                swimUpward(FluidTags.WATER);
            } else if (isInLava() && (!onGround || fluidDepth > swimHeight)) {
                swimUpward(FluidTags.LAVA);
            } else if ((onGround || (inWater && fluidDepth <= swimHeight)) && jumpingCooldown == 0) {
                jump();
                jumpingCooldown = 10;
            }
        }

        float sideways = input.movementSideways * 0.98F;
        float forward = input.movementForward * 0.98F;
        float upward = 0.0F;
        if (hasStatusEffect(StatusEffects.SLOW_FALLING) || hasStatusEffect(StatusEffects.LEVITATION)) {
            onLanding();
        }
        travel(new Vec3d(sideways, upward, forward));
    }

    private void travel(Vec3d movementInput) {
        if (isSwimming && !player.hasVehicle()) {
            double lookY = getRotationVector().y;
            double pull = lookY < -0.2D ? 0.085D : 0.06D;
            BlockPos above = new BlockPos(
                MathHelper.floor(pos.x),
                MathHelper.floor(pos.y + 1.0D - 0.1D),
                MathHelper.floor(pos.z));
            if (lookY <= 0.0D
                || input.playerInput.jump()
                || !player.getWorld().getBlockState(above).getFluidState().isEmpty()) {
                velocity = velocity.add(0.0D, (lookY - velocity.y) * pull, 0.0D);
            }
        }

        double previousVelocityY = velocity.y;
        double gravity = 0.08D;
        boolean falling = velocity.y <= 0.0D;
        if (velocity.y <= 0.0D && hasStatusEffect(StatusEffects.SLOW_FALLING)) {
            gravity = 0.01D;
            onLanding();
        }

        if (isTouchingWater() && player.shouldSwimInFluids()) {
            double startY = pos.y;
            float drag = isSprinting() ? 0.9F : 0.8F;
            float speed = 0.02F;
            drag = (float) getAttributeValue(EntityAttributes.WATER_MOVEMENT_EFFICIENCY);
            if (!onGround) {
                drag *= 0.5F;
            }
            if (drag > 0.0F) {
                drag += (0.54600006F - drag) * drag / 3.0F;
                speed += (getMovementSpeed() - speed) * drag / 3.0F;
            }
            if (hasStatusEffect(StatusEffects.DOLPHINS_GRACE)) {
                drag = 0.96F;
            }

            updateVelocity(speed, movementInput);
            move(velocity);

            Vec3d moved = velocity;
            if (horizontalCollision && isClimbing()) {
                moved = new Vec3d(moved.x, 0.2D, moved.z);
            }
            velocity = moved.multiply(drag, 0.8D, drag);

            Vec3d damped = player.applyFluidMovingSpeed(gravity, falling, velocity);
            velocity = damped;
            if (horizontalCollision && doesNotCollide(damped.x, damped.y + 0.6D - pos.y + startY, damped.z)) {
                velocity = new Vec3d(damped.x, 0.3D, damped.z);
            }
        } else if (isInLava() && player.shouldSwimInFluids()) {
            double startY = pos.y;
            updateVelocity(0.02F, movementInput);
            move(velocity);

            if (getFluidHeight(FluidTags.LAVA) <= getSwimHeight()) {
                velocity = velocity.multiply(0.5D, 0.8D, 0.5D);
                velocity = player.applyFluidMovingSpeed(gravity, falling, velocity);
            } else {
                velocity = velocity.multiply(0.5D);
            }

            if (!player.hasNoGravity()) {
                velocity = velocity.add(0.0D, -gravity / 4.0D, 0.0D);
            }
            if (horizontalCollision
                && doesNotCollide(velocity.x, velocity.y + 0.6D - pos.y + startY, velocity.z)) {
                velocity = new Vec3d(velocity.x, 0.3D, velocity.z);
            }
        } else if (isFallFlying) {
            Vec3d glideVelocity = velocity;
            if (glideVelocity.y > -0.5D) {
                fallDistance = 1.0F;
            }

            Vec3d look = getRotationVector();
            float pitchRadians = pitch * 0.017453292F;
            double horizontalLook = Math.sqrt(look.x * look.x + look.z * look.z);
            double horizontalSpeed = velocity.horizontalLength();
            double lookLength = look.length();
            float lift = MathHelper.cos(pitchRadians);
            lift = (float) (lift * lift * Math.min(1.0D, lookLength / 0.4D));
            glideVelocity = velocity.add(0.0D, gravity * (-1.0D + lift * 0.75D), 0.0D);

            if (glideVelocity.y < 0.0D && horizontalLook > 0.0D) {
                double converted = glideVelocity.y * -0.1D * lift;
                glideVelocity = glideVelocity.add(
                    look.x * converted / horizontalLook,
                    converted,
                    look.z * converted / horizontalLook);
            }
            if (pitchRadians < 0.0F && horizontalLook > 0.0D) {
                double dive = horizontalSpeed * -MathHelper.sin(pitchRadians) * 0.04D;
                glideVelocity = glideVelocity.add(
                    -look.x * dive / horizontalLook,
                    dive * 3.2D,
                    -look.z * dive / horizontalLook);
            }
            if (horizontalLook > 0.0D) {
                glideVelocity = glideVelocity.add(
                    (look.x / horizontalLook * horizontalSpeed - glideVelocity.x) * 0.1D,
                    0.0D,
                    (look.z / horizontalLook * horizontalSpeed - glideVelocity.z) * 0.1D);
            }

            velocity = glideVelocity.multiply(0.99D, 0.98D, 0.99D);
            move(velocity);
        } else {
            BlockPos velocityPos = getVelocityAffectingPos();
            float slipperiness = player.getWorld().getBlockState(velocityPos).getBlock().getSlipperiness();
            float friction = onGround ? slipperiness * 0.91F : 0.91F;
            Vec3d moved = applyMovementInput(movementInput, slipperiness);
            double newY = moved.y;

            if (hasStatusEffect(StatusEffects.LEVITATION)) {
                StatusEffectInstance levitation = getStatusEffect(StatusEffects.LEVITATION);
                if (levitation != null) {
                    newY += (0.05D * (levitation.getAmplifier() + 1) - moved.y) * 0.2D;
                }
            } else if (player.getWorld().isClient() && !player.getWorld().isChunkLoaded(velocityPos)) {
                newY = pos.y > player.getWorld().getBottomY() ? -0.1D : 0.0D;
            } else if (!player.hasNoGravity()) {
                newY -= gravity;
            }

            if (player.hasNoDrag()) {
                velocity = new Vec3d(moved.x, newY, moved.z);
            } else {
                velocity = new Vec3d(moved.x * friction, newY * 0.98F, moved.z * friction);
            }
        }

        if (player.getAbilities().flying && !player.hasVehicle()) {
            velocity = new Vec3d(velocity.x, previousVelocityY * 0.6D, velocity.z);
            onLanding();
        }
    }

    private void move(Vec3d movement) {
        Vec3d sneakAdjusted = adjustMovementForSneaking(movement);
        Vec3d collisionAdjusted = adjustMovementForCollisions(sneakAdjusted);
        if (collisionAdjusted.lengthSquared() > 1.0E-7D) {
            pos = pos.add(collisionAdjusted);
            boundingBox = player.dimensions.getBoxAt(pos);
        }

        boolean blockedX = !MathHelper.approximatelyEquals(movement.x, collisionAdjusted.x);
        boolean blockedZ = !MathHelper.approximatelyEquals(movement.z, collisionAdjusted.z);
        horizontalCollision = blockedX || blockedZ;
        verticalCollision = movement.y != collisionAdjusted.y;
        onGround = verticalCollision && movement.y < 0.0D;

        if (!isTouchingWater()) {
            checkWaterState();
        }
        if (onGround) {
            onLanding();
        } else if (movement.y < 0.0D) {
            fallDistance -= (float) movement.y;
        }

        Vec3d current = velocity;
        if (horizontalCollision || verticalCollision) {
            velocity = new Vec3d(
                blockedX ? 0.0D : current.x,
                onGround ? 0.0D : current.y,
                blockedZ ? 0.0D : current.z);
        }
    }

    private Vec3d adjustMovementForCollisions(Vec3d movement) {
        Box box = new Box(-0.3D, 0.0D, -0.3D, 0.3D, 1.8D, 0.3D).offset(pos);
        List<VoxelShape> extraShapes = Collections.emptyList();

        Vec3d adjusted = movement.lengthSquared() == 0.0D
            ? movement
            : Entity.adjustMovementForCollisions(player, movement, box, player.getWorld(), extraShapes);

        boolean blockedX = movement.x != adjusted.x;
        boolean blockedY = movement.y != adjusted.y;
        boolean blockedZ = movement.z != adjusted.z;
        boolean grounded = onGround || (blockedY && movement.y < 0.0D);

        if (player.getStepHeight() > 0.0F && grounded && (blockedX || blockedZ)) {
            Vec3d stepped = Entity.adjustMovementForCollisions(player,
                new Vec3d(movement.x, player.getStepHeight(), movement.z),
                box, player.getWorld(), extraShapes);
            Vec3d lifted = Entity.adjustMovementForCollisions(player,
                new Vec3d(0.0D, player.getStepHeight(), 0.0D),
                box.stretch(movement.x, 0.0D, movement.z), player.getWorld(), extraShapes);
            Vec3d liftedThenMoved = Entity.adjustMovementForCollisions(player,
                new Vec3d(movement.x, 0.0D, movement.z),
                box.offset(lifted), player.getWorld(), extraShapes).add(lifted);

            if (lifted.y < player.getStepHeight()
                && liftedThenMoved.horizontalLengthSquared() > stepped.horizontalLengthSquared()) {
                stepped = liftedThenMoved;
            }
            if (stepped.horizontalLengthSquared() > adjusted.horizontalLengthSquared()) {
                return stepped.add(Entity.adjustMovementForCollisions(player,
                    new Vec3d(0.0D, -stepped.y + movement.y, 0.0D),
                    box.offset(stepped), player.getWorld(), extraShapes));
            }
        }
        return adjusted;
    }

    /**
     * Trims horizontal movement in 0.05 steps until the player would still be standing on something,
     * which is what stops a sneaking player from walking off an edge.
     */
    private Vec3d adjustMovementForSneaking(Vec3d movement) {
        if (movement.y <= 0.0D && isStandingOnSurface()) {
            double x = movement.x;
            double z = movement.z;

            while (x != 0.0D
                && player.getWorld().isSpaceEmpty(player, boundingBox.offset(x, -STEP_HEIGHT, 0.0D))) {
                if (x < 0.05D && x >= -0.05D) {
                    x = 0.0D;
                    break;
                }
                x += x > 0.0D ? -0.05D : 0.05D;
            }
            while (z != 0.0D
                && player.getWorld().isSpaceEmpty(player, boundingBox.offset(0.0D, -STEP_HEIGHT, z))) {
                if (z < 0.05D && z >= -0.05D) {
                    z = 0.0D;
                    break;
                }
                z += z > 0.0D ? -0.05D : 0.05D;
            }
            while (x != 0.0D && z != 0.0D
                && player.getWorld().isSpaceEmpty(player, boundingBox.offset(x, -STEP_HEIGHT, z))) {
                x = x < 0.05D && x >= -0.05D ? 0.0D : (x > 0.0D ? x - 0.05D : x + 0.05D);
                if (z < 0.05D && z >= -0.05D) {
                    z = 0.0D;
                    break;
                }
                z += z > 0.0D ? -0.05D : 0.05D;
            }

            if (movement.x != x || movement.z != z) {
                clipLedged = true;
            }
            if (shouldClipAtLedge()) {
                movement = new Vec3d(x, movement.y, z);
            }
        }
        return movement;
    }

    private Vec3d applyMovementInput(Vec3d movementInput, float slipperiness) {
        updateVelocity(getMovementSpeed(slipperiness), movementInput);
        velocity = applyClimbingSpeed(velocity);
        move(velocity);

        Vec3d moved = velocity;
        BlockPos blockPos = posToBlockPos(pos);
        BlockState state = getState(blockPos);
        if ((horizontalCollision || isJumping)
            && (isClimbing()
                || (state != null && state.isOf(Blocks.POWDER_SNOW)
                    && PowderSnowBlock.canWalkOnPowderSnow(player)))) {
            moved = new Vec3d(moved.x, 0.2D, moved.z);
        }
        return moved;
    }

    private Vec3d applyClimbingSpeed(Vec3d motion) {
        if (!isClimbing()) {
            return motion;
        }
        onLanding();

        double x = MathHelper.clamp(motion.x, -0.15F, 0.15F);
        double z = MathHelper.clamp(motion.z, -0.15F, 0.15F);
        double y = Math.max(motion.y, -0.15F);
        if (y < 0.0D
            && !getState(posToBlockPos(pos)).isOf(Blocks.SCAFFOLDING)
            && player.isHoldingOntoLadder()) {
            y = 0.0D;
        }
        return new Vec3d(x, y, z);
    }

    private void updateVelocity(float speed, Vec3d movementInput) {
        Vec3d applied = Entity.movementInputToVelocity(movementInput, speed, yaw);
        velocity = velocity.add(applied);
    }

    public void jump() {
        velocity = velocity.add(0.0D, getJumpVelocity() - velocity.y, 0.0D);
        if (isSprinting()) {
            float yawRadians = (float) Math.toRadians(yaw);
            velocity = velocity.add(
                -MathHelper.sin(yawRadians) * 0.2D,
                0.0D,
                MathHelper.cos(yawRadians) * 0.2D);
        }
    }

    private void swimUpward(TagKey<Fluid> fluid) {
        velocity = velocity.add(0.0D, 0.04F, 0.0D);
    }

    private void onLanding() {
        fallDistance = 0.0F;
    }

    private float getJumpVelocity() {
        return 0.42F * getJumpVelocityMultiplier() + getJumpBoostVelocityModifier();
    }

    private float getJumpVelocityMultiplier() {
        float standingOn = 0.0F;
        Block standingBlock = getState(posToBlockPos(pos)).getBlock();
        if (standingBlock != null) {
            standingOn = standingBlock.getJumpVelocityMultiplier();
        }

        float supporting = 0.0F;
        Block supportingBlock = getState(getVelocityAffectingPos()).getBlock();
        if (supportingBlock != null) {
            supporting = supportingBlock.getJumpVelocityMultiplier();
        }
        return standingOn == 1.0F ? supporting : standingOn;
    }

    private float getJumpBoostVelocityModifier() {
        if (hasStatusEffect(StatusEffects.JUMP_BOOST)) {
            StatusEffectInstance jumpBoost = getStatusEffect(StatusEffects.JUMP_BOOST);
            return 0.1F * (jumpBoost.getAmplifier() + 1);
        }
        return 0.0F;
    }

    private float getMovementSpeed() {
        return 0.1F;
    }

    private float getMovementSpeed(float slipperiness) {
        return onGround
            ? getMovementSpeed() * (0.21600002F / (slipperiness * slipperiness * slipperiness))
            : getAirStrafingSpeed();
    }

    private float getAirStrafingSpeed() {
        return input.playerInput.sprint() ? 0.02F + 0.006F : 0.02F;
    }

    private void checkWaterState() {
        if (player.getVehicle() instanceof BoatEntity) {
            BoatEntity boat = (BoatEntity) player.getVehicle();
            if (!boat.isSubmergedInWater()) {
                touchingWater = false;
                return;
            }
        }

        if (updateMovementInFluid(FluidTags.WATER, 0.014D)) {
            onLanding();
            touchingWater = true;
        } else {
            touchingWater = false;
        }
    }

    /**
     * Accumulates the push of every fluid block overlapping the bounding box and records how deep
     * the player is standing in it.
     */
    private boolean updateMovementInFluid(TagKey<Fluid> tag, double speed) {
        if (isRegionUnloaded()) {
            return false;
        }

        Box box = boundingBox.contract(0.001D);
        int minX = MathHelper.floor(box.minX);
        int maxX = MathHelper.ceil(box.maxX);
        int minY = MathHelper.floor(box.minY);
        int maxY = MathHelper.ceil(box.maxY);
        int minZ = MathHelper.floor(box.minZ);
        int maxZ = MathHelper.ceil(box.maxZ);

        double depth = 0.0D;
        boolean touching = false;
        Vec3d push = Vec3d.ZERO;
        int pushingBlocks = 0;
        BlockPos.Mutable cursor = new BlockPos.Mutable();

        for (int x = minX; x < maxX; x++) {
            for (int y = minY; y < maxY; y++) {
                for (int z = minZ; z < maxZ; z++) {
                    cursor.set(x, y, z);
                    FluidState fluidState = player.getWorld().getFluidState(cursor);
                    if (fluidState.isIn(tag)) {
                        double surface = y + fluidState.getHeight(player.getWorld(), cursor);
                        if (surface >= box.minY) {
                            touching = true;
                            depth = Math.max(surface - box.minY, depth);

                            Vec3d fluidVelocity = fluidState.getVelocity(player.getWorld(), cursor);
                            if (depth < 0.4D) {
                                fluidVelocity = fluidVelocity.multiply(depth);
                            }
                            push = push.add(fluidVelocity);
                            pushingBlocks++;
                        }
                    }
                }
            }
        }

        if (push.length() > 0.0D) {
            if (pushingBlocks > 0) {
                push = push.multiply(1.0D / pushingBlocks);
            }
            push = push.multiply(speed);

            if (Math.abs(velocity.x) < 0.003D && Math.abs(velocity.z) < 0.003D && push.length() < 0.0045D) {
                push = push.normalize().multiply(0.0045D);
            }
            velocity = velocity.add(push);
        }

        fluidHeight.put(tag, depth);
        return touching;
    }

    private void updateSubmergedInWaterState() {
        submergedInWater = submergedFluidTag.contains(FluidTags.WATER);
        submergedFluidTag.clear();

        double eyeY = getEyeY() - 0.11111111F;
        Entity vehicle = player.getVehicle();
        if (vehicle instanceof BoatEntity boat
            && !boat.isSubmergedInWater()
            && boat.getBoundingBox().maxY >= eyeY
            && boat.getBoundingBox().minY <= eyeY) {
            return;
        }

        BlockPos eyePos = BlockPos.ofFloored(pos.x, eyeY, pos.z);
        FluidState fluidState = player.getWorld().getFluidState(eyePos);
        double surface = eyePos.getY() + fluidState.getHeight(player.getWorld(), eyePos);
        if (surface > eyeY) {
            submergedFluidTag.addAll(fluidState.streamTags().toList());
        }
    }

    private void updateSwimming() {
        if (isSwimming) {
            isSwimming = isSprinting() && isTouchingWater() && !player.hasVehicle();
        } else {
            isSwimming = isSprinting()
                && isSubmergedInWater()
                && !player.hasVehicle()
                && player.getWorld().getFluidState(posToBlockPos(pos)).isIn(FluidTags.WATER);
        }
    }

    public boolean isSubmergedInWater() {
        return submergedInWater && isTouchingWater();
    }

    private boolean isTouchingWater() {
        return touchingWater;
    }

    public boolean isInLava() {
        return fluidHeight.getDouble(FluidTags.LAVA) > 0.0D;
    }

    private double getFluidHeight(TagKey<Fluid> tag) {
        return fluidHeight.getDouble(tag);
    }

    private double getSwimHeight() {
        return player.getStandingEyeHeight() < 0.4D ? 0.0D : 0.4D;
    }

    public boolean isClimbing() {
        BlockPos blockPos = posToBlockPos(pos);
        BlockState state = getState(blockPos);
        if (state.isIn(BlockTags.CLIMBABLE)) {
            return true;
        }
        return state.getBlock() instanceof TrapdoorBlock && canEnterTrapdoor(blockPos, state);
    }

    private boolean canEnterTrapdoor(BlockPos pos, BlockState state) {
        if (!state.get(TrapdoorBlock.OPEN)) {
            return false;
        }
        BlockState below = player.getWorld().getBlockState(pos.down());
        return below.isOf(Blocks.LADDER)
            && below.get(LadderBlock.FACING).equals(state.get(TrapdoorBlock.FACING));
    }

    protected boolean shouldClipAtLedge() {
        return input.playerInput.sneak() || input.forceSafeWalk;
    }

    private boolean isStandingOnSurface() {
        return onGround
            || (fallDistance < STEP_HEIGHT
                && !player.getWorld().isSpaceEmpty(player,
                    boundingBox.offset(0.0D, fallDistance - STEP_HEIGHT, 0.0D)));
    }

    private boolean isSprinting() {
        return sprinting;
    }

    private boolean doesNotCollide(double offsetX, double offsetY, double offsetZ) {
        return doesNotCollide(boundingBox.offset(offsetX, offsetY, offsetZ));
    }

    private boolean doesNotCollide(Box box) {
        return player.getWorld().isSpaceEmpty(player, box) && !player.getWorld().containsFluid(box);
    }

    private boolean isRegionUnloaded() {
        Box expanded = boundingBox.expand(1.0D);
        int minX = MathHelper.floor(expanded.minX);
        int maxX = MathHelper.ceil(expanded.maxX);
        int minZ = MathHelper.floor(expanded.minZ);
        int maxZ = MathHelper.ceil(expanded.maxZ);
        return !player.getWorld().isRegionLoaded(minX, minZ, maxX, maxZ);
    }

    private BlockPos getVelocityAffectingPos() {
        return BlockPos.ofFloored(pos.x, boundingBox.minY - 0.5000001D, pos.z);
    }

    public BlockPos posToBlockPos(Vec3d pos) {
        return new BlockPos(MathHelper.floor(pos.x), MathHelper.floor(pos.y), MathHelper.floor(pos.z));
    }

    public BlockState getState(BlockPos pos) {
        return player.getWorld().getBlockState(pos);
    }

    public Vec3d pos() {
        return player.getPos();
    }

    private double getEyeY() {
        return pos.y + player.getStandingEyeHeight();
    }

    private Vec3d getRotationVector() {
        return getRotationVector(pitch, yaw);
    }

    private Vec3d getRotationVector(float pitch, float yaw) {
        float pitchRadians = (float) (pitch * Math.PI / 180.0D);
        float yawRadians = (float) (-yaw * Math.PI / 180.0D);
        float cosYaw = MathHelper.cos(yawRadians);
        float sinYaw = MathHelper.sin(yawRadians);
        float cosPitch = MathHelper.cos(pitchRadians);
        float sinPitch = MathHelper.sin(pitchRadians);
        return new Vec3d(sinYaw * cosPitch, -sinPitch, cosYaw * cosPitch);
    }

    public double getAttributeValue(RegistryEntry<EntityAttribute> attribute) {
        return player.getAttributes().getValue(attribute);
    }

    /** Only reports effects that will still be running once the simulation reaches this tick. */
    public boolean hasStatusEffect(RegistryEntry<StatusEffect> effect) {
        StatusEffectInstance instance = player.getStatusEffect(effect);
        return instance != null && instance.getDuration() >= simulatedTicks;
    }

    private StatusEffectInstance getStatusEffect(RegistryEntry<StatusEffect> effect) {
        StatusEffectInstance instance = player.getStatusEffect(effect);
        return instance != null && instance.getDuration() >= simulatedTicks ? instance : null;
    }

    public static class SimulatedPlayerInput extends Input {
        public static final double MAX_WALKING_SPEED = 0.121D;

        public PlayerInput playerInput;
        public float movementForward;
        public float movementSideways;
        public boolean forceSafeWalk = false;

        public SimulatedPlayerInput(PlayerInput playerInput) {
            this.playerInput = playerInput;
        }

        public static SimulatedPlayerInput fromClientPlayer(PlayerInput playerInput) {
            return new SimulatedPlayerInput(playerInput);
        }

        /**
         * Remote players only send positions, so the keys they are holding are inferred from the
         * direction and length of the last movement.
         */
        public static SimulatedPlayerInput guessInput(PlayerEntity player) {
            Vec3d movement = player.getPos().subtract(new Vec3d(player.lastRenderX, player.lastRenderY, player.lastRenderZ));
            double horizontalSpeedSquared = movement.horizontalLengthSquared();

            PlayerInput input = new PlayerInput(false, false, false, false,
                !player.isOnGround(),
                player.isSneaking(),
                horizontalSpeedSquared >= MAX_WALKING_SPEED * MAX_WALKING_SPEED);

            if (horizontalSpeedSquared > 0.05D * 0.05D) {
                double degrees = MovementUtil.getDegreesRelativeToView(movement, player.getYaw());
                input = MovementUtil.getDirectionalInputForDegrees(input, MathHelper.wrapDegrees(degrees));
            }
            return new SimulatedPlayerInput(input);
        }

        @Override
        public void tick() {
            if (playerInput.forward() != playerInput.backward()) {
                movementForward = playerInput.forward() ? 1.0F : -1.0F;
            } else {
                movementForward = 0.0F;
            }

            if (playerInput.left() == playerInput.right()) {
                movementSideways = 0.0F;
            } else {
                movementSideways = playerInput.left() ? 1.0F : -1.0F;
            }

            if (playerInput.sneak()) {
                movementSideways *= 0.3F;
                movementForward *= 0.3F;
            }
        }

        @Override
        public String toString() {
            return "SimulatedPlayerInput(forwards={" + playerInput.forward()
                + "}, backwards={" + playerInput.backward()
                + "}, left={" + playerInput.left()
                + "}, right={" + playerInput.right()
                + "}, jumping={" + playerInput.jump()
                + "}, sprinting=" + playerInput.sprint()
                + ", slowDown=" + playerInput.sneak() + ")";
        }
    }
}
