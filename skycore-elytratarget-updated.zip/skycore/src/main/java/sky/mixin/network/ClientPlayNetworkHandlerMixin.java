package sky.mixin.network;

import com.darkmagician6.eventapi.EventManager;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.ItemPickupAnimationS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.SkyInit;
import sky.access.MinecraftAccess;
import sky.event.network.EntitySpawnEvent;
import sky.event.network.WorldSwapEvent;
import sky.event.network.GameJoinEvent;
import sky.event.network.PickupAnimationEvent;
import sky.event.combat.ThornsDamageEvent;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin implements MinecraftAccess {
    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void sendChatMessageHook(@NotNull String message, CallbackInfo ci) {
        if (message.startsWith(SkyInit.getInstance().getCommandManager().getPrefix())) {
            try {
                SkyInit.getInstance().getCommandManager().getDispatcher().execute(
                        message.substring(SkyInit.getInstance().getCommandManager().getPrefix().length()),
                        SkyInit.getInstance().getCommandManager().getSource()
                );
            } catch (CommandSyntaxException ignored) {
            }

            ci.cancel();
        }
    }

    @Inject(method = "onGameJoin", at = @At("TAIL"))
    private void skycore$onGameJoin(GameJoinS2CPacket packet, CallbackInfo ci) {
        EventManager.call(new GameJoinEvent());
        EventManager.call(new WorldSwapEvent(WorldSwapEvent.State.LOAD));
    }

    @Inject(method = "onPlayerRespawn", at = @At("TAIL"))
    private void skycore$onPlayerRespawn(PlayerRespawnS2CPacket packet, CallbackInfo ci) {
        EventManager.call(new WorldSwapEvent(WorldSwapEvent.State.CHANGED));
    }

    @Inject(method = "onEntityDamage", at = @At("HEAD"), cancellable = true)
    private void skycore$antiThornsEntityDamage(EntityDamageS2CPacket packet, CallbackInfo ci) {
        if (mc.player == null || mc.world == null || packet.entityId() != mc.player.getId()) {
            return;
        }
        if (!packet.sourceType().matchesKey(DamageTypes.THORNS)) {
            return;
        }

        Entity cause = mc.world.getEntityById(packet.sourceCauseId());
        LivingEntity thornsUser = cause instanceof LivingEntity living ? living : null;
        ThornsDamageEvent event = new ThornsDamageEvent(mc.player, thornsUser, 0, 0.0F);
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "onEntitySpawn", at = @At("HEAD"), cancellable = true)
    private void onSpawn(EntitySpawnS2CPacket packet, CallbackInfo ci) {
        if (packet.getEntityId() == 12345) {
            ci.cancel();
        }
    }

    @Inject(method = "onEntitySpawn", at = @At("TAIL"))
    private void skycore$afterEntitySpawn(EntitySpawnS2CPacket packet, CallbackInfo ci) {
        ClientPlayNetworkHandler handler = (ClientPlayNetworkHandler) (Object) this;
        if (handler.getWorld() == null) {
            return;
        }

        Entity entity = handler.getWorld().getEntityById(packet.getEntityId());
        if (entity != null) {
            EventManager.call(new EntitySpawnEvent(entity));
        }
    }

    @Inject(
            method = "onItemPickupAnimation",
            at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/entity/ItemEntity;getStack()Lnet/minecraft/item/ItemStack;")
    )
    private void onPickup(ItemPickupAnimationS2CPacket packet, CallbackInfo ci) {
        ClientPlayNetworkHandler handler = (ClientPlayNetworkHandler) (Object) this;
        if (handler.getWorld() != null
                && handler.getWorld().getEntityById(packet.getCollectorEntityId()) instanceof LivingEntity living
                && handler.getWorld().getEntityById(packet.getEntityId()) instanceof ItemEntity itemEntity) {
            ItemStack stack = itemEntity.getStack();
            EventManager.call(new PickupAnimationEvent(living, stack));
        }
    }
}
