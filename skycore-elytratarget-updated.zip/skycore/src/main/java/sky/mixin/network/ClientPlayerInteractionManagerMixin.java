package sky.mixin.network;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.access.MinecraftAccess;
import sky.event.combat.AttackBlockEvent;
import sky.event.combat.AttackEntityEvent;
import sky.event.player.ClickSlotEvent;
import sky.event.player.BlockPlaceEvent;
import sky.event.player.BlockPlaceNotifyEvent;
import sky.util.combat.AttackPacketUtil;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin implements MinecraftAccess {
    @Unique
    private BlockPos skycore$clickedPos;

    @Unique
    private BlockState skycore$clickedState;

    @Unique
    private Direction skycore$clickedSide;

    @Inject(
            method = "interactBlock(Lnet/minecraft/client/network/ClientPlayerEntity;Lnet/minecraft/util/Hand;Lnet/minecraft/util/hit/BlockHitResult;)Lnet/minecraft/util/ActionResult;",
            at = @At("HEAD")
    )
    private void skycore$interactBlockHead(
            ClientPlayerEntity player,
            Hand hand,
            BlockHitResult hitResult,
            CallbackInfoReturnable<ActionResult> cir
    ) {
        if (mc.world == null) {
            skycore$clickedState = null;
            return;
        }

        skycore$clickedPos = hitResult.getBlockPos();
        skycore$clickedState = mc.world.getBlockState(skycore$clickedPos);
        skycore$clickedSide = hitResult.getSide();
    }

    @Inject(
            method = "attackBlock(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/Direction;)Z",
            at = @At("HEAD")
    )
    private void skycore$attackBlockStart(
            BlockPos pos,
            Direction direction,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if (mc.world == null) {
            return;
        }

        BlockState state = mc.world.getBlockState(pos);
        if (!state.isAir()) {
            EventManager.call(new AttackBlockEvent(
                    state,
                    pos,
                    AttackBlockEvent.State.START,
                    direction
            ));
        }
    }

    @Inject(
            method = "attackBlock(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/Direction;)Z",
            at = @At("RETURN")
    )
    private void skycore$attackBlockStop(
            BlockPos pos,
            Direction direction,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if (mc.world == null) {
            return;
        }

        BlockState state = mc.world.getBlockState(pos);
        if (!state.isAir()) {
            EventManager.call(new AttackBlockEvent(
                    state,
                    pos,
                    AttackBlockEvent.State.STOP,
                    direction
            ));
        }
    }

    @Inject(
            method = "attackEntity(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/entity/Entity;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$attackEntity(PlayerEntity player, Entity target, CallbackInfo ci) {
        AttackEntityEvent event =
                new AttackEntityEvent(target);
        EventManager.call(event);
        if (event.isCancelled()) {
            AttackPacketUtil.notifyAttackCancelled();
            ci.cancel();
        }
    }

    @Inject(
            method = "clickSlot(IIILnet/minecraft/screen/slot/SlotActionType;Lnet/minecraft/entity/player/PlayerEntity;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$clickSlot(
            int syncId,
            int slotId,
            int button,
            SlotActionType actionType,
            PlayerEntity player,
            CallbackInfo ci
    ) {
        ClickSlotEvent event =
                new ClickSlotEvent(syncId, slotId, button, actionType);
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(
            method = "interactBlock(Lnet/minecraft/client/network/ClientPlayerEntity;Lnet/minecraft/util/Hand;Lnet/minecraft/util/hit/BlockHitResult;)Lnet/minecraft/util/ActionResult;",
            at = @At("RETURN")
    )
    private void skycore$interactBlockReturn(
            ClientPlayerEntity player,
            Hand hand,
            BlockHitResult hitResult,
            CallbackInfoReturnable<ActionResult> cir
    ) {
        ActionResult result = cir.getReturnValue();
        if (result != ActionResult.SUCCESS && !result.isAccepted()) {
            return;
        }
        if (mc.world == null || skycore$clickedState == null) {
            return;
        }

        BlockPos placePos = skycore$clickedState.isReplaceable()
                ? skycore$clickedPos
                : skycore$clickedPos.offset(skycore$clickedSide);
        BlockState blockState = mc.world.getBlockState(placePos);
        if (blockState.isAir()) {
            return;
        }

        EventManager.call(new BlockPlaceEvent(
                blockState.getBlock(),
                placePos
        ));
        EventManager.call(new BlockPlaceNotifyEvent(
                blockState.getBlock(),
                placePos
        ));
    }
}
