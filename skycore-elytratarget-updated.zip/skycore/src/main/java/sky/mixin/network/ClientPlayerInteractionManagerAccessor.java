package sky.mixin.network;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.network.SequencedPacketCreator;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ClientPlayerInteractionManager.class)
public interface ClientPlayerInteractionManagerAccessor {
    @Invoker("syncSelectedSlot")
    void skycore$syncSelectedSlot();

    @Invoker("sendSequencedPacket")
    void skycore$sendSequencedPacket(ClientWorld world, SequencedPacketCreator packetCreator);

    @Accessor("lastSelectedSlot")
    int skycore$getLastSelectedSlot();

    @Accessor("lastSelectedSlot")
    void skycore$setLastSelectedSlot(int lastSelectedSlot);

    @Accessor("blockBreakingCooldown")
    void skycore$setBlockBreakingCooldown(int cooldown);
}
