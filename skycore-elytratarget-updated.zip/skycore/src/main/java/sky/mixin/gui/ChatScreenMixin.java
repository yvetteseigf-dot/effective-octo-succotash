package sky.mixin.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.session.ChatPasswordHider;

@Mixin(ChatScreen.class)
public abstract class ChatScreenMixin extends Screen {
    @Shadow
    protected TextFieldWidget chatField;

    protected ChatScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void skycore$renderPasswordHider(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        int yTop = this.height - 14;
        int yBottom = this.height - 2;
        int x1 = this.width - 16;
        int x2 = this.width - 4;
        context.fill(x1, yTop, x2, yBottom,
                MinecraftClient.getInstance().options.getTextBackgroundColor(Integer.MIN_VALUE));

        int color = ChatPasswordHider.isEnabled() ? 0xFFFFFFFF : 0xFF8A8A8A;
        context.drawTextWithShadow(this.textRenderer, "H", x1 + 3, yTop + 2, color);
        ChatPasswordHider.renderMask(context, this.textRenderer, this.chatField.getText(),
                this.chatField.getX(), this.chatField.getY());
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void skycore$clickPasswordHider(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        int yTop = this.height - 14;
        int yBottom = this.height - 2;
        int x1 = this.width - 16;
        int x2 = this.width - 4;
        if (button == 0 && mouseX >= x1 && mouseX <= x2 && mouseY >= yTop && mouseY <= yBottom) {
            ChatPasswordHider.toggle();
            cir.setReturnValue(true);
        }
    }
}
