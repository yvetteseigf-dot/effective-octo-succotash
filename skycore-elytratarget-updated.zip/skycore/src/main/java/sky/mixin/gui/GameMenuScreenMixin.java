package sky.mixin.gui;

import net.minecraft.client.gui.screen.GameMenuScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.module.visuals.Animations;
import sky.ui.animation.EscPanelAnimation;

@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin {
    @Inject(method = "init", at = @At("TAIL"))
    private void skycore$escPanelInit(CallbackInfo ci) {
        EscPanelAnimation.beginOpen(Animations.effect(Animations.ESC_PANEL));
    }
}
