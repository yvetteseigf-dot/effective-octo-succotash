package sky.mixin.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.ui.animation.TooltipAnimation;

@Mixin(Screen.class)
public abstract class ScreenTooltipMixin {
    @Inject(method = "renderWithTooltip", at = @At("RETURN"))
    private void skycore$tooltipFadeOut(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        TooltipAnimation.endFrame(context);
    }
}
