package sky.mixin.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.GameOptionsScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.module.visuals.Animations;
import sky.util.animation.SmoothFloat;

@Mixin(ClickableWidget.class)
public abstract class ClickableWidgetMixin {
    @Unique
    private final SmoothFloat skycore$scale = new SmoothFloat(0.4F);

    @Unique
    private boolean skycore$scaleReady;

    @Unique
    private boolean skycore$matrixPushed;

    @Shadow
    public abstract int getX();

    @Shadow
    public abstract int getY();

    @Shadow
    public abstract int getWidth();

    @Shadow
    public abstract int getHeight();

    @Shadow
    public abstract boolean isHovered();

    @Unique
    private boolean skycore$shouldAnimateButtons(Screen screen) {
        if (screen == null) {
            return false;
        }
        if (!(screen instanceof GameMenuScreen)
                && !(screen instanceof OptionsScreen)
                && !(screen instanceof GameOptionsScreen)) {
            return false;
        }

        Object self = this;
        if (!(self instanceof ButtonWidget) && !(self instanceof CyclingButtonWidget)) {
            return false;
        }

        return this.getHeight() <= 28 && this.getWidth() <= 250;
    }

    @Inject(
            method = "render",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/widget/ClickableWidget;renderWidget(Lnet/minecraft/client/gui/DrawContext;IIF)V")
    )
    private void skycore$buttonScaleHead(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        this.skycore$matrixPushed = false;
        MinecraftClient client = MinecraftClient.getInstance();
        if (!this.skycore$shouldAnimateButtons(client.currentScreen)) {
            return;
        }

        boolean hoverFx = Animations.effect(Animations.ESC_HOVER);
        boolean pressFx = Animations.effect(Animations.ESC_PRESS);
        if (!hoverFx && !pressFx) {
            return;
        }

        if (!this.skycore$scaleReady) {
            this.skycore$scale.setImmediate(1.0F);
            this.skycore$scaleReady = true;
        }

        float target = 1.0F;
        if (hoverFx && this.isHovered()) {
            target = 1.08F;
        }
        if (pressFx && this.isHovered()) {
            long window = client.getWindow().getHandle();
            if (GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS) {
                target = 0.92F;
            }
        }

        this.skycore$scale.setTarget(target);
        this.skycore$scale.update();
        float scale = this.skycore$scale.get();
        if (Math.abs(scale - 1.0F) < 0.002F) {
            return;
        }

        float cx = this.getX() + this.getWidth() / 2.0F;
        float cy = this.getY() + this.getHeight() / 2.0F;
        context.getMatrices().push();
        context.getMatrices().translate(cx, cy, 0.0F);
        context.getMatrices().scale(scale, scale, 1.0F);
        context.getMatrices().translate(-cx, -cy, 0.0F);
        this.skycore$matrixPushed = true;
    }

    @Inject(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/widget/ClickableWidget;renderWidget(Lnet/minecraft/client/gui/DrawContext;IIF)V",
                    shift = At.Shift.AFTER
            )
    )
    private void skycore$buttonScaleTail(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this.skycore$matrixPushed) {
            context.getMatrices().pop();
            this.skycore$matrixPushed = false;
        }
    }
}
