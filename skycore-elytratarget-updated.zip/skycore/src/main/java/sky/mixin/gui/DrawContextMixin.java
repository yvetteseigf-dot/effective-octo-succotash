package sky.mixin.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.client.gui.tooltip.TooltipPositioner;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.ui.animation.InventoryCloseAnimation;
import sky.ui.animation.TooltipAnimation;

import java.util.List;

@Mixin(DrawContext.class)
public abstract class DrawContextMixin {
    @Unique
    private boolean skycore$tooltipAnimActive;

    @Inject(
            method = "drawTooltip(Lnet/minecraft/client/font/TextRenderer;Ljava/util/List;IILnet/minecraft/client/gui/tooltip/TooltipPositioner;Lnet/minecraft/util/Identifier;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$tooltipHead(
            TextRenderer textRenderer,
            List<TooltipComponent> components,
            int x,
            int y,
            TooltipPositioner positioner,
            Identifier texture,
            CallbackInfo ci
    ) {
        this.skycore$tooltipAnimActive = false;
        if (InventoryCloseAnimation.shouldHideContent()) {
            ci.cancel();
            return;
        }
        if (!TooltipAnimation.enabled()) {
            return;
        }

        DrawContext self = (DrawContext) (Object) this;
        float t = TooltipAnimation.beginDraw(textRenderer, components, x, y, positioner, texture);
        if (t <= 0.01F) {
            ci.cancel();
            return;
        }

        TooltipAnimation.applyTransform(self, x, y, t);
        this.skycore$tooltipAnimActive = true;
    }

    @Inject(
            method = "drawTooltip(Lnet/minecraft/client/font/TextRenderer;Ljava/util/List;IILnet/minecraft/client/gui/tooltip/TooltipPositioner;Lnet/minecraft/util/Identifier;)V",
            at = @At("RETURN")
    )
    private void skycore$tooltipTail(
            TextRenderer textRenderer,
            List<TooltipComponent> components,
            int x,
            int y,
            TooltipPositioner positioner,
            Identifier texture,
            CallbackInfo ci
    ) {
        if (this.skycore$tooltipAnimActive) {
            TooltipAnimation.endDraw((DrawContext) (Object) this);
            this.skycore$tooltipAnimActive = false;
        }
    }
}
