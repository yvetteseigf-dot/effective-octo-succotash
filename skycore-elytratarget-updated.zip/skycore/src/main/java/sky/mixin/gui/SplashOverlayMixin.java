package sky.mixin.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.render.DrawHelper;
import sky.render.SplashScreenRenderer;

import java.util.function.Function;

@Mixin(SplashOverlay.class)
public abstract class SplashOverlayMixin {
    @Shadow
    private long reloadCompleteTime;

    @Shadow
    private long reloadStartTime;

    private static final float SKYCORE_FADE_IN_MS = 620.0f;
    private static final float SKYCORE_FADE_OUT_MS = 1850.0f;

    private long skycore$createdAt = -1L;

    @Redirect(
            method = "render",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;fill(Lnet/minecraft/client/render/RenderLayer;IIIII)V")
    )
    private void skycore$hideVanillaBackground(DrawContext context, RenderLayer layer, int x1, int y1, int x2, int y2, int color) {
    }

    @Redirect(
            method = "render",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Ljava/util/function/Function;Lnet/minecraft/util/Identifier;IIFFIIIIIII)V")
    )
    private void skycore$hideMojangLogo(DrawContext context, Function<Identifier, RenderLayer> renderLayers, Identifier sprite,
                                        int x, int y, float u, float v, int width, int height,
                                        int textureWidth, int textureHeight, int regionWidth, int regionHeight, int color) {
    }

    @Redirect(
            method = "render",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/SplashOverlay;renderProgressBar(Lnet/minecraft/client/gui/DrawContext;IIIIF)V")
    )
    private void skycore$hideVanillaProgressBar(SplashOverlay overlay, DrawContext context, int minX, int minY, int maxX, int maxY, float opacity) {
    }

    @Redirect(
            method = "render",
            at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/platform/GlStateManager;_clearColor(FFFF)V")
    )
    private void skycore$hideStartupRedClearColor(float red, float green, float blue, float alpha) {
    }

    @Redirect(
            method = "render",
            at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/platform/GlStateManager;_clear(I)V")
    )
    private void skycore$hideStartupRedClear(int mask) {
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void skycore$renderCustomResourcePackLoading(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        context.draw();
        float alpha = skycore$getLoadingAlpha();
        DrawHelper.runOverlay(() -> SplashScreenRenderer.render(context, alpha));
    }

    private float skycore$getLoadingAlpha() {
        long now = Util.getMeasuringTimeMs();
        if (skycore$createdAt == -1L) {
            skycore$createdAt = now;
        }

        long fadeInStart = reloadStartTime > -1L ? Math.min(reloadStartTime, skycore$createdAt) : skycore$createdAt;
        float fadeIn = skycore$smooth(MathHelper.clamp((float) (now - fadeInStart) / SKYCORE_FADE_IN_MS, 0.0f, 1.0f));
        if (reloadCompleteTime <= -1L) {
            return fadeIn;
        }

        float fadeOut = 1.0f - skycore$smooth(MathHelper.clamp((float) (now - reloadCompleteTime) / SKYCORE_FADE_OUT_MS, 0.0f, 1.0f));
        return fadeIn * fadeOut;
    }

    private float skycore$smooth(float value) {
        return value * value * (3.0f - 2.0f * value);
    }
}
