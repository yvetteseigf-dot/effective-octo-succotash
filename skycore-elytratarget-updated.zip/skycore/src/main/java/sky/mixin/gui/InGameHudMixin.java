package sky.mixin.gui;

import com.darkmagician6.eventapi.EventManager;
import java.util.function.Function;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.misc.HeldItemVisualSpoof;
import sky.access.MinecraftAccess;
import sky.event.render.CrosshairRenderEvent;
import sky.event.render.OverlayRenderEvent;
import sky.module.visuals.Animations;
import sky.module.visuals.Crosshair;
import sky.module.visuals.Saturation;
import sky.render.HudOverlayRenderer;

@Mixin(InGameHud.class)
public class InGameHudMixin implements MinecraftAccess {
    @Unique
    private int skycore$savedHotbarSlot = -1;

    @Unique
    private boolean skycore$hotbarSlotFaked;

    @Unique
    private boolean skycore$deferHotbarHighlight;

    @Unique
    private int skycore$deferredHighlightY;

    @Inject(method = "renderHotbar", at = @At("HEAD"))
    private void skycore$fakeHotbarSelectedSlot(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        this.skycore$deferHotbarHighlight = false;
        if (mc.player == null) {
            return;
        }

        int visual = HeldItemVisualSpoof.getVisualSlot();
        if (visual >= 0 && visual <= 8) {
            this.skycore$savedHotbarSlot = mc.player.getInventory().selectedSlot;
            if (this.skycore$savedHotbarSlot != visual) {
                this.skycore$hotbarSlotFaked = true;
                mc.player.getInventory().selectedSlot = visual;
            }
        }

        if (Animations.effect(Animations.HOTBAR)) {
            int slot = mc.player.getInventory().selectedSlot;
            int centerX = context.getScaledWindowWidth() / 2;
            Animations.hotbar().update(slot, centerX, 120L);
        }
    }

    @Redirect(
            method = "renderHotbar",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Ljava/util/function/Function;Lnet/minecraft/util/Identifier;IIII)V",
                    ordinal = 1
            )
    )
    private void skycore$deferHotbarSelection(
            DrawContext context,
            Function<Identifier, RenderLayer> renderLayers,
            Identifier sprite,
            int x,
            int y,
            int width,
            int height
    ) {
        if (Animations.effect(Animations.HOTBAR) && Animations.hotbar().isReady()) {
            this.skycore$deferredHighlightY = y;
            this.skycore$deferHotbarHighlight = true;
            return;
        }

        context.drawGuiTexture(renderLayers, sprite, x, y, width, height);
    }

    @Inject(method = "renderHotbar", at = @At("RETURN"))
    private void skycore$restoreHotbarSelectedSlot(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (this.skycore$deferHotbarHighlight) {
            this.skycore$deferHotbarHighlight = false;
            int x = Math.round(Animations.hotbar().getX());
            context.getMatrices().push();
            context.getMatrices().translate(0.0F, 0.0F, 200.0F);
            context.drawGuiTexture(
                    RenderLayer::getGuiTextured,
                    Identifier.ofVanilla("hud/hotbar_selection"),
                    x,
                    this.skycore$deferredHighlightY,
                    24,
                    23);
            context.getMatrices().pop();
        }

        if (!this.skycore$hotbarSlotFaked || mc.player == null) {
            this.skycore$hotbarSlotFaked = false;
            return;
        }

        mc.player.getInventory().selectedSlot = this.skycore$savedHotbarSlot;
        this.skycore$hotbarSlotFaked = false;
        this.skycore$savedHotbarSlot = -1;
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void skycore$renderPreHud(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (HeldItemVisualSpoof.shouldSuppressTooltip() && mc.inGameHud != null) {
            ((InGameHudAccessor) mc.inGameHud).setHeldItemTooltipFade(0);
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }

        float partialTicks = tickCounter.getTickDelta(false);
        if (client.options.hudHidden
                || (client.getDebugHud() != null && client.getDebugHud().shouldShowDebugHud())) {
            if (Saturation.INSTANCE.isEnabled()) {
                Saturation.INSTANCE.onRender(
                        new OverlayRenderEvent.World(context.getMatrices(), partialTicks, context));
            }
            return;
        }

        EventManager.call(new OverlayRenderEvent.World(context.getMatrices(), partialTicks, context));
    }

    @Inject(method = "renderMainHud", at = @At("TAIL"))
    private void skycore$renderCustomHud(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }

        if (client.options.hudHidden
                || (client.getDebugHud() != null && client.getDebugHud().shouldShowDebugHud())) {
            return;
        }

        float partialTicks = tickCounter.getTickDelta(false);
        HudOverlayRenderer.renderOverlay(context, partialTicks);
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void skycore$customCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (!Crosshair.INSTANCE.isEnabled()) {
            return;
        }

        float partialTicks = tickCounter.getTickDelta(false);
        CrosshairRenderEvent event =
                new CrosshairRenderEvent(context, context.getMatrices(), partialTicks);
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }
}
