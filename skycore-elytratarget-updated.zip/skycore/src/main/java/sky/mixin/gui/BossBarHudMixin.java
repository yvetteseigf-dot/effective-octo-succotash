package sky.mixin.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.BossBarHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.module.visuals.Animations;
import sky.util.entity.NoRenderFilter;
import sky.util.animation.TweenFloat;

@Mixin(BossBarHud.class)
public class BossBarHudMixin {
    @Unique
    private final TweenFloat skycore$slide = new TweenFloat(0.0F);

    @Unique
    private boolean skycore$matrixPushed;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void skycore$bossbarAnim(DrawContext context, CallbackInfo ci) {
        this.skycore$matrixPushed = false;
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.BOSSBAR)) {
            ci.cancel();
            return;
        }
        if (!Animations.effect(Animations.BOSSBAR)) {
            return;
        }

        boolean hasBars = !((BossBarHudAccessor) this).getBossBars().isEmpty();
        this.skycore$slide.setDuration(260L);
        this.skycore$slide.animateTo(hasBars ? 1.0F : 0.0F);
        float t = this.skycore$slide.update();
        if (!hasBars) {
            return;
        }

        float y = (1.0F - t) * -36.0F;
        if (y < -0.05F) {
            context.getMatrices().push();
            context.getMatrices().translate(0.0F, y, 0.0F);
            this.skycore$matrixPushed = true;
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void skycore$bossbarAnimTail(DrawContext context, CallbackInfo ci) {
        if (this.skycore$matrixPushed) {
            context.getMatrices().pop();
            this.skycore$matrixPushed = false;
        }
    }
}
