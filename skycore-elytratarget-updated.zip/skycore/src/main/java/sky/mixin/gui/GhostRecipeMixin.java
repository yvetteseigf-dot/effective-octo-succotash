package sky.mixin.gui;

import it.unimi.dsi.fastutil.objects.Reference2ObjectMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.recipebook.GhostRecipe;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.module.visuals.Animations;
import sky.ui.animation.GhostRecipeAnimation;

@Mixin(GhostRecipe.class)
public abstract class GhostRecipeMixin {
    @Shadow
    private Reference2ObjectMap<Slot, ?> items;

    @Unique
    private boolean skycore$ghostMatrixPushed;

    @Inject(method = "clear", at = @At("HEAD"))
    private void skycore$ghostClear(CallbackInfo ci) {
        GhostRecipeAnimation.onClear();
    }

    @Inject(method = "draw", at = @At("HEAD"), cancellable = true)
    private void skycore$ghostDrawHead(DrawContext context, MinecraftClient client, boolean resultHasPadding, CallbackInfo ci) {
        this.skycore$ghostMatrixPushed = false;
        if (!Animations.effect(Animations.TOOLTIP)) {
            return;
        }

        int count = this.items == null ? 0 : this.items.size();
        float t = GhostRecipeAnimation.beginDraw(count);
        if (count > 0 && t <= 0.01F) {
            ci.cancel();
            return;
        }

        if (count > 0 && t < 0.999F) {
            float cx = context.getScaledWindowWidth() / 2.0F;
            float cy = context.getScaledWindowHeight() / 2.0F;
            float scale = 0.75F + 0.25F * t;
            context.getMatrices().push();
            context.getMatrices().translate(cx, cy, 0.0F);
            context.getMatrices().scale(scale, scale, 1.0F);
            context.getMatrices().translate(-cx, -cy, 0.0F);
            this.skycore$ghostMatrixPushed = true;
        }
    }

    @Inject(method = "draw", at = @At("RETURN"))
    private void skycore$ghostDrawTail(DrawContext context, MinecraftClient client, boolean resultHasPadding, CallbackInfo ci) {
        if (this.skycore$ghostMatrixPushed) {
            context.getMatrices().pop();
            this.skycore$ghostMatrixPushed = false;
        }
    }
}
