package sky.mixin.gui;

import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.client.gui.tooltip.TooltipPositioner;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(DrawContext.class)
public interface DrawContextAccessor {
    @Accessor("vertexConsumers")
    VertexConsumerProvider.Immediate getVertexConsumers();

    @Invoker("drawItemBar")
    void callDrawItemBar(ItemStack stack, int x, int y);

    @Invoker("drawCooldownProgress")
    void callDrawCooldownProgress(ItemStack stack, int x, int y);

    @Invoker("drawTooltip")
    void callDrawTooltip(
            TextRenderer textRenderer,
            List<TooltipComponent> components,
            int x,
            int y,
            TooltipPositioner positioner,
            Identifier texture
    );
}
