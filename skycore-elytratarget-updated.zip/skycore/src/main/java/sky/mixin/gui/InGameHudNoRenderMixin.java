package sky.mixin.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.scoreboard.ScoreboardObjective;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.util.entity.NoRenderFilter;

@Mixin(InGameHud.class)
public class InGameHudNoRenderMixin {
    @Inject(method = "renderTitleAndSubtitle", at = @At("HEAD"), cancellable = true)
    private void skycore$hideTitles(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.TITLE)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true)
    private void skycore$hideScoreboardTick(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.SCOREBOARD)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V", at = @At("HEAD"), cancellable = true)
    private void skycore$hideScoreboardObjective(DrawContext context, ScoreboardObjective objective, CallbackInfo ci) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.SCOREBOARD)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true)
    private void skycore$hideVignette(DrawContext context, Entity entity, CallbackInfo ci) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.VIGNETTE)) {
            ci.cancel();
        }
    }
}
