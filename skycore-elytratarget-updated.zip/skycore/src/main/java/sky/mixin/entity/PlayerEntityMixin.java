package sky.mixin.entity;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.event.entity.PlayerEntityTickEvent;

@Mixin(PlayerEntity.class)
public class PlayerEntityMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    public void tickMovement(CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (self != MinecraftClient.getInstance().player) {
            return;
        }
        EventManager.call(new PlayerEntityTickEvent());
    }
}
