package sky.mixin.entity;

import com.darkmagician6.eventapi.EventManager;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.event.player.CloseScreenEvent;
import sky.event.player.NoSlowEvent;
import sky.event.player.PlayerMoveEvent;
import sky.event.player.MotionEvent;
import sky.event.player.MotionPostEvent;
import sky.event.player.PlayerTickEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.entity.MoveEvent;
import sky.event.entity.NoPushEvent;
import sky.module.movement.ChargeBoost;
import sky.module.player.LockSlot;
import sky.util.entity.NoRenderFilter;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin extends AbstractClientPlayerEntity {
    @Shadow
    protected abstract void autoJump(float dx, float dz);

    public ClientPlayerEntityMixin(ClientWorld world, GameProfile profile) {
        super(world, profile);
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void skycore$preUpdate(CallbackInfo ci) {
        EventManager.call(new PlayerUpdateEvent());
        EventManager.call(new PlayerTickEvent());
    }

    @ModifyExpressionValue(
            method = "tickMovement",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"
            ),
            slice = @Slice(
                    from = @At(
                            value = "INVOKE",
                            target = "Lnet/minecraft/client/input/Input;tick()V"
                    ),
                    to = @At(
                            value = "INVOKE",
                            target = "Lnet/minecraft/client/network/ClientPlayerEntity;shouldSlowDown()Z"
                    )
            )
    )
    private boolean skycore$skipItemUseSlowdown(boolean usingItem) {
        if (!usingItem || this.hasVehicle()) {
            return usingItem;
        }

        NoSlowEvent event = new NoSlowEvent();
        EventManager.call(event);
        return !event.isCancelled();
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void skycore$postUpdate(CallbackInfo ci) {
        EventManager.call(new MotionPostEvent());
    }

    @Inject(method = "sendMovementPackets", at = @At("HEAD"), cancellable = true)
    private void skycore$motion(CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        MotionEvent event = new MotionEvent(
                player.getX(),
                player.getY(),
                player.getZ(),
                player.getYaw(),
                player.getPitch(),
                player.isOnGround(),
                player.isSneaking(),
                player.isSprinting()
        );
        EventManager.call(event);
        if (event.isCancel()) {
            ci.cancel();
            EventManager.call(new MotionPostEvent());
            return;
        }

        player.setPosition(event.getX(), event.getY(), event.getZ());
        player.setYaw(event.getYaw());
        player.setPitch(event.getPitch());
        player.setOnGround(event.isOnGround());
    }

    @Inject(method = "tickNausea", at = @At("HEAD"), cancellable = true)
    private void skycore$hideBadEffects(boolean fromPortalEffect, CallbackInfo ci) {
        if (!fromPortalEffect && NoRenderFilter.shouldCancel(NoRenderFilter.Type.BAD_EFFECTS)) {
            ci.cancel();
        }
    }

    @Inject(method = "closeHandledScreen", at = @At("HEAD"), cancellable = true)
    private void skycore$closeHandledScreen(CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        if (player != MinecraftClient.getInstance().player) {
            return;
        }

        CloseScreenEvent event =
                new CloseScreenEvent(player.currentScreenHandler.syncId);
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "dropSelectedItem", at = @At("HEAD"), cancellable = true)
    private void skycore$dropSelectedItem(boolean entireStack, CallbackInfoReturnable<Boolean> cir) {
        if (LockSlot.INSTANCE.isCurrentSlotLockedForDrop()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "pushOutOfBlocks", at = @At("HEAD"), cancellable = true)
    private void skycore$pushOutOfBlocks(double x, double z, CallbackInfo ci) {
        NoPushEvent event = new NoPushEvent(NoPushEvent.NoPushType.Block);
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(
            method = "move",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V"
            ),
            cancellable = true
    )
    private void skycore$onMove(MovementType movementType, Vec3d movement, CallbackInfo ci) {
        PlayerMoveEvent event = new PlayerMoveEvent(movement);
        EventManager.call(event);

        Vec3d motion = event.getMovePos();
        MoveEvent moveEvent = new MoveEvent(
                this.getPos(),
                this.getPos().add(motion),
                motion,
                this.isOnGround(),
                this.horizontalCollision,
                this.verticalCollision,
                this.getBoundingBox()
        );
        EventManager.call(moveEvent);

        double prevX = this.getX();
        double prevZ = this.getZ();
        super.move(movementType, moveEvent.getMotion());
        if (!ChargeBoost.shouldBlockAutoJump()) {
            this.autoJump((float) (this.getX() - prevX), (float) (this.getZ() - prevZ));
        }

        ci.cancel();
    }
}
