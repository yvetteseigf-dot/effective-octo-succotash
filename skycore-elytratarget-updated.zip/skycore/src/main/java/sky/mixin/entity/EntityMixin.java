package sky.mixin.entity;

import com.darkmagician6.eventapi.EventManager;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.event.combat.EntityHitboxEvent;
import sky.event.entity.WebCollisionEvent;
import sky.event.entity.NoPushEvent;
import sky.event.entity.MovePostEvent;
import sky.util.entity.NoRenderFilter;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true)
    private void skycore$expandHitBox(CallbackInfoReturnable<Float> cir) {
        Entity self = (Entity) (Object) this;
        EntityHitboxEvent event = new EntityHitboxEvent(self, 0.0F);
        EventManager.call(event);
        if (event.isCancelled() || event.getSize() <= 0.0F) {
            return;
        }
        cir.setReturnValue(event.getSize());
    }

    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void skycore$hideGlow(CallbackInfoReturnable<Boolean> cir) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.GLOWING)) {
            cir.setReturnValue(false);
        }
    }

    @ModifyExpressionValue(
            method = "move",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isControlledByPlayer()Z")
    )
    private boolean skycore$fixFallDistance(boolean original) {
        return (Object) this == MinecraftClient.getInstance().player ? false : original;
    }

    @Inject(method = "pushAwayFrom", at = @At("HEAD"), cancellable = true)
    private void skycore$pushAwayFrom(Entity entity, CallbackInfo ci) {
        if ((Object) this != MinecraftClient.getInstance().player) {
            return;
        }

        NoPushEvent event = new NoPushEvent(NoPushEvent.NoPushType.Player);
        EventManager.call(event);
        if (event.isCancel()) {
            ci.cancel();
        }
    }

    @Inject(method = "isPushedByFluids", at = @At("RETURN"), cancellable = true)
    private void skycore$isPushedByFluids(CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this != MinecraftClient.getInstance().player) {
            return;
        }

        NoPushEvent event = new NoPushEvent(NoPushEvent.NoPushType.Water);
        EventManager.call(event);
        if (event.isCancel()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "collidesWithStateAtPos", at = @At("HEAD"), cancellable = true)
    private void skycore$noWeb(BlockPos pos, BlockState state, CallbackInfoReturnable<Boolean> cir) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || (Object) this != mc.player || !state.isOf(Blocks.COBWEB)) {
            return;
        }

        WebCollisionEvent event = new WebCollisionEvent(pos);
        EventManager.call(event);
        if (event.isCancel()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "slowMovement", at = @At("HEAD"), cancellable = true)
    private void skycore$noWebSlow(BlockState state, Vec3d multiplier, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Entity self = (Entity) (Object) this;
        if (mc.player == null || self != mc.player || !state.isOf(Blocks.COBWEB)) {
            return;
        }

        WebCollisionEvent event = new WebCollisionEvent(self.getBlockPos());
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "updateVelocity", at = @At("TAIL"))
    private void skycore$updateVelocityPost(float speed, Vec3d movementInput, CallbackInfo ci) {
        Entity self = (Entity) (Object) this;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && self.getId() == client.player.getId()) {
            EventManager.call(new MovePostEvent(speed, movementInput));
        }
    }
}
