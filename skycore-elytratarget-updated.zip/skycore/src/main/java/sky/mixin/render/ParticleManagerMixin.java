package sky.mixin.render;

import net.minecraft.block.BlockState;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.util.entity.NoRenderFilter;

@Mixin(ParticleManager.class)
public class ParticleManagerMixin {
    @Inject(method = "addBlockBreakingParticles", at = @At("HEAD"), cancellable = true)
    private void skycore$hideBlockBreakingParticles(BlockPos pos, Direction direction, CallbackInfo ci) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.BREAK_PARTICLES)) {
            ci.cancel();
        }
    }

    @Inject(method = "addBlockBreakParticles", at = @At("HEAD"), cancellable = true)
    private void skycore$hideBlockBreakParticles(BlockPos pos, BlockState state, CallbackInfo ci) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.BREAK_PARTICLES)) {
            ci.cancel();
        }
    }

    @Inject(
            method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$hideSmokeParticles(
            ParticleEffect parameters,
            double x,
            double y,
            double z,
            double velocityX,
            double velocityY,
            double velocityZ,
            CallbackInfoReturnable<Particle> cir
    ) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.SMOKE) && isSmoke(parameters)) {
            cir.setReturnValue(null);
        }
    }

    private static boolean isSmoke(ParticleEffect parameters) {
        ParticleType<?> type = parameters.getType();
        return type == ParticleTypes.SMOKE
                || type == ParticleTypes.LARGE_SMOKE
                || type == ParticleTypes.CAMPFIRE_COSY_SMOKE
                || type == ParticleTypes.CAMPFIRE_SIGNAL_SMOKE
                || type == ParticleTypes.WHITE_SMOKE;
    }
}
