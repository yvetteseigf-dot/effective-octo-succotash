package sky.mixin.render;

import com.darkmagician6.eventapi.EventManager;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import sky.access.MinecraftAccess;
import sky.event.render.EntityTintEvent;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererLayerMixin<T extends LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>> implements MinecraftAccess {
    @Shadow
    @Nullable
    protected abstract RenderLayer getRenderLayer(
            LivingEntityRenderState state,
            boolean showBody,
            boolean translucent,
            boolean showOutline
    );

    @Redirect(
            method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/entity/LivingEntityRenderer;getRenderLayer(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/render/RenderLayer;"
            )
    )
    private RenderLayer renderHook(
            LivingEntityRenderer instance,
            LivingEntityRenderState state,
            boolean showBody,
            boolean translucent,
            boolean showOutline
    ) {
        if (!translucent && state.width == 0.6F) {
            EntityTintEvent event = new EntityTintEvent(-1);
            EventManager.call(event);
            if (event.isCancelled()) {
                translucent = true;
            }
        }

        return getRenderLayer(state, showBody, translucent, showOutline);
    }

    @Redirect(
            method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/entity/model/EntityModel;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V"
            )
    )
    private void renderModelHook(
            EntityModel<?> instance,
            MatrixStack matrixStack,
            VertexConsumer vertexConsumer,
            int i,
            int j,
            int l,
            @Local(ordinal = 0, argsOnly = true) LivingEntityRenderState renderState
    ) {
        EntityTintEvent event = new EntityTintEvent(l);
        if (renderState.invisibleToPlayer) {
            EventManager.call(event);
        }

        instance.render(matrixStack, vertexConsumer, i, j, event.getColor());
    }
}
