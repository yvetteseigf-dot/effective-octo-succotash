package sky.mixin.render;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.world.WorldView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.module.combat.HitBox;
import sky.util.entity.NoRenderFilter;

@Mixin(EntityRenderDispatcher.class)
public class EntityRenderManagerMixin {
    @Inject(method = "renderHitbox", at = @At("HEAD"), cancellable = true)
    private static void skycore$renderExpandedHitbox(
            MatrixStack matrices,
            VertexConsumer vertices,
            Entity entity,
            float tickDelta,
            float red,
            float green,
            float blue,
            CallbackInfo ci
    ) {
        HitBox module = HitBox.INSTANCE;
        if (!(entity instanceof LivingEntity living) || !module.shouldShowHitBox()) {
            return;
        }

        if (module.shouldKeepVanillaHitbox(living)) {
            return;
        }

        float halfWidth = entity.getWidth() / 2.0F + module.size.getCurrent();
        VertexRendering.drawBox(
                matrices,
                vertices,
                -halfWidth,
                0.0,
                -halfWidth,
                halfWidth,
                entity.getHeight(),
                halfWidth,
                red,
                green,
                blue,
                1.0F
        );
        ci.cancel();
    }

    @Inject(method = "renderShadow", at = @At("HEAD"), cancellable = true)
    private static void skycore$hideShadows(
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            EntityRenderState renderState,
            float opacity,
            float tickDelta,
            WorldView world,
            float radius,
            CallbackInfo ci
    ) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.SHADOWS)) {
            ci.cancel();
        }
    }
}
