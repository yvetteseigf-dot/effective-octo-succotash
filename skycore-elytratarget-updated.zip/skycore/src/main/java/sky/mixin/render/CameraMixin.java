package sky.mixin.render;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.event.camera.ThirdPersonDistanceEvent;
import sky.event.camera.CameraUpdateEvent;
import sky.module.combat.AttackAura;
import sky.module.movement.FreeCamera;
import sky.module.movement.NoPush;
import sky.util.entity.NoRenderFilter;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    private float yaw;

    @Shadow
    private float pitch;

    @Inject(method = "clipToSpace", at = @At("HEAD"), cancellable = true)
    private void skycore$clipToSpace(float desiredCameraDistance, CallbackInfoReturnable<Float> cir) {
        ThirdPersonDistanceEvent distanceEvent = new ThirdPersonDistanceEvent(desiredCameraDistance);
        EventManager.call(distanceEvent);
        if (distanceEvent.isCancelled() || distanceEvent.getDistance() != desiredCameraDistance) {
            cir.setReturnValue((float) distanceEvent.getDistance());
            return;
        }

        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.CAMERA_CLIP) || NoPush.allowsBlockVisibility()) {
            cir.setReturnValue(desiredCameraDistance);
        }
    }

    @Redirect(
            method = "update",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V")
    )
    private void skycore$redirectSetRotation(
            Camera instance,
            float yaw,
            float pitch,
            BlockView area,
            Entity focusedEntity,
            boolean thirdPerson,
            boolean inverseView,
            float tickDelta
    ) {
        CameraUpdateEvent event = new CameraUpdateEvent(yaw, pitch, tickDelta);
        EventManager.call(event);

        float newYaw = event.getYaw();
        float newPitch = event.getPitch();
        if (thirdPerson && inverseView) {
            newYaw += 180.0F;
            newPitch = -newPitch;
        }

        ((CameraAccessor) instance).setCustomRotation(newYaw, newPitch);
        if (event.isCancelled() && event.getPosition() != null) {
            ((CameraAccessor) instance).invokeSetPos(
                    event.getPosition().x,
                    event.getPosition().y,
                    event.getPosition().z
            );
        }
    }

    @Inject(method = "update", at = @At("RETURN"))
    private void skycore$applyFreeCameraPosition(
            BlockView area,
            Entity focusedEntity,
            boolean thirdPerson,
            boolean inverseView,
            float tickDelta,
            CallbackInfo ci
    ) {
        FreeCamera freeCamera = FreeCamera.INSTANCE;
        if (!freeCamera.isEnabled()) {
            return;
        }

        Vec3d pos = freeCamera.getInterpolatedCameraPosition(tickDelta);
        if (pos != null) {
            ((CameraAccessor) this).invokeSetPos(pos.x, pos.y, pos.z);
        }
    }

    @Inject(method = "update", at = @At("RETURN"))
    private void skycore$visualTurnBack(
            BlockView area,
            Entity focusedEntity,
            boolean thirdPerson,
            boolean inverseView,
            float tickDelta,
            CallbackInfo ci
    ) {
        if (AttackAura.INSTANCE.isEnabled()
                && AttackAura.INSTANCE.getTarget() != null
                && AttackAura.INSTANCE.isVisuallyTurnedBack()) {
            float offset = AttackAura.INSTANCE.getVisualYawOffset();
            this.yaw += offset;
            if (offset > 90.0F) {
                float factor = (offset - 90.0F) / 90.0F;
                this.pitch = this.pitch * (1.0F - factor) + -this.pitch * factor;
            }
        }
    }
}
