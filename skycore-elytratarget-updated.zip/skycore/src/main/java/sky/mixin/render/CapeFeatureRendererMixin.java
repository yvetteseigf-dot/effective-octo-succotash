package sky.mixin.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.cape.CapeManager;
import sky.cape.CapeMovementMode;
import sky.cape.CapeSimulationHolder;
import sky.cape.CapeWindMode;
import sky.model.CapePhysicsSimulation;
import sky.util.math.MutableXYZ;

@Mixin(CapeFeatureRenderer.class)
public abstract class CapeFeatureRendererMixin extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
    @Unique
    private static final int PART_COUNT = 16;

    public CapeFeatureRendererMixin(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
        super(context);
    }

    @Inject(
            method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FF)V",
            at = @At("HEAD"),
            cancellable = true
    )
    public void onRender(
            MatrixStack matrixStack,
            VertexConsumerProvider vertexConsumerProvider,
            int light,
            PlayerEntityRenderState state,
            float limbAngle,
            float limbDistance,
            CallbackInfo ci
    ) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) {
            return;
        }

        Entity entity = mc.world.getEntityById(state.id);
        if (!(entity instanceof AbstractClientPlayerEntity player)) {
            return;
        }
        if (player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
            return;
        }
        if (player != mc.player) {
            return;
        }
        if (mc.options.getPerspective().isFirstPerson()) {
            ci.cancel();
            return;
        }

        float delta = mc.getRenderTickCounter().getTickDelta(true);
        this.renderSmoothCape(matrixStack, vertexConsumerProvider, player, state, delta, light);
        ci.cancel();
    }

    @Unique
    private void renderSmoothCape(
            MatrixStack poseStack,
            VertexConsumerProvider multiBufferSource,
            AbstractClientPlayerEntity player,
            PlayerEntityRenderState state,
            float delta,
            int light
    ) {
        Identifier capeTextureId = Identifier.of("skycore", "textures/cape.png");
        VertexConsumer bufferBuilder = multiBufferSource.getBuffer(RenderLayer.getEntityCutout(capeTextureId));
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        Matrix4f oldPositionMatrix = null;
        for (int part = 0; part < PART_COUNT; part++) {
            this.modifyPoseStack(poseStack, player, delta, part);
            if (oldPositionMatrix == null) {
                oldPositionMatrix = new Matrix4f(poseStack.peek().getPositionMatrix());
            }

            if (part == 0) {
                addTopVertex(bufferBuilder, poseStack.peek().getPositionMatrix(), oldPositionMatrix,
                        0.3F, 0.0F, 0.0F,
                        -0.3F, 0.0F, -0.06F,
                        part, light);
            }
            if (part == 15) {
                addBottomVertex(bufferBuilder, poseStack.peek().getPositionMatrix(), poseStack.peek().getPositionMatrix(),
                        0.3F, (part + 1) * 0.06F, 0.0F,
                        -0.3F, (part + 1) * 0.06F, -0.06F,
                        part, light);
            }
            addLeftVertex(bufferBuilder, poseStack.peek().getPositionMatrix(), oldPositionMatrix,
                    -0.3F, (part + 1) * 0.06F, 0.0F,
                    -0.3F, part * 0.06F, -0.06F,
                    part, light);
            addRightVertex(bufferBuilder, poseStack.peek().getPositionMatrix(), oldPositionMatrix,
                    0.3F, (part + 1) * 0.06F, 0.0F,
                    0.3F, part * 0.06F, -0.06F,
                    part, light);
            addBackVertex(bufferBuilder, poseStack.peek().getPositionMatrix(), oldPositionMatrix,
                    0.3F, (part + 1) * 0.06F, -0.06F,
                    -0.3F, part * 0.06F, -0.06F,
                    part, light);
            addFrontVertex(bufferBuilder, oldPositionMatrix, poseStack.peek().getPositionMatrix(),
                    0.3F, (part + 1) * 0.06F, 0.0F,
                    -0.3F, part * 0.06F, 0.0F,
                    part, light);

            oldPositionMatrix = new Matrix4f(poseStack.peek().getPositionMatrix());
            poseStack.pop();
        }

        RenderSystem.disableBlend();
    }

    @Unique
    private void modifyPoseStack(MatrixStack poseStack, AbstractClientPlayerEntity player, float delta, int part) {
        if (CapeManager.config.capeMovement == CapeMovementMode.BASIC_SIMULATION) {
            this.modifyPoseStackSimulation(poseStack, player, delta, part);
            return;
        }

        this.modifyPoseStackVanilla(poseStack, player, delta, part);
    }

    @Unique
    private void modifyPoseStackSimulation(MatrixStack poseStack, AbstractClientPlayerEntity player, float delta, int part) {
        CapePhysicsSimulation simulation = ((CapeSimulationHolder) player).getSimulation();
        if (simulation == null || simulation.getPoints().isEmpty() || simulation.getPoints().size() <= part) {
            if (simulation != null && simulation.getPoints().isEmpty()) {
                simulation.init(PART_COUNT);
            }
            if (simulation == null || simulation.getPoints().isEmpty() || simulation.getPoints().size() <= part) {
                this.modifyPoseStackVanilla(poseStack, player, delta, part);
                return;
            }
        }

        poseStack.push();
        double zOffset = player.getEquippedStack(EquipmentSlot.CHEST).isEmpty() ? 0.125D : 0.15D;
        poseStack.translate(0.0D, 0.0D, zOffset);

        CapePhysicsSimulation.Point capePoint = simulation.getPoints().get(0);
        float x = simulation.getPoints().get(part).getLerpX(delta) - capePoint.getLerpX(delta);
        if (x > 0.0F) {
            x = 0.0F;
        }
        float y = capePoint.getLerpY(delta) - part - simulation.getPoints().get(part).getLerpY(delta);
        float z = capePoint.getLerpZ(delta) - simulation.getPoints().get(part).getLerpZ(delta);
        float partRotation = this.getRotation(delta, part, simulation);

        float height = 0.0F;
        if (player.isSneaking()) {
            height += 25.0F;
            poseStack.translate(0.0D, 0.15000000596046448D, 0.0D);
        }

        float naturalWindSwing = this.getNatrualWindSwing(part, player.isSubmergedInWater());
        poseStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(6.0F + height + naturalWindSwing));
        poseStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(0.0F));
        poseStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F));

        poseStack.translate(-z / 16.0F, y / 16.0F, x / 16.0F);
        poseStack.translate(0.0D, 0.03D, -0.03D);
        poseStack.translate(0.0D, part * 1.0F / 16.0F, 0.0D);
        poseStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-partRotation));
        poseStack.translate(0.0D, -part * 1.0F / 16.0F, 0.0D);
        poseStack.translate(0.0D, -0.03D, 0.03D);
    }

    @Unique
    private float getRotation(float delta, int part, CapePhysicsSimulation simulation) {
        if (simulation == null || simulation.points == null || simulation.points.isEmpty()) {
            return 0.0F;
        }
        if (part == 15) {
            return this.getRotation(delta, part - 1, simulation);
        }
        if (part < 0 || part + 1 >= simulation.points.size()) {
            return 0.0F;
        }

        return (float) this.getAngle(
                simulation.points.get(part).getLerpedPos(delta),
                simulation.points.get(part + 1).getLerpedPos(delta)
        );
    }

    @Unique
    private double getAngle(MutableXYZ from, MutableXYZ to) {
        MutableXYZ angle = to.clone().subtract(from);
        return Math.toDegrees(Math.atan2(angle.x, angle.y)) + 180.0D;
    }

    @Unique
    private void modifyPoseStackVanilla(MatrixStack poseStack, AbstractClientPlayerEntity player, float delta, int part) {
        poseStack.push();
        poseStack.translate(0.0D, 0.0D, 0.125D);

        double deltaX = MathHelper.lerp(delta, player.prevCapeX, player.capeX)
                - MathHelper.lerp(delta, player.prevX, player.getX());
        double deltaY = MathHelper.lerp(delta, player.prevCapeY, player.capeY)
                - MathHelper.lerp(delta, player.prevY, player.getY());
        double deltaZ = MathHelper.lerp(delta, player.prevCapeZ, player.capeZ)
                - MathHelper.lerp(delta, player.prevZ, player.getZ());

        float bodyYaw = MathHelper.lerpAngleDegrees(delta, player.prevBodyYaw, player.bodyYaw);
        double yawSin = MathHelper.sin(bodyYaw * 0.017453292F);
        double yawCos = -MathHelper.cos(bodyYaw * 0.017453292F);

        float height = (float) deltaY * 10.0F;
        height = MathHelper.clamp(height, -6.0F, 32.0F);

        float swing = (float) (deltaX * yawSin + deltaZ * yawCos) * easeOutSine(0.0625F * part) * 100.0F;
        swing = MathHelper.clamp(swing, 0.0F, 150.0F * easeOutSine(0.0625F * part));

        float sidewaysRotationOffset = (float) (deltaX * yawCos - deltaZ * yawSin) * 100.0F;
        sidewaysRotationOffset = MathHelper.clamp(sidewaysRotationOffset, -20.0F, 20.0F);

        double horizontalSpeed = player.getVelocity().horizontalLength();
        float walkAnimation = (float) Math.min(horizontalSpeed * 4.0D, 1.0D);
        height += MathHelper.sin((float) (System.currentTimeMillis() / 100.0D) * 6.0F) * 32.0F * walkAnimation;

        if (player.isSneaking()) {
            height += 25.0F;
            poseStack.translate(0.0D, 0.15000000596046448D, 0.0D);
        }

        float naturalWindSwing = this.getNatrualWindSwing(part, player.isSubmergedInWater());
        poseStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(6.0F + swing / 2.0F + height + naturalWindSwing));
        poseStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sidewaysRotationOffset / 2.0F));
        poseStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F - sidewaysRotationOffset / 2.0F));
    }

    @Unique
    private float getNatrualWindSwing(int part, boolean underwater) {
        long highlightedPart = System.currentTimeMillis() / (underwater ? 9 : 3) % 360L;
        float relativePart = (part + 1) / 16.0F;
        if (CapeManager.config.windMode == CapeWindMode.WAVES) {
            return (float) (Math.sin(Math.toRadians(relativePart * 360.0F - highlightedPart)) * 3.0D);
        }

        return 0.0F;
    }

    @Unique
    private static void addBackVertex(
            VertexConsumer bufferBuilder,
            Matrix4f matrix,
            Matrix4f oldMatrix,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            int part,
            int light
    ) {
        if (x1 < x2) {
            float temp = x1;
            x1 = x2;
            x2 = temp;
        }
        if (y1 < y2) {
            float temp = y1;
            y1 = y2;
            y2 = temp;
            Matrix4f tempMatrix = matrix;
            matrix = oldMatrix;
            oldMatrix = tempMatrix;
        }

        float minV = 0.03125F;
        float maxV = 0.53125F;
        float deltaV = maxV - minV;
        float vPerPart = deltaV / 16.0F;
        maxV = minV + vPerPart * (part + 1);
        minV = minV + vPerPart * part;

        bufferBuilder.vertex(oldMatrix, x1, y2, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.171875F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(oldMatrix, x2, y2, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.015625F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(matrix, x2, y1, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.015625F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(matrix, x1, y1, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.171875F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
    }

    @Unique
    private static void addFrontVertex(
            VertexConsumer bufferBuilder,
            Matrix4f matrix,
            Matrix4f oldMatrix,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            int part,
            int light
    ) {
        if (x1 < x2) {
            float temp = x1;
            x1 = x2;
            x2 = temp;
        }
        if (y1 < y2) {
            float temp = y1;
            y1 = y2;
            y2 = temp;
            Matrix4f tempMatrix = matrix;
            matrix = oldMatrix;
            oldMatrix = tempMatrix;
        }

        float minV = 0.03125F;
        float maxV = 0.53125F;
        float deltaV = maxV - minV;
        float vPerPart = deltaV / 16.0F;
        maxV = minV + vPerPart * (part + 1);
        minV = minV + vPerPart * part;

        bufferBuilder.vertex(oldMatrix, x1, y1, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.34375F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(oldMatrix, x2, y1, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.1875F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(matrix, x2, y2, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.1875F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(matrix, x1, y2, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.34375F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
    }

    @Unique
    private static void addLeftVertex(
            VertexConsumer bufferBuilder,
            Matrix4f matrix,
            Matrix4f oldMatrix,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            int part,
            int light
    ) {
        if (x1 < x2) {
            float temp = x1;
            x1 = x2;
            x2 = temp;
        }
        if (y1 < y2) {
            float temp = y1;
            y1 = y2;
            y2 = temp;
        }

        float minU = 0.0F;
        float minV = 0.03125F;
        float maxV = 0.53125F;
        float deltaV = maxV - minV;
        float vPerPart = deltaV / 16.0F;
        maxV = minV + vPerPart * (part + 1);
        minV = minV + vPerPart * part;

        bufferBuilder.vertex(matrix, x2, y1, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.015625F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(matrix, x2, y1, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(minU, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(oldMatrix, x2, y2, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(minU, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(oldMatrix, x2, y2, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.015625F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
    }

    @Unique
    private static void addRightVertex(
            VertexConsumer bufferBuilder,
            Matrix4f matrix,
            Matrix4f oldMatrix,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            int part,
            int light
    ) {
        if (x1 < x2) {
            float temp = x1;
            x1 = x2;
            x2 = temp;
        }
        if (y1 < y2) {
            float temp = y1;
            y1 = y2;
            y2 = temp;
        }

        float minV = 0.03125F;
        float maxV = 0.53125F;
        float deltaV = maxV - minV;
        float vPerPart = deltaV / 16.0F;
        maxV = minV + vPerPart * (part + 1);
        minV = minV + vPerPart * part;

        bufferBuilder.vertex(matrix, x2, y1, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.171875F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(matrix, x2, y1, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.1875F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(oldMatrix, x2, y2, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.1875F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(oldMatrix, x2, y2, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.171875F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
    }

    @Unique
    private static void addBottomVertex(
            VertexConsumer bufferBuilder,
            Matrix4f matrix,
            Matrix4f oldMatrix,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            int part,
            int light
    ) {
        if (x1 < x2) {
            float temp = x1;
            x1 = x2;
            x2 = temp;
        }
        if (y1 < y2) {
            float temp = y1;
            y1 = y2;
            y2 = temp;
        }

        float minV = 0.0F;
        float deltaV = 0.03125F - minV;
        float vPerPart = deltaV / 16.0F;
        float maxV = minV + vPerPart * (part + 1);
        minV = minV + vPerPart * part;

        bufferBuilder.vertex(oldMatrix, x1, y2, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.328125F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(oldMatrix, x2, y2, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.171875F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(matrix, x2, y1, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.171875F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
        bufferBuilder.vertex(matrix, x1, y1, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.328125F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(1.0F, 0.0F, 0.0F);
    }

    @Unique
    private static void addTopVertex(
            VertexConsumer bufferBuilder,
            Matrix4f matrix,
            Matrix4f oldMatrix,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            int part,
            int light
    ) {
        if (x1 < x2) {
            float temp = x1;
            x1 = x2;
            x2 = temp;
        }
        if (y1 < y2) {
            float temp = y1;
            y1 = y2;
            y2 = temp;
        }

        float minV = 0.0F;
        float deltaV = 0.03125F - minV;
        float vPerPart = deltaV / 16.0F;
        float maxV = minV + vPerPart * (part + 1);
        minV = minV + vPerPart * part;

        bufferBuilder.vertex(oldMatrix, x1, y2, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.171875F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(0.0F, 1.0F, 0.0F);
        bufferBuilder.vertex(oldMatrix, x2, y2, z1).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.015625F, maxV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(0.0F, 1.0F, 0.0F);
        bufferBuilder.vertex(matrix, x2, y1, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.015625F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(0.0F, 1.0F, 0.0F);
        bufferBuilder.vertex(matrix, x1, y1, z2).color(1.0F, 1.0F, 1.0F, 1.0F).texture(0.171875F, minV)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(0.0F, 1.0F, 0.0F);
    }

    @Unique
    private static float easeOutSine(float x) {
        return (float) Math.sin(x * Math.PI / 2.0D);
    }
}
