package sky.mixin.render;

import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(Camera.class)
public interface CameraAccessor {
    @Invoker("setRotation")
    void setCustomRotation(float yaw, float pitch);

    @Invoker("setPos")
    void invokeSetPos(double x, double y, double z);

    @Invoker("clipToSpace")
    float setClipToSpace(float desiredCameraDistance);
}
