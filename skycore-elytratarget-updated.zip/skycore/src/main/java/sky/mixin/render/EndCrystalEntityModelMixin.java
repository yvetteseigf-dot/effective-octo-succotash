package sky.mixin.render;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.EndCrystalEntityModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(EndCrystalEntityModel.class)
public interface EndCrystalEntityModelMixin {
    @Accessor("cube")
    ModelPart skycore$getCube();
}
