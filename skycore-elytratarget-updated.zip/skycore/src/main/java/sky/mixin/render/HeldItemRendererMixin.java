package sky.mixin.render;

import com.darkmagician6.eventapi.EventManager;
import com.google.common.base.MoreObjects;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.misc.HeldItemVisualSpoof;
import sky.event.render.EquipOffsetEvent;
import sky.module.visuals.Hands;
import sky.module.visuals.HoldMyItems;
import sky.module.visuals.SwingAnimation;
import sky.module.visuals.ViewModel;
import sky.render.hand.CustomHandRenderer;

@Mixin(value = HeldItemRenderer.class, priority = 900)
public abstract class HeldItemRendererMixin {
    private static final boolean HOLD_MY_ITEMS = FabricLoader.getInstance().isModLoaded("hold-my-items");

    @Shadow
    private ItemStack mainHand;

    @Shadow
    private ItemStack offHand;

    @Shadow
    private float equipProgressMainHand;

    @Shadow
    private float prevEquipProgressMainHand;

    @Shadow
    private float equipProgressOffHand;

    @Shadow
    private float prevEquipProgressOffHand;

    @Shadow
    protected abstract void applyEquipOffset(MatrixStack matrices, Arm arm, float equipProgress);

    @Shadow
    protected abstract void swingArm(float swingProgress, float equipProgress, MatrixStack matrices, int armX, Arm arm);

    @Shadow
    protected abstract void renderFirstPersonItem(
            AbstractClientPlayerEntity player,
            float tickDelta,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack item,
            float equipProgress,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light
    );

    /**
     * @author Sky
     * @reason Wraps first-person rendering for hand shaders and visual item spoofing.
     */
    @Overwrite
    public void renderItem(
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider.Immediate vertexConsumers,
            ClientPlayerEntity player,
            int light
    ) {
        if (HOLD_MY_ITEMS) {
            float f = player.getHandSwingProgress(tickDelta);
            Hand hand = MoreObjects.firstNonNull(player.preferredHand, Hand.MAIN_HAND);
            float g = player.getLerpedPitch(tickDelta);
            HeldItemRenderer.HandRenderType handRenderType = HeldItemRenderer.getHandRenderType(player);

            if (handRenderType.renderMainHand) {
                float j = hand == Hand.MAIN_HAND ? f : 0.0F;
                float k = 1.0F - MathHelper.lerp(tickDelta, this.prevEquipProgressMainHand, this.equipProgressMainHand);
                this.renderFirstPersonItem(player, tickDelta, g, Hand.MAIN_HAND, j, resolveVisualMainHand(this.mainHand), k, matrices, vertexConsumers, light);
            }

            if (handRenderType.renderOffHand) {
                float j = hand == Hand.OFF_HAND ? f : 0.0F;
                float k = 1.0F - MathHelper.lerp(tickDelta, this.prevEquipProgressOffHand, this.equipProgressOffHand);
                this.renderFirstPersonItem(player, tickDelta, g, Hand.OFF_HAND, j, this.offHand, k, matrices, vertexConsumers, light);
            }

            vertexConsumers.draw();
            return;
        }

        float swing = player.getHandSwingProgress(tickDelta);
        Hand preferredHand = MoreObjects.firstNonNull(player.preferredHand, Hand.MAIN_HAND);
        float pitch = player.getLerpedPitch(tickDelta);
        HeldItemRenderer.HandRenderType type = HeldItemRenderer.getHandRenderType(player);

        if (type.renderMainHand) {
            float handSwing = preferredHand == Hand.MAIN_HAND ? swing : 0.0F;
            float equipProgress = 1.0F - MathHelper.lerp(tickDelta, this.prevEquipProgressMainHand, this.equipProgressMainHand);
            this.renderFirstPersonItem(player, tickDelta, pitch, Hand.MAIN_HAND, handSwing, resolveVisualMainHand(this.mainHand), equipProgress, matrices, vertexConsumers, light);
        }

        if (type.renderOffHand) {
            float handSwing = preferredHand == Hand.OFF_HAND ? swing : 0.0F;
            float equipProgress = 1.0F - MathHelper.lerp(tickDelta, this.prevEquipProgressOffHand, this.equipProgressOffHand);
            this.renderFirstPersonItem(player, tickDelta, pitch, Hand.OFF_HAND, handSwing, this.offHand, equipProgress, matrices, vertexConsumers, light);
        }

        vertexConsumers.draw();
    }

    private static ItemStack resolveVisualMainHand(ItemStack stack) {
        return HeldItemVisualSpoof.getVisualStack(stack);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), cancellable = true)
    private void skycore$render3DFirstPerson(
            AbstractClientPlayerEntity player,
            float tickDelta,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack item,
            float equipProgress,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        if (HOLD_MY_ITEMS) {
            return;
        }

        if (CustomHandRenderer.tryRender(
                (HeldItemRenderer) (Object) this,
                player,
                tickDelta,
                pitch,
                hand,
                swingProgress,
                item,
                equipProgress,
                matrices,
                vertexConsumers,
                light
        )) {
            ci.cancel();
        }
    }

    @Inject(
            method = "renderFirstPersonItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/util/math/MatrixStack;push()V",
                    shift = At.Shift.AFTER,
                    ordinal = 0
            )
    )
    private void skycore$injectAfterMatrixPushHandPosition(
            AbstractClientPlayerEntity player,
            float tickDelta,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack item,
            float equipProgress,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        if (HOLD_MY_ITEMS) {
            return;
        }

        Arm arm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        if (item.isEmpty() || item.contains(DataComponentTypes.MAP_ID)) {
            return;
        }

        SwingAnimation swingAnimation = SwingAnimation.INSTANCE;
        if (swingAnimation.hasCustomViewModel()) {
            swingAnimation.applyViewModel(matrices, arm);
        } else {
            ViewModel.INSTANCE.applyHandPosition(matrices, arm);
        }
    }

    @Redirect(
            method = "renderFirstPersonItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/HeldItemRenderer;swingArm(FFLnet/minecraft/client/util/math/MatrixStack;ILnet/minecraft/util/Arm;)V",
                    ordinal = 2
            )
    )
    private void skycore$redirectSwingArmForCustomAnim(
            HeldItemRenderer instance,
            float swingProgress,
            float equipProgress,
            MatrixStack matrices,
            int armX,
            Arm arm
    ) {
        if (HOLD_MY_ITEMS) {
            this.swingArm(swingProgress, equipProgress, matrices, armX, arm);
            return;
        }

        SwingAnimation swingAnimation = SwingAnimation.INSTANCE;
        HoldMyItems holdMyItems = HoldMyItems.INSTANCE;
        if (swingAnimation.shouldReplaceSwingArm(arm)) {
            skycore$applyVanillaSwingArmBase(swingProgress, equipProgress, matrices, armX, arm);
            swingAnimation.renderSwordAnimation(matrices, swingProgress, equipProgress, arm);
            return;
        }

        this.swingArm(swingProgress, equipProgress, matrices, armX, arm);
        if (holdMyItems.isEnabled() && !swingAnimation.isHandlingSwing(arm)) {
            holdMyItems.applyFirstPerson(matrices, swingProgress);
        }
    }

    @Unique
    private void skycore$applyVanillaSwingArmBase(
            float swingProgress, float equipProgress, MatrixStack matrices, int armX, Arm arm) {
        float sqrt = MathHelper.sqrt(swingProgress);
        matrices.translate(
                armX * (-0.4F * MathHelper.sin(sqrt * (float) Math.PI)),
                0.2F * MathHelper.sin(sqrt * ((float) Math.PI * 2.0F)),
                -0.2F * MathHelper.sin(swingProgress * (float) Math.PI));
        this.applyEquipOffset(matrices, arm, equipProgress);
    }

    @Inject(method = "applyEquipOffset", at = @At("HEAD"), cancellable = true)
    private void skycore$modifyEquipOffset(MatrixStack matrices, Arm arm, float equipProgress, CallbackInfo ci) {
        EquipOffsetEvent event = new EquipOffsetEvent(arm, equipProgress);
        EventManager.call(event);
        if (event.getEquippedProg() != equipProgress) {
            applyVanillaEquipOffset(matrices, arm, event.getEquippedProg());
            ci.cancel();
        }
    }

    @Unique
    private static void applyVanillaEquipOffset(MatrixStack matrices, Arm arm, float equipProgress) {
        int side = arm == Arm.RIGHT ? 1 : -1;
        matrices.translate(side * 0.56F, -0.52F + equipProgress * -0.6F, -0.72F);
    }
}
