package sky.mixin.render;

import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.access.MinecraftAccess;
import sky.model.CustomModelRenderer;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin implements MinecraftAccess {
    @Inject(
            method = "getTexture(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)Lnet/minecraft/util/Identifier;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$customModelTexture(PlayerEntityRenderState state, CallbackInfoReturnable<Identifier> cir) {
        if (mc.world == null) {
            return;
        }

        Entity entity = mc.world.getEntityById(state.id);
        if (entity instanceof LivingEntity living && CustomModelRenderer.shouldApply(living)) {
            Identifier texture = CustomModelRenderer.getTextureIdentifier();
            if (texture != null) {
                cir.setReturnValue(texture);
            }
        }
    }
}
