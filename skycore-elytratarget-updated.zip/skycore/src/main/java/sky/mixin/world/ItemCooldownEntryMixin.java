package sky.mixin.world;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(targets = "net/minecraft/entity/player/ItemCooldownManager$Entry")
public interface ItemCooldownEntryMixin {
    @Invoker("endTick")
    int skycore$endTick();

    @Invoker("startTick")
    int skycore$startTick();
}
