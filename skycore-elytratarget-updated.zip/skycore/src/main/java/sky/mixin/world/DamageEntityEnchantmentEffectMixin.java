package sky.mixin.world;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.enchantment.EnchantmentEffectContext;
import net.minecraft.enchantment.effect.entity.DamageEntityEnchantmentEffect;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.event.combat.ThornsDamageEvent;

@Mixin(DamageEntityEnchantmentEffect.class)
public abstract class DamageEntityEnchantmentEffectMixin {
    @Inject(method = "apply", at = @At("HEAD"), cancellable = true)
    private void skycore$onUserHurt(
            ServerWorld world,
            int level,
            EnchantmentEffectContext context,
            Entity user,
            Vec3d pos,
            CallbackInfo ci
    ) {
        DamageEntityEnchantmentEffect effect = (DamageEntityEnchantmentEffect) (Object) this;
        if (!effect.damageType().matchesKey(DamageTypes.THORNS) || user == null) {
            return;
        }

        LivingEntity thornsUser = context.owner();
        ThornsDamageEvent event = new ThornsDamageEvent(user, thornsUser, level, 0.0F);
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }
}
