package sky.mixin.client;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.PlayerInput;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.event.input.InputTickEvent;
import sky.event.input.StrafeInputEvent;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {
    @Shadow
    @Final
    private GameOptions settings;

    @Unique
    private float abobaGetMovementMultiplier(boolean positive, boolean negative) {
        if (positive == negative) {
            return 0.0F;
        }
        return positive ? 1.0F : -1.0F;
    }

    @Inject(
            method = "tick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/input/KeyboardInput;playerInput:Lnet/minecraft/util/PlayerInput;",
                    ordinal = 0,
                    shift = At.Shift.AFTER
            ),
            cancellable = true
    )
    public void injectInputEvent(CallbackInfo ci) {
        float forward = abobaGetMovementMultiplier(
                this.playerInput.forward(),
                this.playerInput.backward()
        );
        float strafe = abobaGetMovementMultiplier(
                this.playerInput.left(),
                this.playerInput.right()
        );

        InputTickEvent inputEvent = new InputTickEvent(
                forward,
                strafe,
                this.playerInput.forward(),
                this.playerInput.backward(),
                this.playerInput.left(),
                this.playerInput.right(),
                this.playerInput.jump(),
                this.playerInput.sneak(),
                0.3D
        );
        EventManager.call(inputEvent);

        forward = inputEvent.getForward();
        strafe = inputEvent.getStrafe();
        boolean jump = inputEvent.isJump();
        boolean sneak = inputEvent.isSneak();

        PlayerInput originalInput = this.playerInput;
        StrafeInputEvent event = new StrafeInputEvent(originalInput, forward, strafe);
        EventManager.call(event);

        this.movementForward = event.getForward();
        this.movementSideways = event.getStrafe();
        if (sneak) {
            float sneakSlow = (float) inputEvent.getSneakSlowDownMultiplier();
            this.movementForward *= sneakSlow;
            this.movementSideways *= sneakSlow;
        }

        PlayerInput modifiedInput = event.getInput();
        if (modifiedInput != null && modifiedInput != originalInput) {
            this.playerInput = modifiedInput;
        } else {
            this.playerInput = new PlayerInput(
                    this.movementForward > 0.0F,
                    this.movementForward < 0.0F,
                    this.movementSideways > 0.0F,
                    this.movementSideways < 0.0F,
                    jump,
                    sneak,
                    this.settings.sprintKey.isPressed()
            );
        }

        ci.cancel();
    }
}
