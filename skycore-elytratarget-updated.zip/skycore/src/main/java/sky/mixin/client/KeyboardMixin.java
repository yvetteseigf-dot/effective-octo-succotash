package sky.mixin.client;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.config.BindCapture;
import sky.hud.HudManager;
import sky.event.input.KeyHoldEvent;
import sky.event.input.KeyInputEvent;
import sky.event.input.ScreenKeyEvent;

@Mixin(Keyboard.class)
public class KeyboardMixin {
    @Inject(method = "onKey", at = @At("HEAD"), cancellable = true)
    private void skycore$onKey(
            long window,
            int key,
            int scancode,
            int action,
            int modifiers,
            CallbackInfo ci
    ) {
        if (window != MinecraftClient.getInstance().getWindow().getHandle()) {
            return;
        }

        if (BindCapture.hasActive() && action == 1 && key != -1) {
            BindCapture.applyKey(key == 256 ? -1 : key);
            ci.cancel();
            return;
        }

        if (action == 1 && HudManager.getInstance().watermark.handleKeyPressed(key)) {
            ci.cancel();
            return;
        }
        if (action == 2 && HudManager.getInstance().watermark.handleKeyPressed(key)) {
            ci.cancel();
            return;
        }
        if (action == 0 && HudManager.getInstance().watermark.handleKeyReleased(key)) {
            ci.cancel();
            return;
        }

        if (action == 1) {
            EventManager.call(new KeyInputEvent(key, true));
            EventManager.call(new ScreenKeyEvent(key, true));
            EventManager.call(new KeyHoldEvent(key));
        } else if (action == 0) {
            EventManager.call(new KeyInputEvent(key, false));
            EventManager.call(new ScreenKeyEvent(key, false));
        }
    }

    @Inject(method = "onChar", at = @At("HEAD"), cancellable = true)
    private void skycore$onChar(long window, int codePoint, int modifiers, CallbackInfo ci) {
        if (window != MinecraftClient.getInstance().getWindow().getHandle()) {
            return;
        }

        if (Character.isBmpCodePoint(codePoint)
                && HudManager.getInstance().watermark.handleCharTyped((char) codePoint)) {
            ci.cancel();
        }
    }
}
