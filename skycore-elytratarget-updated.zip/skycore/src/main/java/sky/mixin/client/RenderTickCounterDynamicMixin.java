package sky.mixin.client;

import com.darkmagician6.eventapi.EventManager;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.scheduler.TickRateLimiter;
import sky.scheduler.TimerSpeedController;
import sky.event.render.BeginRenderTickEvent;

@Mixin(RenderTickCounter.Dynamic.class)
public abstract class RenderTickCounterDynamicMixin {
    private static final int RATE_LIMITER_MAX_TICKS = 10;

    @Shadow
    private float lastFrameDuration;

    @Inject(method = "beginRenderTick(J)I", at = @At("HEAD"), cancellable = true)
    private void skycore$eventTimer(long timeMillis, CallbackInfoReturnable<Integer> cir) {
        BeginRenderTickEvent event = new BeginRenderTickEvent(timeMillis);
        EventManager.call(event);
        if (event.isCancelled()) {
            cir.setReturnValue(0);
            cir.cancel();
        }
    }

    @Inject(
            method = "beginRenderTick(J)I",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/render/RenderTickCounter$Dynamic;lastFrameDuration:F",
                    opcode = 181,
                    shift = At.Shift.AFTER
            )
    )
    private void skycore$scaleLastFrameDuration(long timeMillis, CallbackInfoReturnable<Integer> cir) {
        float speed = TimerSpeedController.getSpeed();
        if (Math.abs(speed - 1.0F) >= 0.001F) {
            lastFrameDuration *= speed;
        }
    }

    @ModifyReturnValue(method = "beginRenderTick(J)I", at = @At("RETURN"))
    private int skycore$capRateLimiterTicks(int tickCount) {
        if (!TickRateLimiter.isActive()) {
            return tickCount;
        }
        return Math.min(RATE_LIMITER_MAX_TICKS, tickCount);
    }
}
