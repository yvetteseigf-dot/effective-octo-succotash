package sky.ui.animation;

import sky.util.animation.TweenFloat;

/**
 * Slides the hotbar selection highlight between slots instead of snapping it.
 */
public final class HotbarSelectAnimation {
    private static final int UNSET = -1;
    private static final int SLOT_W = 20;
    private static final int LEFT = 91;
    private static final int TEX_OFF = 1;

    private final TweenFloat x = new TweenFloat(0.0f);
    private int selectedSlot = UNSET;
    private boolean ready;

    public void update(int slot, int centerX, long durationMs) {
        float target = centerX - LEFT - TEX_OFF + slot * SLOT_W;
        x.setDuration(durationMs);

        if (!ready || selectedSlot == UNSET) {
            selectedSlot = slot;
            x.snap(target);
            ready = true;
            return;
        }

        if (slot != selectedSlot) {
            selectedSlot = slot;
            x.animateTo(target);
        } else if (Math.abs(x.getTarget() - target) > 0.5f) {
            x.animateTo(target);
        }

        x.update();
    }

    public void reset() {
        selectedSlot = UNSET;
        ready = false;
        x.snap(0.0f);
    }

    public boolean isReady() {
        return ready;
    }

    public float getX() {
        return x.get();
    }
}
