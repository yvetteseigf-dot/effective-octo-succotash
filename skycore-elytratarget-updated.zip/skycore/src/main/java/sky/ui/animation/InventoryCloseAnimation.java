package sky.ui.animation;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import sky.module.visuals.Animations;
import sky.util.animation.TweenFloat;

/**
 * Defers closing a container screen until its fade-out has played.
 * <p>
 * The screen swap is applied at the end of the frame so the outgoing screen can still be
 * rendered while the animation runs.
 */
public final class InventoryCloseAnimation {

    private static final TweenFloat progress = new TweenFloat(1.0F);

    private static HandledScreen<?> closing;
    private static Screen pending;
    private static boolean finishPending;
    private static boolean bypass;

    private InventoryCloseAnimation() {
    }

    /**
     * Starts the close animation for a screen swap.
     *
     * @return {@code true} when the caller must suppress the swap because the animation owns it
     */
    public static boolean tryBeginClose(Screen current, Screen next) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            cancel();
            return false;
        }

        if (bypass || !Animations.effect(Animations.INV_CLOSE)) {
            return false;
        }

        if (next != null) {
            cancel();
            return false;
        }

        if (!(current instanceof HandledScreen<?> handled)) {
            return false;
        }

        if (closing != null) {
            pending = next;
            return true;
        }

        closing = handled;
        pending = next;
        finishPending = false;
        progress.setDuration(220L);
        progress.snap(1.0F);
        progress.animateTo(0.0F);
        return true;
    }

    public static boolean isClosing(Screen screen) {
        return closing != null && closing == screen;
    }

    public static boolean shouldHideContent() {
        return closing != null && (finishPending || progress.get() <= 0.02F);
    }

    public static float getProgress() {
        if (finishPending) {
            return 0.0F;
        }
        return Math.max(0.0F, progress.get());
    }

    public static void tick() {
        if (closing == null || finishPending) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            cancel();
            return;
        }

        progress.update();
        if (progress.isDone() && progress.get() <= 0.02F) {
            finishPending = true;
        }
    }

    public static void endFrame() {
        if (!finishPending) {
            return;
        }

        finishPending = false;
        finish();
    }

    public static void cancel() {
        closing = null;
        pending = null;
        finishPending = false;
        progress.snap(1.0F);
    }

    private static void finish() {
        Screen next = pending;
        closing = null;
        pending = null;
        bypass = true;
        MinecraftClient.getInstance().setScreen(next);
        bypass = false;
    }
}
