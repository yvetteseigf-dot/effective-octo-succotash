package sky.macro;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import sky.config.AbstractConfigFile;
import sky.config.ClientPaths;

/** Persisted keyboard macros. */
public final class MacrosFile extends AbstractConfigFile<List<MacrosFile.MacroEntry>> {
    public MacrosFile() {
        super(ClientPaths.MACROS_FILE_REL);
    }

    public void removeMacro(String name) {
        if (name == null) {
            return;
        }
        if (data.removeIf(macro -> macro.getName().equalsIgnoreCase(name.trim()))) {
            save();
        }
    }

    public void addMacro(String name, int keyCode, String command) {
        if (name == null || command == null) {
            return;
        }
        removeMacro(name);
        data.add(new MacroEntry(name.trim(), keyCode, command));
        save();
    }

    public void clear() {
        if (!data.isEmpty()) {
            data.clear();
            save();
        }
    }

    @Override
    protected void initializeData() {
        data = new ArrayList<>();
    }

    @Override
    protected void deserializeData(JsonObject object) {
        data.clear();
        if (!object.has("macros")) {
            return;
        }
        JsonArray macros = object.getAsJsonArray("macros");
        if (macros == null) {
            return;
        }
        for (JsonElement element : macros) {
            if (!element.isJsonObject()) {
                continue;
            }
            JsonObject value = element.getAsJsonObject();
            loadProperty(value, "name", name -> loadProperty(value, "key", key ->
                    loadProperty(value, "cmd", command -> data.add(new MacroEntry(
                            name.getAsString(),
                            key.getAsInt(),
                            command.getAsString()
                    )))
            ));
        }
    }

    private void loadProperty(JsonObject object, String property, Consumer<JsonElement> consumer) {
        JsonElement element = object.get(property);
        if (element != null && !element.isJsonNull()) {
            consumer.accept(element);
        }
    }

    @Override
    protected void handleLoadError(Exception exception) {
        if (data == null) {
            initializeData();
        }
    }

    @Override
    protected JsonObject serializeData() {
        JsonObject object = new JsonObject();
        JsonArray macros = new JsonArray();
        for (MacroEntry macro : data) {
            JsonObject value = new JsonObject();
            value.addProperty("name", macro.getName());
            value.addProperty("key", macro.getKeyCode());
            value.addProperty("cmd", macro.getCommand());
            macros.add(value);
        }
        object.add("macros", macros);
        return object;
    }

    public List<MacroEntry> getMacros() {
        return new ArrayList<>(data);
    }

    public static final class MacroEntry {
        private final String command;
        private final String name;
        private final int keyCode;

        public MacroEntry(String name, int keyCode, String command) {
            this.name = name;
            this.keyCode = keyCode;
            this.command = command;
        }

        public int getKeyCode() {
            return keyCode;
        }

        public String getName() {
            return name;
        }

        public String getCommand() {
            return command;
        }
    }
}
