package sky.macro;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.util.PlayerInput;
import sky.SkyInit;
import sky.event.player.PlayerUpdateEvent;
import sky.event.input.StrafeInputEvent;
import sky.event.input.KeyInputEvent;
import sky.module.movement.Sprint;
import sky.access.MinecraftAccess;
import sky.command.ConfigCommand;
import sky.misc.MovementBlocker;

/**
 * Runs the commands bound to a macro key. The queued commands are held back for one tick so that
 * the sprint state can be cleared server-side first, which stops the anti-cheat from seeing a
 * command sent mid-sprint.
 */
public final class MacroExecutor implements MinecraftAccess {
    private final List<String> pendingCommands = new ArrayList<>();
    private boolean needSprintReset;
    private boolean sprintResetDone;
    private int sprintResetTicks;

    @EventTarget
    public void onKey(KeyInputEvent event) {
        if (!event.isHold() || mc.player == null || mc.world == null) {
            return;
        }
        if (mc.currentScreen instanceof ChatScreen) {
            return;
        }
        if (mc.currentScreen != null) {
            return;
        }

        queueMacro(event.getKey());
    }

    @EventTarget
    public void onMoveInput(StrafeInputEvent event) {
        if (!needSprintReset) {
            return;
        }

        event.setForward(0.0F);
        event.setStrafe(0.0F);
        MovementBlocker.stopTicks = Math.max(MovementBlocker.stopTicks, 1);
        stopSprint();
        needSprintReset = false;
        sprintResetDone = true;
        sprintResetTicks = 0;
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (pendingCommands.isEmpty()) {
            return;
        }
        if (sprintResetDone) {
            sprintResetTicks++;
        }
        if (needSprintReset) {
            return;
        }
        if (sprintResetDone && sprintResetTicks < 1) {
            return;
        }

        runPendingCommands();
    }

    private void queueMacro(int key) {
        List<String> matched = new ArrayList<>();
        for (MacrosFile.MacroEntry entry : SkyInit.getInstance().getMacroManager().getMacros()) {
            if (entry.getKeyCode() != key) {
                continue;
            }
            String command = entry.getCommand();
            if (command == null || command.isEmpty()) {
                continue;
            }
            matched.add(command);
        }
        if (matched.isEmpty()) {
            return;
        }

        pendingCommands.addAll(matched);
        needSprintReset = true;
        sprintResetDone = false;
        sprintResetTicks = 0;
    }

    private void stopSprint() {
        if (mc.player == null || mc.getNetworkHandler() == null) {
            return;
        }

        mc.getNetworkHandler().sendPacket(
                new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
        mc.player.setSprinting(false);
        mc.getNetworkHandler().sendPacket(
                new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        if (!Sprint.INSTANCE.isEnabled()) {
            mc.options.sprintKey.setPressed(false);
        }
    }

    private void runPendingCommands() {
        String prefix = SkyInit.getInstance().getCommandManager().getPrefix();
        for (String command : pendingCommands) {
            if (command.startsWith(prefix) && ConfigCommand.handle(command)) {
                continue;
            }
            mc.player.networkHandler.sendChatMessage(command);
        }

        pendingCommands.clear();
        sprintResetDone = false;
        sprintResetTicks = 0;
    }
}
