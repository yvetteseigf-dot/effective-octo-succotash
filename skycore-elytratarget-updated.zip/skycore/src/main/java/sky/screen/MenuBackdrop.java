package sky.screen;

import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import sky.theme.GuiTheme;
import sky.render.DrawHelper;
import sky.render.shader.ManagedShader;
import sky.render.shader.ShaderLibrary;
import sky.util.render.BlendStateUtil;
import sky.util.render.ColorUtil;

/** Shared main-menu background used by the title screen and Alt Manager. */
final class MenuBackdrop {
    /** Set to false to go back to the original animated shader background. */
    private static final boolean USE_IMAGE_BACKGROUND = true;
    private static final Identifier IMAGE = Identifier.of("skycore", "mainmenu/snow_leopard.png");
    private static final int IMAGE_WIDTH = 1280;
    private static final int IMAGE_HEIGHT = 720;

    private MenuBackdrop() {
    }

    /** Draws the picture scaled to cover the whole screen (no stretching), then a light dim. */
    private static void drawImage(DrawContext context, float width, float height) {
        float scale = Math.max(width / IMAGE_WIDTH, height / IMAGE_HEIGHT);
        float x = (width - IMAGE_WIDTH * scale) / 2.0F;
        float y = (height - IMAGE_HEIGHT * scale) / 2.0F;

        context.getMatrices().push();
        context.getMatrices().translate(x, y, 0.0F);
        context.getMatrices().scale(scale, scale, 1.0F);
        context.drawTexture(RenderLayer::getGuiTextured, IMAGE, 0, 0, 0.0F, 0.0F, IMAGE_WIDTH, IMAGE_HEIGHT,
                IMAGE_WIDTH, IMAGE_HEIGHT, ColorUtil.rgba(255, 255, 255, 255));
        context.getMatrices().pop();

        context.fill(0, 0, Math.round(width), Math.round(height), ColorUtil.rgba(0, 0, 0, 90));
        context.draw();
    }

    static void fillVanilla(DrawContext context, int width, int height) {
        DrawHelper.ensureMainFramebuffer();
        context.fill(0, 0, width, height, -16250096);
        context.draw();
    }

    static void drawPattern(DrawHelper renderer, DrawContext context, float width, float height) {
        if (USE_IMAGE_BACKGROUND) {
            drawImage(context, width, height);
            return;
        }

        GuiTheme theme = GuiTheme.theme;

        ShaderLibrary.loadMainMenuShaders();
        ShaderLibrary.getRegistry()
                .find("main_menu_background")
                .filter(ManagedShader::isLinked)
                .ifPresentOrElse(program -> {
                    program.bind(context.getMatrices().peek().getPositionMatrix());
                    program.setVec2("resolution",
                            MinecraftClient.getInstance().getWindow().getFramebufferWidth(),
                            MinecraftClient.getInstance().getWindow().getFramebufferHeight());
                    program.setFloat("time", (System.currentTimeMillis() % 1000000L) / 1000.0F);
                    program.setColor("accentColor", theme.getAccent());
                    program.setColor("accentColor2", theme.getCardActiveBottom());
                    BlendStateUtil.runBlended(() -> ManagedShader.drawQuad(0.0F, 0.0F, width, height));
                    program.unbind();
                }, () -> renderer.drawSolidRect(0.0F, 0.0F, width, height, new Color(8, 11, 16, 255),
                        context.getMatrices()));

        context.fill(0, 0, Math.round(width), Math.round(height), ColorUtil.rgba(0, 0, 0, 34));
    }
}
