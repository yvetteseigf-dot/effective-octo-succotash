package sky.screen;

import java.awt.Color;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import sky.theme.GuiTheme;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.HudProjectionManager;
import sky.render.DrawHelper;
import sky.util.render.ColorUtil;
import sky.util.render.GuiCoordinateUtil;
import sky.util.render.HudScaleUtil;
import sky.util.animation.SmoothFloat;

/** Custom main menu replacing the vanilla title screen. */
public final class MainMenuScreen extends Screen {
    private static final float BUTTON_WIDTH = 124.0F;
    private static final float SETTINGS_BUTTON_WIDTH = 96.0F;
    private static final float BUTTON_HEIGHT = 23.0F;
    private static final float BUTTON_GAP = 3.5F;
    private static final float BUTTON_RADIUS = 8.0F;
    private static final int BUTTON_TEXT_SIZE = 15;
    private static final int BUTTON_ICON_SIZE = 14;
    private static final float SIDE_BADGE_SIZE = 23.0F;
    private static final float SIDE_BADGE_GAP = 5.0F;
    private static final float LOGO_TITLE_GAP = 18.0F;
    private static final float CONTENT_Y_OFFSET = 22.0F;

    private final List<MenuButton> buttons;

    public MainMenuScreen() {
        super(Text.literal("Skycore"));
        this.buttons = new ArrayList<>();
    }

    @Override
    protected void init() {
        this.buttons.clear();
        this.buttons.add(new MenuButton("i", "Singleplayer",
                () -> this.client.setScreen(new SelectWorldScreen(this))));
        this.buttons.add(new MenuButton("j", "Multiplayer",
                () -> this.client.setScreen(new MultiplayerScreen(this))));
        this.buttons.add(new MenuButton("b", "AltManager", this::openAltManager));
        this.buttons.add(new MenuButton("c", "Settings", true,
                () -> this.client.setScreen(new OptionsScreen(this, this.client.options)),
                () -> MinecraftClient.getInstance().scheduleStop()));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        MenuBackdrop.fillVanilla(context, this.width, this.height);

        DrawHelper renderer = DrawHelper.get();
        if (renderer == null) {
            return;
        }

        MatrixStack matrices = context.getMatrices();
        Window window = this.client.getWindow();

        float framebufferHalfWidth = (float) (window.getFramebufferWidth() / 2.0D);
        float framebufferHalfHeight = (float) (window.getFramebufferHeight() / 2.0D);
        float scaleX = framebufferHalfWidth > 0.0F ? window.getScaledWidth() / framebufferHalfWidth : 1.0F;
        float scaleY = framebufferHalfHeight > 0.0F ? window.getScaledHeight() / framebufferHalfHeight : 1.0F;

        matrices.push();
        matrices.scale(scaleX, scaleY, 1.0F);

        HudProjectionManager.beginHud();
        try {
            this.renderMenu(renderer, context, mouseX, mouseY);
        } finally {
            DrawHelper.finishGuiOverlayDraw();
            matrices.pop();
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        for (MenuButton menuButton : this.buttons) {
            if (menuButton.mouseClicked(mouseX, mouseY)) {
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void renderMenu(DrawHelper renderer, DrawContext context, int mouseX, int mouseY) {
        GuiTheme theme = GuiTheme.theme;
        float width = HudScaleUtil.getRenderWidth();
        float height = HudScaleUtil.getRenderHeight();

        this.renderBackgroundPattern(renderer, context, width, height);

        FontRenderer subtitleFont = FontRegistry.getRegular(13);
        if (subtitleFont == null) {
            return;
        }

        String subtitle = "The best 1.21.4 client";
        float subtitleHeight = subtitleFont.getLineHeight(subtitle);

        float buttonsHeight = this.buttons.size() * BUTTON_HEIGHT + (this.buttons.size() - 1) * BUTTON_GAP;
        float contentHeight = subtitleHeight + 16.0F + buttonsHeight;

        float subtitleY = Math.max(10.0F, (height - contentHeight) / 2.0F);
        subtitleFont.drawCentered(subtitle, width / 2.0F, subtitleY, ColorUtil.withAlpha(theme.getTextDim(), 0.62F),
                context.getMatrices());

        float buttonsY = subtitleY + subtitleHeight + 16.0F;
        for (int i = 0; i < this.buttons.size(); i++) {
            MenuButton button = this.buttons.get(i);
            float buttonX = width / 2.0F - button.rowWidth() / 2.0F;
            button.render(renderer, context, buttonX, buttonsY + i * 26.5F, mouseX, mouseY);
        }
    }

    private void renderStyledLogo(FontRenderer logoFont, DrawContext context, float centerX, float logoY,
                                  GuiTheme theme) {
        logoFont.drawCentered("a", centerX, logoY, theme.getAccent(), context.getMatrices());
    }

    private void renderBackgroundPattern(DrawHelper renderer, DrawContext context, float width, float height) {
        MenuBackdrop.drawPattern(renderer, context, width, height);
    }

    private void openAltManager() {
        Screen screen = this.createAltManagerScreen();
        if (screen != null) {
            this.client.setScreen(screen);
        }
    }

    /** Tries a bundled IAS screen first, then the built-in Alt Manager. */
    private Screen createAltManagerScreen() {
        String[] candidates = {
                "ru.vidtu.ias.screen.AccountScreen",
                "me.dags.ias.gui.GuiAccountSelector",
                "me.dags.ias.gui.GuiAccountManager",
                "com.github.ias.accountswitcher.gui.GuiAccountSelector",
                "net.raphimc.minecraftauth.gui.screen.AccountManagerScreen"
        };

        for (String className : candidates) {
            Screen screen = this.tryCreateScreen(className);
            if (screen != null) {
                return screen;
            }
        }

        return new AltManagerScreen(this);
    }

    private Screen tryCreateScreen(String className) {
        try {
            Class<?> type = Class.forName(className);
            if (!Screen.class.isAssignableFrom(type)) {
                return this.tryFactoryMethod(type);
            }

            for (Constructor<?> constructor : type.getDeclaredConstructors()) {
                constructor.setAccessible(true);
                Class<?>[] parameters = constructor.getParameterTypes();

                if (parameters.length == 1 && Screen.class.isAssignableFrom(parameters[0])) {
                    return (Screen) constructor.newInstance(this);
                }

                if (parameters.length == 0) {
                    return (Screen) constructor.newInstance();
                }
            }
        } catch (ReflectiveOperationException | LinkageError ignored) {
            return null;
        }

        return null;
    }

    private Screen tryFactoryMethod(Class<?> clazz) throws ReflectiveOperationException {
        String[] factoryNames = {"open", "create", "getScreen"};

        for (String factoryName : factoryNames) {
            for (Method method : clazz.getDeclaredMethods()) {
                if (!method.getName().equals(factoryName)) {
                    continue;
                }

                if (!Screen.class.isAssignableFrom(method.getReturnType())) {
                    continue;
                }

                method.setAccessible(true);
                Class<?>[] parameters = method.getParameterTypes();

                if (parameters.length == 1 && parameters[0] == MinecraftClient.class) {
                    return (Screen) method.invoke(null, MinecraftClient.getInstance());
                }

                if (parameters.length == 1 && Screen.class.isAssignableFrom(parameters[0])) {
                    return (Screen) method.invoke(null, this);
                }

                if (parameters.length == 0) {
                    return (Screen) method.invoke(null);
                }
            }
        }

        return null;
    }

    private static float iconEdgePadding(FontRenderer iconFont, String icon) {
        return (BUTTON_HEIGHT - iconFont.getLineHeight(icon)) / 2.0F;
    }

    private static void drawIconWithGlow(DrawHelper renderer, FontRenderer iconFont, String icon, float x, float y,
                                         Color iconColor, Color glowColor, float glowStrength, DrawContext context) {
        if (glowStrength > 0.01F) {
            float centerX = x + iconFont.getWidth(icon) * 0.5F;
            float centerY = y + iconFont.getLineHeight(icon) * 0.5F;

            float[][] halo = {{8.0F, 0.07F}, {6.0F, 0.11F}, {4.5F, 0.15F}};
            for (float[] ring : halo) {
                renderer.drawCircle(centerX, centerY, ring[0],
                        ColorUtil.withAlpha(glowColor, ring[1] * glowStrength), context.getMatrices());
            }
        }

        iconFont.draw(icon, x, y, iconColor, context.getMatrices());
    }

    private static final class MenuButton {
        private static final Color EXIT_ACCENT = new Color(224, 96, 112, 255);
        private static final Color EXIT_ACCENT_DEEP = new Color(150, 52, 68, 255);

        private final String icon;
        private final String label;
        private final boolean settingsBadge;
        private final Runnable action;
        private final Runnable badgeAction;
        private final SmoothFloat hover = new SmoothFloat(0.24F);
        private final SmoothFloat badgeHover = new SmoothFloat(0.24F);

        private float x;
        private float y;
        private float width;
        private float badgeX;
        private float badgeY;

        private MenuButton(String icon, String label, Runnable action) {
            this(icon, label, false, action, null);
        }

        private MenuButton(String icon, String label, boolean settingsBadge, Runnable action, Runnable badgeAction) {
            this.icon = icon;
            this.label = label;
            this.settingsBadge = settingsBadge;
            this.action = action;
            this.badgeAction = badgeAction;
        }

        /** Total horizontal space the row occupies, including the detached exit badge. */
        private float rowWidth() {
            return this.settingsBadge ? SETTINGS_BUTTON_WIDTH + SIDE_BADGE_GAP + SIDE_BADGE_SIZE : BUTTON_WIDTH;
        }

        private void render(DrawHelper renderer, DrawContext context, float x, float y, int mouseX, int mouseY) {
            this.x = x;
            this.y = y;
            this.width = this.settingsBadge ? SETTINGS_BUTTON_WIDTH : BUTTON_WIDTH;
            this.badgeX = x + this.width + SIDE_BADGE_GAP;
            this.badgeY = y;

            GuiTheme theme = GuiTheme.theme;
            boolean hovered = GuiCoordinateUtil.isHovered(mouseX, mouseY, x, y, this.width, BUTTON_HEIGHT);
            boolean badgeHovered = this.settingsBadge && GuiCoordinateUtil.isHovered(mouseX, mouseY, this.badgeX,
                    this.badgeY, SIDE_BADGE_SIZE, SIDE_BADGE_SIZE);

            this.hover.setTarget(hovered ? 1.0F : 0.0F);
            this.badgeHover.setTarget(badgeHovered ? 1.0F : 0.0F);
            this.hover.update();
            this.badgeHover.update();

            float progress = this.hover.get();
            renderer.drawMainMenuButton(x, y, this.width, BUTTON_HEIGHT, BUTTON_RADIUS, progress, theme.getAccent(),
                    theme.getCardActiveBottom(), context.getMatrices());

            FontRenderer labelFont = FontRegistry.getMedium(BUTTON_TEXT_SIZE);
            FontRenderer iconFont = FontRegistry.getSkycore(BUTTON_ICON_SIZE);
            if (labelFont == null || iconFont == null) {
                return;
            }

            Color idleIcon = new Color(118, 120, 128, 255);
            Color idleLabel = ColorUtil.withAlpha(theme.getText(), 0.95F);
            Color activeIcon = ColorUtil.withAlpha(Color.WHITE, 0.98F);
            Color accent = theme.getAccent();

            Color labelColor = ColorUtil.lerp(idleLabel, accent, progress);
            Color iconColor = ColorUtil.lerp(idleIcon, activeIcon, progress);

            float padding = iconEdgePadding(iconFont, this.icon);
            float iconX = x + padding;
            float iconY = y + padding;
            float labelY = y + (BUTTON_HEIGHT - labelFont.getLineHeight(this.label)) / 2.0F + 0.5F;
            float glowStrength = 0.38F + progress * 0.62F;
            Color glowColor = ColorUtil.lerp(ColorUtil.withAlpha(theme.getAccent(), 0.55F), Color.WHITE, progress);

            drawIconWithGlow(renderer, iconFont, this.icon, iconX, iconY, iconColor, glowColor, glowStrength, context);
            labelFont.drawCentered(this.label, x + this.width / 2.0F, labelY, labelColor, context.getMatrices());

            if (this.settingsBadge) {
                this.renderExitBadge(renderer, context, this.badgeX, this.badgeY, iconFont, this.badgeHover.get());
            }
        }

        private void renderExitBadge(DrawHelper renderer, DrawContext context, float x, float y,
                                     FontRenderer iconFont, float progress) {
            renderer.drawMainMenuButton(x, y, SIDE_BADGE_SIZE, SIDE_BADGE_SIZE, BUTTON_RADIUS, progress, EXIT_ACCENT,
                    EXIT_ACCENT_DEEP, context.getMatrices());

            Color iconColor = ColorUtil.lerp(new Color(118, 120, 128, 255),
                    ColorUtil.withAlpha(Color.WHITE, 0.95F), progress);
            float iconX = x + (SIDE_BADGE_SIZE - iconFont.getWidth("d")) / 2.0F;
            float iconY = y + (SIDE_BADGE_SIZE - iconFont.getLineHeight("d")) / 2.0F - 0.4F;
            float glowStrength = 0.35F + progress * 0.65F;
            Color glowColor = ColorUtil.lerp(ColorUtil.withAlpha(EXIT_ACCENT, 0.5F), Color.WHITE, progress);

            drawIconWithGlow(renderer, iconFont, "d", iconX, iconY, iconColor, glowColor, glowStrength, context);
        }

        private boolean mouseClicked(double mouseX, double mouseY) {
            if (this.settingsBadge && GuiCoordinateUtil.isHovered(mouseX, mouseY, this.badgeX, this.badgeY,
                    SIDE_BADGE_SIZE, SIDE_BADGE_SIZE)) {
                if (this.badgeAction != null) {
                    this.badgeAction.run();
                }

                return true;
            }

            if (GuiCoordinateUtil.isHovered(mouseX, mouseY, this.x, this.y, this.width, BUTTON_HEIGHT)) {
                this.action.run();
                return true;
            }

            return false;
        }
    }
}
