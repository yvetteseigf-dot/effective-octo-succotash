package sky.screen;

import java.awt.Color;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import sky.SkyInit;
import sky.render.DrawHelper;
import sky.render.HudProjectionManager;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.session.AccountsFile;
import sky.session.AltAccount;
import sky.session.SessionSwitcher;
import sky.theme.GuiTheme;
import sky.util.animation.SmoothFloat;
import sky.util.render.ColorUtil;
import sky.util.render.GuiCoordinateUtil;
import sky.util.render.HudScaleUtil;

/** Built-in alt list used when no third-party account manager is installed. */
public final class AltManagerScreen extends Screen {
    private static final float BUTTON_WIDTH = 124.0F;
    private static final float BUTTON_HEIGHT = 23.0F;
    private static final float BUTTON_GAP = 3.5F;
    private static final float BUTTON_RADIUS = 8.0F;
    private static final int VISIBLE_ROWS = 6;
    private static final float ROW_STEP = BUTTON_HEIGHT + BUTTON_GAP;

    private final Screen parent;
    private final AccountsFile accounts;
    private final SmoothFloat addHover = new SmoothFloat(0.24F);
    private final SmoothFloat loginHover = new SmoothFloat(0.24F);
    private final SmoothFloat deleteHover = new SmoothFloat(0.24F);
    private final SmoothFloat backHover = new SmoothFloat(0.24F);
    private final SmoothFloat[] rowHover = new SmoothFloat[VISIBLE_ROWS];

    private String input = "";
    private boolean inputFocused = true;
    private int selectedIndex;
    private int scroll;
    private int caretTicks;

    private float listX;
    private float listY;
    private float inputX;
    private float inputY;
    private float addX;
    private float addY;
    private float loginX;
    private float loginY;
    private float deleteX;
    private float deleteY;
    private float backX;
    private float backY;
    private float fieldWidth = 260.0F;

    public AltManagerScreen(Screen parent) {
        super(Text.literal("AltManager"));
        this.parent = parent;
        this.accounts = SkyInit.getInstance().getAccountsFile();
        for (int i = 0; i < rowHover.length; i++) {
            rowHover[i] = new SmoothFloat(0.24F);
        }
    }

    @Override
    protected void init() {
        AltAccount current = SessionSwitcher.current();
        accounts.addIfAbsent(current);
        if (current != null) {
            selectUsername(current.getUsername());
        } else if (!accounts.getAccounts().isEmpty()) {
            selectedIndex = 0;
        }
        clampSelection();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        this.client.setScreen(parent instanceof MainMenuScreen ? parent : new MainMenuScreen());
    }

    @Override
    public void tick() {
        caretTicks++;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        MenuBackdrop.fillVanilla(context, this.width, this.height);

        DrawHelper renderer = DrawHelper.get();
        if (renderer == null) {
            return;
        }

        MatrixStack matrices = context.getMatrices();
        Window window = this.client.getWindow();
        float framebufferHalfWidth = (float) (window.getFramebufferWidth() / 2.0D);
        float framebufferHalfHeight = (float) (window.getFramebufferHeight() / 2.0D);
        float scaleX = framebufferHalfWidth > 0.0F ? window.getScaledWidth() / framebufferHalfWidth : 1.0F;
        float scaleY = framebufferHalfHeight > 0.0F ? window.getScaledHeight() / framebufferHalfHeight : 1.0F;

        matrices.push();
        matrices.scale(scaleX, scaleY, 1.0F);
        HudProjectionManager.beginHud();
        try {
            renderContents(renderer, context, mouseX, mouseY);
        } finally {
            DrawHelper.finishGuiOverlayDraw();
            matrices.pop();
        }
    }

    private void renderContents(DrawHelper renderer, DrawContext context, int mouseX, int mouseY) {
        GuiTheme theme = GuiTheme.theme;
        float width = HudScaleUtil.getRenderWidth();
        float height = HudScaleUtil.getRenderHeight();
        MenuBackdrop.drawPattern(renderer, context, width, height);

        FontRenderer titleFont = FontRegistry.getRegular(19);
        FontRenderer subtitleFont = FontRegistry.getRegular(13);
        FontRenderer labelFont = FontRegistry.getMedium(15);
        if (titleFont == null || subtitleFont == null || labelFont == null) {
            return;
        }

        List<AltAccount> list = accounts.getAccounts();
        clampSelection();

        fieldWidth = 260.0F;
        float contentHeight = 36.0F + VISIBLE_ROWS * ROW_STEP + 16.0F + BUTTON_HEIGHT + BUTTON_GAP + BUTTON_HEIGHT
                + BUTTON_GAP + BUTTON_HEIGHT;
        float originY = Math.max(18.0F, (height - contentHeight) / 2.0F);
        float centerX = width / 2.0F;
        listX = centerX - fieldWidth / 2.0F;
        listY = originY + 36.0F;

        titleFont.drawCentered("AltManager", centerX, originY, ColorUtil.withAlpha(theme.getText(), 0.88F),
                context.getMatrices());
        String currentName = this.client.getSession() == null ? "-" : this.client.getSession().getUsername();
        subtitleFont.drawCentered("current: " + currentName, centerX, originY + 18.0F,
                ColorUtil.withAlpha(theme.getTextDim(), 0.62F), context.getMatrices());

        int visible = Math.min(VISIBLE_ROWS, Math.max(0, list.size() - scroll));
        for (int i = 0; i < VISIBLE_ROWS; i++) {
            float rowY = listY + i * ROW_STEP;
            boolean hovered = GuiCoordinateUtil.isHovered(mouseX, mouseY, listX, rowY, fieldWidth, BUTTON_HEIGHT);
            boolean selected = scroll + i == selectedIndex && scroll + i < list.size();
            rowHover[i].setTarget(hovered || selected ? 1.0F : 0.0F);
            rowHover[i].update();
            float progress = Math.max(rowHover[i].get(), selected ? 1.0F : 0.0F);
            renderer.drawMainMenuButton(listX, rowY, fieldWidth, BUTTON_HEIGHT, BUTTON_RADIUS, progress,
                    theme.getAccent(), theme.getCardActiveBottom(), context.getMatrices());
            if (i < visible) {
                AltAccount account = list.get(scroll + i);
                Color color = ColorUtil.lerp(ColorUtil.withAlpha(theme.getText(), 0.95F), theme.getAccent(), progress);
                labelFont.drawCentered(account.getUsername(), centerX, rowY + 5.0F, color, context.getMatrices());
            }
        }

        inputY = listY + VISIBLE_ROWS * ROW_STEP + 12.0F;
        inputX = listX;
        boolean fieldHovered = GuiCoordinateUtil.isHovered(mouseX, mouseY, inputX, inputY, fieldWidth, BUTTON_HEIGHT);
        renderer.drawMainMenuButton(inputX, inputY, fieldWidth, BUTTON_HEIGHT, BUTTON_RADIUS,
                inputFocused || fieldHovered ? 0.55F : 0.15F, theme.getAccent(), theme.getCardActiveBottom(),
                context.getMatrices());
        String shown = input.isEmpty() && !inputFocused ? "username" : input;
        Color inputColor = input.isEmpty() && !inputFocused
                ? ColorUtil.withAlpha(theme.getTextDim(), 0.45F)
                : ColorUtil.withAlpha(theme.getText(), 0.95F);
        labelFont.draw(shown, inputX + 10.0F, inputY + 5.0F, inputColor, context.getMatrices());
        if (inputFocused && (caretTicks / 8) % 2 == 0) {
            float caretX = inputX + 10.0F + labelFont.getWidth(input);
            renderer.drawSolidRect(caretX, inputY + 5.0F, 1.0F, 12.0F, Color.WHITE, context.getMatrices());
        }

        float actionY = inputY + BUTTON_HEIGHT + BUTTON_GAP;
        float actionWidth = (fieldWidth - BUTTON_GAP * 2.0F) / 3.0F;
        addX = listX;
        addY = actionY;
        loginX = listX + actionWidth + BUTTON_GAP;
        loginY = actionY;
        deleteX = listX + (actionWidth + BUTTON_GAP) * 2.0F;
        deleteY = actionY;
        backX = centerX - BUTTON_WIDTH / 2.0F;
        backY = actionY + BUTTON_HEIGHT + BUTTON_GAP;

        drawAction(renderer, context, labelFont, "Add", addX, addY, actionWidth, addHover,
                GuiCoordinateUtil.isHovered(mouseX, mouseY, addX, addY, actionWidth, BUTTON_HEIGHT));
        drawAction(renderer, context, labelFont, "Login", loginX, loginY, actionWidth, loginHover,
                GuiCoordinateUtil.isHovered(mouseX, mouseY, loginX, loginY, actionWidth, BUTTON_HEIGHT));
        drawAction(renderer, context, labelFont, "Delete", deleteX, deleteY, actionWidth, deleteHover,
                GuiCoordinateUtil.isHovered(mouseX, mouseY, deleteX, deleteY, actionWidth, BUTTON_HEIGHT));
        drawAction(renderer, context, labelFont, "Back", backX, backY, BUTTON_WIDTH, backHover,
                GuiCoordinateUtil.isHovered(mouseX, mouseY, backX, backY, BUTTON_WIDTH, BUTTON_HEIGHT));
    }

    private void drawAction(DrawHelper renderer, DrawContext context, FontRenderer font, String label,
                            float x, float y, float width, SmoothFloat hover, boolean hovered) {
        hover.setTarget(hovered ? 1.0F : 0.0F);
        hover.update();
        GuiTheme theme = GuiTheme.theme;
        renderer.drawMainMenuButton(x, y, width, BUTTON_HEIGHT, BUTTON_RADIUS, hover.get(), theme.getAccent(),
                theme.getCardActiveBottom(), context.getMatrices());
        Color color = ColorUtil.lerp(ColorUtil.withAlpha(theme.getText(), 0.95F), theme.getAccent(), hover.get());
        font.drawCentered(label, x + width / 2.0F, y + 5.0F, color, context.getMatrices());
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        List<AltAccount> list = accounts.getAccounts();
        for (int i = 0; i < VISIBLE_ROWS; i++) {
            float rowY = listY + i * ROW_STEP;
            if (GuiCoordinateUtil.isHovered(mouseX, mouseY, listX, rowY, fieldWidth, BUTTON_HEIGHT)
                    && scroll + i < list.size()) {
                selectedIndex = scroll + i;
                input = list.get(selectedIndex).getUsername();
                inputFocused = false;
                return true;
            }
        }

        if (GuiCoordinateUtil.isHovered(mouseX, mouseY, inputX, inputY, fieldWidth, BUTTON_HEIGHT)) {
            inputFocused = true;
            return true;
        }
        inputFocused = false;

        float actionWidth = (fieldWidth - BUTTON_GAP * 2.0F) / 3.0F;
        if (GuiCoordinateUtil.isHovered(mouseX, mouseY, addX, addY, actionWidth, BUTTON_HEIGHT)) {
            addAccount();
            return true;
        }
        if (GuiCoordinateUtil.isHovered(mouseX, mouseY, loginX, loginY, actionWidth, BUTTON_HEIGHT)) {
            loginSelected();
            return true;
        }
        if (GuiCoordinateUtil.isHovered(mouseX, mouseY, deleteX, deleteY, actionWidth, BUTTON_HEIGHT)) {
            deleteSelected();
            return true;
        }
        if (GuiCoordinateUtil.isHovered(mouseX, mouseY, backX, backY, BUTTON_WIDTH, BUTTON_HEIGHT)) {
            close();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int maxScroll = Math.max(0, accounts.getAccounts().size() - VISIBLE_ROWS);
        if (verticalAmount < 0.0D) {
            scroll = Math.min(maxScroll, scroll + 1);
        } else if (verticalAmount > 0.0D) {
            scroll = Math.max(0, scroll - 1);
        }
        clampSelection();
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            if (!input.isEmpty()) {
                addAccount();
            } else {
                loginSelected();
            }
            return true;
        }
        if (inputFocused && keyCode == GLFW.GLFW_KEY_BACKSPACE && !input.isEmpty()) {
            input = input.substring(0, input.length() - 1);
            return true;
        }
        if (inputFocused && Screen.hasControlDown() && keyCode == GLFW.GLFW_KEY_V) {
            String clip = MinecraftClient.getInstance().keyboard.getClipboard();
            if (clip != null) {
                for (int i = 0; i < clip.length(); i++) {
                    appendChar(clip.charAt(i));
                }
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (!inputFocused) {
            return super.charTyped(chr, modifiers);
        }
        return appendChar(chr);
    }

    private boolean appendChar(char chr) {
        if (!Character.isLetterOrDigit(chr) && chr != '_') {
            return false;
        }
        if (input.length() >= 16) {
            return true;
        }
        input += chr;
        return true;
    }

    private void addAccount() {
        AltAccount created = accounts.addOffline(input);
        if (created == null) {
            return;
        }
        selectUsername(created.getUsername());
        input = "";
    }

    private void loginSelected() {
        List<AltAccount> list = accounts.getAccounts();
        if (selectedIndex < 0 || selectedIndex >= list.size()) {
            if (AltAccount.isValidUsername(input)) {
                AltAccount created = accounts.addOffline(input);
                if (created != null) {
                    SessionSwitcher.apply(created);
                }
            }
            return;
        }
        SessionSwitcher.apply(list.get(selectedIndex));
    }

    private void deleteSelected() {
        List<AltAccount> list = accounts.getAccounts();
        if (selectedIndex < 0 || selectedIndex >= list.size()) {
            return;
        }
        accounts.remove(list.get(selectedIndex));
        clampSelection();
    }

    private void selectUsername(String username) {
        List<AltAccount> list = accounts.getAccounts();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).sameName(username)) {
                selectedIndex = i;
                if (selectedIndex < scroll) {
                    scroll = selectedIndex;
                } else if (selectedIndex >= scroll + VISIBLE_ROWS) {
                    scroll = selectedIndex - VISIBLE_ROWS + 1;
                }
                return;
            }
        }
    }

    private void clampSelection() {
        List<AltAccount> list = accounts.getAccounts();
        int maxScroll = Math.max(0, list.size() - VISIBLE_ROWS);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
        if (list.isEmpty()) {
            selectedIndex = -1;
            return;
        }
        selectedIndex = Math.max(0, Math.min(selectedIndex, list.size() - 1));
    }
}
