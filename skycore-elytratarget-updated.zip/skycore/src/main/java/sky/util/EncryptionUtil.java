package sky.util;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Compatibility codec used by the original client configuration files.
 *
 * <p>This is not cryptographic protection: it is a repeating-key XOR stream
 * prefixed with a marker before Base64 encoding.  It is reproduced only so
 * existing configuration files remain readable.</p>
 */
public final class EncryptionUtil {
    private static final byte[] MAGIC_BYTES = {(byte) 0xCA, (byte) 0xFE, (byte) 0xBA, (byte) 0xBE};
    private static final byte[] SECRET_KEY = "kotopesprot".getBytes(StandardCharsets.UTF_8);

    private EncryptionUtil() {
    }

    public static String encrypt(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }

        try {
            byte[] plain = input.getBytes(StandardCharsets.UTF_8);
            byte[] encrypted = xor(plain);
            byte[] payload = new byte[MAGIC_BYTES.length + encrypted.length];
            System.arraycopy(MAGIC_BYTES, 0, payload, 0, MAGIC_BYTES.length);
            System.arraycopy(encrypted, 0, payload, MAGIC_BYTES.length, encrypted.length);
            return Base64.getEncoder().encodeToString(payload);
        } catch (Exception ignored) {
            return input;
        }
    }

    public static String decrypt(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }

        try {
            byte[] payload = Base64.getDecoder().decode(input);
            if (payload.length < MAGIC_BYTES.length) {
                return input;
            }
            for (int index = 0; index < MAGIC_BYTES.length; index++) {
                if (payload[index] != MAGIC_BYTES[index]) {
                    return input;
                }
            }

            byte[] encrypted = new byte[payload.length - MAGIC_BYTES.length];
            System.arraycopy(payload, MAGIC_BYTES.length, encrypted, 0, encrypted.length);
            return new String(xor(encrypted), StandardCharsets.UTF_8);
        } catch (Exception ignored) {
            return input;
        }
    }

    private static byte[] xor(byte[] bytes) {
        byte[] result = new byte[bytes.length];
        for (int index = 0; index < bytes.length; index++) {
            result[index] = (byte) (bytes[index] ^ SECRET_KEY[index % SECRET_KEY.length]);
        }
        return result;
    }
}
