package sky.util.network;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public final class TickRotationSync {
    private static float yaw;
    private static float pitch;
    private static boolean captured;

    private TickRotationSync() {
    }

    public static void capture(float yaw, float pitch) {
        TickRotationSync.yaw = yaw;
        TickRotationSync.pitch = pitch;
        captured = true;
    }

    public static void captureFromPlayer() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player == null) {
            captured = false;
            return;
        }
        capture(player.getYaw(), player.getPitch());
    }

    public static boolean isCaptured() {
        return captured;
    }

    public static float yaw() {
        return yaw;
    }

    public static float pitch() {
        return pitch;
    }

    public static void applyToPlayer() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (!captured || player == null) {
            return;
        }
        player.setYaw(yaw);
        player.setPitch(pitch);
    }
}
