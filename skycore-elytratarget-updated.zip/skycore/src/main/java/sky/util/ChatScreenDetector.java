package sky.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;

public final class ChatScreenDetector {
    private ChatScreenDetector() {
    }

    public static boolean isActive() {
        MinecraftClient client = MinecraftClient.getInstance();
        return client.currentScreen instanceof ChatScreen;
    }
}
