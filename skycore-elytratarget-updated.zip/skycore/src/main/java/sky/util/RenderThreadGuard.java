package sky.util;

import java.util.function.Supplier;

public class RenderThreadGuard {
    private static Thread renderThread;

    public static boolean isOnRenderThread() {
        return Thread.currentThread() == renderThread;
    }

    public static void assertThread(Supplier<Boolean> predicate) {
        if (!predicate.get()) {
            throw new IllegalStateException("Rendersystem called from wrong thread");
        }
    }
}
