package sky.util.elytra;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import sky.access.MinecraftAccess;
import sky.module.combat.ElytraTarget;

public final class ElytraPredictionUtil implements MinecraftAccess {
    private ElytraPredictionUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Vec3d bypasselytrahacking(LivingEntity entity) {
        Vec3d lerpDirection = Vec3d.fromPolar(entity.getLerpTargetPitch(), entity.getLerpTargetYaw());
        Vec3d facing = entity.getRotationVector();
        Vec3d offsetFromEye = entity.getPos()
            .add(0.0D, entity.getHeight() * 0.6F, 0.0D)
            .subtract(mc.player.getEyePos());
        Vec3d blended = lerpDirection.normalize().lerp(facing, lerpDirection.length());

        ElytraTarget elytraTarget = ElytraTarget.INSTANCE;
        float distance = elytraTarget != null ? elytraTarget.distance.getCurrent() : 3.0F;

        return offsetFromEye.add(blended.normalize().multiply(distance));
    }

    public static Vec3d predict(LivingEntity entity, Vec3d position, float ticks) {
        if (Math.hypot(entity.getX() - entity.lastRenderX, entity.getZ() - entity.lastRenderZ) * 20.0D <= 5.0D
            && (entity.getY() - entity.lastRenderY) * 20.0D <= 5.0D) {
            return position;
        }

        float pitchRadians = (entity.getPitch() + (entity.prevPitch - entity.getPitch())) * 0.017453292F;
        float yawRadians = -(entity.getYaw() + (entity.prevHeadYaw - entity.getYaw())) * 0.017453292F;

        float yawCos = MathHelper.cos(yawRadians);
        float yawSin = MathHelper.sin(yawRadians);
        float pitchCos = MathHelper.cos(pitchRadians);
        float pitchSin = MathHelper.sin(pitchRadians);

        Vec3d velocity = entity.getVelocity();
        Vec3d facing = new Vec3d(yawSin * pitchCos, -pitchSin, yawCos * pitchCos);

        float pitch = (float) (entity.getPitch() * (MathHelper.PI / 180.0D));
        double facingHorizontalLength = Math.sqrt(facing.x * facing.x + facing.z * facing.z);
        double horizontalSpeed = velocity.horizontalLength();

        boolean falling = entity.getVelocity().y <= 0.0D;
        double gravity = falling && entity.hasStatusEffect(StatusEffects.SLOW_FALLING)
            ? Math.min(entity.getFinalGravity(), 0.01D)
            : entity.getFinalGravity();

        double pitchCosSquared = MathHelper.square(Math.cos(pitch));
        velocity = velocity.add(0.0D, gravity * (-1.0D + pitchCosSquared * 0.75D), 0.0D);

        if (velocity.y < 0.0D && facingHorizontalLength > 0.0D) {
            double lift = velocity.y * -0.1D * pitchCosSquared;
            velocity = velocity.add(
                facing.x * lift / facingHorizontalLength,
                lift,
                facing.z * lift / facingHorizontalLength
            );
        }

        if (pitch < 0.0F && facingHorizontalLength > 0.0D) {
            double dive = horizontalSpeed * -MathHelper.sin(pitch) * 0.04D;
            velocity = velocity.add(
                -facing.x * dive / facingHorizontalLength,
                dive * 3.2D,
                -facing.z * dive / facingHorizontalLength
            );
        }

        if (facingHorizontalLength > 0.0D) {
            velocity = velocity.add(
                (facing.x / facingHorizontalLength * horizontalSpeed - velocity.x) * 0.1D,
                0.0D,
                (facing.z / facingHorizontalLength * horizontalSpeed - velocity.z) * 0.1D
            );
        }

        Vec3d damped = velocity.multiply(0.99F, 0.98F, 0.99F);
        return position.add(damped.multiply(ticks)).add(0.0D, 0.35F, 0.0D);
    }
}
