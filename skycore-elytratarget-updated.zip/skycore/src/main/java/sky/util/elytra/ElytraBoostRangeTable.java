package sky.util.elytra;

import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import sky.access.SkyClientAccess;

public final class ElytraBoostRangeTable implements SkyClientAccess {
    private ElytraBoostRangeTable() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Vec3d getBoost(LivingEntity entity) {
        float yaw = entity.getYaw();
        float pitch = entity.getPitch();

        float normalizedYaw = yaw % 180.0F;
        if (normalizedYaw > 90.0F) {
            normalizedYaw -= 180.0F;
        } else if (normalizedYaw < -90.0F) {
            normalizedYaw += 180.0F;
        }

        float normalizedPitch = pitch % 180.0F;
        if (normalizedPitch > 90.0F) {
            normalizedPitch -= 180.0F;
        } else if (normalizedPitch < -90.0F) {
            normalizedPitch += 180.0F;
        }

        float horizontal = getSpeedForPitchRange(normalizedPitch, normalizedYaw);
        float vertical = getSpeedYForPitchRange(normalizedPitch);
        return new Vec3d(horizontal, vertical, horizontal);
    }

    private static float getSpeedYForPitchRange(float pitch) {
        float absPitch = Math.abs(pitch);
        if (absPitch >= 45.0F && absPitch <= 50.0F) {
            return 2.05F;
        }
        if (absPitch >= 40.0F && absPitch <= 45.0F) {
            return 2.12F;
        }
        if (absPitch >= 35.0F && absPitch <= 40.0F) {
            return 2.19F;
        }
        if (absPitch >= 30.0F && absPitch <= 35.0F) {
            return 2.15F;
        }
        if (absPitch >= 25.0F && absPitch <= 30.0F) {
            return 2.17F;
        }
        if (absPitch >= 20.0F && absPitch <= 25.0F) {
            return 1.86F;
        }
        if (absPitch >= 15.0F && absPitch <= 20.0F) {
            return 1.72F;
        }
        if (absPitch >= 10.0F && absPitch <= 15.0F) {
            return 1.72F;
        }
        if (absPitch >= 5.0F && absPitch <= 10.0F) {
            return 1.6F;
        }
        return 1.63F;
    }

    private static float getSpeedForPitchRange(float pitch, float yaw) {
        float absYaw = Math.abs(yaw);
        float absPitch = Math.abs(pitch);
        if ((absYaw >= 40.0F && absYaw <= 50.0F) || (absPitch >= 40.0F && absPitch <= 50.0F)) {
            return 1.8F;
        }
        if ((absYaw >= 35.0F && absYaw <= 55.0F) || (absPitch >= 35.0F && absPitch <= 55.0F)) {
            return 1.81F;
        }
        if ((absYaw >= 30.0F && absYaw <= 60.0F) || (absPitch >= 30.0F && absPitch <= 60.0F)) {
            return 1.81F;
        }
        if ((absYaw >= 25.0F && absYaw <= 65.0F) || (absPitch >= 25.0F && absPitch <= 65.0F)) {
            return 1.7F;
        }
        if ((absYaw >= 20.0F && absYaw <= 70.0F) || (absPitch >= 20.0F && absPitch <= 70.0F)) {
            return 1.7F;
        }
        if ((absYaw >= 15.0F && absYaw <= 75.0F) || (absPitch >= 15.0F && absPitch <= 75.0F)) {
            return 1.67F;
        }
        if ((absYaw >= 10.0F && absYaw <= 80.0F) || (absPitch >= 10.0F && absPitch <= 80.0F)) {
            return 1.58F;
        }
        return 1.58F;
    }
}
