package sky.util.combat;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import sky.access.SkyClientAccess;

public final class RaycastUtil implements SkyClientAccess {
    private RaycastUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static BlockHitResult raycast(double range, Rotation angle, boolean includeFluids) {
        return raycast(Objects.requireNonNull(mc.player).getCameraPosVec(1.0F), range, angle, includeFluids);
    }

    public static BlockHitResult raycast(Vec3d vec, double range, Rotation angle, boolean includeFluids) {
        Entity camera = mc.cameraEntity;
        if (camera == null) {
            return null;
        }

        Vec3d direction = angle.toVector();
        Vec3d end = vec.add(direction.x * range, direction.y * range, direction.z * range);

        World world = mc.world;
        if (world == null) {
            return null;
        }

        RaycastContext.FluidHandling fluidHandling =
            includeFluids ? RaycastContext.FluidHandling.ANY : RaycastContext.FluidHandling.NONE;
        RaycastContext context =
            new RaycastContext(vec, end, RaycastContext.ShapeType.OUTLINE, fluidHandling, camera);
        return world.raycast(context);
    }

    public static BlockHitResult raycast(Vec3d start, Vec3d end, RaycastContext.ShapeType shapeType) {
        return raycast(start, end, shapeType, mc.player);
    }

    public static BlockHitResult raycast(Vec3d start, Vec3d end, RaycastContext.ShapeType shapeType, Entity entity) {
        return mc.world.raycast(
            new RaycastContext(start, end, shapeType, RaycastContext.FluidHandling.NONE, entity));
    }

    public static EntityHitResult raytraceEntity(double range, Rotation angle, Predicate<Entity> filter) {
        Entity camera = mc.cameraEntity;
        if (camera == null) {
            return null;
        }

        Vec3d start = camera.getCameraPosVec(1.0F);
        Vec3d direction = angle.toVector();
        Vec3d end = start.add(direction.x * range, direction.y * range, direction.z * range);
        Box box = camera.getBoundingBox().stretch(direction.multiply(range)).expand(1.0D, 1.0D, 1.0D);

        return ProjectileUtil.raycast(camera, start, end, box,
            entity -> !entity.isSpectator() && filter.test(entity), range * range);
    }

    public static boolean rayTrace(Vec3d clientVec, double range, Box box) {
        Vec3d eyePos = Objects.requireNonNull(mc.player).getEyePos();
        return box.contains(eyePos)
            || box.raycast(eyePos, eyePos.add(clientVec.multiply(range))).isPresent();
    }

    public static boolean rayTraceSingleEntity(float yaw, float pitch, double distance, Entity entity) {
        return rayTraceEntity(yaw, pitch, distance, entity, false, false);
    }

    public static boolean rayTraceEntity(float yaw, float pitch, double distance, Entity entity, boolean checkBlocks) {
        return rayTraceEntity(yaw, pitch, distance, entity, checkBlocks, false);
    }

    public static boolean rayTraceEntity(float yaw, float pitch, double distance, Entity entity,
                                         boolean checkBlocks, boolean allowDoorHits) {
        if (mc.player == null || mc.world == null || entity == null) {
            return false;
        }

        Vec3d eyePos = mc.player.getEyePos();
        Vec3d direction = Vec3d.fromPolar(pitch, yaw);
        Vec3d end = eyePos.add(direction.multiply(distance));

        Box box = entity.getBoundingBox();
        Optional<Vec3d> intersection = box.raycast(eyePos, end);
        boolean intersects = box.contains(eyePos) || intersection.isPresent();
        if (!intersects) {
            return false;
        }
        if (!checkBlocks) {
            return true;
        }

        Vec3d target = box.contains(eyePos) ? eyePos : intersection.get();
        BlockHitResult result = mc.world.raycast(new RaycastContext(
            eyePos, target, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        if (result.getType() == HitResult.Type.MISS) {
            return true;
        }
        return allowDoorHits
            && result.getBlockPos() != null
            && mc.world.getBlockState(result.getBlockPos()).isIn(BlockTags.DOORS);
    }
}
