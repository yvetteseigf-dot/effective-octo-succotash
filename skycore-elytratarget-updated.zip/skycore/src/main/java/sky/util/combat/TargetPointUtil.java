package sky.util.combat;

import net.minecraft.entity.Entity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import sky.access.SkyClientAccess;
import sky.util.math.MathUtil;

public class TargetPointUtil implements SkyClientAccess {
    private static Vec3d rotationPoint = Vec3d.ZERO;
    private static Vec3d rotationMotion = Vec3d.ZERO;

    public static Vec3d getMultipoint(Entity entity, double range) {
        double width = entity.getBoundingBox().getLengthX();
        double height = entity.getBoundingBox().getLengthY();
        double depth = entity.getBoundingBox().getLengthZ();

        if (rotationMotion.equals(Vec3d.ZERO)) {
            rotationMotion = new Vec3d(
                MathUtil.random(-0.05000000074505806D, 0.05000000074505806D),
                MathUtil.random(-0.05000000074505806D, 0.05000000074505806D),
                MathUtil.random(-0.05000000074505806D, 0.05000000074505806D)
            );
        }
        rotationPoint = rotationPoint.add(rotationMotion);

        if (rotationPoint.x >= (width - 0.05D) / 2.0D) {
            rotationMotion = new Vec3d(-MathUtil.random(0.01F, 0.03F), rotationMotion.getY(), rotationMotion.getZ());
        }
        if (rotationPoint.y >= height / 2.0D) {
            rotationMotion = new Vec3d(rotationMotion.getX(), -MathUtil.random(0.01F, 0.03F), rotationMotion.getZ());
        }
        if (rotationPoint.z >= (depth - 0.05D) / 2.0D) {
            rotationMotion = new Vec3d(rotationMotion.getX(), rotationMotion.getY(), -MathUtil.random(0.01F, 0.03F));
        }
        if (rotationPoint.x <= -(width - 0.05D) / 2.0D) {
            rotationMotion = new Vec3d(MathUtil.random(0.01F, 0.029999999329447746D), rotationMotion.getY(), rotationMotion.getZ());
        }
        if (rotationPoint.y <= 0.1D) {
            rotationMotion = new Vec3d(rotationMotion.getX(), MathUtil.random(0.01F, 0.03F), rotationMotion.getZ());
        }
        if (rotationPoint.z <= -(depth - 0.05D) / 2.0D) {
            rotationMotion = new Vec3d(rotationMotion.getX(), rotationMotion.getY(), MathUtil.random(0.01F, 0.03F));
        }

        rotationPoint.add(
            MathUtil.random(-0.029999999329447746D, 0.029999999329447746D),
            0.0D,
            MathUtil.random(-0.029999999329447746D, 0.029999999329447746D)
        );

        if (!RaycastUtil.rayTrace(mc.player.getRotationVector(), range, entity.getBoundingBox())) {
            float halfWidth = (float) (width / 2.0D);
            for (float x = -halfWidth; x <= halfWidth; x += 0.05F) {
                for (float z = -halfWidth; z <= halfWidth; z += 0.05F) {
                    for (float y = 0.05F; y <= entity.getBoundingBox().getLengthY(); y += 0.15F) {
                        Vec3d point = new Vec3d(entity.getX() + x, entity.getY() + y, entity.getZ() + z);
                        Rotation rotation = RotationUtil.fromVec3d(point);
                        if (RaycastUtil.rayTrace(rotation.toVector(), range, entity.getBoundingBox())) {
                            rotationPoint = new Vec3d(x, y, z);
                        }
                    }
                }
            }
        }
        return entity.getPos().add(rotationPoint);
    }

    public static Vec3d getNearestPoint(Entity entity, double range) {
        Vec3d eyePos = mc.player.getCameraPosVec(1.0F);
        double squaredRange = range * range;
        Box box = entity.getBoundingBox();
        Vec3d center = box.getCenter();
        Vec3d closest = null;
        double closestDistance = Double.POSITIVE_INFINITY;

        for (double x = box.minX; x <= box.maxX; x += 0.1D) {
            for (double y = box.minY; y <= box.maxY; y += 0.1D) {
                for (double z = box.minZ; z <= box.maxZ; z += 0.1D) {
                    Vec3d point = new Vec3d(x, y, z);
                    if (eyePos.squaredDistanceTo(point) <= squaredRange) {
                        RaycastContext context = new RaycastContext(
                            eyePos,
                            point,
                            RaycastContext.ShapeType.COLLIDER,
                            RaycastContext.FluidHandling.NONE,
                            mc.player
                        );
                        BlockHitResult hit = mc.world.raycast(context);
                        boolean visible = hit.getType() == HitResult.Type.MISS || hit.getType() != HitResult.Type.BLOCK;
                        if (visible) {
                            double distance = center.squaredDistanceTo(point);
                            if (distance < closestDistance) {
                                closestDistance = distance;
                                closest = point;
                            }
                        }
                    }
                }
            }
        }
        return closest == null ? entity.getBoundingBox().getCenter() : closest;
    }

    public TargetPointUtil() {
    }
}
