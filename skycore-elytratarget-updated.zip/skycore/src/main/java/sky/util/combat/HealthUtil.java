package sky.util.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import sky.module.misc.ScoreboardHealth;

public final class HealthUtil {
    private static final MinecraftClient CLIENT = MinecraftClient.getInstance();

    private HealthUtil() {
    }

    public static float getDisplayHealth(LivingEntity entity) {
        if (ScoreboardHealth.INSTANCE.isEnabled()) {
            return Math.max(0.0F, ScoreboardHealth.getHealth(entity));
        }
        return entity.getHealth();
    }

    public static boolean isConnectedToServer(String serverAddressPart) {
        return CLIENT.getNetworkHandler() != null
                && CLIENT.getNetworkHandler().getServerInfo() != null
                && CLIENT.getNetworkHandler().getServerInfo().address != null
                && CLIENT.getNetworkHandler().getServerInfo().address.toLowerCase()
                .contains(serverAddressPart.toLowerCase());
    }

    public static float getHealth(LivingEntity entity) {
        if (ScoreboardHealth.INSTANCE.isEnabled()) {
            return ScoreboardHealth.getHealth(entity);
        }
        return entity.getHealth() + entity.getAbsorptionAmount();
    }
}
