package sky.util.combat;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

public final class AnchorAimUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private AnchorAimUtil() {
    }

    public static boolean canHitAnchor(Vec3d from, Vec3d target, BlockPos anchorPos) {
        if (mc.world == null || mc.player == null || from == null || target == null || anchorPos == null) {
            return false;
        }

        Vec3d delta = target.subtract(from);
        if (delta.lengthSquared() < 1.0E-8D) {
            return true;
        }

        double range = mc.player.getBlockInteractionRange();
        Vec3d end = from.add(delta.normalize().multiply(range));
        BlockHitResult hit = mc.world.raycast(new RaycastContext(
            from,
            end,
            RaycastContext.ShapeType.OUTLINE,
            RaycastContext.FluidHandling.NONE,
            mc.player
        ));
        return hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(anchorPos);
    }

    private static double dotEye(Direction direction, Vec3d vector) {
        return direction.getOffsetX() * vector.x
            + direction.getOffsetY() * vector.y
            + direction.getOffsetZ() * vector.z;
    }

    private static Vec3d searchFace(Vec3d eyePos, BlockPos ignoredBlockPos, Vec3d center, Direction direction) {
        double centerX = center.x + direction.getOffsetX() * 0.5D;
        double centerY = center.y + direction.getOffsetY() * 0.5D;
        double centerZ = center.z + direction.getOffsetZ() * 0.5D;
        double firstSign;
        double secondSign;
        switch (direction.getAxis()) {
            case X -> {
                firstSign = eyePos.y >= center.y ? 1.0D : -1.0D;
                secondSign = eyePos.z >= center.z ? 1.0D : -1.0D;
            }
            case Y -> {
                firstSign = eyePos.x >= center.x ? 1.0D : -1.0D;
                secondSign = eyePos.z >= center.z ? 1.0D : -1.0D;
            }
            case Z -> {
                firstSign = eyePos.x >= center.x ? 1.0D : -1.0D;
                secondSign = eyePos.y >= center.y ? 1.0D : -1.0D;
            }
            default -> throw new MatchException(null, null);
        }

        double randomOffset = 0.3D + ThreadLocalRandom.current().nextDouble() * 0.1D;
        double[][] offsets = {
            {firstSign * randomOffset, secondSign * randomOffset},
            {firstSign * 0.25D, secondSign * 0.25D},
            {firstSign * 0.2D, secondSign * 0.2D},
            {firstSign * 0.15D, secondSign * 0.15D},
            {firstSign * 0.1D, secondSign * 0.1D},
            {firstSign * 0.3D, 0.0D},
            {0.0D, secondSign * 0.3D},
            {0.0D, 0.0D},
            {-firstSign * 0.3D, secondSign * 0.3D},
            {firstSign * 0.3D, -secondSign * 0.3D},
            {-firstSign * 0.3D, -secondSign * 0.3D},
            {-firstSign * 0.3D, 0.0D},
            {0.0D, -secondSign * 0.3D}
        };
        for (double[] offset : offsets) {
            Vec3d sample = faceSamplePoint(direction.getAxis(), centerX, centerY, centerZ, offset[0], offset[1]);
            if (canHitAnchor(eyePos, sample, ignoredBlockPos)) {
                return sample;
            }
        }
        return null;
    }

    private static Vec3d faceSamplePoint(Direction.Axis axis, double x, double y, double z, double first, double second) {
        return switch (axis) {
            case X -> new Vec3d(x, y + first, z + second);
            case Y -> new Vec3d(x + first, y, z + second);
            case Z -> new Vec3d(x + first, y + second, z);
        };
    }

    public static Vec3d findClearAimPoint(BlockPos anchorPos, float tickDelta) {
        if (anchorPos == null) {
            return null;
        }
        if (mc.player == null || mc.world == null) {
            return Vec3d.ofCenter(anchorPos);
        }

        Vec3d eyePos = mc.player.getCameraPosVec(tickDelta);
        Vec3d center = Vec3d.ofCenter(anchorPos);
        Vec3d toEye = eyePos.subtract(center);
        Direction[] directions = Direction.values().clone();
        Arrays.sort(directions, (first, second) -> Double.compare(dotEye(second, toEye), dotEye(first, toEye)));
        for (Direction direction : directions) {
            if (dotEye(direction, toEye) <= 0.0D) {
                continue;
            }
            Vec3d point = searchFace(eyePos, anchorPos, center, direction);
            if (point != null) {
                return point;
            }
        }
        return center;
    }
}
