package sky.util.combat;

import sky.access.MinecraftAccess;

public final class SensitivityUtil implements MinecraftAccess {
    private SensitivityUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static float getGCD() {
        float sensitivity = (float) (mc.options.getMouseSensitivity().getValue() * 0.6D + 0.2D);
        return sensitivity * sensitivity * sensitivity * 8.0F;
    }

    public static float getGCDValue() {
        return (float) (getGCD() * 0.15D);
    }

    public static float getDeltaMouse(float delta) {
        return Math.round(delta / getGCDValue());
    }

    public static float getDeltaMouse(float delta, float gcdValue) {
        if (gcdValue == 0.0F) {
            return 0.0F;
        }
        return Math.round(delta / gcdValue);
    }

    public static float getSens(float rotation) {
        return getDeltaMouse(rotation) * getGCDValue();
    }

    public static float getSensitivity(float rot) {
        float gcdValue = getGCDValue();
        return getDeltaMouse(rot, gcdValue) * gcdValue;
    }

    public static float getImprovedSensitivity(float rot) {
        float sensitivity = getSensitivity(rot);
        return sensitivity + getRandomSensitivityOffset();
    }

    public static float getRandomSensitivityOffset() {
        return (float) (Math.random() * 0.1D - 0.05D);
    }
}
