package sky.util.combat;

import net.minecraft.client.MinecraftClient;
import sky.access.MinecraftAccess;

/** Snaps rotations onto the discrete steps the vanilla mouse handler is able to produce. */
public final class GcdUtil implements MinecraftAccess {
    private GcdUtil() {
    }

    public static float getGCD() {
        double sensitivity = MinecraftClient.getInstance().options.getMouseSensitivity().getValue() / 0.15F / 8.0D;
        double cbrt = Math.cbrt(sensitivity);
        float scale = (float) ((cbrt - 0.2F) / 0.6F * 0.6D + 0.2D);
        return scale * scale * scale * 8.0F;
    }

    public static float getGCDValue() {
        return (float) (getGCD() * 0.15D);
    }

    public static float getDeltaMouse(float delta) {
        return Math.round(delta / getGCDValue());
    }

    public static float getFixRotate(float rot) {
        return getDeltaMouse(rot) * getGCDValue();
    }

    /**
     * @deprecated Superseded by {@link #getFixRotate(float)}, which this simply delegates to.
     */
    public static float getFixedRotation(float rot) {
        return getFixRotate(rot);
    }
}
