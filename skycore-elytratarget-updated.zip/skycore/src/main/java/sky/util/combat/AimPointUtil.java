package sky.util.combat;

import net.minecraft.entity.Entity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import sky.access.MinecraftAccess;
import sky.util.math.MathUtil;

public final class AimPointUtil implements MinecraftAccess {
    private static Vec3d rotationMotion = Vec3d.ZERO;
    private static Vec3d rotationPoint = Vec3d.ZERO;

    private AimPointUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Vec3d getPoint2(Entity entity) {
        Box box = entity.getBoundingBox();
        double width = box.maxX - box.minX;
        double height = box.maxY - box.minY;
        double depth = box.maxZ - box.minZ;
        double centerX = box.minX + width / 2.0D;
        double centerY = box.minY + height * 0.65D;
        double centerZ = box.minZ + depth / 2.0D;
        double time = System.currentTimeMillis() / 65.0D;
        int entityId = entity.getId();
        double xOffset = Math.sin(time + entityId) * width * 0.7D;
        double yOffset = Math.cos(time * 0.8D + entityId) * height * 0.4D;
        double zOffset = Math.cos(time * 1.2D + entityId) * depth * 0.7D;
        return new Vec3d(centerX + xOffset, centerY + yOffset, centerZ + zOffset);
    }

    public static Vec3d getNearestVisiblePoint(Entity entity, Vec3d preferredPoint, double range) {
        if (preferredPoint == null || mc.player == null || mc.world == null) {
            return preferredPoint;
        }
        if (isPointVisible(entity, preferredPoint, range)) {
            return preferredPoint;
        }

        Box box = entity.getBoundingBox();
        Vec3d closest = null;
        double closestDistance = Double.MAX_VALUE;
        for (double x = box.minX; x <= box.maxX; x += 0.12D) {
            for (double y = box.minY; y <= box.maxY; y += 0.12D) {
                for (double z = box.minZ; z <= box.maxZ; z += 0.12D) {
                    Vec3d candidate = new Vec3d(x, y, z);
                    if (!isPointVisible(entity, candidate, range)) {
                        continue;
                    }
                    double distance = candidate.squaredDistanceTo(preferredPoint);
                    if (distance < closestDistance) {
                        closestDistance = distance;
                        closest = candidate;
                    }
                }
            }
        }
        return closest != null ? closest : preferredPoint;
    }

    public static Vec3d getMultipoint(Entity entity, double range) {
        double width = entity.getBoundingBox().getLengthX();
        double height = entity.getBoundingBox().getLengthY();
        double depth = entity.getBoundingBox().getLengthZ();

        if (rotationMotion.equals(Vec3d.ZERO)) {
            rotationMotion = new Vec3d(
                MathUtil.random(-0.019999999552965164D, 0.019999999552965164D),
                MathUtil.random(-0.019999999552965164D, 0.019999999552965164D),
                MathUtil.random(-0.019999999552965164D, 0.019999999552965164D)
            );
        }
        if (rotationPoint.equals(Vec3d.ZERO)) {
            rotationPoint = new Vec3d(0.0D, height * 0.5D, 0.0D);
        }
        rotationPoint = rotationPoint.add(rotationMotion);

        double xLimit = (width - 0.1D) / 2.0D;
        double zLimit = (depth - 0.1D) / 2.0D;
        if (rotationPoint.x >= xLimit) {
            rotationMotion = new Vec3d(-MathUtil.random(0.005F, 0.015F), rotationMotion.getY(), rotationMotion.getZ());
        } else if (rotationPoint.x <= -xLimit) {
            rotationMotion = new Vec3d(MathUtil.random(0.005F, 0.015F), rotationMotion.getY(), rotationMotion.getZ());
        }
        if (rotationPoint.y >= height * 0.75D) {
            rotationMotion = new Vec3d(rotationMotion.getX(), -MathUtil.random(0.0015F, 0.015F), rotationMotion.getZ());
        } else if (rotationPoint.y <= height * 0.3D) {
            rotationMotion = new Vec3d(rotationMotion.getX(), MathUtil.random(0.0015F, 0.015F), rotationMotion.getZ());
        }
        if (rotationPoint.z >= zLimit) {
            rotationMotion = new Vec3d(rotationMotion.getX(), rotationMotion.getY(), -MathUtil.random(0.005F, 0.015F));
        } else if (rotationPoint.z <= -zLimit) {
            rotationMotion = new Vec3d(rotationMotion.getX(), rotationMotion.getY(), MathUtil.random(0.005F, 0.015F));
        }

        rotationPoint = rotationPoint.add(
            MathUtil.random(-0.05000000074505806D, 0.05000000074505806D),
            0.0D,
            MathUtil.random(-0.05000000074505806D, 0.05000000074505806D)
        );

        if (!RaycastUtil.rayTrace(mc.player.getRotationVector(), range, entity.getBoundingBox())) {
            float halfWidth = (float) (width / 2.0D) * 0.8F;
            for (float x = -halfWidth; x <= halfWidth; x += 0.1F) {
                for (float z = -halfWidth; z <= halfWidth; z += 0.1F) {
                    for (float y = (float) (height * 0.9D); y >= height * 0.3D; y -= 0.1F) {
                        Vec3d point = new Vec3d(entity.getX() + x, entity.getY() + y, entity.getZ() + z);
                        Rotation rotation = RotationUtil.fromVec3d(point.subtract(mc.player.getEyePos()));
                        if (RaycastUtil.rayTrace(rotation.toVector(), range, entity.getBoundingBox())) {
                            rotationPoint = new Vec3d(x, y, z);
                            return entity.getPos().add(rotationPoint);
                        }
                    }
                }
            }
        }
        return entity.getPos().add(rotationPoint);
    }

    public static Vec3d getPoint(Entity entity) {
        Box box = entity.getBoundingBox();
        double width = box.maxX - box.minX;
        double height = box.maxY - box.minY;
        double depth = box.maxZ - box.minZ;
        double centerX = box.minX + width / 2.0D;
        double centerY = box.minY + height * 0.7D;
        double centerZ = box.minZ + depth / 2.0D;
        double time = System.currentTimeMillis() / 50.0D;
        int entityId = entity.getId();
        double xOffset = Math.sin(time + entityId) * width * 0.45D;
        double yOffset = Math.cos(time * 0.8D + entityId) * height * 0.1D;
        double zOffset = Math.cos(time * 1.2D + entityId) * depth * 0.45D;
        return new Vec3d(centerX + xOffset, centerY + yOffset, centerZ + zOffset);
    }

    public static Vec3d getRotationPoint() {
        return rotationPoint;
    }

    public static Vec3d getNearestPoint(Entity entity) {
        Box box = entity.getBoundingBox();
        Vec3d closest = null;
        double closestDistance = Double.MAX_VALUE;
        for (double x = box.minX; x <= box.maxX; x += 0.1D) {
            for (double y = box.minY; y <= box.maxY; y += 0.1D) {
                for (double z = box.minZ; z <= box.maxZ; z += 0.1D) {
                    Vec3d point = new Vec3d(x, y, z);
                    double distance = mc.player.getEyePos().distanceTo(point);
                    if (distance < closestDistance) {
                        closestDistance = distance;
                        closest = point;
                    }
                }
            }
        }
        return closest;
    }

    private static boolean isPointVisible(Entity entity, Vec3d point, double range) {
        Vec3d eyePos = mc.player.getEyePos();
        double distance = eyePos.distanceTo(point);
        if (distance > range) {
            return false;
        }
        Vec3d direction = point.subtract(eyePos).normalize();
        if (!RaycastUtil.rayTrace(direction, distance + 0.2D, entity.getBoundingBox())) {
            return false;
        }

        BlockHitResult hit = RaycastUtil.raycast(
            eyePos,
            point,
            RaycastContext.ShapeType.COLLIDER,
            mc.player
        );
        return hit.getType() == HitResult.Type.MISS
            || eyePos.squaredDistanceTo(hit.getPos()) >= eyePos.squaredDistanceTo(point) - 1.0E-4D;
    }
}
