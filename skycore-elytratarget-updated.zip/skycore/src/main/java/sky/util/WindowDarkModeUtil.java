package sky.util;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.WinDef.HWND;
import com.sun.jna.win32.StdCallLibrary;
import org.lwjgl.glfw.GLFWNativeWin32;

public class WindowDarkModeUtil {
    public static void setDarkMode(long windowHandle) {
        String operatingSystem = System.getProperty("os.name").toLowerCase();
        if (operatingSystem.contains("linux")) {
            return;
        }
        long nativeHandle = GLFWNativeWin32.glfwGetWin32Window(windowHandle);
        HWND window = new HWND(new Pointer(nativeHandle));
        Memory enabled = new Memory(4L);
        enabled.setInt(0L, 1);
        DwmApi.INSTANCE.DwmSetWindowAttribute(window, 20, enabled, 4);
    }

    interface DwmApi extends StdCallLibrary {
        DwmApi INSTANCE = Native.load("dwmapi", DwmApi.class);

        int DwmSetWindowAttribute(HWND window, int attribute, Pointer value, int valueSize);
    }
}
