package sky.util;

import sky.access.MinecraftAccess;
import sky.module.misc.ClientSounds;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import java.io.BufferedInputStream;
import java.io.InputStream;

public final class SoundUtil implements MinecraftAccess {
    private SoundUtil() {
    }

    private static void playSoundInternal(String sound, float volume) {
        try {
            InputStream resource = openSoundStream(sound);
            if (resource == null) {
                return;
            }

            try (InputStream ignoredClose = resource;
                 AudioInputStream source = AudioSystem.getAudioInputStream(new BufferedInputStream(resource))) {
                AudioFormat sourceFormat = source.getFormat();
                AudioFormat targetFormat = new AudioFormat(
                        AudioFormat.Encoding.PCM_SIGNED,
                        sourceFormat.getSampleRate(),
                        16,
                        sourceFormat.getChannels(),
                        sourceFormat.getChannels() * 2,
                        sourceFormat.getSampleRate(),
                        false);
                try (AudioInputStream converted = AudioSystem.getAudioInputStream(targetFormat, source)) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(converted);
                    applyVolume(clip, volume);
                    clip.start();
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static InputStream openSoundStream(String sound) {
        InputStream wav = SoundUtil.class.getResourceAsStream("/assets/skycore/sounds/" + sound + ".wav");
        if (wav != null) {
            return wav;
        }
        return SoundUtil.class.getResourceAsStream("/assets/skycore/sounds/" + sound + ".ogg");
    }

    private static void applyVolume(Clip clip, float volume) {
        if (!clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            return;
        }

        FloatControl control = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
        float minimum = control.getMinimum();
        float maximum = control.getMaximum();
        volume = Math.max(0.0F, Math.min(1.0F, volume));
        if (volume == 0.0F) {
            control.setValue(minimum);
            return;
        }

        float decibels = (float) (20.0D * Math.log10(volume));
        control.setValue(Math.max(minimum, Math.min(maximum, decibels)));
    }

    public static void playSound(String sound) {
        if (sound == null || sound.isEmpty() || !ClientSounds.INSTANCE.isEnabled()) {
            return;
        }

        float volume = ClientSounds.INSTANCE.volume.getCurrent() / 100.0F;
        Thread thread = new Thread(() -> {
            try {
                playSoundInternal(sound, volume);
            } catch (Throwable ignored) {
            }
        }, "Skycore-Sound");
        thread.setDaemon(true);
        thread.start();
    }
}
