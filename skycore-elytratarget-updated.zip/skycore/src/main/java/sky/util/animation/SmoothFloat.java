package sky.util.animation;

/** A float value that approaches its target by a fixed fraction per update. */
public final class SmoothFloat {
    private static final float SNAP_THRESHOLD = 0.01F;

    private final float smoothing;
    private float target;
    private float value;

    public SmoothFloat(float smoothing) {
        this.smoothing = smoothing;
    }

    public boolean isSettled() {
        return Math.abs(target - value) <= SNAP_THRESHOLD;
    }

    public void update() {
        if (isSettled()) {
            value = target;
            return;
        }
        value += (target - value) * smoothing;
    }

    public float get() {
        return value;
    }

    public void setTarget(float target) {
        this.target = target;
    }

    public float getTarget() {
        return target;
    }

    public void setImmediate(float value) {
        this.value = value;
        target = value;
    }
}
