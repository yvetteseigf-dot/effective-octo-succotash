package sky.util.animation;

import net.minecraft.util.math.MathHelper;

public final class TweenFloat {
    private float value;
    private float startValue;
    private boolean running;
    private float targetValue;
    private long durationMs = 200L;
    private long startMs;

    public TweenFloat(float value) {
        this.value = value;
        this.startValue = value;
        this.targetValue = value;
    }

    public float getTarget() {
        return targetValue;
    }

    public float get() {
        return value;
    }

    public boolean isRunning() {
        return running;
    }

    public float update() {
        if (!running) {
            return value;
        }

        float progress = MathHelper.clamp(
                (float) (System.currentTimeMillis() - startMs) / (float) durationMs,
                0.0F,
                1.0F
        );
        float inverseProgress = 1.0F - progress;
        float easedProgress = 1.0F - inverseProgress * inverseProgress * inverseProgress;
        value = startValue + (targetValue - startValue) * easedProgress;

        if (progress >= 1.0F) {
            value = targetValue;
            running = false;
        }
        return value;
    }

    public boolean isDone() {
        return !running;
    }

    public void setDuration(long durationMs) {
        this.durationMs = Math.max(1L, durationMs);
    }

    public void snap(float value) {
        this.value = value;
        this.startValue = value;
        this.targetValue = value;
        this.running = false;
    }

    public void animateTo(float targetValue) {
        if (Math.abs(targetValue - this.targetValue) < 0.0001F) {
            return;
        }
        this.startValue = value;
        this.targetValue = targetValue;
        this.startMs = System.currentTimeMillis();
        this.running = true;
    }
}
