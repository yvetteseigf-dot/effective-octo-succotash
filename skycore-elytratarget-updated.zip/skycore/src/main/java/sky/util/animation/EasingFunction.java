package sky.util.animation;

/** Maps a normalized animation progress value to an eased progress value. */
@FunctionalInterface
public interface EasingFunction {
    double apply(double progress);
}
