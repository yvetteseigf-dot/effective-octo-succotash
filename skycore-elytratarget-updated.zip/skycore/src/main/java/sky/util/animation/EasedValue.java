package sky.util.animation;

public class EasedValue {
    private float value;
    private long duration;
    private float startValue;
    private boolean done;
    private boolean direction;
    private Easing easing;
    private float targetValue;
    private long startTime;

    public EasedValue(long duration, Easing easing) {
        this(duration, 0.0F, easing);
    }

    public EasedValue(long duration, float value, Easing easing) {
        this.duration = duration;
        this.easing = easing;
        this.value = value;
        startValue = value;
        targetValue = value;
        done = true;
    }

    public void setEasing(Easing easing) {
        this.easing = easing;
    }

    public boolean isDone() {
        return done;
    }

    public float update(float target) {
        long now = System.currentTimeMillis();
        if (target != targetValue) {
            startValue = value;
            targetValue = target;
            startTime = now;
            done = false;
        }
        long elapsed = now - startTime;
        if (elapsed >= duration) {
            value = targetValue;
            done = true;
            return value;
        }
        float progress = (float) elapsed / duration;
        float eased = easing.ease(progress, 0.0F, 1.0F, 1.0F);
        value = startValue + (targetValue - startValue) * eased;
        return value;
    }

    public void reset(float value) {
        this.value = value;
        startValue = value;
        targetValue = value;
        done = true;
    }

    public Easing getEasing() {
        return easing;
    }

    public float getValue() {
        return value;
    }

    public float getStartValue() {
        return startValue;
    }

    public void setTargetValue(float targetValue) {
        this.targetValue = targetValue;
    }

    public void setDirection(boolean direction) {
        this.direction = direction;
    }

    public void update(boolean direction) {
        update(direction ? 1.0F : 0.0F);
    }

    public float getTargetValue() {
        return targetValue;
    }

    public void setStartValue(float startValue) {
        this.startValue = startValue;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public long getDuration() {
        return duration;
    }

    public void setValue(float value) {
        this.value = value;
        startValue = value;
        targetValue = value;
        done = true;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public void animateTo(float target) {
        if (target != targetValue) {
            startValue = value;
            targetValue = target;
            startTime = System.currentTimeMillis();
            done = false;
        }
    }

    public boolean isDirection() {
        return direction;
    }

    public void reset() {
        reset(0.0F);
    }

    public void setDone(boolean done) {
        this.done = done;
    }

    public float update() {
        return update(targetValue);
    }
}
