package sky.util.render;

public final class GuiCoordinateUtil {
    private GuiCoordinateUtil() {
    }

    public static boolean isHovered(double mouseX, double mouseY, float x, float y, float width, float height) {
        float hudX = toHudX(mouseX);
        float hudY = toHudY(mouseY);
        return hudX >= x && hudX <= x + width && hudY >= y && hudY <= y + height;
    }

    public static float toHudY(double coordinate) {
        return HudScaleUtil.toHudY(coordinate);
    }

    public static float toHudX(double coordinate) {
        return HudScaleUtil.toHudX(coordinate);
    }
}
