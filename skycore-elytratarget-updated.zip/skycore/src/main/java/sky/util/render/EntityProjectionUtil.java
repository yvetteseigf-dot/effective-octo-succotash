package sky.util.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4d;
import org.joml.Vector4f;
import sky.mixin.render.WorldRendererAccessor;
import sky.render.ProjectionMatrixCapture;

public final class EntityProjectionUtil {
    private static final MinecraftClient CLIENT = MinecraftClient.getInstance();
    private static final Matrix4f MATRIX_PROJ = new Matrix4f();
    private static final Vector3f PROJECT_TARGET = new Vector3f();
    private static final Vector4f TRANSFORMED = new Vector4f();
    private static final Vec3d[] CORNER_BUFFER = new Vec3d[8];

    private EntityProjectionUtil() {
    }

    public static boolean isInView(Entity entity) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!(client.worldRenderer instanceof WorldRendererAccessor renderer)) {
            return false;
        }
        Frustum frustum = renderer.skycore$getFrustum();
        return frustum == null || frustum.isVisible(entity.getBoundingBox());
    }

    private static Vec3d[] getBoundingCorners(Entity entity, Vec3d position) {
        var box = entity.getBoundingBox();
        double minX = box.minX - entity.getX() + position.x - 0.1D;
        double minY = box.minY - entity.getY() + position.y - 0.1D;
        double minZ = box.minZ - entity.getZ() + position.z - 0.1D;
        double maxX = box.maxX - entity.getX() + position.x + 0.1D;
        double maxY = box.maxY - entity.getY() + position.y + 0.1D;
        double maxZ = box.maxZ - entity.getZ() + position.z + 0.1D;
        CORNER_BUFFER[0] = new Vec3d(minX, minY, minZ);
        CORNER_BUFFER[1] = new Vec3d(minX, maxY, minZ);
        CORNER_BUFFER[2] = new Vec3d(maxX, minY, minZ);
        CORNER_BUFFER[3] = new Vec3d(maxX, maxY, minZ);
        CORNER_BUFFER[4] = new Vec3d(minX, minY, maxZ);
        CORNER_BUFFER[5] = new Vec3d(minX, maxY, maxZ);
        CORNER_BUFFER[6] = new Vec3d(maxX, minY, maxZ);
        CORNER_BUFFER[7] = new Vec3d(maxX, maxY, maxZ);
        return CORNER_BUFFER;
    }

    public static Vector4d getVector4D(Entity entity, float tickDelta) {
        return projectBounds(entity, tickDelta, true);
    }

    public static float[] projectGuiPoint(Entity entity, float tickDelta, float heightProgress) {
        Vec3d point = interpolate(entity, tickDelta).add(0.0D, entity.getHeight() * heightProgress, 0.0D);
        Vec3d projected = worldSpaceToGuiSpace(point);
        if (projected.z <= 0.0D || projected.z >= 1.0D) {
            return null;
        }
        float x = (float) projected.x;
        float y = (float) projected.y;
        return new float[]{x, y, y, y};
    }

    private static Vec3d toGuiSpace(Vector3f projected) {
        double x = projected.x / CLIENT.getWindow().getScaleFactor();
        double y = (CLIENT.getWindow().getHeight() - projected.y) / CLIENT.getWindow().getScaleFactor();
        return new Vec3d(x, y, projected.z);
    }

    public static Vec3d interpolate(Entity entity, float tickDelta) {
        return new Vec3d(
            MathHelper.lerp(tickDelta, entity.lastRenderX, entity.getX()),
            MathHelper.lerp(tickDelta, entity.lastRenderY, entity.getY()),
            MathHelper.lerp(tickDelta, entity.lastRenderZ, entity.getZ())
        );
    }

    public static Vec3d worldSpaceToGuiSpace(Vec3d position) {
        if (!ProjectionMatrixCapture.isCaptured() || CLIENT.gameRenderer == null) {
            return new Vec3d(0.0D, 0.0D, -1.0D);
        }

        Vector3f relative = position
            .subtract(CLIENT.gameRenderer.getCamera().getPos())
            .toVector3f();
        int[] viewport = ProjectionMatrixCapture.getViewport();
        TRANSFORMED.set(relative.x, relative.y, relative.z, 1.0F)
            .mul(ProjectionMatrixCapture.getWorldSpace());
        MATRIX_PROJ.set(ProjectionMatrixCapture.getProjection());
        MATRIX_PROJ.project(
            TRANSFORMED.x(),
            TRANSFORMED.y(),
            TRANSFORMED.z(),
            viewport,
            PROJECT_TARGET
        );
        return toGuiSpace(PROJECT_TARGET);
    }

    public static Vector4d getGuiVector4D(Entity entity, float tickDelta) {
        return projectBounds(entity, tickDelta, false);
    }

    private static Vector4d projectBounds(Entity entity, float tickDelta, boolean hudSpace) {
        Vector4d bounds = null;
        for (Vec3d corner : getBoundingCorners(entity, interpolate(entity, tickDelta))) {
            Vec3d projected = hudSpace ? worldSpaceToHudSpace(corner) : worldSpaceToGuiSpace(corner);
            if (projected.z > 0.0D && projected.z < 1.0D) {
                if (bounds == null) {
                    bounds = new Vector4d(projected.x, projected.y, projected.z, 0.0D);
                }
                bounds.x = Math.min(projected.x, bounds.x);
                bounds.y = Math.min(projected.y, bounds.y);
                bounds.z = Math.max(projected.x, bounds.z);
                bounds.w = Math.max(projected.y, bounds.w);
            }
        }
        return bounds;
    }

    public static Vec3d worldSpaceToScreenSpace(Vec3d position) {
        return worldSpaceToHudSpace(position);
    }

    public static Vec3d worldSpaceToHudSpace(Vec3d position) {
        Vec3d guiPosition = worldSpaceToGuiSpace(position);
        return new Vec3d(
            HudScaleUtil.toHudX(guiPosition.x),
            HudScaleUtil.toHudY(guiPosition.y),
            guiPosition.z
        );
    }
}
