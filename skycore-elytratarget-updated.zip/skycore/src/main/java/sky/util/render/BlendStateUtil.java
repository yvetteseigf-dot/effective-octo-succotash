package sky.util.render;

import com.mojang.blaze3d.systems.RenderSystem;

public final class BlendStateUtil {
    private BlendStateUtil() {
    }

    public static void runBlended(Runnable action) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        try {
            action.run();
        } finally {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
        }
    }
}
