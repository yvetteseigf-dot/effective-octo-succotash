package sky.util.render;

import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import sky.access.MinecraftAccess;
import sky.util.math.ScreenPoint;

public final class CameraProjectionUtil implements MinecraftAccess {
    private CameraProjectionUtil() {
    }

    public static ScreenPoint project2D(double x, double y, double z) {
        if (mc.gameRenderer == null || mc.gameRenderer.getCamera() == null) {
            return new ScreenPoint(Float.MAX_VALUE, Float.MAX_VALUE);
        }

        Camera camera = mc.gameRenderer.getCamera();
        Vec3d cameraPos = camera.getPos();
        Vector3f relative = new Vector3f(
            (float) (x - cameraPos.x),
            (float) (y - cameraPos.y),
            (float) (z - cameraPos.z)
        );
        relative.rotate(new Quaternionf(camera.getRotation()).conjugate());
        if (relative.z >= -0.01F) {
            return new ScreenPoint(Float.MAX_VALUE, Float.MAX_VALUE);
        }

        int fov = mc.options.getFov().getValue();
        float tangent = (float) Math.tan(Math.toRadians(fov) / 2.0D);
        float aspect = Math.max(
            0.1F,
            (float) mc.getWindow().getFramebufferWidth() / Math.max(1, mc.getWindow().getFramebufferHeight())
        );
        float normalizedX = relative.x / -relative.z / (tangent * aspect);
        float normalizedY = relative.y / -relative.z / tangent;
        float screenX = mc.getWindow().getScaledWidth() * 0.5F
            + normalizedX * mc.getWindow().getScaledWidth() * 0.5F;
        float screenY = mc.getWindow().getScaledHeight() * 0.5F
            - normalizedY * mc.getWindow().getScaledHeight() * 0.5F;
        return new ScreenPoint(screenX, screenY);
    }

    public static ScreenPoint project2D(Vec3d position) {
        return project2D(position.x, position.y, position.z);
    }
}
