package sky.util.render;

import net.minecraft.util.math.MathHelper;

public final class ArgbUtil {
    private ArgbUtil() {
    }

    public static int blue(int color) {
        return color & 255;
    }

    public static int multAlpha(int color, float multiplier) {
        return getColor(red(color), green(color), blue(color), Math.round(alpha(color) * multiplier));
    }

    public static int alpha(int color) {
        return color >> 24 & 255;
    }

    public static int green(int color) {
        return color >> 8 & 255;
    }

    public static String removeFormatting(String text) {
        return text == null ? "" : text.replaceAll("§.", "");
    }

    public static int red(int color) {
        return color >> 16 & 255;
    }

    private static int getColor(int red, int green, int blue, int alpha) {
        return MathHelper.clamp(alpha, 0, 255) << 24
                | MathHelper.clamp(red, 0, 255) << 16
                | MathHelper.clamp(green, 0, 255) << 8
                | MathHelper.clamp(blue, 0, 255);
    }
}
