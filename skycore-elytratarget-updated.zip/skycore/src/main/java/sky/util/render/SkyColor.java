package sky.util.render;

import java.awt.Color;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;
import sky.render.shader.ShaderColorState;
import sky.util.math.NumberUtil;

public class SkyColor extends Color {
    public static final SkyColor BLACK = new SkyColor(0.0D, 0.0D, 0.0D);
    public static final SkyColor WHITE = new SkyColor(255.0D, 255.0D, 255.0D);
    public static final SkyColor CYAN = new SkyColor(0.0D, 255.0D, 255.0D);
    public static final SkyColor RED = new SkyColor(255.0D, 0.0D, 0.0D);
    public static final SkyColor BLUE = new SkyColor(0.0D, 0.0D, 255.0D);
    public static final SkyColor YELLOW = new SkyColor(255.0D, 255.0D, 0.0D);
    public static final SkyColor GREEN = new SkyColor(0.0D, 255.0D, 0.0D);
    public static final SkyColor ORANGE = new SkyColor(255.0D, 165.0D, 0.0D);
    public static final SkyColor GRAY = new SkyColor(128.0D, 128.0D, 128.0D);
    public static final SkyColor PURPLE = new SkyColor(128.0D, 0.0D, 128.0D);
    public static final SkyColor LIGHT_PURPLE = new SkyColor(200.0D, 160.0D, 255.0D);
    public static final SkyColor TRANSPARENT = new SkyColor(0.0D, 0.0D, 0.0D, 0.0D);

    private static final ConcurrentHashMap<ColorKey, CacheEntry> colorCache = new ConcurrentHashMap<>();
    private static final DelayQueue<CacheEntry> cleanupQueue = new DelayQueue<>();

    public SkyColor(int hex) {
        super(hex);
    }

    public SkyColor(Color color) {
        super(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    public SkyColor(double r, double g, double b) {
        super(fix(r), fix(g), fix(b));
    }

    public SkyColor(double r, double g, double b, double a) {
        super(fix(r), fix(g), fix(b), fix(a));
    }

    public Color getColor() {
        return new Color(getRed(), getGreen(), getBlue(), getAlpha());
    }

    public SkyColor alpha(float alpha) {
        return new SkyColor(getRed(), getGreen(), getBlue(), getAlpha() * (alpha / 255.0F));
    }

    public SkyColor alpha(double alpha) {
        return new SkyColor(getRed(), getGreen(), getBlue(), getAlpha() * (alpha / 255.0D));
    }

    public SkyColor withAlphaPercentage(float alphaPercentage) {
        return new SkyColor(getRed(), getGreen(), getBlue(),
            NumberUtil.getPercentage((int) alphaPercentage, 100));
    }

    public static SkyColor decodeColor(String nm) {
        Integer decoded = Integer.decode(nm);
        int value = decoded.intValue();
        return new SkyColor(value >> 16 & 255, value >> 8 & 255, value & 255);
    }

    private static int fix(double val) {
        return (int) Math.max(0.0D, Math.min(255.0D, val));
    }

    public static int getColor(int red, int green, int blue, int alpha) {
        ColorKey key = new ColorKey(red, green, blue, alpha);
        CacheEntry entry = colorCache.computeIfAbsent(key, k -> {
            CacheEntry created = new CacheEntry(k, computeColor(red, green, blue, alpha), 60000L);
            cleanupQueue.offer(created);
            return created;
        });
        return entry.getColor();
    }

    private static int computeColor(int red, int green, int blue, int alpha) {
        return MathHelper.clamp(alpha, 0, 255) << 24
            | MathHelper.clamp(red, 0, 255) << 16
            | MathHelper.clamp(green, 0, 255) << 8
            | MathHelper.clamp(blue, 0, 255);
    }

    public static int applyAlpha(int color, int alpha) {
        return MathHelper.clamp(alpha, 0, 255) << 24 | color & 0xFFFFFF;
    }

    public static int replAlpha(int color, float alpha) {
        return getColor(red(color), green(color), blue(color), (int) alpha);
    }

    public static int multAlpha(int color, float percent01) {
        return getColor(red(color), green(color), blue(color), Math.round(a(color) * percent01));
    }

    public static int rainbow(int speed, int index, float saturation, float brightness, float opacity) {
        int hue = (int) ((System.currentTimeMillis() / speed + index) % 360L);
        float hueFraction = hue / 360.0F;
        int rgb = Color.HSBtoRGB(hueFraction, saturation, brightness);
        return getColor(red(rgb), green(rgb), blue(rgb), Math.round(opacity * 255.0F));
    }

    public static int fade(int speed, int index, int first, int second) {
        int angle = (int) ((System.currentTimeMillis() / speed + index) % 360L);
        angle = angle >= 180 ? 360 - angle : angle;
        return overCol(first, second, angle / 180.0F);
    }

    public static int overCol(int color1, int color2, float percent01) {
        float progress = MathHelper.clamp(percent01, 0.0F, 1.0F);
        return getColor(
            NumberUtil.lerp(r(color1), r(color2), progress),
            NumberUtil.lerp(g(color1), g(color2), progress),
            NumberUtil.lerp(b(color1), b(color2), progress),
            NumberUtil.lerp(a(color1), a(color2), progress));
    }

    public static int interpolateColor(int color1, int color2, float amount) {
        amount = Math.min(1.0F, Math.max(0.0F, amount));

        int red1 = getRed(color1);
        int green1 = getGreen(color1);
        int blue1 = getBlue(color1);
        int alpha1 = getAlpha(color1);

        int red2 = getRed(color2);
        int green2 = getGreen(color2);
        int blue2 = getBlue(color2);
        int alpha2 = getAlpha(color2);

        int red = interpolateInt(red1, red2, amount);
        int green = interpolateInt(green1, green2, amount);
        int blue = interpolateInt(blue1, blue2, amount);
        int alpha = interpolateInt(alpha1, alpha2, amount);

        return alpha << 24 | red << 16 | green << 8 | blue;
    }

    public static int interpolateInt(int oldValue, int newValue, double interpolationValue) {
        return interpolate(oldValue, newValue, (float) interpolationValue).intValue();
    }

    public static Double interpolate(double oldValue, double newValue, double interpolationValue) {
        return oldValue + (newValue - oldValue) * interpolationValue;
    }

    public static void color(int color) {
        color(color, (color >> 24 & 255) / 255.0F);
    }

    public static void color(int color, float alpha) {
        float red = (color >> 16 & 255) / 255.0F;
        float green = (color >> 8 & 255) / 255.0F;
        float blue = (color & 255) / 255.0F;
        ShaderColorState.color4f(red, green, blue, alpha);
    }

    public static void glSetupColor(Color color) {
        GL11.glColor4f(
            color.getRed() / 255.0F,
            color.getGreen() / 255.0F,
            color.getBlue() / 255.0F,
            color.getAlpha() / 255.0F);
    }

    public static float[] rgb(int color) {
        return new float[] {
            (color >> 16 & 255) / 255.0F,
            (color >> 8 & 255) / 255.0F,
            (color & 255) / 255.0F,
            (color >> 24 & 255) / 255.0F
        };
    }

    public static float[] getRGBAf(int c) {
        return new float[] {
            r(c) / 255.0F,
            g(c) / 255.0F,
            b(c) / 255.0F,
            a(c) / 255.0F
        };
    }

    public static float[] getRGBAFloat(SkyColor color) {
        return new float[] {
            color.getRed() / 255.0F,
            color.getGreen() / 255.0F,
            color.getBlue() / 255.0F,
            color.getAlpha() / 255.0F
        };
    }

    public static int getRed(int hex) {
        return hex >> 16 & 255;
    }

    public static int getGreen(int hex) {
        return hex >> 8 & 255;
    }

    public static int getBlue(int hex) {
        return hex & 255;
    }

    public static int getAlpha(int hex) {
        return hex >> 24 & 255;
    }

    public static int r(int c) {
        return c >> 16 & 255;
    }

    public static int g(int c) {
        return c >> 8 & 255;
    }

    public static int b(int c) {
        return c & 255;
    }

    public static int a(int c) {
        return c >> 24 & 255;
    }

    public static int red(int c) {
        return c >> 16 & 255;
    }

    public static int green(int c) {
        return c >> 8 & 255;
    }

    public static int blue(int c) {
        return c & 255;
    }

    static class ColorKey {
        final int red;
        final int green;
        final int blue;
        final int alpha;

        public ColorKey(int red, int green, int blue, int alpha) {
            this.red = red;
            this.green = green;
            this.blue = blue;
            this.alpha = alpha;
        }

        public int getRed() {
            return red;
        }

        public int getGreen() {
            return green;
        }

        public int getBlue() {
            return blue;
        }

        public int getAlpha() {
            return alpha;
        }

        protected boolean canEqual(Object other) {
            return other instanceof ColorKey;
        }

        @Override
        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof ColorKey)) {
                return false;
            }
            ColorKey other = (ColorKey) o;
            if (!other.canEqual(this)) {
                return false;
            }
            if (getRed() != other.getRed()) {
                return false;
            }
            if (getGreen() != other.getGreen()) {
                return false;
            }
            if (getBlue() != other.getBlue()) {
                return false;
            }
            return getAlpha() == other.getAlpha();
        }

        @Override
        public int hashCode() {
            int result = 59 + getRed();
            result = result * 59 + getGreen();
            result = result * 59 + getBlue();
            result = result * 59 + getAlpha();
            return result;
        }
    }

    static class CacheEntry implements Delayed {
        private final ColorKey key;
        private final int color;
        private final long expirationTime;

        CacheEntry(ColorKey key, int color, long ttl) {
            this.key = key;
            this.color = color;
            this.expirationTime = System.currentTimeMillis() + ttl;
        }

        public ColorKey getKey() {
            return key;
        }

        public int getColor() {
            return color;
        }

        public long getExpirationTime() {
            return expirationTime;
        }

        public boolean isExpired() {
            return System.currentTimeMillis() > expirationTime;
        }

        @Override
        public long getDelay(TimeUnit unit) {
            long remaining = expirationTime - System.currentTimeMillis();
            return unit.convert(remaining, TimeUnit.MILLISECONDS);
        }

        @Override
        public int compareTo(Delayed other) {
            if (other instanceof CacheEntry) {
                return Long.compare(expirationTime, ((CacheEntry) other).expirationTime);
            }
            return 0;
        }
    }
}
