package sky.util;

/** Reusable elapsed-time cooldown timer. */
public class CooldownTimer {
    private long lastTime;

    public CooldownTimer() {
        reset();
    }

    public boolean finished(double delay) {
        return System.currentTimeMillis() - delay >= lastTime;
    }

    public void reset() {
        lastTime = System.currentTimeMillis();
    }

    public void setLastTime(long lastTime) {
        this.lastTime = lastTime;
    }

    public boolean every(long delay) {
        if (!finished((double) delay)) {
            return false;
        }
        reset();
        return true;
    }

    public long getElapsedTime() {
        return System.currentTimeMillis() - lastTime;
    }

    public long getLastTime() {
        return lastTime;
    }
}
