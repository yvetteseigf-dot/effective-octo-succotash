package sky.util.inventory;

import net.minecraft.util.Formatting;

public final class EffectDisplayUtil {
    private EffectDisplayUtil() {
    }

    public static String formatDuration(int durationTicks) {
        int seconds = durationTicks / 20;
        int minutes = seconds / 60;
        seconds %= 60;
        return String.format("%d:%02d", minutes, seconds);
    }

    public static Formatting getEffectColor(String effectId) {
        effectId = effectId.toLowerCase();
        if (effectId.contains("strength")) {
            return Formatting.RED;
        }
        if (effectId.contains("fire_resistance")) {
            return Formatting.GOLD;
        }
        if (effectId.contains("speed")) {
            return Formatting.AQUA;
        }
        if (effectId.contains("absorption")) {
            return Formatting.YELLOW;
        }
        if (effectId.contains("regeneration")) {
            return Formatting.LIGHT_PURPLE;
        }
        if (effectId.contains("jump_boost")) {
            return Formatting.GREEN;
        }
        return Formatting.WHITE;
    }

    public static int getEffectArgb(String effectId) {
        Integer color = getEffectColor(effectId).getColorValue();
        return color != null ? 0xFF000000 | color : -1;
    }
}
