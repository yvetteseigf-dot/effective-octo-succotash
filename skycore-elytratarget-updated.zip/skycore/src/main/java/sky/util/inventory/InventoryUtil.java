package sky.util.inventory;

import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import it.unimi.dsi.fastutil.ints.IntPredicate;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.EnderChestInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.consume.UseAction;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.PlayerInput;
import sky.access.SkyClientAccess;
import sky.scheduler.TaskRunner;
import sky.module.movement.Sprint;
import sky.util.math.MathUtil;

public final class InventoryUtil implements SkyClientAccess {
    public static final List<KeyBinding> moveKeys = List.of(
        mc.options.forwardKey,
        mc.options.backKey,
        mc.options.leftKey,
        mc.options.rightKey,
        mc.options.jumpKey
    );

    private InventoryUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Stream<Slot> slots() {
        return mc.player.currentScreenHandler.slots.stream();
    }

    public static Slot getSlot(Predicate<Slot> filter) {
        return slots().filter(filter).findFirst().orElse(null);
    }

    public static Slot getSlot(Predicate<Slot> filter, Comparator<Slot> comparator) {
        return slots().filter(filter).max(comparator).orElse(null);
    }

    public static Slot getSlot(Item item) {
        return getSlot(item, slot -> true);
    }

    public static Slot getSlot(Item item, Predicate<Slot> filter) {
        return getSlot(item, Comparator.comparingInt(slot -> 0), filter);
    }

    public static Slot getSlot(Item item, Comparator<Slot> comparator, Predicate<Slot> filter) {
        return slots()
            .filter(slot -> slot.getStack().getItem().equals(item))
            .filter(filter)
            .max(comparator)
            .orElse(null);
    }

    public static Slot getSlot(ItemStack stack) {
        return getSlot(stack, slot -> true);
    }

    public static Slot getSlot(ItemStack stack, Predicate<Slot> filter) {
        return getSlot(stack, Comparator.comparingInt(slot -> 0), filter);
    }

    public static Slot getSlot(ItemStack stack, Comparator<Slot> comparator, Predicate<Slot> filter) {
        return slots()
            .filter(slot -> slot.getStack().getName().equals(stack.getName())
                && slot.getStack().getItem() == stack.getItem())
            .filter(filter)
            .max(comparator)
            .orElse(null);
    }

    public static Slot getSlot(List<Item> items) {
        return slots()
            .filter(slot -> items.contains(slot.getStack().getItem()))
            .findFirst()
            .orElse(null);
    }

    public static Slot mainHandSlot() {
        long slotCount = slots().count();
        int hotbarOffset = slotCount == 46L ? 10 : 9;
        return slots()
            .toList()
            .get(Math.toIntExact(slotCount - hotbarOffset + mc.player.getInventory().selectedSlot));
    }

    public static int getCount(Predicate<Slot> filter) {
        return slots().filter(filter).mapToInt(slot -> slot.getStack().getCount()).sum();
    }

    public static Slot getPotion(RegistryEntry<StatusEffect> effect) {
        return slots()
            .filter(slot -> {
                PotionContentsComponent contents = slot.getStack().get(DataComponentTypes.POTION_CONTENTS);
                return contents != null
                    && StreamSupport.stream(contents.getEffects().spliterator(), false)
                        .anyMatch(instance -> instance.getEffectType().equals(effect));
            })
            .findFirst()
            .orElse(null);
    }

    public static Slot getPotionFromCategory(StatusEffectCategory category) {
        return slots()
            .filter(slot -> {
                ItemStack stack = slot.getStack();
                PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
                if (!stack.getItem().equals(Items.SPLASH_POTION) || contents == null) {
                    return false;
                }

                StatusEffectCategory opposite = category.equals(StatusEffectCategory.BENEFICIAL)
                    ? StatusEffectCategory.HARMFUL
                    : StatusEffectCategory.BENEFICIAL;

                long wanted = StreamSupport.stream(contents.getEffects().spliterator(), false)
                    .filter(instance -> instance.getEffectType().value().getCategory().equals(category))
                    .count();
                long unwanted = StreamSupport.stream(contents.getEffects().spliterator(), false)
                    .filter(instance -> instance.getEffectType().value().getCategory().equals(opposite))
                    .count();
                return wanted >= unwanted;
            })
            .findFirst()
            .orElse(null);
    }

    public static Slot getFoodMaxSaturationSlot() {
        return slots()
            .filter(slot -> slot.getStack().get(DataComponentTypes.FOOD) != null
                && !slot.getStack().get(DataComponentTypes.FOOD).canAlwaysEat())
            .max(Comparator.comparingDouble(slot -> slot.getStack().get(DataComponentTypes.FOOD).saturation()))
            .orElse(null);
    }

    public static int getInventoryCount(Item item) {
        return IntStream.range(0, 45)
            .filter(slot -> Objects.requireNonNull(mc.player).getInventory().getStack(slot).getItem().equals(item))
            .map(slot -> mc.player.getInventory().getStack(slot).getCount())
            .sum();
    }

    public static int getHotbarItems(List<Item> items) {
        return IntStream.range(0, 9)
            .filter(slot -> items.contains(mc.player.getInventory().getStack(slot).getItem()))
            .findFirst()
            .orElse(-1);
    }

    public static int getHotbarSlotId(IntPredicate filter) {
        return IntStream.range(0, 9).filter(filter).findFirst().orElse(-1);
    }

    public static int find(Item item, int start, int end) {
        if (mc.player == null) {
            return -1;
        }
        for (int slot = end; slot >= start; slot--) {
            if (mc.player.currentScreenHandler.syncId != 0
                && mc.player.currentScreenHandler.getSlot(slot).getStack().getItem() == item) {
                return slot;
            }
            if (mc.player.currentScreenHandler.syncId == 0
                && mc.player.getInventory().getStack(slot).getItem() == item) {
                return slot;
            }
        }
        return -1;
    }

    public static int find(List<Item> items, int start, int end) {
        if (mc.player == null) {
            return -1;
        }
        for (int slot = end; slot >= start; slot--) {
            for (Item item : items) {
                if (mc.player.currentScreenHandler.syncId != 0
                    && mc.player.currentScreenHandler.getSlot(slot).getStack().getItem() == item) {
                    return slot;
                }
                if (mc.player.currentScreenHandler.syncId == 0
                    && mc.player.getInventory().getStack(slot).getItem() == item) {
                    return slot;
                }
            }
        }
        return -1;
    }

    public static boolean isServerScreen() {
        return slots().toList().size() != 46;
    }

    public static void updateSlots() {
        ScreenHandler handler = mc.player.currentScreenHandler;
        ItemStack stack = Registries.ITEM.get((int) MathUtil.getRandom(0.0D, 100.0D)).getDefaultStack();
        mc.player.networkHandler.sendPacket(new ClickSlotC2SPacket(
            handler.syncId,
            handler.getRevision(),
            0,
            0,
            SlotActionType.PICKUP_ALL,
            stack,
            Int2ObjectMaps.singleton(0, stack)
        ));
    }

    public static void closeScreen(boolean sendPacket) {
        if (sendPacket) {
            mc.player.networkHandler.sendPacket(
                new CloseHandledScreenC2SPacket(mc.player.currentScreenHandler.syncId));
        } else {
            mc.player.closeHandledScreen();
        }
    }

    public static void clickSlot(int syncId, int slot, int button, SlotActionType actionType, boolean applyLocally) {
        mc.interactionManager.clickSlot(syncId, slot, button, actionType, mc.player);
        if (applyLocally) {
            mc.player.currentScreenHandler.onSlotClick(slot, button, actionType, mc.player);
        }
    }

    public static void clickSlot(int slot, int button, SlotActionType actionType, boolean applyLocally) {
        clickSlot(mc.player.currentScreenHandler.syncId, slot, button, actionType, applyLocally);
    }

    public static void clickSlot(Slot slot, int button, SlotActionType actionType, boolean applyLocally) {
        if (slot != null) {
            clickSlot(slot.id, button, actionType, applyLocally);
        }
    }

    public static void swapHand(Slot slot, int hotbarSlot) {
        clickSlot(slot, hotbarSlot, SlotActionType.SWAP, false);
    }

    public static void swapHand(Slot slot, int hotbarSlot, boolean update) {
        clickSlot(slot, hotbarSlot, SlotActionType.SWAP, false);
        if (update) {
            updateSlots();
        }
    }

    public static void swapHand(Slot slot, Hand hand, boolean update) {
        if (slot == null || slot.id == -1) {
            return;
        }
        if (hand.equals(Hand.OFF_HAND)
            && !(slot.inventory instanceof PlayerInventory)
            && !(slot.inventory instanceof EnderChestInventory)) {
            return;
        }
        int hotbarSlot = hand.equals(Hand.MAIN_HAND) ? mc.player.getInventory().selectedSlot : 40;
        swapHand(slot, hotbarSlot, update);
    }

    public static void moveItem(int from, int to, boolean update) {
        clickSlot(from, 0, SlotActionType.SWAP, false);
        clickSlot(to, 0, SlotActionType.SWAP, false);
        clickSlot(from, 0, SlotActionType.SWAP, false);
        if (update) {
            updateSlots();
        }
    }

    public static void moveItem(int from, int to, boolean queue, boolean update) {
        if (from == to || from == -1) {
            return;
        }

        int inventoryStart = Math.toIntExact(slots().count()) - 9;
        if (from >= inventoryStart && inventoryStart == 36) {
            if (queue) {
                TaskRunner.addTask(() -> clickSlot(to, from - inventoryStart, SlotActionType.SWAP, false));
            } else {
                clickSlot(to, from - inventoryStart, SlotActionType.SWAP, false);
                closeScreen(true);
            }
        } else if (queue) {
            TaskRunner.addTask(() -> moveItem(from, to, update));
        } else {
            moveItem(from, to, update);
            closeScreen(true);
        }
    }

    public static void moveItem(Slot slot, int to) {
        if (slot != null) {
            moveItem(slot.id, to, false, false);
        }
    }

    public static void moveItem(Slot slot, int to, boolean queue) {
        moveItem(slot, to, queue, false);
    }

    public static void moveItem(Slot slot, int to, boolean queue, boolean update) {
        if (slot != null) {
            moveItem(slot.id, to, queue, update);
        }
    }

    public static void swapAndUseLegit(Item item) {
        int inventorySlot = find(item, 9, 45);
        int hotbarSlot = find(item, 0, 8);
        int previousSlot = mc.player.getInventory().selectedSlot;

        if (mc.player.getMainHandStack().getItem() == item) {
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            return;
        }
        if (mc.player.getOffHandStack().getItem() == item) {
            mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
            return;
        }

        if (hotbarSlot != -1) {
            mc.player.getInventory().selectedSlot = hotbarSlot;
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.player.getInventory().selectedSlot = previousSlot;
        }
        if (hotbarSlot != -1 || inventorySlot == -1) {
            return;
        }

        int swapSlot = -1;
        for (int slot = 0; slot < 8; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.isEmpty()) {
                swapSlot = slot;
            }
            UseAction useAction = stack.getUseAction();
            if (useAction == UseAction.NONE) {
                swapSlot = slot;
            }
        }

        if (swapSlot == -1) {
            boolean sprintStopped = false;
            if (mc.player.isSprinting()) {
                mc.getNetworkHandler().sendPacket(
                    new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
                mc.player.setSprinting(false);
                mc.getNetworkHandler().sendPacket(
                    new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                if (!Sprint.INSTANCE.isEnabled()) {
                    mc.options.sprintKey.setPressed(false);
                }
                sprintStopped = true;
            }

            mc.interactionManager.clickSlot(0, inventorySlot, 8, SlotActionType.SWAP, mc.player);
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
            mc.player.getInventory().selectedSlot = swapSlot;
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.player.getInventory().selectedSlot = previousSlot;

            if (sprintStopped) {
                mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
            }
            return;
        }

        boolean sprintStopped = false;
        if (mc.player.isSprinting()) {
            mc.getNetworkHandler().sendPacket(
                new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
            mc.player.setSprinting(false);
            mc.getNetworkHandler().sendPacket(
                new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            if (!Sprint.INSTANCE.isEnabled()) {
                mc.options.sprintKey.setPressed(false);
            }
            sprintStopped = true;
        }

        mc.interactionManager.clickSlot(0, inventorySlot, swapSlot, SlotActionType.SWAP, mc.player);
        mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
        mc.player.getInventory().selectedSlot = swapSlot;
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.getInventory().selectedSlot = previousSlot;
        mc.interactionManager.clickSlot(0, inventorySlot, swapSlot, SlotActionType.SWAP, mc.player);
        mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));

        if (sprintStopped) {
            mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
        }
    }

    public static void swapAndUseHvH(Item item) {
        int inventorySlot = find(item, 9, 45);
        int hotbarSlot = find(item, 0, 8);
        int previousSlot = mc.player.getInventory().selectedSlot;

        if (mc.player.getMainHandStack().getItem() == item) {
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            return;
        }
        if (mc.player.getOffHandStack().getItem() == item) {
            mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
            return;
        }

        if (hotbarSlot != -1) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(hotbarSlot));
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(previousSlot));
        }
        if (hotbarSlot != -1 || inventorySlot == -1) {
            return;
        }

        int swapSlot = -1;
        for (int slot = 0; slot < 8; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.isEmpty()) {
                swapSlot = slot;
            }
            UseAction useAction = stack.getUseAction();
            if (useAction == UseAction.NONE) {
                swapSlot = slot;
            }
        }

        if (swapSlot == -1) {
            boolean sprintStopped = false;
            if (mc.player.isSprinting()) {
                mc.getNetworkHandler().sendPacket(
                    new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
                mc.player.setSprinting(false);
                mc.getNetworkHandler().sendPacket(
                    new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                if (!Sprint.INSTANCE.isEnabled()) {
                    mc.options.sprintKey.setPressed(false);
                }
                sprintStopped = true;
            }

            mc.interactionManager.clickSlot(0, inventorySlot, 8, SlotActionType.SWAP, mc.player);
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(8));
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(previousSlot));

            if (sprintStopped) {
                mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
            }
            return;
        }

        boolean sprintStopped = false;
        if (mc.player.isSprinting()) {
            mc.getNetworkHandler().sendPacket(
                new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
            mc.player.setSprinting(false);
            mc.getNetworkHandler().sendPacket(
                new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            if (!Sprint.INSTANCE.isEnabled()) {
                mc.options.sprintKey.setPressed(false);
            }
            sprintStopped = true;
        }

        mc.interactionManager.clickSlot(0, inventorySlot, swapSlot, SlotActionType.SWAP, mc.player);
        mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(swapSlot));
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(previousSlot));
        mc.interactionManager.clickSlot(0, inventorySlot, swapSlot, SlotActionType.SWAP, mc.player);
        mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));

        if (sprintStopped) {
            mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
        }
    }

    public static void swapToOffHandAndUseLegit(Item item) {
        int inventorySlot = find(item, 9, 45);
        int hotbarSlot = find(item, 0, 8);

        if (mc.player.getOffHandStack().getItem() == item) {
            mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
            return;
        }

        if (mc.player.isUsingItem() && !mc.player.isBlocking()) {
            boolean sprintStopped = false;
            if (mc.player.isSprinting()) {
                mc.getNetworkHandler().sendPacket(
                    new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
                mc.player.setSprinting(false);
                mc.getNetworkHandler().sendPacket(
                    new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                if (!Sprint.INSTANCE.isEnabled()) {
                    mc.options.sprintKey.setPressed(false);
                }
                sprintStopped = true;
            }

            if (hotbarSlot != -1) {
                moveItem(hotbarSlot, 45, false, false);
                mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
                moveItem(hotbarSlot, 45, false, false);
            } else if (inventorySlot != -1) {
                moveItem(inventorySlot, 45, false, false);
                mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
                moveItem(inventorySlot, 45, false, false);
            }

            if (sprintStopped) {
                mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
            }
            return;
        }

        boolean sprintStopped = false;
        if (mc.player.isSprinting()) {
            mc.getNetworkHandler().sendPacket(
                new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
            mc.player.setSprinting(false);
            mc.getNetworkHandler().sendPacket(
                new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            if (!Sprint.INSTANCE.isEnabled()) {
                mc.options.sprintKey.setPressed(false);
            }
            sprintStopped = true;
        }

        if (hotbarSlot != -1) {
            mc.interactionManager.clickSlot(0, hotbarSlot, 40, SlotActionType.SWAP, mc.player);
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
            mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
            mc.interactionManager.clickSlot(0, hotbarSlot, 40, SlotActionType.SWAP, mc.player);
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
        } else if (inventorySlot != -1) {
            mc.interactionManager.clickSlot(0, inventorySlot, 40, SlotActionType.SWAP, mc.player);
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
            mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
            mc.interactionManager.clickSlot(0, inventorySlot, 40, SlotActionType.SWAP, mc.player);
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
        }

        if (sprintStopped) {
            mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
        }
    }

    public static void swapToOffHandAndUseHvH(Item item) {
        int inventorySlot = find(item, 9, 45);
        int hotbarSlot = find(item, 0, 8);

        if (mc.player.getOffHandStack().getItem() == item) {
            mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
            return;
        }

        if (mc.player.isUsingItem() && !mc.player.isBlocking()) {
            boolean sprintStopped = false;
            if (mc.player.isSprinting()) {
                mc.getNetworkHandler().sendPacket(
                    new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
                mc.player.setSprinting(false);
                mc.getNetworkHandler().sendPacket(
                    new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                if (!Sprint.INSTANCE.isEnabled()) {
                    mc.options.sprintKey.setPressed(false);
                }
                sprintStopped = true;
            }

            if (hotbarSlot != -1) {
                moveItem(hotbarSlot, 45, false, false);
                mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
                moveItem(hotbarSlot, 45, false, false);
            } else if (inventorySlot != -1) {
                moveItem(inventorySlot, 45, false, false);
                mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
                moveItem(inventorySlot, 45, false, false);
            }

            if (sprintStopped) {
                mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
            }
            return;
        }

        boolean sprintStopped = false;
        if (mc.player.isSprinting()) {
            mc.getNetworkHandler().sendPacket(
                new PlayerInputC2SPacket(new PlayerInput(false, false, false, false, false, false, false)));
            mc.player.setSprinting(false);
            mc.getNetworkHandler().sendPacket(
                new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            if (!Sprint.INSTANCE.isEnabled()) {
                mc.options.sprintKey.setPressed(false);
            }
            sprintStopped = true;
        }

        if (hotbarSlot != -1) {
            mc.interactionManager.clickSlot(0, hotbarSlot, 40, SlotActionType.SWAP, mc.player);
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
            mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
            mc.interactionManager.clickSlot(0, hotbarSlot, 40, SlotActionType.SWAP, mc.player);
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
        } else if (inventorySlot != -1) {
            mc.interactionManager.clickSlot(0, inventorySlot, 40, SlotActionType.SWAP, mc.player);
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
            mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
            mc.interactionManager.clickSlot(0, inventorySlot, 40, SlotActionType.SWAP, mc.player);
            mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
        }

        if (sprintStopped) {
            mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
        }
    }
}
