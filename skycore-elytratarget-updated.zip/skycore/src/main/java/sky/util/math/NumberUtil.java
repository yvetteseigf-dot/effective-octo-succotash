package sky.util.math;

import java.math.BigDecimal;
import java.math.RoundingMode;
import sky.access.RenderAccess;

public final class NumberUtil implements RenderAccess {
    public static FastRandom fastRandomize = new FastRandom();

    private NumberUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static double roundHalfUp(double num, double increment) {
        double rounded = Math.round(num / increment) * increment;
        BigDecimal decimal = new BigDecimal(rounded);
        decimal = decimal.setScale(2, RoundingMode.HALF_UP);
        return decimal.doubleValue();
    }

    public static double round(double target, int decimal) {
        return Math.round(target * Math.pow(10.0D, decimal)) / Math.pow(10.0D, decimal);
    }

    public static int lerp(int input, int step, double target) {
        return (int) (input + target * (step - input));
    }

    public static float interpolate(double oldValue, double newValue, double interpolationValue) {
        return (float) (oldValue + (newValue - oldValue) * interpolationValue);
    }

    public static double randomSimple(double min, double max) {
        return Math.random() * (max - min) + min;
    }

    public static float randomNew(double min, double max) {
        if (min > max) {
            return (float) (fastRandomize.nextFloat() * (min - max) + max);
        }
        return (float) (fastRandomize.nextFloat() * (max - min) + min);
    }

    public static <T extends Number> T lerp(T input, T step, double target) {
        double inputValue = input.doubleValue();
        double stepValue = step.doubleValue();
        double result = inputValue + target * (stepValue - inputValue);

        if (input instanceof Integer) {
            return (T) Integer.valueOf((int) Math.round(result));
        }
        if (input instanceof Double) {
            return (T) Double.valueOf(result);
        }
        if (input instanceof Float) {
            return (T) Float.valueOf((float) result);
        }
        if (input instanceof Long) {
            return (T) Long.valueOf(Math.round(result));
        }
        if (input instanceof Short) {
            return (T) Short.valueOf((short) Math.round(result));
        }
        if (input instanceof Byte) {
            return (T) Byte.valueOf((byte) Math.round(result));
        }
        throw new IllegalArgumentException("Unsupported type: " + input.getClass().getSimpleName());
    }

    public static int getPercentage(int totalValue, int percentage) {
        return (int) (percentage * (totalValue / 100.0F));
    }

    public static int randomInt(int min, int max) {
        return (int) (min + (max - min) * Math.random());
    }

    public static float wrapAngleTo180(float v) {
        return 0.0F;
    }

    public static float random(float min, float max) {
        return new MersenneTwisterRandom().randomNumber(0.0F, 1.0F, false) * (max - min) + min;
    }
}
