package sky.util.math;

import java.util.Random;

/** Inclusive integer range with a per-instance random source. */
public class RandomIntRange {
    private final Random random = new Random();
    private final int start;
    private final int endInclusive;

    public RandomIntRange(int start, int endInclusive) {
        if (start > endInclusive) {
            throw new IllegalArgumentException("Start must be less than or equal to endInclusive");
        }
        this.start = start;
        this.endInclusive = endInclusive;
    }

    public int getStart() {
        return start;
    }

    public int random() {
        return start + random.nextInt(endInclusive - start + 1);
    }

    @Override
    public String toString() {
        return start + ".." + endInclusive;
    }

    public int getEndInclusive() {
        return endInclusive;
    }
}
