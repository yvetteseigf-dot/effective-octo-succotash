package sky.util.text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import net.minecraft.text.MutableText;
import net.minecraft.text.PlainTextContent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class TextUtil {
    private static final Map<Integer, Integer> RANK_COLORS;
    private static final Map<Integer, String> MSDF_SYMBOL_REPLACEMENTS;

    static {
        MSDF_SYMBOL_REPLACEMENTS = new HashMap<>();
        MSDF_SYMBOL_REPLACEMENTS.put(9889, "");
        MSDF_SYMBOL_REPLACEMENTS.put(9733, "");
        MSDF_SYMBOL_REPLACEMENTS.put(42240, "PLAYER");
        MSDF_SYMBOL_REPLACEMENTS.put(42244, "HERO");
        MSDF_SYMBOL_REPLACEMENTS.put(42248, "TITAN");
        MSDF_SYMBOL_REPLACEMENTS.put(42258, "AVENGER");
        MSDF_SYMBOL_REPLACEMENTS.put(42262, "OVERLORD");
        MSDF_SYMBOL_REPLACEMENTS.put(42272, "MAGISTER");
        MSDF_SYMBOL_REPLACEMENTS.put(42276, "IMPERATOR");
        MSDF_SYMBOL_REPLACEMENTS.put(42280, "DRAGON");
        MSDF_SYMBOL_REPLACEMENTS.put(42336, "D.HELPER");
        MSDF_SYMBOL_REPLACEMENTS.put(42290, "BULL");
        MSDF_SYMBOL_REPLACEMENTS.put(42294, "TIGER");
        MSDF_SYMBOL_REPLACEMENTS.put(42308, "DRACULA");
        MSDF_SYMBOL_REPLACEMENTS.put(42326, "BUNNY");
        MSDF_SYMBOL_REPLACEMENTS.put(42312, "COBRA");
        MSDF_SYMBOL_REPLACEMENTS.put(42304, "HYDRA");
        MSDF_SYMBOL_REPLACEMENTS.put(42322, "RABBIT");
        MSDF_SYMBOL_REPLACEMENTS.put(42249, "HELPER");
        MSDF_SYMBOL_REPLACEMENTS.put(42259, "ML.MODER");
        MSDF_SYMBOL_REPLACEMENTS.put(42263, "MODER");
        MSDF_SYMBOL_REPLACEMENTS.put(42273, "MODER+");
        MSDF_SYMBOL_REPLACEMENTS.put(42277, "ST.MODER");
        MSDF_SYMBOL_REPLACEMENTS.put(42281, "GL.MODER");
        MSDF_SYMBOL_REPLACEMENTS.put(42291, "ML.ADMIN");
        MSDF_SYMBOL_REPLACEMENTS.put(42295, "ADMIN");
        MSDF_SYMBOL_REPLACEMENTS.put(42241, "MEDIA");
        MSDF_SYMBOL_REPLACEMENTS.put(42245, "YT");
        MSDF_SYMBOL_REPLACEMENTS.put(42305, "GOD");
        MSDF_SYMBOL_REPLACEMENTS.put(42327, "SPONSOR");
        MSDF_SYMBOL_REPLACEMENTS.put(42328, "");
        MSDF_SYMBOL_REPLACEMENTS.put(42242, "D.MODER");
        MSDF_SYMBOL_REPLACEMENTS.put(9670, "@");
        MSDF_SYMBOL_REPLACEMENTS.put(9475, "|");
        MSDF_SYMBOL_REPLACEMENTS.put(128293, "@");
        MSDF_SYMBOL_REPLACEMENTS.put(7424, "A");
        MSDF_SYMBOL_REPLACEMENTS.put(665, "B");
        MSDF_SYMBOL_REPLACEMENTS.put(7428, "C");
        MSDF_SYMBOL_REPLACEMENTS.put(7429, "D");
        MSDF_SYMBOL_REPLACEMENTS.put(7431, "E");
        MSDF_SYMBOL_REPLACEMENTS.put(42800, "F");
        MSDF_SYMBOL_REPLACEMENTS.put(610, "G");
        MSDF_SYMBOL_REPLACEMENTS.put(668, "H");
        MSDF_SYMBOL_REPLACEMENTS.put(618, "I");
        MSDF_SYMBOL_REPLACEMENTS.put(7434, "J");
        MSDF_SYMBOL_REPLACEMENTS.put(7435, "K");
        MSDF_SYMBOL_REPLACEMENTS.put(671, "L");
        MSDF_SYMBOL_REPLACEMENTS.put(7437, "M");
        MSDF_SYMBOL_REPLACEMENTS.put(628, "N");
        MSDF_SYMBOL_REPLACEMENTS.put(7439, "O");
        MSDF_SYMBOL_REPLACEMENTS.put(7448, "P");
        MSDF_SYMBOL_REPLACEMENTS.put(491, "Q");
        MSDF_SYMBOL_REPLACEMENTS.put(640, "R");
        MSDF_SYMBOL_REPLACEMENTS.put(7451, "T");
        MSDF_SYMBOL_REPLACEMENTS.put(7452, "U");
        MSDF_SYMBOL_REPLACEMENTS.put(42801, "S");
        MSDF_SYMBOL_REPLACEMENTS.put(7456, "V");
        MSDF_SYMBOL_REPLACEMENTS.put(7457, "W");
        MSDF_SYMBOL_REPLACEMENTS.put(7521, "X");
        MSDF_SYMBOL_REPLACEMENTS.put(655, "Y");
        MSDF_SYMBOL_REPLACEMENTS.put(7458, "Z");

        RANK_COLORS = new HashMap<>();
        RANK_COLORS.put(42240, rgb(120, 120, 120));
        RANK_COLORS.put(42244, rgb(100, 113, 251));
        RANK_COLORS.put(42248, rgb(214, 200, 42));
        RANK_COLORS.put(42258, rgb(101, 189, 56));
        RANK_COLORS.put(42262, rgb(85, 255, 255));
        RANK_COLORS.put(42272, rgb(202, 130, 60));
        RANK_COLORS.put(42276, rgb(202, 60, 60));
        RANK_COLORS.put(42280, rgb(245, 51, 238));
        RANK_COLORS.put(42336, rgb(214, 200, 42));
        RANK_COLORS.put(42290, rgb(121, 81, 202));
        RANK_COLORS.put(42294, rgb(202, 130, 60));
        RANK_COLORS.put(42308, rgb(202, 60, 60));
        RANK_COLORS.put(42326, rgb(68, 65, 66));
        RANK_COLORS.put(42312, rgb(127, 214, 86));
        RANK_COLORS.put(42304, rgb(92, 120, 7));
        RANK_COLORS.put(42322, rgb(120, 120, 120));
        RANK_COLORS.put(42249, rgb(214, 200, 42));
        RANK_COLORS.put(42259, rgb(100, 113, 251));
        RANK_COLORS.put(42263, rgb(100, 113, 251));
        RANK_COLORS.put(42273, rgb(121, 81, 202));
        RANK_COLORS.put(42277, rgb(100, 113, 251));
        RANK_COLORS.put(42281, rgb(121, 81, 202));
        RANK_COLORS.put(42291, rgb(64, 151, 214));
        RANK_COLORS.put(42295, rgb(202, 60, 60));
        RANK_COLORS.put(42241, rgb(121, 81, 202));
        RANK_COLORS.put(42245, rgb(255, 255, 255));
        RANK_COLORS.put(42305, rgb(214, 200, 42));
    }

    public TextUtil() {
    }

    public static Text sanitizeDisplayText(Text text) {
        if (text == null) {
            return Text.empty();
        }
        MutableText result = Text.empty();
        sanitizeDisplayText(result, text);
        return result;
    }

    public static Text replaceLiteral(Text input, String target, String replacement) {
        if (input == null) {
            return null;
        }
        String flattened = input.getString();
        if (!flattened.toLowerCase().contains(target.toLowerCase())) {
            return input;
        }
        flattened = flattened.replaceAll("(?i)" + Pattern.quote(target), replacement);
        MutableText result = Text.empty();
        List<StyledChar> chars = flatten(input);
        int styleIndex = 0;
        for (int i = 0; i < flattened.length(); i++) {
            Style style = styleIndex < chars.size() ? chars.get(styleIndex).style() : Style.EMPTY;
            result.append(Text.literal(String.valueOf(flattened.charAt(i))).setStyle(style));
            styleIndex++;
        }
        return result;
    }

    public static Text truncateAfterPlayerName(Text text, String playerName) {
        if (text == null || playerName == null || playerName.isEmpty()) {
            return text == null ? Text.empty() : text;
        }
        MutableText result = Text.empty();
        List<OrderedChar> chars = new ArrayList<>();
        text.asOrderedText().accept((index, style, codePoint) -> {
            chars.add(new OrderedChar(style, codePoint));
            return true;
        });

        int matchIndex = 0;
        boolean foundName = false;
        boolean keepDigits = false;
        for (OrderedChar ordered : chars) {
            int codePoint = ordered.codePoint;
            Style style = ordered.style;
            if (!isDisplayChar(codePoint)) {
                continue;
            }
            String msdf = replaceCodePointForMsdf(codePoint);
            if (msdf != null) {
                if (msdf.isEmpty()) {
                    continue;
                }
                appendDisplayCodePoint(result, codePoint, style);
                matchIndex = 0;
                keepDigits = false;
                continue;
            }
            String piece = new String(Character.toChars(codePoint));
            char ch = piece.charAt(0);
            if (!foundName) {
                result.append(Text.literal(piece).setStyle(style));
                if (ch == playerName.charAt(matchIndex)) {
                    matchIndex++;
                    if (matchIndex == playerName.length()) {
                        foundName = true;
                        keepDigits = true;
                    }
                } else {
                    matchIndex = ch == playerName.charAt(0) ? 1 : 0;
                }
            } else {
                if (!keepDigits || !Character.isDigit(ch)) {
                    break;
                }
                result.append(Text.literal(piece).setStyle(style));
            }
        }
        return result.getString().isEmpty() ? text : result;
    }

    public static int getGradientColorForReplacement(int codePoint, int charIndex, int totalChars, float alpha,
                                                     int currentColor) {
        if (totalChars <= 1) {
            return applyOpacity(currentColor, alpha);
        }
        Integer rankColor = RANK_COLORS.get(codePoint);
        if (rankColor == null) {
            return applyOpacity(currentColor, alpha);
        }
        int darkened = darken(rankColor, 0.8f);
        float ratio = (float) charIndex / (float) (totalChars - 1);
        return applyOpacity(interpolate(darkened, rankColor, ratio), alpha);
    }

    public static boolean isDisplayChar(int codePoint) {
        if (shouldStripDisplayCodePoint(codePoint)) {
            return false;
        }
        if (replaceCodePointForMsdf(codePoint) != null) {
            return true;
        }
        if (codePoint == 9679 || codePoint == 9675 || codePoint == 9673) {
            return true;
        }
        if (codePoint == ' ' || codePoint == '_' || codePoint == '-' || codePoint == '.'
                || codePoint == '|' || codePoint == '@') {
            return true;
        }
        if (codePoint >= '0' && codePoint <= '9') {
            return true;
        }
        if (codePoint >= 'A' && codePoint <= 'Z') {
            return true;
        }
        if (codePoint >= 'a' && codePoint <= 'z') {
            return true;
        }
        return codePoint >= 1024 && codePoint <= 1279;
    }

    public static Text replaceSymbols(Text text) {
        String[][] replacements = {
                {"◆", "@"},
                {"┃", "|"},
                {"\uD83D\uDD25", "@"},
                {"ᴀ", "A"},
                {"ʙ", "B"},
                {"ᴄ", "C"},
                {"ᴅ", "D"},
                {"ᴇ", "E"},
                {"ғ", "F"},
                {"ɢ", "G"},
                {"ʜ", "H"},
                {"ɪ", "I"},
                {"ᴊ", "J"},
                {"ᴋ", "K"},
                {"ʟ", "L"},
                {"ᴍ", "M"},
                {"ɴ", "N"},
                {"ꜱ", "S"},
                {"ᴏ", "O"},
                {"ᴘ", "P"},
                {"ǫ", "Q"},
                {"ʀ", "R"},
                {"ᴛ", "T"},
                {"ᴜ", "U"},
                {"ᴠ", "V"},
                {"ᴡ", "W"},
                {"ꜰ", "F"},
                {"ʏ", "Y"},
                {"ᴢ", "Z"}
        };
        for (String[] pair : replacements) {
            if (text.getString().contains(pair[0])) {
                text = replace(text, pair[0], pair[1]);
            }
        }
        return text;
    }

    public static String toQwerty(String text) {
        return text
                .replace("й", "q").replace("ц", "w").replace("у", "e").replace("к", "r").replace("е", "t")
                .replace("н", "y").replace("г", "u").replace("ш", "i").replace("щ", "o").replace("з", "p")
                .replace("х", "[").replace("ъ", "]")
                .replace("ф", "a").replace("ы", "s").replace("в", "d").replace("а", "f").replace("п", "g")
                .replace("р", "h").replace("о", "j").replace("л", "k").replace("д", "l").replace("ж", ";")
                .replace("э", "'")
                .replace("я", "z").replace("ч", "x").replace("с", "c").replace("м", "v").replace("и", "b")
                .replace("т", "n").replace("ь", "m").replace("б", ",").replace("ю", ".").replace("ё", "`")
                .replace("Й", "Q").replace("Ц", "W").replace("У", "E").replace("К", "R").replace("Е", "T")
                .replace("Н", "Y").replace("Г", "U").replace("Ш", "I").replace("Щ", "O").replace("З", "P")
                .replace("Х", "{").replace("Ъ", "}")
                .replace("Ф", "A").replace("Ы", "S").replace("В", "D").replace("А", "F").replace("П", "G")
                .replace("Р", "H").replace("О", "J").replace("Л", "K").replace("Д", "L").replace("Ж", ":")
                .replace("Э", "\"")
                .replace("Я", "Z").replace("Ч", "X").replace("С", "C").replace("М", "V").replace("И", "B")
                .replace("Т", "N").replace("Ь", "M").replace("Б", "<").replace("Ю", ">").replace("Ё", "~");
    }

    public static Text replace(Text input, String target, String replacement) {
        if (input == null || target == null || replacement == null) {
            return input;
        }
        MutableText result = Text.empty().setStyle(input.getStyle());
        appendReplaced(result, input, target, replacement);
        return result;
    }

    public static String replaceCodePoint(int codePoint) {
        return replaceCodePointForMsdf(codePoint);
    }

    public static String replaceSymbols(String s) {
        if (s == null || s.isEmpty()) {
            return s;
        }
        StringBuilder builder = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); ) {
            int codePoint = s.codePointAt(i);
            int count = Character.charCount(codePoint);
            if (codePoint == 42327 && i + count < s.length() && s.charAt(i + count) == 42328) {
                builder.append("SPONSOR");
                i += count + 1;
                continue;
            }
            String replacement = replaceCodePointForMsdf(codePoint);
            if (replacement != null) {
                builder.append(replacement);
            } else {
                builder.appendCodePoint(codePoint);
            }
            i += count;
        }
        return builder.toString();
    }

    private static List<StyledChar> flatten(Text text) {
        List<StyledChar> list = new ArrayList<>();
        collect(text, list);
        return list;
    }

    private static void collect(Text text, List<StyledChar> list) {
        Style style = text.getStyle();
        if (text.getContent() instanceof PlainTextContent.Literal literal) {
            String string = literal.string();
            for (int i = 0; i < string.length(); i++) {
                list.add(new StyledChar(string.charAt(i), style));
            }
        }
        for (Text sibling : text.getSiblings()) {
            collect(sibling, list);
        }
    }

    private static boolean shouldStripDisplayCodePoint(int codePoint) {
        String replacement = replaceCodePointForMsdf(codePoint);
        if (replacement != null && replacement.isEmpty()) {
            return true;
        }
        if (replacement != null) {
            return false;
        }
        if (Character.isISOControl(codePoint)) {
            return true;
        }
        int type = Character.getType(codePoint);
        if (type == Character.FORMAT || type == Character.SURROGATE || type == Character.PRIVATE_USE) {
            return true;
        }
        if (codePoint >= 57344 && codePoint <= 63743) {
            return true;
        }
        if (codePoint >= 40960 && codePoint <= 42239) {
            return true;
        }
        if (codePoint >= 8203 && codePoint <= 8207) {
            return true;
        }
        if (codePoint >= 8288 && codePoint <= 8303) {
            return true;
        }
        return codePoint >= 65024 && codePoint <= 65039;
    }

    private static int darken(int color, float factor) {
        int red = (int) ((color >> 16 & 255) * factor);
        int green = (int) ((color >> 8 & 255) * factor);
        int blue = (int) ((color & 255) * factor);
        return rgb(red, green, blue);
    }

    private static String replaceCodePointForMsdf(int codePoint) {
        return MSDF_SYMBOL_REPLACEMENTS.get(codePoint);
    }

    private static int interpolate(int from, int to, float ratio) {
        int fromRed = from >> 16 & 255;
        int fromGreen = from >> 8 & 255;
        int fromBlue = from & 255;
        int toRed = to >> 16 & 255;
        int toGreen = to >> 8 & 255;
        int toBlue = to & 255;
        return rgb(
                Math.round(fromRed + (toRed - fromRed) * ratio),
                Math.round(fromGreen + (toGreen - fromGreen) * ratio),
                Math.round(fromBlue + (toBlue - fromBlue) * ratio));
    }

    private static int rgb(int red, int green, int blue) {
        return red << 16 | green << 8 | blue;
    }

    private static void appendDisplayCodePoint(MutableText result, int codePoint, Style style) {
        result.append(Text.literal(new String(Character.toChars(codePoint))).setStyle(style));
    }

    private static void appendSanitizedLiteral(MutableText result, String string, Style baseStyle) {
        Style style = baseStyle;
        StringBuilder buffer = new StringBuilder();
        for (int i = 0; i < string.length(); ) {
            int codePoint = string.codePointAt(i);
            int count = Character.charCount(codePoint);
            if (codePoint == 167 && i + count < string.length()) {
                if (!buffer.isEmpty()) {
                    result.append(Text.literal(buffer.toString()).setStyle(style));
                    buffer.setLength(0);
                }
                char code = string.charAt(i + count);
                Formatting formatting = Formatting.byCode(code);
                if (formatting != null) {
                    style = formatting == Formatting.RESET ? baseStyle : style.withFormatting(formatting);
                }
                i += count + 1;
                continue;
            }
            if (!isDisplayChar(codePoint)) {
                i += count;
                continue;
            }
            buffer.appendCodePoint(codePoint);
            i += count;
        }
        if (!buffer.isEmpty()) {
            result.append(Text.literal(buffer.toString()).setStyle(style));
        }
    }

    private static int applyOpacity(int color, float alpha) {
        int opacity = Math.round(Math.min(1.0f, Math.max(0.0f, alpha)) * 255.0f);
        return opacity << 24 | color & 16777215;
    }

    private static void appendReplaced(MutableText result, Text current, String target, String replacement) {
        if (current.getContent() instanceof PlainTextContent.Literal literal) {
            Pattern pattern = Pattern.compile(Pattern.quote(target), Pattern.CASE_INSENSITIVE);
            String replaced = pattern.matcher(literal.string()).replaceAll(replacement);
            result.append(Text.literal(replaced).setStyle(current.getStyle()));
        }
        for (Text sibling : current.getSiblings()) {
            appendReplaced(result, sibling, target, replacement);
        }
    }

    private static void sanitizeDisplayText(MutableText result, Text text) {
        if (text.getContent() instanceof PlainTextContent.Literal literal) {
            appendSanitizedLiteral(result, literal.string(), text.getStyle());
        }
        for (Text sibling : text.getSiblings()) {
            sanitizeDisplayText(result, sibling);
        }
    }

    private record StyledChar(char c, Style style) {
    }

    private static final class OrderedChar {
        private final Style style;
        private final int codePoint;

        private OrderedChar(Style style, int codePoint) {
            this.style = style;
            this.codePoint = codePoint;
        }
    }
}
