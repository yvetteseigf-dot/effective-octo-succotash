package sky.util.text;

import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import sky.access.MinecraftAccess;
import sky.theme.ThemeRegistry;

public final class ChatUtil implements MinecraftAccess {
    private ChatUtil() {
    }

    public static void displayWarning(String message) {
        send(Text.literal(message).formatted(Formatting.YELLOW));
    }

    public static void displayInfotest(String message) {
        send(Text.literal(message).formatted(Formatting.WHITE));
    }

    public static void addText(String message) {
        displayInfo(message);
    }

    public static void displayInfo(String message) {
        send(Text.literal(message).formatted(Formatting.GRAY));
    }

    public static void displayError(String message) {
        send(Text.literal(message).formatted(Formatting.RED));
    }

    public static void send(Text message) {
        if (mc.player == null) {
            return;
        }

        Text prefix = Text.literal("SkyCore").setStyle(Style.EMPTY.withColor(
                TextColor.fromRgb(ThemeRegistry.getCurrent().getSwatchColor().getRGB() & 0xFFFFFF)));
        Text separator = Text.literal(" /").formatted(Formatting.DARK_GRAY);
        mc.player.sendMessage(Text.empty().append(prefix).append(separator).append(message), false);
    }
}
