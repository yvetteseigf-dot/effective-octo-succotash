package sky.util;

public class TimeHelper {
    public long lastMS;

    public TimeHelper() {
        lastMS = System.currentTimeMillis();
    }

    public long getLastMS() {
        return lastMS;
    }

    public boolean hasTimeElapsed(long duration, boolean reset) {
        if (System.currentTimeMillis() - lastMS > duration) {
            if (reset) {
                reset();
            }
            return true;
        }
        return false;
    }

    public void reset() {
        lastMS = System.currentTimeMillis();
    }

    public long getTime() {
        return System.currentTimeMillis() - lastMS;
    }

    public long getTimeElapsed() {
        return System.currentTimeMillis() - lastMS;
    }

    public void setLastMC() {
        lastMS = System.currentTimeMillis();
    }

    public boolean isReached(long duration) {
        return System.currentTimeMillis() - lastMS > duration;
    }

    public boolean passed(long duration) {
        return System.currentTimeMillis() - lastMS > duration;
    }

    public boolean passed(float duration) {
        return passed((long) duration);
    }

    public boolean hasTimeElapsed(long duration) {
        return System.currentTimeMillis() - lastMS > duration;
    }

    public void setTime(long time) {
        lastMS = time;
    }

    public boolean finished(double duration) {
        return (double) (System.currentTimeMillis() - lastMS) > duration;
    }
}
