package sky.hud;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import sky.theme.GuiTheme;
import sky.mixin.world.ItemCooldownEntryMixin;
import sky.mixin.world.ItemCooldownManagerMixin;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.HudPanelRenderer;
import sky.render.DrawHelper;
import sky.util.ChatScreenDetector;
import sky.util.render.ColorUtil;
import sky.util.animation.FadeAnimation;

/**
 * HUD panel listing the item cooldowns currently running for anything the player is carrying.
 */
public final class CooldownHud {
    private static final String TITLE = "Cooldowns";
    private static final String ICON = "f";
    private static final long FADE_MS = 250L;

    private final Map<Item, Tracker> activeCooldowns;
    private final FadeAnimation fade;
    private float animatedWidth;
    private float animatedHeight;

    public CooldownHud() {
        this.activeCooldowns = new HashMap<>();
        this.fade = new FadeAnimation();
        this.animatedWidth = 72.5f;
        this.animatedHeight = 23.0f;
    }

    public void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (!Interface.INSTANCE.isCooldownsEnabled() || mc.player == null) {
            if (fade.isVisible()) {
                fade.fadeOut(FADE_MS);
                fade.update();
            }
            return;
        }

        ItemCooldownManager manager = mc.player.getItemCooldownManager();
        ItemCooldownManagerMixin accessor = (ItemCooldownManagerMixin) manager;
        int tick = accessor.getTick();
        Map<Identifier, Object> entries = accessor.getEntries();

        Map<Item, ItemStack> stacks = new HashMap<>();

        for (ItemStack stack : mc.player.getInventory().main) {
            if (!stack.isEmpty()) {
                stacks.putIfAbsent(stack.getItem(), stack);
            }
        }

        if (!mc.player.getOffHandStack().isEmpty()) {
            stacks.putIfAbsent(mc.player.getOffHandStack().getItem(), mc.player.getOffHandStack());
        }

        activeCooldowns.entrySet().removeIf(entry -> {
            ItemStack stack = stacks.get(entry.getKey());
            return stack == null || !manager.isCoolingDown(stack);
        });

        for (Map.Entry<Item, ItemStack> entry : stacks.entrySet()) {
            ItemStack stack = entry.getValue();
            if (!manager.isCoolingDown(stack)) {
                continue;
            }

            Identifier group = manager.getGroup(stack);
            Object rawEntry = entries.get(group);
            float remaining = remainingSeconds(rawEntry, tick, stack, manager);
            activeCooldowns.computeIfAbsent(entry.getKey(), ignored -> new Tracker(stack)).update(stack, remaining);
        }

        boolean visible = !activeCooldowns.isEmpty() || ChatScreenDetector.isActive();

        if (visible && !fade.isOpen()) {
            fade.fadeIn(FADE_MS);
        } else if (!visible && fade.isVisible()) {
            fade.fadeOut(FADE_MS);
        }

        fade.update();
    }

    public void render(DrawContext context, float screenWidth) {
        if (!Interface.INSTANCE.isCooldownsEnabled() || !fade.isVisible()) {
            return;
        }

        DrawHelper renderer = DrawHelper.get();
        if (renderer == null) {
            return;
        }

        MatrixStack matrices = context.getMatrices();
        FontRenderer font = FontRegistry.getKrisaMedium(13);
        FontRenderer iconFont = FontRegistry.getSkycore(12);

        if (font == null) {
            return;
        }

        if (iconFont == null) {
            iconFont = font;
        }

        List<Tracker> trackers = new ArrayList<>(activeCooldowns.values());
        trackers.sort(Comparator.comparing(tracker -> tracker.stack.getName().getString(),
                String.CASE_INSENSITIVE_ORDER));

        float width = 72.5f;
        for (Tracker tracker : trackers) {
            width = Math.max(width, 14.0f + font.getWidth(tracker.stack.getName().getString()) + 18.0f
                    + font.getWidth(tracker.getTimeText()) + 5.0f);
        }

        float height = 23.0f + trackers.size() * 9.0f;
        animatedWidth += (width - animatedWidth) * 0.2f;
        animatedHeight += (height - animatedHeight) * 0.2f;

        CooldownHudPosition position = HudEditor.getInstance().getCooldowns();
        position.setSize(animatedWidth, animatedHeight);
        position.ensureInitialized(screenWidth);

        float panelWidth = position.getWidth();
        float panelHeight = position.getHeight();
        float x = position.getX();
        float y = position.getY();
        float alpha = fade.getAlpha();
        GuiTheme theme = GuiTheme.theme;

        HudPanelRenderer.drawBackground(renderer, x, y, panelWidth, panelHeight, 13.0f,
                ColorUtil.withAlpha(theme.getPanelTop(), alpha),
                ColorUtil.withAlpha(theme.getPanelBottom(), alpha), alpha, matrices);

        iconFont.draw(ICON, x + panelWidth - 5.0f - iconFont.getWidth(ICON), y + 5.5f,
                ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);
        font.draw(TITLE, x + 6.0f, y + 4.5f, ColorUtil.withAlpha(theme.getText(), alpha), matrices);
        drawSeparator(renderer, matrices, x, y + 16.0f, panelWidth, alpha, theme);

        float rowY = y + 19.0f;

        for (Tracker tracker : trackers) {
            String name = tracker.stack.getName().getString();
            String time = tracker.getTimeText();
            float textY = rowY + (9.0f - font.getLineHeight(name)) / 2.0f;

            renderer.drawStack(context, matrices, tracker.stack, x + 5.0f, rowY + 1.7f, 0.4f);
            font.draw(name, x + 15.0f, textY, ColorUtil.withAlpha(theme.getText(), alpha), matrices);
            font.draw(time, x + panelWidth - 6.0f - font.getWidth(time), textY,
                    ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);

            rowY += 9.0f;
        }
    }

    private void drawSeparator(DrawHelper renderer, MatrixStack matrices, float x, float y, float width, float alpha,
            GuiTheme theme) {
        Color edge = ColorUtil.withAlpha(theme.getText(), 0.02f * alpha);
        Color center = ColorUtil.withAlpha(theme.getText(), 0.05f * alpha);
        float half = width / 2.0f;

        renderer.drawGradientRoundedRect(x, y, half, 1.0f, 0.0f, edge, center, edge, center, matrices);
        renderer.drawGradientRoundedRect(x + half, y, half, 1.0f, 0.0f, center, edge, center, edge, matrices);
    }

    private float remainingSeconds(Object rawEntry, int tick, ItemStack stack, ItemCooldownManager manager) {
        if (rawEntry instanceof ItemCooldownEntryMixin entry) {
            int ticksLeft = Math.max(0, entry.skycore$endTick() - tick);
            return ticksLeft / 20.0f;
        }

        float progress = manager.getCooldownProgress(stack, 0.0f);
        return Math.max(0.0f, progress * 20.0f);
    }

    private static final class Tracker {
        private ItemStack stack;
        private float remainingSeconds;
        private float displayedSeconds;

        private Tracker(ItemStack stack) {
            this.stack = stack.copy();
        }

        private void update(ItemStack stack, float remainingSeconds) {
            this.stack = stack.copy();

            if (remainingSeconds > this.displayedSeconds + 0.75f) {
                this.displayedSeconds = remainingSeconds;
            } else {
                this.displayedSeconds = Math.min(this.displayedSeconds, remainingSeconds);
            }

            this.remainingSeconds = remainingSeconds;

            if (this.displayedSeconds <= 0.0f) {
                this.displayedSeconds = this.remainingSeconds;
            }
        }

        private String getTimeText() {
            int totalSeconds = Math.max(0, (int) Math.floor(displayedSeconds + 0.001f));
            return String.format("%02d:%02d", totalSeconds / 60, totalSeconds % 60);
        }
    }
}
