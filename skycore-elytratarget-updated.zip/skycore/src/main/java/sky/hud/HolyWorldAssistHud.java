package sky.hud;

import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.util.math.MatrixStack;
import sky.config.BindCapture;
import sky.theme.GuiTheme;
import sky.config.KeybindSetting;
import sky.module.misc.HolyWorldAssist;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.HudPanelRenderer;
import sky.render.DrawHelper;
import sky.util.ChatScreenDetector;
import sky.util.render.ColorUtil;
import sky.util.animation.FadeAnimation;
import sky.util.render.HudScaleUtil;
import sky.util.input.KeyNameUtil;

/**
 * HUD panel listing the HolyWorld assist keybinds, rebindable by middle-clicking a row
 * while the chat overlay is open.
 */
public final class HolyWorldAssistHud {
    private static final String TITLE = "HW Assist";
    private static final String KEYBOARD_ICON = "c";

    private final FadeAnimation globalFade = new FadeAnimation();
    private final Map<String, FadeAnimation> rowFades = new HashMap<>();

    private float animatedWidth = 70.0f;
    private float targetWidth = 70.0f;
    private float layoutWidthFrom = 70.0f;
    private long layoutAnimStartMs;
    private boolean layoutAnimating;

    public void tick() {
        if (!Interface.INSTANCE.isHolyWorldAssistHudEnabled()) {
            return;
        }

        HolyWorldAssist assist = HolyWorldAssist.INSTANCE;
        boolean enabled = assist.isEnabled();
        boolean shouldShow = enabled || ChatScreenDetector.isActive();

        if (shouldShow) {
            if (!globalFade.isOpen()) {
                globalFade.fadeIn(250L);
            }
        } else if (globalFade.isVisible()) {
            globalFade.fadeOut(250L);
        }

        globalFade.update();

        for (KeybindSetting bind : assist.getBindSettings()) {
            FadeAnimation rowFade = rowFades.computeIfAbsent(bind.getName(), name -> new FadeAnimation());
            boolean rowVisible = assist.isEnabled();

            if (rowVisible) {
                if (!rowFade.isOpen()) {
                    rowFade.fadeIn(250L);
                }
            } else if (rowFade.isVisible()) {
                rowFade.fadeOut(250L);
            }

            rowFade.update();
        }
    }

    public void render(MatrixStack matrices, float scale) {
        if (!Interface.INSTANCE.isHolyWorldAssistHudEnabled()) {
            return;
        }

        globalFade.update();
        if (!globalFade.isVisible()) {
            return;
        }

        float alpha = globalFade.getAlpha();
        if (alpha <= 0.01f) {
            return;
        }

        DrawHelper renderer = DrawHelper.get();
        if (renderer == null || matrices == null) {
            return;
        }

        FontRenderer titleFont = FontRegistry.getKrisaMedium(13);
        FontRenderer rowFont = FontRegistry.getKrisaMedium(13);
        FontRenderer iconFont = FontRegistry.getSkycore(12);
        if (titleFont == null || rowFont == null) {
            return;
        }

        if (iconFont == null) {
            iconFont = rowFont;
        }

        HolyWorldAssist assist = HolyWorldAssist.INSTANCE;

        float widest = 72.5f;
        for (KeybindSetting bind : assist.getBindSettings()) {
            FadeAnimation rowFade = rowFades.get(bind.getName());
            float rowAlpha = rowFade == null ? 0.0f : rowFade.getAlpha();
            if (!shouldRenderRow(assist, bind, rowAlpha)) {
                continue;
            }

            String bindText = getBindText(bind);
            float rowWidth = 5.0f + rowFont.getWidth(bind.getName()) + 18.0f + rowFont.getWidth(bindText) + 5.0f;
            widest = Math.max(widest, rowWidth);
        }

        startLayoutAnimation(widest);
        updateLayoutAnimation();

        float width = animatedWidth;
        float height = 23.0f;
        for (KeybindSetting bind : assist.getBindSettings()) {
            FadeAnimation rowFade = rowFades.get(bind.getName());
            float rowAlpha = rowFade == null ? 0.0f : rowFade.getAlpha();
            if (shouldRenderRow(assist, bind, rowAlpha)) {
                height += 9.0f * rowAlpha;
            }
        }

        HolyWorldAssistHudPosition position = HudEditor.getInstance().getHolyWorldAssist();
        position.setSize(width, height);
        position.ensureInitialized(scale);

        float x = position.getX();
        float y = position.getY();
        GuiTheme theme = GuiTheme.theme;

        HudPanelRenderer.drawBackground(renderer, x, y, width, height, 13.0f,
                ColorUtil.withAlpha(theme.getPanelTop(), alpha),
                ColorUtil.withAlpha(theme.getPanelBottom(), alpha), alpha, matrices);

        float iconWidth = iconFont.getWidth(KEYBOARD_ICON);
        float iconX = x + width - 5.0f - iconWidth;
        iconFont.draw(KEYBOARD_ICON, iconX, y + 5.5f, ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);

        titleFont.draw(TITLE, Math.round(x + 6.0f), Math.round(y + 4.5f),
                ColorUtil.withAlpha(theme.getText(), alpha), matrices);

        drawHeaderSeparator(renderer, matrices, x, y + 15.0f, width, alpha, theme);

        float rowY = y + 18.0f;
        for (KeybindSetting bind : assist.getBindSettings()) {
            FadeAnimation rowFade = rowFades.get(bind.getName());
            if (rowFade == null) {
                continue;
            }

            float rowAlpha = rowFade.getAlpha();
            if (!shouldRenderRow(assist, bind, rowAlpha) || rowAlpha <= 0.01f) {
                continue;
            }

            rowFade.update();

            float rowTextAlpha = rowAlpha * alpha;
            float rowTop = rowY + 1.0f;
            String bindText = getBindText(bind);
            float textY = Math.round(rowTop + (9.0f - rowFont.getLineHeight(bind.getName())) / 2.0f);

            rowFont.draw(bind.getName(), Math.round(x + 6.0f), textY,
                    ColorUtil.withAlpha(theme.getText(), rowTextAlpha), matrices);

            float bindX = x + width - 5.0f - rowFont.getWidth(bindText) - 1.0f;
            rowFont.draw(bindText, Math.round(bindX), textY,
                    ColorUtil.withAlpha(theme.getAccent(), rowTextAlpha), matrices);

            rowY += 9.0f * rowAlpha;
        }

        cleanupRowAnimations(assist);
    }

    public boolean handleMouseClick(double mouseX, double mouseY, int button) {
        if (!Interface.INSTANCE.isHolyWorldAssistHudEnabled() || !ChatScreenDetector.isActive()) {
            return false;
        }

        if (button != 2) {
            return false;
        }

        float renderWidth = HudScaleUtil.getRenderWidth();
        HolyWorldAssistHudPosition position = HudEditor.getInstance().getHolyWorldAssist();
        position.ensureInitialized(renderWidth);

        float hudX = HudScaleUtil.toHudX(mouseX);
        float hudY = HudScaleUtil.toHudY(mouseY);
        if (!position.contains(hudX, hudY)) {
            return false;
        }

        HolyWorldAssist assist = HolyWorldAssist.INSTANCE;
        float rowY = position.getY() + 18.0f;

        for (KeybindSetting bind : assist.getBindSettings()) {
            FadeAnimation rowFade = rowFades.get(bind.getName());
            float rowAlpha = rowFade == null ? 0.0f : rowFade.getAlpha();
            if (!shouldRenderRow(assist, bind, rowAlpha)) {
                continue;
            }

            float rowHeight = 9.0f * rowAlpha;
            if (isHovered(hudX, hudY, position.getX(), rowY, position.getWidth(), rowHeight)) {
                BindCapture.begin(bind);
                return true;
            }

            rowY += rowHeight;
        }

        return false;
    }

    public boolean shouldRenderInMainHud() {
        return !ChatScreenDetector.isActive();
    }

    public boolean shouldRenderInChatOverlay() {
        return ChatScreenDetector.isActive();
    }

    private boolean shouldRenderRow(HolyWorldAssist assist, KeybindSetting bind, float rowAlpha) {
        if (ChatScreenDetector.isActive()) {
            return assist.isEnabled();
        }

        return rowAlpha > 0.01f || assist.isEnabled();
    }

    private String getBindText(KeybindSetting bind) {
        if (BindCapture.isActive(bind)) {
            return BindCapture.getListeningLabel();
        }

        if (bind.getKeyCode() < 0) {
            return "NONE";
        }

        return KeyNameUtil.toShortBind(bind.getKeyCode());
    }

    private void drawHeaderSeparator(DrawHelper renderer, MatrixStack matrices, float x, float y, float width,
            float alpha, GuiTheme theme) {
        float half = width / 2.0f;
        Color edge = ColorUtil.withAlpha(theme.getText(), 0.02f * alpha);
        Color center = ColorUtil.withAlpha(theme.getText(), 0.05f * alpha);

        renderer.drawGradientRoundedRect(x, y + 1.0f, half, 1.0f, 0.0f, edge, center, edge, center, matrices);
        renderer.drawGradientRoundedRect(x + half, y + 1.0f, half, 1.0f, 0.0f, center, edge, center, edge, matrices);
    }

    private void startLayoutAnimation(float width) {
        if (Math.abs(width - targetWidth) < 0.5f) {
            return;
        }

        layoutWidthFrom = animatedWidth;
        targetWidth = width;
        layoutAnimStartMs = System.currentTimeMillis();
        layoutAnimating = true;
    }

    private void updateLayoutAnimation() {
        if (!layoutAnimating) {
            return;
        }

        float progress = getSmoothProgress(layoutAnimStartMs);
        animatedWidth = layoutWidthFrom + (targetWidth - layoutWidthFrom) * progress;

        if (progress >= 1.0f) {
            animatedWidth = targetWidth;
            layoutAnimating = false;
        }
    }

    private float getSmoothProgress(long startMs) {
        float elapsed = System.currentTimeMillis() - startMs;
        float linear = Math.min(1.0f, Math.max(0.0f, elapsed / 250.0f));
        float eased = linear * linear * (3.0f - 2.0f * linear);
        return eased * eased * (3.0f - 2.0f * eased);
    }

    private void cleanupRowAnimations(HolyWorldAssist assist) {
        Iterator<Map.Entry<String, FadeAnimation>> iterator = rowFades.entrySet().iterator();

        rows:
        while (iterator.hasNext()) {
            Map.Entry<String, FadeAnimation> entry = iterator.next();
            if (entry.getValue().isVisible()) {
                continue;
            }

            for (KeybindSetting bind : assist.getBindSettings()) {
                if (bind.getName().equals(entry.getKey())) {
                    continue rows;
                }
            }

            iterator.remove();
        }
    }

    private static boolean isHovered(float pointX, float pointY, float x, float y, float width, float height) {
        return pointX >= x && pointX <= x + width && pointY >= y && pointY <= y + height;
    }
}
