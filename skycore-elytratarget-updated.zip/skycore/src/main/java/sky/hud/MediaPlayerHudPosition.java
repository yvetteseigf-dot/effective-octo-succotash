package sky.hud;

/**
 * Placement and bounds of the media player HUD panel, as edited by the HUD editor.
 */
public final class MediaPlayerHudPosition {

    private static final float DEFAULT_WIDTH = 155.0F;
    private static final float DEFAULT_HEIGHT = 18.0F;

    private float x;
    private float y;
    private float width = DEFAULT_WIDTH;
    private float height = DEFAULT_HEIGHT;
    private boolean initialized;

    /**
     * Centres the panel above the hotbar the first time it is rendered.
     */
    public void ensureInitialized(float screenWidth, float screenHeight) {
        if (initialized) {
            return;
        }

        x = (screenWidth - width) / 2.0F;
        y = screenHeight - height - 32.0F;
        initialized = true;
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
        this.initialized = true;
    }

    public void setSize(float width, float height) {
        this.width = Math.max(70.0F, width);
        this.height = Math.max(DEFAULT_HEIGHT, height);
    }

    public boolean contains(float pointX, float pointY) {
        return pointX >= x && pointX <= x + width && pointY >= y && pointY <= y + height;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }
}
