package sky.hud;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import sky.theme.GuiTheme;
import sky.module.combat.AttackAura;
import sky.module.misc.NameProtect;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.GuiSurfaceRenderer;
import sky.render.HudPanelRenderer;
import sky.render.DrawHelper;
import sky.util.ChatScreenDetector;
import sky.util.render.ColorUtil;
import sky.util.animation.EasedValue;
import sky.util.animation.Easing;
import sky.util.animation.FadeAnimation;
import sky.util.combat.HealthUtil;

/**
 * Target HUD: default compact card, follow-mode world projection, or the round layout.
 */
public final class TargetHud {
    private static final int ROUND_NAME_FONT = 16;
    private static final float FOLLOW_PROJECTION_RATE = 8.0f;
    private static final long ABSORPTION_ANIM_MS = 667L;
    private static final float HEAD_SIZE = 18.0f;
    private static final float ROUND_HEIGHT = 62.0f;
    private static final float PADDING = 5.0f;
    private static final float FOLLOW_DISPLAY_RATE = 5.0f;
    private static final float ROUND_FACE_SIZE = 37.0f;
    private static final float ROUND_RADIUS = 11.5f;
    private static final float ROUND_WIDTH = 213.0f;
    private static final float BAR_RADIUS = 2.0f;
    private static final float HP_ANIM_HEAVY_AT = 0.3f;
    private static final float RED_DURATION = 0.19f;
    private static final long SHOW_HIDE_ANIM_MS = 420L;
    private static final float HEIGHT = 32.0f;
    private static final float WIDTH = 96.0f;
    private static final float MIN_SCALE = 0.72f;
    private static final long HP_ANIM_LIGHT_MS = 360L;
    private static final int NAME_FONT = 14;
    private static final float BAR_HEIGHT = 3.0f;
    private static final float RADIUS = 11.5f;
    private static final int ROUND_HP_FONT = 15;
    private static final Color ABSORPTION_COLOR = new Color(255, 210, 0);
    private static final long HP_ANIM_HEAVY_MS = 720L;
    private static final float ROUND_MIN_SCALE = 0.8f;

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD,
            EquipmentSlot.CHEST,
            EquipmentSlot.LEGS,
            EquipmentSlot.FEET
    };

    private final MinecraftClient client;
    private final FadeAnimation visibility;
    private final EasedValue absorptionAnim;
    private final EasedValue secondaryAbsorptionAnim;

    private long lastDamageTime;
    private boolean healthAnimating;
    private long animDurationMs;
    private float followX;
    private long hideAfterMs;
    private float lastTargetProgress;
    private long lastRenderTimeNs;
    private float damageAnimationProgress;
    private float roundHealthTextAnim;
    private float roundHealthSegmentsAnim;
    private int roundHealthTextEntityId;
    private long lastFollowRenderNs;
    private Color headColor;
    private long animStartMs;
    private float animFrom;
    private float animTo;
    private float smoothProjY;
    private float smoothProjX;
    private float followY;
    private LivingEntity displayTarget;
    private float animatedHealth;
    private Color initialHeadColor;

    public TargetHud() {
        this.client = MinecraftClient.getInstance();
        this.visibility = new FadeAnimation();
        this.absorptionAnim = new EasedValue(ABSORPTION_ANIM_MS, 0.0f, Easing.CUBIC_OUT);
        this.secondaryAbsorptionAnim = new EasedValue(ABSORPTION_ANIM_MS, 0.0f, Easing.LINEAR);
        this.animatedHealth = -1.0f;
        this.lastTargetProgress = -1.0f;
        this.followX = Float.NaN;
        this.followY = Float.NaN;
        this.smoothProjX = Float.NaN;
        this.smoothProjY = Float.NaN;
        this.headColor = Color.WHITE;
        this.initialHeadColor = Color.WHITE;
        this.lastRenderTimeNs = System.nanoTime();
        this.roundHealthTextAnim = 20.0f;
        this.roundHealthTextEntityId = Integer.MIN_VALUE;
    }

    public void tick() {
        updateVisibility(resolveDesiredTarget());
        visibility.update();
        stepAbsorptionAnimations();
        cleanupIfClosed();
    }

    public void render(DrawContext context, float screenWidth, float screenHeight, float delta) {
        MatrixStack matrices = context.getMatrices();
        if (client.player == null || client.world == null) {
            return;
        }
        if (!visibility.isVisible() || displayTarget == null) {
            return;
        }
        DrawHelper renderer = DrawHelper.get();
        if (renderer == null) {
            return;
        }
        if (isRoundMode()) {
            renderRound(context, renderer, matrices, screenWidth, screenHeight, delta);
        } else {
            renderDefault(context, renderer, matrices, screenWidth, screenHeight, delta);
        }
    }

    private boolean isRoundMode() {
        return Interface.INSTANCE.targetHudMode.is("Circle");
    }

    private boolean useFollowMode() {
        return Interface.INSTANCE.targetHudMode.is("Follow") && !ChatScreenDetector.isActive();
    }

    private LivingEntity resolveDesiredTarget() {
        if (ChatScreenDetector.isActive() && client.player != null) {
            return client.player;
        }
        LivingEntity target = AttackAura.INSTANCE.getTarget();
        if (target != null && !isDead(target) && target != client.player) {
            return target;
        }
        return null;
    }

    private void updateVisibility(LivingEntity desired) {
        if (desired != null) {
            if (desired != displayTarget) {
                resetHealthAnimation();
                resetRoundAnimation(desired);
                resetFollowSmoothing();
                resetAbsorptionAnimation(desired);
            }
            displayTarget = desired;
            hideAfterMs = 0L;
            visibility.fadeIn(SHOW_HIDE_ANIM_MS);
            return;
        }
        if (displayTarget == null) {
            return;
        }
        if (visibility.isOpen()) {
            long delay = useFollowMode() ? 1500L : 0L;
            if (delay <= 0L) {
                visibility.fadeOut(SHOW_HIDE_ANIM_MS);
                return;
            }
            long now = System.currentTimeMillis();
            if (hideAfterMs == 0L) {
                hideAfterMs = now + delay;
                return;
            }
            if (now >= hideAfterMs) {
                visibility.fadeOut(SHOW_HIDE_ANIM_MS);
            }
        }
    }

    private void cleanupIfClosed() {
        if (visibility.isVisible()) {
            return;
        }
        displayTarget = null;
        resetHealthAnimation();
        resetFollowSmoothing();
        hideAfterMs = 0L;
    }

    private boolean isDead(LivingEntity entity) {
        return HealthUtil.getDisplayHealth(entity) <= 0.0f || entity.isDead();
    }

    private boolean isInvisibleTarget(LivingEntity target) {
        if (target.hasStatusEffect(StatusEffects.INVISIBILITY)) {
            return true;
        }
        if (target instanceof PlayerEntity player && player.isInvisible()) {
            return true;
        }
        return false;
    }

    private boolean isLocalPlayer(LivingEntity entity) {
        return entity != null && entity == client.player;
    }

    private String getName(LivingEntity entity) {
        return getName(entity, 30);
    }

    private String getName(LivingEntity entity, int maxLen) {
        if (entity == null) {
            return "?";
        }
        String name = entity instanceof PlayerEntity
                ? entity.getNameForScoreboard()
                : entity.getDisplayName() == null ? "?" : entity.getDisplayName().getString();
        if (name == null || name.isEmpty()) {
            name = "?";
        }
        name = NameProtect.getCustomName(name);
        if (name == null || name.isEmpty()) {
            return "?";
        }
        if (name.length() > maxLen) {
            return name.substring(0, maxLen);
        }
        return name;
    }

    private String formatHealth(LivingEntity entity) {
        return String.format(Locale.US, "%.1f", Math.max(0.0f, HealthUtil.getDisplayHealth(entity)));
    }

    private float getHealthProgress(LivingEntity entity) {
        float maxHealth = Math.max(1.0f, entity.getMaxHealth());
        return Math.max(0.0f, Math.min(1.0f, HealthUtil.getDisplayHealth(entity) / maxHealth));
    }

    private float getPanelWidth() {
        return isRoundMode() ? ROUND_WIDTH : WIDTH;
    }

    private float getPanelHeight() {
        return isRoundMode() ? ROUND_HEIGHT : HEIGHT;
    }

    private void resetRoundAnimation(LivingEntity target) {
        roundHealthSegmentsAnim = 0.0f;
        roundHealthTextAnim = Math.max(0.0f, HealthUtil.getDisplayHealth(target));
        roundHealthTextEntityId = target.getId();
        damageAnimationProgress = 0.0f;
        headColor = Color.WHITE;
        initialHeadColor = Color.WHITE;
        resetAbsorptionAnimation(target);
    }

    private void resetAbsorptionAnimation(LivingEntity target) {
        float absorption = Math.max(0.0f, target.getAbsorptionAmount());
        absorptionAnim.setValue(absorption);
        secondaryAbsorptionAnim.setValue(absorption);
    }

    private void resetFollowSmoothing() {
        followX = Float.NaN;
        followY = Float.NaN;
        smoothProjX = Float.NaN;
        smoothProjY = Float.NaN;
        lastFollowRenderNs = 0L;
    }

    private void resetHealthAnimation() {
        animatedHealth = -1.0f;
        lastTargetProgress = -1.0f;
        healthAnimating = false;
        animStartMs = 0L;
        animDurationMs = 0L;
    }

    private void stepAbsorptionAnimations() {
        if (displayTarget == null) {
            return;
        }
        float absorption = Math.max(0.0f, displayTarget.getAbsorptionAmount());
        absorptionAnim.update(absorption);
        secondaryAbsorptionAnim.update(absorption);
    }

    private void renderRound(DrawContext context, DrawHelper renderer, MatrixStack matrices,
                             float screenWidth, float screenHeight, float delta) {
        float alpha = visibility.getAlpha();
        float eased = easeOutBack(alpha);
        float scale = ROUND_MIN_SCALE + (1.0f - ROUND_MIN_SCALE) * eased;
        float scaledWidth = ROUND_WIDTH * scale;
        float scaledHeight = ROUND_HEIGHT * scale;
        float[] center = resolveAnchorCenter(screenWidth, screenHeight, delta);
        float centerX = center[0];
        float centerY = center[1];
        float x = centerX - scaledWidth / 2.0f;
        float y = centerY - scaledHeight / 2.0f;

        long nowNs = System.nanoTime();
        float deltaTime = resolveRenderDeltaSeconds(nowNs);
        lastRenderTimeNs = nowNs;
        updateDamageFlash(displayTarget, nowNs, deltaTime);

        DrawHelper.scaleStart(matrices, centerX, centerY, scale);
        GuiTheme theme = GuiTheme.theme;
        GuiSurfaceRenderer.drawHudSurface(renderer, x, y, ROUND_WIDTH, ROUND_HEIGHT, ROUND_RADIUS, alpha, matrices);

        float faceX = x + 8.0f;
        float faceY = Math.round(centerY - ROUND_FACE_SIZE / 2.0f);
        float nameX = x + ROUND_FACE_SIZE + 17.0f;
        float nameY = y + 25.0f;

        renderHead(renderer, matrices, displayTarget, faceX, faceY, ROUND_FACE_SIZE, alpha, theme, headColor);

        FontRenderer nameFont = FontRegistry.getRegular(ROUND_NAME_FONT);
        if (nameFont == null) {
            DrawHelper.scaleEnd(matrices);
            return;
        }
        String name = getName(displayTarget, 11);
        nameFont.draw(name, (double) nameX, (double) nameY,
                ColorUtil.withAlpha(theme.getText(), alpha), matrices);

        renderTargetItems(context, matrices, displayTarget, nameX, y + 33.0f, alpha);

        float healthPercentage = isDead(displayTarget) ? 0.0f : getHealthProgress(displayTarget);
        renderRoundHealth(renderer, matrices, displayTarget, faceX + 4.0f, faceY, ROUND_FACE_SIZE,
                alpha, deltaTime, healthPercentage);

        DrawHelper.scaleEnd(matrices);
    }

    private void renderRoundHealth(DrawHelper renderer, MatrixStack matrices, LivingEntity target,
                                   float faceX, float faceY, float faceSize, float alpha, float deltaTime,
                                   float healthPercentage) {
        float ringRadius = faceSize * 0.42f;
        float step = 360.0f / 128.0f;
        float ringX = faceX + ROUND_WIDTH - 40.0f;
        float ringY = faceY + faceSize * 0.5f;
        boolean invisible = isInvisibleTarget(target);

        float targetSegments;
        if (invisible) {
            long cycle = System.currentTimeMillis() % 6000L;
            float half = 6000.0f / 2.0f;
            float pulse = cycle < 3000L
                    ? 1.0f - (float) cycle / half
                    : ((float) cycle - half) / half;
            targetSegments = pulse * 128.0f;
        } else {
            targetSegments = healthPercentage * 128.0f;
        }

        roundHealthSegmentsAnim = lerp(roundHealthSegmentsAnim, targetSegments, deltaTime * 6.0f);
        int filled = Math.max(0, Math.min(128, Math.round(roundHealthSegmentsAnim)));

        GuiTheme theme = GuiTheme.theme;
        Color trackColor = ColorUtil.withAlpha(theme.getPanelBottom(), alpha * 0.35f);
        float dot = 3.1f;
        float halfDot = dot * 0.5f;

        for (int i = 0; i < 128; i++) {
            float degrees = i * step - 90.0f;
            float radians = (float) Math.toRadians(degrees);
            float x = ringX + (float) Math.cos(radians) * ringRadius - halfDot;
            float y = ringY + (float) Math.sin(radians) * ringRadius - halfDot;
            renderer.drawRoundedRect(x, y, dot, dot, halfDot, trackColor, matrices);
        }

        if (!invisible) {
            Color fill = ColorUtil.withAlpha(theme.getAccent(), alpha);
            Color fillLight = ColorUtil.withAlpha(
                    ColorUtil.lerp(theme.getAccent(), Color.WHITE, 0.35f), alpha);
            for (int i = 0; i < filled; i++) {
                float degrees = i * step - 90.0f;
                float radians = (float) Math.toRadians(degrees);
                float x = ringX + (float) Math.cos(radians) * ringRadius - halfDot;
                float y = ringY + (float) Math.sin(radians) * ringRadius - halfDot;
                renderer.drawGradientRoundedRect(x, y, dot, dot, halfDot, fill, fillLight, fill, fillLight, matrices);
            }
        }

        String healthText;
        if (invisible) {
            healthText = "?";
            roundHealthTextAnim = -1.0f;
        } else {
            float health = Math.max(0.0f, HealthUtil.getDisplayHealth(target));
            if (roundHealthTextEntityId != target.getId()) {
                roundHealthTextEntityId = target.getId();
                roundHealthTextAnim = health;
            }
            roundHealthTextAnim = lerp(roundHealthTextAnim, health, deltaTime * 8.0f);
            healthText = String.valueOf(Math.round(Math.max(0.0f, roundHealthTextAnim)));
        }

        FontRenderer font = FontRegistry.getRegular(ROUND_HP_FONT);
        if (font == null) {
            return;
        }
        float textY = ringY - font.getLineHeight(healthText) * 0.01f + PADDING;
        font.drawCentered(healthText, (double) ringX, (double) textY,
                ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);
    }

    private void renderDefault(DrawContext context, DrawHelper renderer, MatrixStack matrices,
                               float screenWidth, float screenHeight, float delta) {
        boolean dead = isDead(displayTarget);
        float alpha = visibility.getAlpha();
        float eased = easeOutBack(alpha);
        float scale = (MIN_SCALE + (1.0f - MIN_SCALE) * eased) * 1.1f;

        String name = getName(displayTarget);
        FontRenderer compactFont = FontRegistry.getKrisaMedium(12);
        if (compactFont == null) {
            return;
        }
        float nameWidth = compactFont.getWidth(name);
        float panelWidth = (77.5f + Math.max(0.0f, nameWidth - 37.5f)) * scale;
        float panelHeight = 23.0f * scale;

        float[] center = resolveAnchorCenter(screenWidth, screenHeight, delta);
        float centerX = center[0];
        float centerY = center[1];
        float x = centerX - panelWidth / 2.0f;
        float y = centerY - panelHeight / 2.0f;

        GuiTheme theme = GuiTheme.theme;
        HudPanelRenderer.drawBackground(renderer, x, y, panelWidth, panelHeight, 11.0f * scale,
                ColorUtil.withAlpha(theme.getPanelTop(), alpha),
                ColorUtil.withAlpha(theme.getPanelBottom(), alpha),
                alpha, matrices);

        float headSize = 15.0f * scale;
        float headX = x + 4.0f * scale;
        float headY = y + 4.0f * scale;
        FontRenderer nameFont = compactFont;
        float nameX = x + 23.5f * scale;
        float nameY = y + 4.0f * scale;
        nameFont.draw(name, (double) nameX, (double) nameY,
                ColorUtil.withAlpha(theme.getText(), alpha), matrices);

        renderHead(renderer, matrices, displayTarget, headX, headY, headSize, alpha, theme, Color.WHITE);

        float healthProgress = dead ? 0.0f : getHealthProgress(displayTarget);
        stepHealthAnimation(healthProgress);

        float ringX = x + panelWidth - 10.0f * scale;
        float ringY = y + RADIUS * scale;
        float ringRadius = 6.0f * scale;
        float ringThickness = 1.5f * scale;
        renderHealthRings(renderer, matrices, ringX, ringY, ringRadius, ringThickness, alpha, theme, displayTarget);

        nameFont.drawCentered(
                String.valueOf(Math.round(HealthUtil.getDisplayHealth(displayTarget))),
                (double) (ringX + 0.1f),
                (double) (ringY - 2.5f * scale - 1.5f),
                ColorUtil.withAlpha(theme.getText(), alpha),
                matrices);

        renderCompactArmor(context, renderer, matrices, x + 23.0f * scale, y + 13.0f * scale, alpha);
    }

    private void renderHead(DrawHelper renderer, MatrixStack matrices, LivingEntity entity,
                            float x, float y, float size, float alpha, GuiTheme theme, Color tint) {
        if (entity instanceof AbstractClientPlayerEntity player) {
            initialHeadColor = Color.WHITE;
            if (player.getSkinTextures() == null || player.getSkinTextures().texture() == null) {
                return;
            }
            Identifier skin = player.getSkinTextures().texture();
            float radius = isRoundMode() ? 9.0f : 7.0f;
            renderer.drawRoundedTexture(skin, x, y, size, size, radius,
                    0.125f, 0.125f, 0.125f, 0.125f,
                    ColorUtil.withAlpha(tint, alpha), matrices);
            return;
        }

        initialHeadColor = theme.getPanelBottom();
        float radius = isRoundMode() ? 9.0f : 7.0f;
        renderer.drawRoundedRect(x, y, size, size, radius, ColorUtil.withAlpha(tint, alpha), matrices);
        FontRenderer font = FontRegistry.getRegular(12);
        if (font == null) {
            return;
        }
        String letter = getName(entity);
        if (letter.isEmpty()) {
            letter = "?";
        } else {
            letter = letter.substring(0, 1).toUpperCase();
        }
        font.drawCentered(letter,
                (double) (x + size / 2.0f),
                (double) (y + (size - font.getLineHeight(letter)) / 2.0f),
                ColorUtil.withAlpha(theme.getText(), alpha),
                matrices);
    }

    private void renderHealthRings(DrawHelper renderer, MatrixStack matrices, float ringX, float ringY,
                                   float ringRadius, float ringThickness, float alpha, GuiTheme theme,
                                   LivingEntity target) {
        renderer.drawArc(ringX, ringY, ringRadius, -90.0f, 360.0f, ringThickness,
                ColorUtil.withAlpha(new Color(36, 36, 36), alpha), matrices);
        renderer.drawArc(ringX, ringY, ringRadius, -90.0f, 360.0f * animatedHealth, ringThickness,
                ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);

        if (!Interface.INSTANCE.targetHudGoldenHearts.isEnabled()) {
            return;
        }

        float maxHealth = Math.max(1.0f, target.getMaxHealth());
        float secondary = Math.min(1.0f, Math.max(0.0f, secondaryAbsorptionAnim.getValue() / maxHealth));
        float primary = Math.min(1.0f, Math.max(0.0f, absorptionAnim.getValue() / maxHealth));

        if (secondary > 0.01f) {
            renderer.drawArc(ringX, ringY, ringRadius, -90.0f, 360.0f * secondary, ringThickness,
                    ColorUtil.withAlpha(ColorUtil.darken(ABSORPTION_COLOR, 0.4f), alpha * 0.65f), matrices);
        }
        if (primary > 0.01f) {
            renderer.drawArc(ringX, ringY, ringRadius, -90.0f, 360.0f * primary, ringThickness,
                    ColorUtil.withAlpha(ABSORPTION_COLOR, alpha), matrices);
        }
    }

    private void renderCompactArmor(DrawContext context, DrawHelper renderer, MatrixStack matrices,
                                    float x, float y, float alpha) {
        for (int i = 0; i < ARMOR_SLOTS.length; i++) {
            if (i > 0) {
                renderer.drawRoundedRect(
                        x + i * 8.5f - 1.0f,
                        y + 1.0f,
                        0.5f,
                        4.0f,
                        ColorUtil.withAlpha(Color.WHITE, alpha * 0.04f),
                        matrices);
            }
            ItemStack stack = displayTarget.getEquippedStack(ARMOR_SLOTS[i]);
            if (!stack.isEmpty()) {
                renderer.drawStack(context, matrices, stack, x + i * 8.5f, y, 0.38f);
            }
        }
    }

    private void renderTargetItems(DrawContext context, MatrixStack matrices, LivingEntity target,
                                   float x, float y, float alpha) {
        DrawHelper renderer = DrawHelper.get();
        if (renderer == null) {
            return;
        }
        float cursorX = x - 2.0f;
        float gap = 1.0f;
        Color slotBg = ColorUtil.withAlpha(Color.WHITE, alpha * 0.06f);
        for (ItemStack stack : getTargetItems(target)) {
            renderer.drawRoundedRect(cursorX, y, 16.0f + 2.0f, 16.0f + 2.0f, 4.0f, slotBg, matrices);
            if (stack != null && !stack.isEmpty()) {
                renderer.drawStack(context, matrices, stack, cursorX + BAR_HEIGHT, y + BAR_HEIGHT,
                        (16.0f - 4.0f) / 16.0f);
            }
            cursorX += 16.0f + 2.0f + gap;
        }
    }

    private List<ItemStack> getTargetItems(LivingEntity target) {
        List<ItemStack> items = new ArrayList<>(6);
        items.add(target.getMainHandStack());
        items.add(target.getOffHandStack());
        items.add(target.getEquippedStack(EquipmentSlot.HEAD));
        items.add(target.getEquippedStack(EquipmentSlot.CHEST));
        items.add(target.getEquippedStack(EquipmentSlot.LEGS));
        items.add(target.getEquippedStack(EquipmentSlot.FEET));
        return items;
    }

    private void updateDamageFlash(LivingEntity target, long currentTime, float deltaTime) {
        if (target == null) {
            return;
        }
        float hurtRatio = target.hurtTime / 7.0f;
        float elapsed = (currentTime - lastDamageTime) / 1.0E9f;
        Color damageRed = new Color(255, 70, 70, 255);
        if (hurtRatio > 1.0f) {
            lastDamageTime = currentTime;
            damageAnimationProgress = lerp(damageAnimationProgress, 1.0f, deltaTime / 0.1f);
        } else if (hurtRatio < 1.0f) {
            damageAnimationProgress = lerp(damageAnimationProgress, 0.0f, deltaTime / 0.15f);
        } else if (elapsed < RED_DURATION) {
            damageAnimationProgress = 1.0f;
        }
        headColor = lerpColorWithAlpha(initialHeadColor, damageRed, damageAnimationProgress);
    }

    private void stepHealthAnimation(float targetProgress) {
        if (animatedHealth < 0.0f) {
            animatedHealth = targetProgress;
            lastTargetProgress = targetProgress;
            return;
        }
        if (lastTargetProgress >= 0.0f && targetProgress < lastTargetProgress - 0.004f) {
            float damage = lastTargetProgress - targetProgress;
            animFrom = animatedHealth;
            animTo = targetProgress;
            animStartMs = System.currentTimeMillis();
            animDurationMs = resolveHealthDuration(damage);
            healthAnimating = true;
        } else if (targetProgress > animatedHealth + 0.004f) {
            healthAnimating = false;
            animatedHealth = targetProgress;
        }
        lastTargetProgress = targetProgress;
        if (!healthAnimating) {
            if (Math.abs(targetProgress - animatedHealth) < 5.0E-4f) {
                animatedHealth = targetProgress;
            }
            return;
        }
        long elapsed = System.currentTimeMillis() - animStartMs;
        float progress = Math.min(1.0f, (float) elapsed / (float) animDurationMs);
        float eased = easeOutCubic(progress);
        animatedHealth = animFrom + (animTo - animFrom) * eased;
        if (progress >= 1.0f) {
            animatedHealth = animTo;
            healthAnimating = false;
        }
    }

    private long resolveHealthDuration(float damage) {
        float span = Math.max(0.08f, HP_ANIM_HEAVY_AT);
        float t = Math.min(1.0f, damage / span);
        t = t * t * (3.0f - 2.0f * t);
        return Math.round(HP_ANIM_LIGHT_MS + (HP_ANIM_HEAVY_MS - HP_ANIM_LIGHT_MS) * t);
    }

    private float[] resolveAnchorCenter(float screenWidth, float screenHeight, float delta) {
        TargetHudPosition position = HudEditor.getInstance().getTargetHud();
        position.setSize(getPanelWidth(), getPanelHeight());
        position.ensureInitialized(screenWidth, screenHeight);
        float centerX = position.getX() + position.getWidth() / 2.0f;
        float centerY = position.getY() + position.getHeight() / 2.0f;

        if (ChatScreenDetector.isActive() || isLocalPlayer(displayTarget)) {
            resetFollowSmoothing();
            return new float[] {centerX, centerY};
        }

        if (useFollowMode() && displayTarget != null) {
            float[] projected = projectEntityToHud(screenWidth, screenHeight, displayTarget);
            if (projected != null) {
                float frameDelta = getFollowFrameDeltaSeconds();
                if (Float.isNaN(smoothProjX) || Float.isNaN(smoothProjY)) {
                    smoothProjX = projected[0];
                    smoothProjY = projected[1];
                    followX = projected[0];
                    followY = projected[1];
                } else {
                    float projFactor = expSmoothFactor(FOLLOW_PROJECTION_RATE, frameDelta);
                    smoothProjX += (projected[0] - smoothProjX) * projFactor;
                    smoothProjY += (projected[1] - smoothProjY) * projFactor;
                    float displayFactor = expSmoothFactor(FOLLOW_DISPLAY_RATE, frameDelta);
                    followX += (smoothProjX - followX) * displayFactor;
                    followY += (smoothProjY - followY) * displayFactor;
                }
                return new float[] {followX, followY};
            }
            if (!Float.isNaN(followX) && !Float.isNaN(followY)) {
                return new float[] {followX, followY};
            }
        }

        if (!useFollowMode()) {
            resetFollowSmoothing();
        }
        return new float[] {centerX, centerY};
    }

    private float[] projectEntityToHud(float screenWidth, float screenHeight, LivingEntity entity) {
        if (client.gameRenderer == null || client.world == null) {
            return null;
        }
        Camera camera = client.gameRenderer.getCamera();
        if (camera == null) {
            return null;
        }
        float tickDelta = client.getRenderTickCounter().getTickDelta(false);
        Vec3d cameraPos = camera.getPos();
        Vec3d entityPos = entity.getLerpedPos(tickDelta).add(0.0, entity.getHeight() * 0.45, 0.0);
        Vector3f relative = new Vector3f(
                (float) (entityPos.x - cameraPos.x),
                (float) (entityPos.y - cameraPos.y),
                (float) (entityPos.z - cameraPos.z));
        relative.rotate(new Quaternionf(camera.getRotation()).conjugate());
        if (relative.z >= -0.01f) {
            return null;
        }
        float fov = client.options.getFov().getValue();
        float tanHalfFov = (float) Math.tan(Math.toRadians(fov) / 2.0);
        float aspect = Math.max(0.1f, screenWidth / Math.max(1.0f, screenHeight));
        float ndcX = (relative.x / -relative.z) / (tanHalfFov * aspect);
        float ndcY = (relative.y / -relative.z) / tanHalfFov;
        float hudX = screenWidth * 0.5f + ndcX * screenWidth * 0.5f;
        float hudY = screenHeight * 0.5f - ndcY * screenHeight * 0.5f - getPanelHeight() * 0.05f;
        return new float[] {hudX, hudY};
    }

    private float getFollowFrameDeltaSeconds() {
        long now = System.nanoTime();
        if (lastFollowRenderNs == 0L) {
            lastFollowRenderNs = now;
            return 0.016f;
        }
        float delta = (now - lastFollowRenderNs) / 1.0E9f;
        lastFollowRenderNs = now;
        return Math.max(0.001f, Math.min(0.05f, delta));
    }

    private float resolveRenderDeltaSeconds(long currentTimeNs) {
        if (lastRenderTimeNs == 0L) {
            return 0.016f;
        }
        float delta = (currentTimeNs - lastRenderTimeNs) / 1.0E9f;
        return Math.max(0.001f, Math.min(0.05f, delta));
    }

    private float expSmoothFactor(float rate, float deltaSeconds) {
        return 1.0f - (float) Math.exp(-rate * deltaSeconds);
    }

    private static float lerp(float current, float target, float speed) {
        return current + (target - current) * Math.min(speed, 1.0f);
    }

    private static Color lerpColorWithAlpha(Color start, Color end, float progress) {
        progress = Math.max(0.0f, Math.min(1.0f, progress));
        int red = (int) (start.getRed() + (end.getRed() - start.getRed()) * progress);
        int green = (int) (start.getGreen() + (end.getGreen() - start.getGreen()) * progress);
        int blue = (int) (start.getBlue() + (end.getBlue() - start.getBlue()) * progress);
        int alpha = (int) (start.getAlpha() + (end.getAlpha() - start.getAlpha()) * progress);
        return new Color(red, green, blue, alpha);
    }

    private static float easeOutBack(float value) {
        value = Math.max(0.0f, Math.min(1.0f, value));
        float c3 = 1.70158f + 1.0f;
        return 1.0f + c3 * (float) Math.pow(value - 1.0f, 3.0) + 1.70158f * (float) Math.pow(value - 1.0f, 2.0);
    }

    private static float easeOutCubic(float value) {
        float inverse = 1.0f - value;
        return 1.0f - inverse * inverse * inverse;
    }
}
