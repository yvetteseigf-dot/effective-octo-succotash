package sky.hud;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import sky.module.visuals.Interface;
import sky.module.visuals.Tags;
import sky.render.EntityTagRenderer;
import sky.render.DrawHelper;
import sky.hud.ArmorHud;
import sky.hud.CooldownHud;
import sky.hud.CoordinatesHud;
import sky.hud.HolyWorldAssistHud;
import sky.hud.HudEditor;
import sky.hud.KeybindHud;
import sky.hud.MediaPlayerHud;
import sky.hud.NotificationManager;
import sky.hud.PotionEffectsHud;
import sky.hud.StaffListHud;
import sky.hud.TargetHud;
import sky.hud.TimerHud;
import sky.hud.WatermarkHud;
import sky.util.ChatScreenDetector;
import sky.util.render.HudScaleUtil;

public final class HudManager {
    private static final HudManager INSTANCE = new HudManager();

    private final MinecraftClient client = MinecraftClient.getInstance();

    public WatermarkHud watermark = new WatermarkHud();
    public TargetHud targetHud = new TargetHud();
    public NotificationManager notifications = new NotificationManager();
    public KeybindHud keyBinds = new KeybindHud();
    public HolyWorldAssistHud holyWorldAssist = new HolyWorldAssistHud();
    public CooldownHud cooldowns = new CooldownHud();
    public PotionEffectsHud potions = new PotionEffectsHud();
    public StaffListHud staffList = new StaffListHud();
    public MediaPlayerHud mediaPlayer = new MediaPlayerHud();
    public CoordinatesHud coordinates = new CoordinatesHud();
    public ArmorHud armorHud = new ArmorHud();
    public TimerHud timerHud = new TimerHud();
    public EntityTagRenderer tags = new EntityTagRenderer();

    private boolean eventsRegistered;

    private HudManager() {
    }

    public static HudManager getInstance() {
        return INSTANCE;
    }

    public void registerEvents() {
        if (this.eventsRegistered) {
            return;
        }
        this.eventsRegistered = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world == null || client.player == null) {
                return;
            }
            if (ChatScreenDetector.isActive()) {
                HudEditor.getInstance().updateDragPosition();
            }
            if (Interface.INSTANCE.isTargetHudEnabled()) {
                this.targetHud.tick();
            }
            if (Interface.INSTANCE.isNotificationsEnabled()) {
                this.notifications.tick();
            }
            if (Interface.INSTANCE.isKeyBindsEnabled()) {
                this.keyBinds.tick();
            }
            if (Interface.INSTANCE.isHolyWorldAssistHudEnabled()) {
                this.holyWorldAssist.tick();
            }
            if (Interface.INSTANCE.isCooldownsEnabled()) {
                this.cooldowns.tick();
            }
            if (Interface.INSTANCE.isPotionsEnabled()) {
                this.potions.tick();
            }
            if (Interface.INSTANCE.isStaffListEnabled()) {
                this.staffList.tick();
            }
            if (Interface.INSTANCE.isMediaPlayerEnabled()) {
                this.mediaPlayer.tick();
            }
            if (Interface.INSTANCE.isTimerHudEnabled()) {
                this.timerHud.tick();
            }
        });
    }

    public void render(DrawContext context, float delta) {
        if (this.client.world == null || this.client.player == null || DrawHelper.get() == null) {
            return;
        }

        float screenWidth = HudScaleUtil.getRenderWidth();
        float screenHeight = HudScaleUtil.getRenderHeight();

        boolean chatActive = ChatScreenDetector.isActive();
        if (chatActive) {
            HudEditor.getInstance().updateDragPosition();
        }

        if (Tags.INSTANCE.isEnabled()) {
            renderSafe(() -> this.tags.render(context, context.getMatrices(), screenWidth, screenHeight, delta));
        }

        renderHudPanels(context, delta, screenWidth, screenHeight);
    }

    private void renderHudPanels(DrawContext context, float delta, float screenWidth, float screenHeight) {
        boolean chatActive = ChatScreenDetector.isActive();
        DrawHelper.beginHudRenderBatch();
        try {
            if (Interface.INSTANCE.isWatermarkEnabled()) {
                renderSafe(() -> this.watermark.render(context.getMatrices(), screenWidth));
            }
            if (Interface.INSTANCE.isNotificationsEnabled()
                    && (chatActive
                            ? this.notifications.shouldRenderInChatOverlay()
                            : this.notifications.shouldRenderInMainHud())) {
                renderSafe(() -> this.notifications.render(context.getMatrices(), screenWidth, screenHeight));
            }
            if (Interface.INSTANCE.isKeyBindsEnabled()
                    && (chatActive
                            ? this.keyBinds.shouldRenderInChatOverlay()
                            : this.keyBinds.shouldRenderInMainHud())) {
                renderSafe(() -> this.keyBinds.render(context.getMatrices(), screenWidth));
            }
            if (Interface.INSTANCE.isHolyWorldAssistHudEnabled()
                    && (chatActive
                            ? this.holyWorldAssist.shouldRenderInChatOverlay()
                            : this.holyWorldAssist.shouldRenderInMainHud())) {
                renderSafe(() -> this.holyWorldAssist.render(context.getMatrices(), screenWidth));
            }
            if (Interface.INSTANCE.isCooldownsEnabled()) {
                renderSafe(() -> this.cooldowns.render(context, screenWidth));
            }
            if (Interface.INSTANCE.isPotionsEnabled()
                    && (chatActive
                            ? this.potions.shouldRenderInChatOverlay()
                            : this.potions.shouldRenderInMainHud())) {
                renderSafe(() -> this.potions.render(context.getMatrices(), screenWidth));
            }
            if (Interface.INSTANCE.isStaffListEnabled()
                    && (chatActive
                            ? this.staffList.shouldRenderInChatOverlay()
                            : this.staffList.shouldRenderInMainHud())) {
                renderSafe(() -> this.staffList.render(context.getMatrices(), screenWidth));
            }
            if (Interface.INSTANCE.isMediaPlayerEnabled()
                    && (chatActive
                            ? this.mediaPlayer.shouldRenderInChatOverlay()
                            : this.mediaPlayer.shouldRenderInMainHud())) {
                renderSafe(() -> this.mediaPlayer.render(context.getMatrices(), screenWidth, screenHeight));
            }
            if (Interface.INSTANCE.isTargetHudEnabled()) {
                renderSafe(() -> this.targetHud.render(context, screenWidth, screenHeight, delta));
            }
            if (Interface.INSTANCE.isCoordinatesEnabled()) {
                renderSafe(() -> this.coordinates.render(context.getMatrices(), screenWidth, screenHeight));
            }
            if (Interface.INSTANCE.isArmorHudEnabled()) {
                renderSafe(() -> this.armorHud.render(context, screenWidth, screenHeight));
            }
            if (Interface.INSTANCE.isTimerHudEnabled()
                    && (chatActive
                            ? this.timerHud.shouldRenderInChatOverlay()
                            : this.timerHud.shouldRenderInMainHud())) {
                renderSafe(() -> this.timerHud.render(context.getMatrices(), screenWidth, screenHeight));
            }
            renderSafe(() -> HudEditor.getInstance().renderOverlay(DrawHelper.get(), context.getMatrices()));
        } finally {
            DrawHelper.endHudRenderBatch();
        }
    }

    private void renderSafe(Runnable action) {
        try {
            action.run();
        } catch (Throwable ignored) {
        }
    }
}
