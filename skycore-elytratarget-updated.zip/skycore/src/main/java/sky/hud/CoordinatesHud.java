package sky.hud;

import java.awt.Color;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;

/**
 * Bottom-left overlay showing the player's block position and travel speed.
 */
public final class CoordinatesHud {
    private static final int FONT_SIZE = 18;
    private static final float MARGIN_X = 6.0f;
    private static final float MARGIN_Y = 6.0f;
    private static final float LINE_GAP = 2.0f;
    private static final Color TEXT_COLOR = new Color(255, 255, 255, 255);

    public void render(MatrixStack matrices, float screenWidth, float screenHeight) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            return;
        }

        FontRenderer font = FontRegistry.getMedium(FONT_SIZE);
        if (font == null) {
            return;
        }

        int blockX = (int) Math.floor(player.getX());
        int blockY = (int) Math.floor(player.getY());
        int blockZ = (int) Math.floor(player.getZ());
        String coordinates = String.format(Locale.US, "X: %d, Y: %d, Z: %d", blockX, blockY, blockZ);

        double deltaX = player.getX() - player.lastRenderX;
        double deltaY = player.getY() - player.lastRenderY;
        double deltaZ = player.getZ() - player.lastRenderZ;
        double blocksPerSecond = Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ) * 20.0;
        String speed = "BPS: " + String.format(Locale.US, "%.1f", blocksPerSecond);

        float lineHeight = font.getLineHeight(coordinates);
        float lineStep = lineHeight + LINE_GAP;
        float coordinatesY = screenHeight - MARGIN_Y - lineHeight;
        float speedY = coordinatesY - lineStep;

        font.draw(speed, MARGIN_X, speedY, TEXT_COLOR, matrices);
        font.draw(coordinates, MARGIN_X, coordinatesY, TEXT_COLOR, matrices);
    }
}
