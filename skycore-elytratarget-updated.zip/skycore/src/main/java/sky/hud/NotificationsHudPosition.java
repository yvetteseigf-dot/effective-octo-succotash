package sky.hud;

/**
 * Draggable anchor for the notification stack. Horizontally the stack stays centred on the
 * screen, so only the vertical anchor is persisted.
 */
public final class NotificationsHudPosition {
    private static final float DEFAULT_WIDTH = 100.0f;
    private static final float HEIGHT = 19.0f;

    private float x;
    private float y;
    private float width = DEFAULT_WIDTH;
    private float hitHeight = HEIGHT;
    private boolean initialized;

    public void ensureInitialized(float screenWidth, float screenHeight) {
        ensureInitialized(screenWidth, screenHeight, HEIGHT);
    }

    public void ensureInitialized(float screenWidth, float screenHeight, float elementHeight) {
        if (!initialized) {
            syncCenterX(screenWidth);
            y = (screenHeight - elementHeight) / 2.0f;
            initialized = true;
        }
    }

    public void syncCenterX(float screenWidth) {
        x = (screenWidth - width) / 2.0f;
    }

    public void setAnchorY(float y, float screenWidth) {
        syncCenterX(screenWidth);
        this.y = y;
        initialized = true;
    }

    public void loadAnchorY(float y) {
        this.y = y;
        initialized = true;
    }

    public boolean contains(float renderX, float renderY) {
        return renderX >= x && renderX <= x + width && renderY >= y && renderY <= y + hitHeight;
    }

    public void setWidth(float width) {
        this.width = Math.max(44.0f, width);
    }

    public void setHitHeight(float hitHeight) {
        this.hitHeight = Math.max(HEIGHT, hitHeight);
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return HEIGHT;
    }

    public float getCenterX() {
        return x + width / 2.0f;
    }
}
