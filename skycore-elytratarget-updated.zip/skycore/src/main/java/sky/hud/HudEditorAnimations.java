package sky.hud;

import sky.util.animation.FadeAnimation;

/**
 * Shared fade animations driven by the HUD editor screen.
 */
public final class HudEditorAnimations {

    public static final FadeAnimation LAYOUT_HINT = new FadeAnimation();
    public static final FadeAnimation DRAG_GRID = new FadeAnimation();

    private HudEditorAnimations() {
    }

    public static void updateAll() {
        LAYOUT_HINT.update();
        DRAG_GRID.update();
    }
}
