package sky.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import sky.theme.GuiTheme;
import sky.module.movement.ChargeBoost;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.HudPanelRenderer;
import sky.render.DrawHelper;
import sky.util.ChatScreenDetector;
import sky.util.render.ColorUtil;
import sky.util.animation.FadeAnimation;

/**
 * HUD panel showing the charge state and progress of the speed timer.
 */
public final class TimerHud {
    private static final float HEIGHT = 18.0f;
    private static final float MIN_WIDTH = 72.0f;
    private static final float MAX_WIDTH = 155.0f;
    private static final float PADDING = 3.0f;
    private static final float RADIUS = 12.0f;
    private static final float COVER_SIZE = 11.0f;
    private static final long FADE_DURATION_MS = 250L;

    private final FadeAnimation fade = new FadeAnimation();
    private float perc;

    public void tick() {
        if (!Interface.INSTANCE.isTimerHudEnabled()) {
            if (fade.isVisible()) {
                fade.fadeOut(FADE_DURATION_MS);
            }
            fade.update();
            return;
        }

        if (!fade.isOpen()) {
            fade.fadeIn(FADE_DURATION_MS);
        }
        fade.update();
    }

    public boolean shouldRenderInMainHud() {
        return !ChatScreenDetector.isActive();
    }

    public boolean shouldRenderInChatOverlay() {
        return ChatScreenDetector.isActive();
    }

    public void render(MatrixStack matrices, float screenWidth, float screenHeight) {
        if (!Interface.INSTANCE.isTimerHudEnabled()) {
            return;
        }

        fade.update();
        if (!fade.isVisible()) {
            return;
        }

        DrawHelper render2D = DrawHelper.get();
        if (render2D == null || matrices == null) {
            return;
        }

        GuiTheme theme = GuiTheme.theme;
        FontRenderer titleFont = FontRegistry.getRegular(12);
        FontRenderer statusFont = FontRegistry.getRegular(11);
        FontRenderer iconFont = FontRegistry.getSkycore(10);
        if (titleFont == null || statusFont == null) {
            return;
        }
        if (iconFont == null) {
            iconFont = titleFont;
        }

        float progress = ChargeBoost.INSTANCE.isEnabled() ? ChargeBoost.INSTANCE.getHudProgress() : 1.0f;
        perc = lerp(perc, progress, 10.0f);
        int percent = Math.max(0, Math.min(99, (int) (perc * 100.0f)));

        String title = "Timer";
        String status = resolveStatus();
        String percentText = percent + "%";

        float percentWidth = titleFont.getWidth(percentText);
        float titleWidth = titleFont.getWidth(title)
                + (status.isEmpty() ? 0.0f : statusFont.getWidth(" " + status));
        float desiredWidth = PADDING + COVER_SIZE + PADDING + titleWidth + 5.0f + 0.75f + 5.0f
                + percentWidth + PADDING + 2.0f;
        float width = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, desiredWidth));

        TimerHudPosition position = HudEditor.getInstance().getTimerHud();
        position.setSize(width, HEIGHT);
        position.ensureInitialized(screenWidth, screenHeight);

        float x = position.getX();
        float y = position.getY();
        float alpha = fade.getAlpha();

        HudPanelRenderer.drawBackground(render2D, x, y, width, HEIGHT, RADIUS,
                ColorUtil.withAlpha(theme.getCardActiveTop(), alpha * 0.96f),
                ColorUtil.withAlpha(theme.getCardActiveBottom(), alpha * 0.96f), alpha, matrices);

        float coverX = x + PADDING;
        float coverY = y + 3.5f;
        render2D.drawRoundedRect(coverX, coverY, COVER_SIZE, COVER_SIZE, 5.0f,
                ColorUtil.withAlpha(theme.getAccent(), alpha * 0.36f), matrices);
        iconFont.draw("i", coverX + PADDING, coverY + 2.5f,
                ColorUtil.withAlpha(theme.getText(), alpha * 0.75f), matrices);

        float textX = coverX + COVER_SIZE + PADDING;
        float percentX = x + width - PADDING - percentWidth - PADDING;
        float separatorX = percentX - 7.0f;
        render2D.drawRoundedRect(separatorX, y + PADDING, 0.75f, HEIGHT - PADDING * 2.0f, 0.0f,
                ColorUtil.withAlpha(theme.getHudSeparator(), alpha * 0.55f), matrices);

        float textY = y + 5.5f;
        titleFont.draw(title, textX, textY, ColorUtil.withAlpha(theme.getText(), alpha), matrices);
        if (!status.isEmpty()) {
            statusFont.draw(" " + status, textX + titleFont.getWidth(title), textY + 0.5f,
                    ColorUtil.withAlpha(theme.getTextDim(), alpha), matrices);
        }
        titleFont.draw(percentText, percentX, textY, ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);
    }

    private String resolveStatus() {
        ChargeBoost speed = ChargeBoost.INSTANCE;
        if (!speed.isEnabled()) {
            return "Off";
        }
        if (!speed.isCycleActive()) {
            return "Ready";
        }
        if (speed.isBoosting()) {
            return "Boost";
        }
        if (speed.isCharging()) {
            return "Charge";
        }
        return "Ready";
    }

    private float lerp(float from, float to, float speed) {
        MinecraftClient client = MinecraftClient.getInstance();
        int fps = client.getCurrentFps();
        float frameTime = fps > 0 ? 1.0f / fps : 1.0f;
        return from + (to - from) * MathHelper.clamp(frameTime * speed, 0.0f, 1.0f);
    }
}
