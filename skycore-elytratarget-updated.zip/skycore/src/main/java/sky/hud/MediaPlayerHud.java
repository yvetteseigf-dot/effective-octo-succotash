package sky.hud;

import dev.redstones.mediaplayerinfo.IMediaSession;
import dev.redstones.mediaplayerinfo.MediaInfo;
import dev.redstones.mediaplayerinfo.MediaPlayerInfo;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.client.util.math.MatrixStack;
import sky.theme.GuiTheme;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.HudPanelRenderer;
import sky.render.DrawHelper;
import sky.render.ScissorStack;
import sky.util.ChatScreenDetector;
import sky.util.render.ColorUtil;
import sky.util.animation.FadeAnimation;

/**
 * HUD panel showing the track currently playing in the system media session.
 * <p>
 * The session is queried off the render thread because the platform bridge can block.
 */
public final class MediaPlayerHud {

    private static final float MIN_WIDTH = 72.0F;
    private static final float MAX_WIDTH = 155.0F;
    private static final float HEIGHT = 18.0F;
    private static final float RADIUS = 12.0F;
    private static final float PADDING = 3.0F;
    private static final float COVER_SIZE = 11.0F;
    private static final long POLL_DELAY_MS = 500L;
    private static final long FADE_DURATION_MS = 250L;

    private final FadeAnimation fade = new FadeAnimation();
    private final ExecutorService executor;

    private volatile TrackInfo mediaInfo;
    private volatile boolean polling;
    private long lastPoll;

    public MediaPlayerHud() {
        this.executor = Executors.newSingleThreadExecutor(runnable -> {
            Thread thread = new Thread(runnable, "Skycore-MediaPlayerHud");
            thread.setDaemon(true);
            return thread;
        });
    }

    public void tick() {
        if (!Interface.INSTANCE.isMediaPlayerEnabled()) {
            if (fade.isVisible()) {
                fade.fadeOut(FADE_DURATION_MS);
            }
            fade.update();
            return;
        }

        pollMedia();
        if (!fade.isOpen()) {
            fade.fadeIn(FADE_DURATION_MS);
        }
        fade.update();
    }

    public void render(MatrixStack matrices, float screenWidth, float screenHeight) {
        if (!Interface.INSTANCE.isMediaPlayerEnabled()) {
            return;
        }

        fade.update();
        if (!fade.isVisible()) {
            return;
        }

        try {
            renderPanel(matrices, screenWidth, screenHeight);
        } catch (Throwable ignored) {
        }
    }

    private void renderPanel(MatrixStack matrices, float screenWidth, float screenHeight) {
        DrawHelper renderer = DrawHelper.get();
        if (renderer == null || matrices == null) {
            return;
        }

        GuiTheme theme = GuiTheme.theme;
        if (theme == null) {
            return;
        }
        FontRenderer titleFont = FontRegistry.getRegular(12);
        FontRenderer subFont = FontRegistry.getRegular(11);
        FontRenderer iconFont = FontRegistry.getSkycore(10);
        if (titleFont == null || subFont == null) {
            return;
        }
        if (iconFont == null) {
            iconFont = titleFont;
        }

        TrackInfo track = mediaInfo;
        boolean idle = track == null || (isBlank(track.title) && isBlank(track.artist));
        String title = idle ? "Nothing playing" : emptyToDefault(track.title, "Unknown title");
        String artist = idle ? "" : emptyToDefault(track.artist, "");
        String time = idle ? "--:--" : formatTime(track.positionSeconds);

        float timeWidth = titleFont.getWidth(time);
        float textWidth = titleFont.getWidth(title)
                + (artist.isEmpty() ? 0.0F : subFont.getWidth(" " + artist));
        float desiredWidth = 17.0F + textWidth + 5.0F + 0.75F + 5.0F + timeWidth + PADDING + 2.0F;
        float width = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, desiredWidth));

        MediaPlayerHudPosition position = HudEditor.getInstance().getMediaPlayer();
        if (position == null) {
            return;
        }
        position.setSize(width, HEIGHT);
        position.ensureInitialized(screenWidth, screenHeight);

        float x = position.getX();
        float y = position.getY();
        float alpha = fade.getAlpha();

        HudPanelRenderer.drawBackground(renderer, x, y, width, HEIGHT, RADIUS,
                ColorUtil.withAlpha(theme.getCardActiveTop(), alpha * 0.96F),
                ColorUtil.withAlpha(theme.getCardActiveBottom(), alpha * 0.96F), alpha, matrices);

        float coverX = x + PADDING;
        float coverY = y + 3.5F;
        renderer.drawRoundedRect(coverX, coverY, COVER_SIZE, COVER_SIZE, 5.0F,
                ColorUtil.withAlpha(theme.getAccent(), alpha * 0.36F), matrices);
        iconFont.draw("i", coverX + PADDING, coverY + 2.5F,
                ColorUtil.withAlpha(theme.getText(), alpha * 0.75F), matrices);

        float textX = coverX + COVER_SIZE + PADDING;
        float timeX = x + width - PADDING - timeWidth - PADDING;
        float separatorX = timeX - 7.0F;

        renderer.drawRoundedRect(separatorX, y + PADDING, 0.75F, 12.0F, 0.0F,
                ColorUtil.withAlpha(theme.getHudSeparator(), alpha * 0.55F), matrices);

        float trackLineWidth = Math.max(10.0F, separatorX - 5.0F - textX);
        float textY = y + 5.5F;
        drawTrackLine(titleFont, subFont, title, artist, textX, textY, trackLineWidth, theme, matrices, alpha);

        titleFont.draw(time, timeX, textY, ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);
    }

    public boolean shouldRenderInMainHud() {
        return !ChatScreenDetector.isActive();
    }

    public boolean shouldRenderInChatOverlay() {
        return ChatScreenDetector.isActive();
    }

    /**
     * Draws "title artist", scrolling it horizontally when it does not fit into {@code maxWidth}.
     */
    private void drawTrackLine(FontRenderer titleFont, FontRenderer subFont, String title, String artist,
                               float x, float y, float maxWidth, GuiTheme theme, MatrixStack matrices, float alpha) {
        float titleWidth = titleFont.getWidth(title);
        float artistWidth = artist.isEmpty() ? 0.0F : subFont.getWidth(" " + artist);
        float totalWidth = titleWidth + artistWidth;

        float scroll = 0.0F;
        if (totalWidth > maxWidth) {
            float overflow = totalWidth - maxWidth;
            float cycle = (System.currentTimeMillis() % 3200L) / (float) 3200L;
            if (cycle < 0.32F) {
                scroll = 0.0F;
            } else if (cycle < 0.58F) {
                scroll = overflow * smooth((cycle - 0.32F) / 0.26F);
            } else if (cycle < 0.88F) {
                scroll = overflow;
            } else {
                scroll = overflow * (1.0F - smooth((cycle - 0.88F) / 0.12F));
            }
        }

        ScissorStack.enable(x - 1.0F, y - 2.0F, maxWidth + 2.0F, titleFont.getLineHeight(title) + 6.0F);

        float drawX = x - scroll + 1.0F;
        titleFont.draw(title, drawX, y, ColorUtil.withAlpha(theme.getText(), alpha), matrices);
        if (!artist.isEmpty()) {
            subFont.draw(" " + artist, drawX + titleWidth, y + 0.5F,
                    ColorUtil.withAlpha(theme.getTextDim(), alpha), matrices);
        }

        ScissorStack.disable();
    }

    private void pollMedia() {
        long now = System.currentTimeMillis();
        if (polling || now - lastPoll < POLL_DELAY_MS) {
            return;
        }

        lastPoll = now;
        polling = true;
        executor.execute(() -> {
            try {
                mediaInfo = readCurrentTrack();
            } catch (Throwable ignored) {
                mediaInfo = null;
            } finally {
                polling = false;
            }
        });
    }

    private TrackInfo readCurrentTrack() {
        List<IMediaSession> sessions = MediaPlayerInfo.Instance.getMediaSessions();
        if (sessions == null || sessions.isEmpty()) {
            return null;
        }

        IMediaSession session = sessions.stream()
                .filter(candidate -> candidate != null && candidate.getMedia() != null)
                .max(Comparator.comparing(candidate -> candidate.getMedia().getPlaying()))
                .orElse(null);

        MediaInfo media = session == null ? null : session.getMedia();
        if (media == null) {
            return null;
        }

        long position = normalizeTime(media.getPosition());
        long duration = normalizeTime(media.getDuration());
        return new TrackInfo(media.getTitle(), media.getArtist(), position, duration, media.getPlaying());
    }

    private static float smooth(float value) {
        float clamped = Math.max(0.0F, Math.min(1.0F, value));
        return clamped * clamped * (3.0F - 2.0F * clamped);
    }

    private static String formatTime(long seconds) {
        long minutes = Math.max(0L, seconds) / 60L;
        long remainder = Math.max(0L, seconds) % 60L;
        return minutes + ":" + (remainder < 10L ? "0" : "") + remainder;
    }

    /**
     * Some providers report milliseconds where seconds are expected.
     */
    private static long normalizeTime(long value) {
        return value > 86400L ? value / 1000L : value;
    }

    private static boolean isBlank(String value) {
        return value == null || value.isEmpty();
    }

    private static String emptyToDefault(String value, String fallback) {
        return isBlank(value) ? fallback : value;
    }

    private record TrackInfo(String title, String artist, long positionSeconds, long durationSeconds,
                             boolean playing) {
    }
}
