package sky.model;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RotationAxis;
import sky.access.MinecraftAccess;
import sky.pet.PetDogController;

/** Model and renderer for the companion dog pet. */
public final class PetDogModel implements MinecraftAccess {
    private final ModelPart head;
    private final ModelPart neck;
    private final ModelPart body;
    private final ModelPart frontLeftLeg;
    private final ModelPart frontRightLeg;
    private final ModelPart leftBackLeg;
    private final ModelPart rightBackLeg;
    private final ModelPart tail;

    public PetDogModel(ModelPart root) {
        this.head = root.getChild("head");
        this.neck = root.getChild("neck");
        this.body = root.getChild("body");
        this.frontLeftLeg = root.getChild("front_left_leg");
        this.frontRightLeg = root.getChild("front_right_leg");
        this.leftBackLeg = root.getChild("left_back_leg");
        this.rightBackLeg = root.getChild("right_back_leg");
        this.tail = root.getChild("tail");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        ModelPartBuilder headBuilder = ModelPartBuilder.create().uv(0, 0)
                .cuboid(-3.0F, -3.0F, -4.0F, 6.0F, 6.0F, 4.0F, Dilation.NONE)
                .uv(21, 0)
                .cuboid(-1.5F, 0.0F, -7.0F, 3.0F, 3.0F, 3.0F, Dilation.NONE);
        ModelPartData head = root.addChild("head", headBuilder, ModelTransform.pivot(0.0F, 10.5F, -6.8F));

        ModelPartBuilder leftEarBuilder = ModelPartBuilder.create().uv(32, 4)
                .cuboid(0.0F, -5.0F, -1.5F, 1.0F, 3.0F, 3.0F, Dilation.NONE)
                .uv(34, 1)
                .cuboid(0.0F, -5.5F, -0.75F, 1.0F, 1.0F, 1.5F, Dilation.NONE);
        head.addChild("left_ear", leftEarBuilder, ModelTransform.pivot(3.0F, 3.0F, -2.0F));

        ModelPartBuilder rightEarBuilder = ModelPartBuilder.create().uv(32, 4)
                .cuboid(-1.0F, -5.0F, -1.5F, 1.0F, 3.0F, 3.0F, Dilation.NONE)
                .uv(34, 1)
                .cuboid(-1.0F, -5.5F, -0.75F, 1.0F, 1.0F, 1.5F, Dilation.NONE);
        head.addChild("right_ear", rightEarBuilder, ModelTransform.pivot(-3.0F, 3.0F, -2.0F));

        ModelPartBuilder neckBuilder = ModelPartBuilder.create().uv(15, 7)
                .cuboid(-2.95F, -1.0F, -4.0F, 5.9F, 5.0F, 6.0F, Dilation.NONE);
        root.addChild("neck", neckBuilder, ModelTransform.pivot(0.0F, 10.5F, -5.0F));

        ModelPartBuilder chestBuilder = ModelPartBuilder.create().uv(32, 13)
                .cuboid(-4.0F, -3.5F, -3.0F, 8.0F, 7.0F, 6.0F, Dilation.NONE);
        ModelPartBuilder backBuilder = ModelPartBuilder.create().uv(3, 19)
                .cuboid(-3.0F, -3.0F, -0.5F, 6.0F, 6.0F, 11.0F, Dilation.NONE);

        ModelPartData body = root.addChild("body", ModelPartBuilder.create(),
                ModelTransform.pivot(0.0F, 13.5F, -5.0F));
        body.addChild("chest", chestBuilder, ModelTransform.pivot(0.0F, 0.0F, 3.0F));
        body.addChild("back", backBuilder, ModelTransform.pivot(0.0F, -0.5F, 5.5F));

        ModelPartBuilder frontLeftLegBuilder = ModelPartBuilder.create().uv(42, 0)
                .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, Dilation.NONE);
        ModelPartBuilder frontRightLegBuilder = ModelPartBuilder.create().uv(42, 0)
                .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, Dilation.NONE);
        ModelPartBuilder leftBackLegBuilder = ModelPartBuilder.create().uv(52, 0)
                .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, Dilation.NONE);
        ModelPartBuilder rightBackLegBuilder = ModelPartBuilder.create().uv(52, 0)
                .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, Dilation.NONE);

        root.addChild("front_left_leg", frontLeftLegBuilder, ModelTransform.pivot(1.5F, 16.0F, -3.0F));
        root.addChild("front_right_leg", frontRightLegBuilder, ModelTransform.pivot(-1.5F, 16.0F, -3.0F));
        root.addChild("left_back_leg", leftBackLegBuilder, ModelTransform.pivot(1.5F, 16.0F, 9.0F));
        root.addChild("right_back_leg", rightBackLegBuilder, ModelTransform.pivot(-1.5F, 16.0F, 9.0F));

        ModelPartBuilder tailBuilder = ModelPartBuilder.create().uv(2, 12)
                .cuboid(-1.0F, 2.0F, -1.0F, 2.0F, 8.0F, 2.0F, Dilation.NONE);
        root.addChild("tail", tailBuilder, ModelTransform.pivot(0.0F, 9.0F, 10.0F));

        return TexturedModelData.of(modelData, 60, 36);
    }

    public void setRotationAngles(float ageInTicks, PetDogController brain) {
        float layProgress = brain.getLayProgress();
        float wakeProgress = brain.getTrickWakeProgress();

        this.neck.pitch = -0.43633232F;
        this.head.yaw = brain.getYaw() * 0.017453292F
                + (float) Math.sin(ageInTicks * 3.8F) * 0.16F * wakeProgress;
        this.head.pitch = brain.getPitch() * 0.017453292F;

        this.frontLeftLeg.pitch = (float) Math.cos(brain.limbSwing * 0.6662F) * 1.4F * brain.limbSwingAmount;
        this.frontRightLeg.pitch =
                (float) Math.cos(brain.limbSwing * 0.6662F + 3.1415927F) * 1.4F * brain.limbSwingAmount;
        this.leftBackLeg.pitch =
                (float) Math.cos(brain.limbSwing * 0.6662F + 3.1415927F) * 1.4F * brain.limbSwingAmount;
        this.rightBackLeg.pitch = (float) Math.cos(brain.limbSwing * 0.6662F) * 1.4F * brain.limbSwingAmount;

        this.frontLeftLeg.pitch = lerp(this.frontLeftLeg.pitch, (float) Math.toRadians(-90.0D), layProgress);
        this.frontRightLeg.pitch = lerp(this.frontRightLeg.pitch, (float) Math.toRadians(-90.0D), layProgress);
        this.leftBackLeg.pitch = lerp(this.leftBackLeg.pitch, (float) Math.toRadians(90.0D), layProgress);
        this.rightBackLeg.pitch = lerp(this.rightBackLeg.pitch, (float) Math.toRadians(90.0D), layProgress);

        this.frontLeftLeg.yaw = lerp(0.0F, (float) Math.toRadians(-22.0D), layProgress);
        this.frontRightLeg.yaw = lerp(0.0F, (float) Math.toRadians(22.0D), layProgress);
        this.leftBackLeg.yaw = lerp(0.0F, (float) Math.toRadians(22.0D), layProgress);
        this.rightBackLeg.yaw = lerp(0.0F, (float) Math.toRadians(-22.0D), layProgress);

        this.tail.pitch = (float) Math.toRadians(lerp(22.0F, 45.0F, layProgress));
        this.tail.roll = (float) (Math.toRadians(-22.5D) + Math.toRadians(22.5D)
                + Math.cos(ageInTicks * 0.15F) * 0.3F);
    }

    public void render(MatrixStack matrices, VertexConsumerProvider consumers, Identifier texture,
                       PetDogController brain, float ageInTicks) {
        BlockPos pos = BlockPos.ofFloored(brain.getPos());
        int light = mc.world != null ? WorldRenderer.getLightmapCoordinates(mc.world, pos) : 15728880;
        int overlay = OverlayTexture.DEFAULT_UV;
        VertexConsumer consumer = consumers.getBuffer(RenderLayer.getEntityTranslucent(texture));

        matrices.push();
        matrices.translate(0.0D, 1.2F - brain.getLayProgress() * 0.3F, 0.0D);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(180.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(brain.getBody()));

        this.head.render(matrices, consumer, light, overlay, -1);
        this.neck.render(matrices, consumer, light, overlay, -1);
        this.body.render(matrices, consumer, light, overlay, -1);
        this.frontLeftLeg.render(matrices, consumer, light, overlay, -1);
        this.frontRightLeg.render(matrices, consumer, light, overlay, -1);
        this.leftBackLeg.render(matrices, consumer, light, overlay, -1);
        this.rightBackLeg.render(matrices, consumer, light, overlay, -1);
        this.tail.render(matrices, consumer, light, overlay, -1);

        matrices.pop();
    }

    public void renderHat(MatrixStack matrices, VertexConsumerProvider consumers, Identifier texture,
                          PetDogController brain, PropellerHatModel hat, float ageInTicks) {
        BlockPos pos = BlockPos.ofFloored(brain.getPos());
        int light = mc.world != null ? WorldRenderer.getLightmapCoordinates(mc.world, pos) : 15728880;

        matrices.push();
        matrices.translate(0.0D, 1.2F - brain.getLayProgress() * 0.3F, 0.0D);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(180.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(brain.getBody()));

        this.head.rotate(matrices);
        matrices.translate(0.0F, 0.0F, -0.09F);
        matrices.scale(0.55F, 0.55F, 0.55F);

        hat.render(matrices, consumers, texture, light, ageInTicks, brain.isFlying());

        matrices.pop();
    }

    private static float lerp(float from, float to, float delta) {
        return from + (to - from) * delta;
    }
}
