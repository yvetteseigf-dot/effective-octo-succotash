package sky.model;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.MathHelper;
import sky.cape.CapeManager;
import sky.util.math.MutableXYZ;

/**
 * Verlet-style point/stick solver driving the physics cape. Points are chained top to bottom;
 * the first point is locked to the wearer and every other point is pulled by gravity and then
 * constrained so the cloth keeps its length, does not fold too sharply and does not clip through
 * itself or the player.
 */
public class CapePhysicsSimulation {
    public List<Point> points;
    public List<Stick> sticks;
    public MutableXYZ gravityDirection;
    public float gravity;
    public int numIterations;
    public boolean sneaking;

    private final float maxBend;

    public CapePhysicsSimulation() {
        this.points = new ArrayList<>();
        this.sticks = new ArrayList<>();
        this.gravityDirection = new MutableXYZ(0.0F, -1.0F, 0.0F);
        this.gravity = CapeManager.config.gravity;
        this.numIterations = 30;
        this.maxBend = 20.0F;
        this.sneaking = false;
    }

    /** Rebuilds the point chain, returning {@code false} when it already has {@code partCount} points. */
    public boolean init(int partCount) {
        if (this.points.size() == partCount) {
            return false;
        }

        this.points.clear();
        this.sticks.clear();

        for (int i = 0; i < partCount; i++) {
            Point point = new Point();
            point.position.y = -i;
            point.position.x = -i;
            point.locked = i == 0;
            this.points.add(point);

            if (i > 0) {
                this.sticks.add(new Stick(this.points.get(i - 1), point, 1.0F));
            }
        }

        return true;
    }

    public void simulate() {
        this.applyGravity();
        this.preventClipping();
        this.preventSelfClipping();
        this.applyMotion();
        this.preventSelfClipping();
        this.preventHardBends();
        this.limitLength();
    }

    public void applyMovement(MutableXYZ movement) {
        this.points.get(0).prevPosition.copy(this.points.get(0).position);
        this.points.get(0).position.add(movement);
    }

    public boolean empty() {
        return this.sticks.isEmpty();
    }

    public List<Point> getPoints() {
        return this.points;
    }

    public float getGravity() {
        return this.gravity;
    }

    public void setGravity(float gravity) {
        this.gravity = gravity;
    }

    public void setGravityDirection(MutableXYZ gravityDirection) {
        this.gravityDirection = gravityDirection;
    }

    public boolean isSneaking() {
        return this.sneaking;
    }

    public void setSneaking(boolean sneaking) {
        this.sneaking = sneaking;
    }

    private void applyGravity() {
        MutableXYZ step = this.gravityDirection.clone().mul(this.gravity * 0.05F);
        MutableXYZ previous = new MutableXYZ(0.0F, 0.0F, 0.0F);

        for (Point point : this.points) {
            if (!point.locked) {
                previous.copy(point.position);
                point.position.add(step);
                point.prevPosition.copy(previous);
            }
        }
    }

    private void applyMotion() {
        for (int iteration = 0; iteration < this.numIterations; iteration++) {
            for (int i = this.sticks.size() - 1; i >= 0; i--) {
                Stick stick = this.sticks.get(i);
                MutableXYZ center = stick.pointA.position.clone().add(stick.pointB.position).div(2.0F);
                MutableXYZ direction = stick.pointA.position.clone().subtract(stick.pointB.position).normalize();

                if (!stick.pointA.locked) {
                    stick.pointA.position = center.clone().add(direction.clone().mul(stick.length / 2.0F));
                }

                if (!stick.pointB.locked) {
                    stick.pointB.position = center.clone().subtract(direction.clone().mul(stick.length / 2.0F));
                }
            }
        }
    }

    private void limitLength() {
        for (int i = 0; i < this.sticks.size(); i++) {
            Stick stick = this.sticks.get(i);
            MutableXYZ direction = stick.pointA.position.clone().subtract(stick.pointB.position).normalize();

            if (!stick.pointB.locked) {
                stick.pointB.position = stick.pointA.position.clone().subtract(direction.mul(stick.length));
            }
        }
    }

    private void preventHardBends() {
        for (int i = 1; i < this.points.size() - 2; i++) {
            double angle = this.getAngle(this.points.get(i).position, this.points.get(i - 1).position,
                    this.points.get(i + 1).position);

            if (angle < -this.maxBend) {
                MutableXYZ replacement = this.getReplacement(this.points.get(i).position, this.points.get(i - 1).position,
                        -this.maxBend * 2.0F);
                this.points.get(i + 1).position = replacement;
            }

            if (angle > this.maxBend) {
                MutableXYZ replacement = this.getReplacement(this.points.get(i).position, this.points.get(i - 1).position,
                        this.maxBend * 2.0F);
                this.points.get(i + 1).position = replacement;
            }
        }
    }

    private void preventClipping() {
        Point root = this.points.get(0);

        for (int i = 1; i < this.points.size(); i++) {
            Point point = this.points.get(i);

            if (point.position.x - root.position.x > 0.0F) {
                point.position.x = root.position.x;
            }

            float allowed = (float) i / this.points.size() * ((float) i / this.points.size()) * 5.0F;
            float offset = root.position.z - point.position.z;

            if (offset > allowed) {
                point.position.z = root.position.z - allowed;
            }

            if (offset < -allowed) {
                point.position.z = root.position.z + allowed;
            }
        }
    }

    private void preventSelfClipping() {
        int corrections = 0;
        boolean clipping;

        do {
            clipping = false;

            for (int i = 0; i < this.points.size(); i++) {
                for (int j = i + 1; j < this.points.size(); j++) {
                    Point first = this.points.get(i);
                    Point second = this.points.get(j);
                    MutableXYZ offset = first.position.clone().subtract(second.position);

                    if (offset.sqrMagnitude() < 0.99D) {
                        clipping = true;
                        corrections++;
                        offset.normalize();

                        MutableXYZ center = first.position.clone().add(second.position).div(2.0F);

                        if (!first.locked) {
                            first.position = center.clone().add(offset.clone().mul(0.5F));
                        }

                        if (!second.locked) {
                            second.position = center.clone().subtract(offset.clone().mul(0.5F));
                        }
                    }
                }
            }
        } while (clipping && corrections < 32);
    }

    /** Signed angle in degrees of the corner formed at {@code previous} between the two neighbours. */
    private double getAngle(MutableXYZ current, MutableXYZ previous, MutableXYZ next) {
        float toCurrentX = previous.x - current.x;
        float toCurrentY = previous.y - current.y;
        float toNextX = previous.x - next.x;
        float toNextY = previous.y - next.y;

        float dot = toCurrentX * toNextX + toCurrentY * toNextY;
        float cross = toCurrentX * toNextY - toCurrentY * toNextX;

        double angle = MathHelper.atan2(cross, dot);
        return angle * 180.0D / Math.PI;
    }

    private MutableXYZ getReplacement(MutableXYZ target, MutableXYZ prev, double middle) {
        MutableXYZ replacement = target.clone().subtract(prev);
        replacement.rotateDegrees((float) middle).add(target);
        return replacement;
    }

    public static class Point {
        public MutableXYZ position;
        public MutableXYZ prevPosition;
        public boolean locked;

        public Point() {
            this.position = new MutableXYZ(0.0F, 0.0F, 0.0F);
            this.prevPosition = new MutableXYZ(0.0F, 0.0F, 0.0F);
        }

        public MutableXYZ getLerpedPos(float delta) {
            return new MutableXYZ(this.getLerpX(delta), this.getLerpY(delta), this.getLerpZ(delta));
        }

        public float getLerpX(float delta) {
            return MathHelper.lerp(delta, this.prevPosition.x, this.position.x);
        }

        public float getLerpY(float delta) {
            return MathHelper.lerp(delta, this.prevPosition.y, this.position.y);
        }

        public float getLerpZ(float delta) {
            return MathHelper.lerp(delta, this.prevPosition.z, this.position.z);
        }
    }

    public static class Stick {
        public Point pointA;
        public Point pointB;
        public float length;

        public Stick(Point pointA, Point pointB, float length) {
            this.pointA = pointA;
            this.pointB = pointB;
            this.length = length;
        }
    }
}
