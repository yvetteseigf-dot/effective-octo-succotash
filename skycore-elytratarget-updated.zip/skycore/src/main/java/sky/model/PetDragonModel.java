package sky.model;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import sky.access.MinecraftAccess;
import sky.pet.PetDragonController;

/** Model and renderer for the companion dragon pet. */
public final class PetDragonModel implements MinecraftAccess {
    private static final Dilation THIN_PLANE = new Dilation(0.015F);

    private final ModelPart dragon;
    private final ModelPart torso;
    private final ModelPart waist;
    private final ModelPart neck;
    private final ModelPart head;
    private final ModelPart jaw;
    private final ModelPart leftWing;
    private final ModelPart rightWing;
    private final ModelPart leftForearm;
    private final ModelPart rightForearm;
    private final ModelPart leftRearLeg;
    private final ModelPart rightRearLeg;
    private final ModelPart segment1;
    private final ModelPart segment2;
    private final ModelPart segment3;
    private final ModelPart segment4;

    public PetDragonModel(ModelPart root) {
        this.dragon = root.getChild("dragon");
        this.torso = this.dragon.getChild("torso");
        this.waist = this.torso.getChild("waist");

        ModelPart tail = this.waist.getChild("tail");
        this.segment1 = tail.getChild("segment_1");
        this.segment2 = this.segment1.getChild("segment_2");
        this.segment3 = this.segment2.getChild("segment_3");
        this.segment4 = this.segment3.getChild("segment_4");

        this.neck = this.torso.getChild("neck");
        this.head = this.neck.getChild("head");
        this.jaw = this.head.getChild("jaw");

        this.leftWing = this.torso.getChild("left_wing");
        this.rightWing = this.torso.getChild("right_wing");
        this.leftRearLeg = this.waist.getChild("left_rearleg");
        this.rightRearLeg = this.waist.getChild("right_rearleg");
        this.leftForearm = this.torso.getChild("left_forearm");
        this.rightForearm = this.torso.getChild("right_forearm");
    }

    public void setRotationAngles(float ageInTicks, PetDragonController brain) {
        this.head.yaw = 0.0F;
        this.head.pitch = (float) Math.toRadians(27.5D);
        this.neck.pitch = (float) Math.toRadians(12.5D);
        this.torso.pitch = (float) Math.toRadians(-30.0D);
        this.waist.pitch = (float) Math.toRadians(-20.0D);

        if (!brain.isPlayerMoving()) {
            float idle = ageInTicks * 0.05F;

            this.head.yaw += (float) Math.sin(idle * 0.8F) * 0.1F;
            this.head.pitch += (float) Math.sin(idle * 0.6F) * 0.1F;
            this.torso.roll = (float) Math.sin(idle * 0.4F) * 0.1F;

            float sway = (float) Math.sin(idle * 1.2F) * 0.6F;
            this.setTailAngles(sway, 1.0F);

            float flapStrength = (float) Math.sin(ageInTicks * 0.4F) * 1.05F;
            this.setWingAngles(flapStrength, 0.9F);

            this.leftRearLeg.pitch = (float) Math.toRadians(20.0D + Math.sin(idle * 0.5F) * 5.0D);
            this.rightRearLeg.pitch = (float) Math.toRadians(20.0D - Math.sin(idle * 0.5F) * 5.0D);
            this.leftForearm.pitch = (float) Math.toRadians(15.0D + Math.sin(idle * 0.4F) * 8.0D);
            this.rightForearm.pitch = (float) Math.toRadians(15.0D - Math.sin(idle * 0.4F) * 8.0D);
        } else {
            float sway = (float) Math.sin(ageInTicks * 0.2F) * 0.4F;
            this.setTailAngles(sway, 0.7F);

            float flapStrength = (float) Math.sin(ageInTicks * 0.4F) * 1.2F;
            this.setWingAngles(flapStrength, 1.0F);

            float stride = (float) Math.sin(ageInTicks * 0.1F) * 0.2F;
            this.leftRearLeg.pitch = (float) Math.toRadians(37.5D + stride * 10.0D);
            this.rightRearLeg.pitch = (float) Math.toRadians(37.5D - stride * 10.0D);
            this.leftForearm.pitch = (float) Math.toRadians(30.0D + stride * 15.0D);
            this.rightForearm.pitch = (float) Math.toRadians(30.0D - stride * 15.0D);
        }

        this.jaw.pitch = (float) Math.toRadians(2.5D + Math.sin(ageInTicks * 0.3F) * 2.0D);
    }

    public void render(MatrixStack matrices, VertexConsumerProvider consumers, Identifier texture,
                       PetDragonController brain, float ageInTicks) {
        int overlay = OverlayTexture.DEFAULT_UV;
        VertexConsumer consumer = consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(texture));
        float hover = (float) Math.sin(ageInTicks * 0.2F) * 0.3F;

        matrices.push();
        matrices.translate(0.0D, 0.8F + hover, 0.0D);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(180.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(brain.getBody()));
        matrices.scale(0.5F, 0.5F, 0.5F);

        this.dragon.render(matrices, consumer, 15728880, overlay, -1);

        matrices.pop();
    }

    private void setTailAngles(float sway, float strength) {
        this.segment1.pitch = (float) Math.toRadians(-15.0D);
        this.segment1.yaw = sway;
        this.segment2.pitch = (float) Math.toRadians(-10.0D);
        this.segment2.yaw = sway * 0.8F * strength;
        this.segment3.pitch = (float) Math.toRadians(-7.5D);
        this.segment3.yaw = sway * 0.6F * strength;
        this.segment4.pitch = (float) Math.toRadians(-5.0D);
        this.segment4.yaw = sway * 0.4F * strength;
    }

    private void setWingAngles(float strength, float flap) {
        this.leftWing.pitch = (float) Math.toRadians(5.0D + strength * 10.0D * flap);
        this.leftWing.yaw = (float) Math.toRadians(-15.0D + strength * 5.0D * flap);
        this.leftWing.roll = (float) Math.toRadians(45.0D + strength * 60.0D * flap);
        this.rightWing.pitch = (float) Math.toRadians(5.0D + strength * 10.0D * flap);
        this.rightWing.yaw = (float) Math.toRadians(15.0D - strength * 5.0D * flap);
        this.rightWing.roll = (float) Math.toRadians(-45.0D - strength * 60.0D * flap);
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        ModelPartData dragon = root.addChild("dragon", ModelPartBuilder.create(),
                ModelTransform.pivot(0.0F, 17.0F, 0.0F));

        ModelPartData torso = dragon.addChild("torso", ModelPartBuilder.create()
                        .uv(45, 83)
                        .cuboid(0.0F, -6.5F, -2.25F, 0.0F, 3.0F, 4.0F, THIN_PLANE)
                        .uv(0, 35)
                        .cuboid(-3.5F, -3.5F, -4.0F, 7.0F, 7.0F, 7.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, -3.5F, -1.0F));

        ModelPartData waist = torso.addChild("waist", ModelPartBuilder.create()
                        .uv(60, 35)
                        .cuboid(-3.0F, -3.0F, 0.0F, 6.0F, 6.0F, 6.0F, Dilation.NONE)
                        .uv(26, 84)
                        .cuboid(0.0F, -5.0F, 0.75F, 0.0F, 2.0F, 4.0F, THIN_PLANE),
                ModelTransform.pivot(0.0F, 0.0F, 3.0F));

        ModelPartData tail = waist.addChild("tail", ModelPartBuilder.create(),
                ModelTransform.pivot(0.0F, 0.5F, 6.025F));

        ModelPartData segment1 = tail.addChild("segment_1", ModelPartBuilder.create()
                        .uv(0, 65)
                        .cuboid(-2.5F, -2.5F, 0.0F, 5.0F, 5.0F, 5.0F, Dilation.NONE)
                        .uv(59, 85)
                        .cuboid(0.0F, -4.5F, 0.75F, 0.0F, 2.0F, 3.0F, THIN_PLANE),
                ModelTransform.pivot(0.0F, 0.0F, -0.025F));

        ModelPartData segment2 = segment1.addChild("segment_2", ModelPartBuilder.create()
                        .uv(42, 65)
                        .cuboid(-2.0F, -2.0F, 0.0F, 4.0F, 4.0F, 4.0F, Dilation.NONE)
                        .uv(66, 85)
                        .cuboid(0.0F, -4.0F, 0.5F, 0.0F, 2.0F, 3.0F, THIN_PLANE),
                ModelTransform.pivot(0.0F, 0.0F, 5.0F));

        ModelPartData segment3 = segment2.addChild("segment_3", ModelPartBuilder.create()
                        .uv(21, 76)
                        .cuboid(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 4.0F, Dilation.NONE)
                        .uv(73, 85)
                        .cuboid(0.0F, -3.5F, 0.5F, 0.0F, 2.0F, 3.0F, THIN_PLANE),
                ModelTransform.pivot(0.0F, 0.0F, 4.0F));

        segment3.addChild("segment_4", ModelPartBuilder.create()
                        .uv(59, 78)
                        .cuboid(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 4.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 0.0F, 4.0F));

        ModelPartData neck = torso.addChild("neck", ModelPartBuilder.create()
                        .uv(42, 74)
                        .cuboid(-2.0F, -2.0F, -4.0F, 4.0F, 4.0F, 4.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, -0.5F, -4.0F));

        ModelPartData head = neck.addChild("head", ModelPartBuilder.create()
                        .uv(60, 48)
                        .cuboid(-3.0F, -2.0F, -9.0F, 0.0F, 6.0F, 9.0F, THIN_PLANE)
                        .uv(62, 0)
                        .cuboid(3.0F, -2.0F, -9.0F, 0.0F, 6.0F, 9.0F, THIN_PLANE)
                        .uv(72, 78)
                        .cuboid(-3.0F, -2.0F, -9.0F, 6.0F, 6.0F, 0.0F, THIN_PLANE)
                        .uv(29, 35)
                        .cuboid(-3.0F, -2.02F, -9.0F, 6.0F, 0.08F, 9.0F, Dilation.NONE)
                        .uv(29, 45)
                        .cuboid(-3.0F, 4.0F, -9.0F, 6.0F, 0.0F, 9.0F, THIN_PLANE)
                        .uv(0, 55)
                        .cuboid(-3.0F, 3.94F, -9.0F, 6.0F, 0.08F, 9.0F, Dilation.NONE)
                        .uv(0, 50)
                        .cuboid(-2.75F, -0.65F, -9.04F, 5.5F, 2.5F, 0.08F, Dilation.NONE)
                        .uv(79, 48)
                        .cuboid(-3.0F, -2.0F, 0.0F, 6.0F, 6.0F, 0.0F, THIN_PLANE),
                ModelTransform.pivot(0.0F, 0.0F, -4.0F));

        head.addChild("jaw", ModelPartBuilder.create()
                        .uv(31, 55)
                        .cuboid(-2.5F, 1.95F, -8.48F, 5.0F, 0.0F, 9.0F, THIN_PLANE)
                        .uv(0, 50)
                        .cuboid(-2.5F, 1.9F, -8.52F, 5.0F, 0.1F, 9.0F, Dilation.NONE)
                        .uv(11, 50)
                        .cuboid(-2.5F, -0.3F, -8.52F, 5.0F, 2.2F, 0.08F, Dilation.NONE)
                        .uv(62, 16)
                        .cuboid(-2.5F, -2.05F, -8.48F, 0.0F, 4.0F, 9.0F, THIN_PLANE)
                        .uv(60, 64)
                        .cuboid(2.5F, -2.05F, -8.48F, 0.0F, 4.0F, 9.0F, THIN_PLANE),
                ModelTransform.of(0.0F, 3.4F, -0.75F, -0.0873F, 0.0F, 0.0F));

        waist.addChild("left_rearleg", legBuilder(62, 30, 81, 8), ModelTransform.pivot(3.5F, 1.7F, 5.75F));
        waist.addChild("right_rearleg", legBuilder(71, 30, 81, 15), ModelTransform.pivot(-3.5F, 1.7F, 5.75F));

        torso.addChild("left_forearm", forearmBuilder(79, 62, 81, 0), ModelTransform.pivot(5.0F, 1.0F, -0.25F));
        torso.addChild("right_forearm", forearmBuilder(79, 55, 79, 69), ModelTransform.pivot(-5.0F, 1.0F, -0.25F));

        torso.addChild("left_wing", ModelPartBuilder.create()
                        .uv(85, 30)
                        .cuboid(-0.875F, -3.0F, -0.975F, 2.0F, 4.0F, 2.0F, Dilation.NONE)
                        .uv(54, 83)
                        .cuboid(-0.875F, -13.0F, -0.975F, 1.0F, 10.0F, 1.0F, Dilation.NONE)
                        .uv(21, 65)
                        .cuboid(-0.875F, -1.0F, 1.025F, 1.0F, 1.0F, 9.0F, Dilation.NONE)
                        .uv(0, 0)
                        .cuboid(-0.375F, -19.0F, -0.975F, 0.0F, 19.0F, 15.0F, THIN_PLANE),
                ModelTransform.pivot(3.375F, 0.0F, -2.025F));

        torso.addChild("right_wing", ModelPartBuilder.create()
                        .uv(85, 37)
                        .cuboid(-1.375F, -3.0F, -0.975F, 2.0F, 4.0F, 2.0F, Dilation.NONE)
                        .uv(21, 84)
                        .cuboid(-0.375F, -13.0F, -0.975F, 1.0F, 10.0F, 1.0F, Dilation.NONE)
                        .uv(0, 76)
                        .cuboid(-0.375F, -1.0F, 1.025F, 1.0F, 1.0F, 9.0F, Dilation.NONE)
                        .uv(31, 0)
                        .cuboid(0.125F, -19.0F, -0.975F, 0.0F, 19.0F, 15.0F, THIN_PLANE),
                ModelTransform.pivot(-3.125F, 0.0F, -2.025F));

        return TexturedModelData.of(modelData, 128, 128);
    }

    private static ModelPartBuilder legBuilder(int jointU, int jointV, int limbU, int limbV) {
        return ModelPartBuilder.create()
                .uv(jointU, jointV)
                .cuboid(-1.0F, -1.0F, -1.0F, 2.0F, 2.0F, 2.0F, Dilation.NONE)
                .uv(limbU, limbV)
                .cuboid(-1.5F, 1.0F, -1.0F, 3.0F, 4.0F, 2.0F, Dilation.NONE)
                .uv(22, 50)
                .cuboid(-1.2F, 4.5F, -1.8F, 1.0F, 2.0F, 1.0F, Dilation.NONE)
                .uv(36, 76)
                .cuboid(-0.5F, 4.5F, -2.0F, 1.0F, 2.0F, 1.0F, Dilation.NONE)
                .uv(80, 30)
                .cuboid(0.2F, 4.5F, -1.8F, 1.0F, 2.0F, 1.0F, Dilation.NONE);
    }

    private static ModelPartBuilder forearmBuilder(int jointU, int jointV, int limbU, int limbV) {
        return ModelPartBuilder.create()
                .uv(jointU, jointV)
                .cuboid(-1.5F, -1.5F, -1.5F, 3.0F, 3.0F, 3.0F, Dilation.NONE)
                .uv(limbU, limbV)
                .cuboid(-1.0F, 1.0F, -1.5F, 2.0F, 4.0F, 3.0F, Dilation.NONE)
                .uv(5, 87)
                .cuboid(-1.2F, 4.5F, -2.1F, 1.0F, 2.0F, 1.0F, Dilation.NONE)
                .uv(10, 87)
                .cuboid(-0.5F, 4.5F, -2.3F, 1.0F, 2.0F, 1.0F, Dilation.NONE)
                .uv(15, 87)
                .cuboid(0.2F, 4.5F, -2.1F, 1.0F, 2.0F, 1.0F, Dilation.NONE);
    }
}
