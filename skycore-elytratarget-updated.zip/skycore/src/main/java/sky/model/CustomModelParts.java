package sky.model;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Holds the procedurally built cosmetic player models and renders them on top of a vanilla
 * {@link BipedEntityModel}, mirroring the limb rotations of the wearer.
 */
public final class CustomModelParts {
    private static CustomModelParts instance;

    private final ModelPart rabbitRoot;
    private final ModelPart rabbitHead;
    private final ModelPart rabbitLeftArm;
    private final ModelPart rabbitRightArm;
    private final ModelPart rabbitLeftLeg;
    private final ModelPart rabbitRightLeg;

    private final ModelPart demonHead;
    private final ModelPart demonBody;
    private final ModelPart demonLeftArm;
    private final ModelPart demonRightArm;
    private final ModelPart demonLeftLeg;
    private final ModelPart demonRightLeg;

    private final ModelPart freddyRoot;
    private final ModelPart freddyHead;
    private final ModelPart freddyLeftArm;
    private final ModelPart freddyRightArm;
    private final ModelPart freddyLeftLeg;
    private final ModelPart freddyRightLeg;

    private final ModelPart amogusBody;
    private final ModelPart amogusEye;
    private final ModelPart amogusLeftLeg;
    private final ModelPart amogusRightLeg;

    private CustomModelParts() {
        ModelPart rabbit = createRabbitModel().createModel().getChild("bone");
        this.rabbitRoot = rabbit;
        this.rabbitHead = rabbit.getChild("head");
        this.rabbitLeftArm = rabbit.getChild("left_arm");
        this.rabbitRightArm = rabbit.getChild("right_arm");
        this.rabbitLeftLeg = rabbit.getChild("left_leg");
        this.rabbitRightLeg = rabbit.getChild("right_leg");

        ModelPart demon = createDemonModel().createModel();
        this.demonHead = demon.getChild("head");
        this.demonBody = demon.getChild("body");
        this.demonLeftArm = demon.getChild("left_arm");
        this.demonRightArm = demon.getChild("right_arm");
        this.demonLeftLeg = demon.getChild("left_leg");
        this.demonRightLeg = demon.getChild("right_leg");

        this.freddyRoot = createFreddyModel().createModel().getChild("body");
        this.freddyHead = this.freddyRoot.getChild("head");
        this.freddyLeftArm = this.freddyRoot.getChild("left_arm");
        this.freddyRightArm = this.freddyRoot.getChild("right_arm");
        this.freddyLeftLeg = this.freddyRoot.getChild("left_leg");
        this.freddyRightLeg = this.freddyRoot.getChild("right_leg");

        ModelPart amogus = createAmogusModel().createModel();
        this.amogusBody = amogus.getChild("body");
        this.amogusEye = amogus.getChild("eye");
        this.amogusLeftLeg = amogus.getChild("left_leg");
        this.amogusRightLeg = amogus.getChild("right_leg");
    }

    public static CustomModelParts getInstance() {
        if (instance == null) {
            instance = new CustomModelParts();
        }

        return instance;
    }

    public void renderRabbit(MatrixStack matrices, BipedEntityModel<?> source, VertexConsumer consumer, int light,
                             int overlay, int color) {
        copyRotation(this.rabbitHead, source.head);
        copyRotation(this.rabbitLeftArm, source.leftArm);
        this.rabbitLeftArm.roll = source.leftArm.roll - 0.0873F;
        copyRotation(this.rabbitRightArm, source.rightArm);
        this.rabbitRightArm.roll = source.rightArm.roll + 0.0873F;
        copyRotation(this.rabbitLeftLeg, source.leftLeg);
        copyRotation(this.rabbitRightLeg, source.rightLeg);

        matrices.push();
        matrices.scale(1.25F, 1.25F, 1.25F);
        matrices.translate(0.0F, -0.3F, 0.0F);
        this.rabbitRoot.render(matrices, consumer, light, overlay, color);
        matrices.pop();
    }

    public void renderDemon(MatrixStack matrices, BipedEntityModel<?> source, VertexConsumer consumer, int light,
                            int overlay, int color) {
        copyRotation(this.demonHead, source.head);
        copyRotation(this.demonBody, source.body);
        copyRotation(this.demonLeftArm, source.leftArm);
        copyRotation(this.demonRightArm, source.rightArm);
        copyRotation(this.demonLeftLeg, source.leftLeg);
        copyRotation(this.demonRightLeg, source.rightLeg);

        matrices.push();
        this.demonHead.render(matrices, consumer, light, overlay, color);
        this.demonBody.render(matrices, consumer, light, overlay, color);
        this.demonLeftArm.render(matrices, consumer, light, overlay, color);
        this.demonRightArm.render(matrices, consumer, light, overlay, color);
        this.demonLeftLeg.render(matrices, consumer, light, overlay, color);
        this.demonRightLeg.render(matrices, consumer, light, overlay, color);
        matrices.pop();
    }

    public void renderFreddy(MatrixStack matrices, BipedEntityModel<?> source, VertexConsumer consumer, int light,
                             int overlay, int color) {
        copyRotation(this.freddyHead, source.head);
        copyRotation(this.freddyLeftArm, source.leftArm);
        copyRotation(this.freddyRightArm, source.rightArm);
        copyRotation(this.freddyLeftLeg, source.leftLeg);
        copyRotation(this.freddyRightLeg, source.rightLeg);

        matrices.push();
        matrices.scale(0.75F, 0.65F, 0.75F);
        matrices.translate(0.0F, 0.85F, 0.0F);
        this.freddyRoot.render(matrices, consumer, light, overlay, color);
        matrices.pop();
    }

    public void renderAmogus(MatrixStack matrices, VertexConsumer consumer, int light, int overlay, int color) {
        matrices.push();
        matrices.translate(0.0F, -0.5F, 0.0F);
        this.amogusBody.render(matrices, consumer, light, overlay, color);
        this.amogusEye.render(matrices, consumer, light, overlay, color);
        this.amogusLeftLeg.render(matrices, consumer, light, overlay, color);
        this.amogusRightLeg.render(matrices, consumer, light, overlay, color);
        matrices.pop();
    }

    private static void copyRotation(ModelPart target, ModelPart source) {
        target.pitch = source.pitch;
        target.yaw = source.yaw;
        target.roll = source.roll;
    }

    private static TexturedModelData createRabbitModel() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        ModelPartData bone = root.addChild("bone", ModelPartBuilder.create().uv(28, 45)
                        .cuboid(-5.0F, -13.0F, -5.0F, 10.0F, 11.0F, 8.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 24.0F, 0.0F));

        bone.addChild("right_leg", ModelPartBuilder.create()
                        .cuboid(-2.0F, 0.0F, -2.0F, 4.0F, 2.0F, 4.0F, Dilation.NONE),
                ModelTransform.pivot(-3.0F, -2.0F, -1.0F));

        bone.addChild("left_arm", ModelPartBuilder.create()
                        .cuboid(0.0F, 0.0F, -2.0F, 2.0F, 8.0F, 4.0F, Dilation.NONE),
                ModelTransform.of(5.0F, -13.0F, -1.0F, 0.0F, 0.0F, -0.0873F));

        bone.addChild("right_arm", ModelPartBuilder.create()
                        .cuboid(-2.0F, 0.0F, -2.0F, 2.0F, 8.0F, 4.0F, Dilation.NONE),
                ModelTransform.of(-5.0F, -13.0F, -1.0F, 0.0F, 0.0F, 0.0873F));

        bone.addChild("left_leg", ModelPartBuilder.create()
                        .cuboid(-2.0F, 0.0F, -2.0F, 4.0F, 2.0F, 4.0F, Dilation.NONE),
                ModelTransform.pivot(3.0F, -2.0F, -1.0F));

        bone.addChild("head", ModelPartBuilder.create().uv(0, 0)
                        .cuboid(-3.0F, 0.0F, -4.0F, 6.0F, 1.0F, 6.0F, Dilation.NONE)
                        .uv(56, 0)
                        .cuboid(-5.0F, -9.0F, -5.0F, 2.0F, 3.0F, 2.0F, Dilation.NONE)
                        .uv(56, 0).mirrored()
                        .cuboid(3.0F, -9.0F, -5.0F, 2.0F, 3.0F, 2.0F, Dilation.NONE)
                        .uv(0, 45)
                        .cuboid(-4.0F, -11.0F, -4.0F, 8.0F, 11.0F, 8.0F, Dilation.NONE)
                        .uv(46, 0)
                        .cuboid(1.0F, -20.0F, 0.0F, 3.0F, 9.0F, 1.0F, Dilation.NONE)
                        .uv(46, 0)
                        .cuboid(-4.0F, -20.0F, 0.0F, 3.0F, 9.0F, 1.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, -14.0F, -1.0F));

        return TexturedModelData.of(modelData, 64, 64);
    }

    private static TexturedModelData createDemonModel() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        ModelPartData head = root.addChild("head", ModelPartBuilder.create().uv(0, 0)
                        .cuboid(-4.0F, -4.0F, -3.0F, 8.0F, 8.0F, 8.0F, new Dilation(0.3F)),
                ModelTransform.pivot(0.0F, -6.0F, -1.0F));

        head.addChild("left_horn", ModelPartBuilder.create().uv(32, 8)
                        .cuboid(13.4346F, -5.2071F, 2.7071F, 6.0F, 2.0F, 2.0F, new Dilation(0.1F))
                        .uv(0, 0)
                        .cuboid(17.4346F, -10.4071F, 2.7071F, 2.0F, 5.0F, 2.0F, new Dilation(0.1F)),
                ModelTransform.of(-8.0F, 8.0F, 0.0F, -0.3927F, 0.3927F, -0.5236F));

        head.addChild("right_horn", ModelPartBuilder.create().uv(32, 8).mirrored()
                        .cuboid(-19.4346F, -5.2071F, 2.7071F, 6.0F, 2.0F, 2.0F, new Dilation(0.1F))
                        .uv(0, 0).mirrored()
                        .cuboid(-19.4346F, -10.4071F, 2.7071F, 2.0F, 5.0F, 2.0F, new Dilation(0.1F)),
                ModelTransform.of(8.0F, 8.0F, 0.0F, -0.3927F, -0.3927F, 0.5236F));

        ModelPartData body = root.addChild("body", ModelPartBuilder.create().uv(0, 16)
                        .cuboid(-4.5F, -1.7028F, 1.4696F, 8.0F, 12.0F, 4.0F, Dilation.NONE),
                ModelTransform.of(0.5F, -0.1F, -3.5F, 0.1745F, 0.0F, 0.0F));

        body.addChild("left_wing", ModelPartBuilder.create().uv(40, 12)
                        .cuboid(-7.0072F, -0.5972F, 0.7515F, 12.0F, 13.0F, 0.0F, Dilation.NONE),
                ModelTransform.of(8.25F, -2.0F, 10.0F, 0.0873F, -0.829F, 0.1745F));

        body.addChild("right_wing", ModelPartBuilder.create().uv(40, 12).mirrored()
                        .cuboid(-4.9928F, -0.5972F, 0.7515F, 12.0F, 13.0F, 0.0F, Dilation.NONE),
                ModelTransform.of(-9.25F, -2.0F, 10.0F, 0.0873F, 0.829F, -0.1745F));

        root.addChild("left_arm", ModelPartBuilder.create().uv(24, 16)
                        .cuboid(-1.1F, -1.05F, 0.0F, 4.0F, 14.0F, 4.0F, Dilation.NONE),
                ModelTransform.of(5.4F, -1.25F, -2.0F, 0.0F, 0.0F, -0.2182F));

        root.addChild("right_arm", ModelPartBuilder.create().uv(24, 16).mirrored()
                        .cuboid(-2.9F, -1.05F, 0.0F, 4.0F, 14.0F, 4.0F, Dilation.NONE),
                ModelTransform.of(-5.4F, -1.25F, -2.0F, 0.0F, 0.0F, 0.2182F));

        ModelPartData leftLeg = root.addChild("left_leg", ModelPartBuilder.create().uv(48, 22)
                        .cuboid(-3.25F, -2.25F, -1.0F, 4.0F, 9.0F, 4.0F, Dilation.NONE),
                ModelTransform.pivot(3.0F, 10.0F, 0.0F));

        ModelPartData leftLegLower = leftLeg.addChild("left_leg1", ModelPartBuilder.create().uv(34, 34)
                        .cuboid(0.95F, 4.6F, 8.0511F, 3.0F, 5.0F, 3.0F, Dilation.NONE),
                ModelTransform.of(-1.7F, -0.1F, -3.55F, -0.5236F, 0.0F, 0.0F));

        leftLegLower.addChild("bone2", ModelPartBuilder.create().uv(26, 0)
                        .cuboid(-0.7F, -1.15F, 9.3F, 4.0F, 2.0F, 4.0F, Dilation.NONE)
                        .uv(40, 0)
                        .cuboid(-0.7F, -1.15F, 7.3F, 4.0F, 2.0F, 2.0F, Dilation.NONE),
                ModelTransform.of(1.4F, 15.0F, 0.25F, 0.5236F, 0.0F, 0.0F));

        ModelPartData leftHoof = leftLegLower.addChild("bone3", ModelPartBuilder.create(),
                ModelTransform.of(-1.0F, 0.0F, -2.0F, 0.0F, -0.0873F, -0.2618F));

        leftHoof.addChild("bone7", ModelPartBuilder.create().uv(16, 34)
                        .cuboid(-0.7911F, -10.1159F, 8.0029F, 4.0F, 4.0F, 5.0F, Dilation.NONE)
                        .uv(0, 32)
                        .cuboid(-0.7911F, -15.1159F, 4.0029F, 4.0F, 9.0F, 4.0F, Dilation.NONE),
                ModelTransform.pivot(1.9F, 12.0F, 0.25F));

        ModelPartData rightLeg = root.addChild("right_leg", ModelPartBuilder.create().uv(48, 22).mirrored()
                        .cuboid(-0.75F, -2.25F, -1.0F, 4.0F, 9.0F, 4.0F, Dilation.NONE),
                ModelTransform.pivot(-3.0F, 10.0F, 0.0F));

        ModelPartData rightLegLower = rightLeg.addChild("right_leg1", ModelPartBuilder.create().uv(34, 34).mirrored()
                        .cuboid(-3.95F, 4.6F, 8.0511F, 3.0F, 5.0F, 3.0F, Dilation.NONE),
                ModelTransform.of(1.7F, -0.1F, -3.55F, -0.5236F, 0.0F, 0.0F));

        rightLegLower.addChild("bone4", ModelPartBuilder.create().uv(26, 0).mirrored()
                        .cuboid(-3.3F, -1.15F, 9.3F, 4.0F, 2.0F, 4.0F, Dilation.NONE)
                        .uv(40, 0).mirrored()
                        .cuboid(-3.3F, -1.15F, 7.3F, 4.0F, 2.0F, 2.0F, Dilation.NONE),
                ModelTransform.of(-1.4F, 15.0F, 0.25F, 0.5236F, 0.0F, 0.0F));

        ModelPartData rightHoof = rightLegLower.addChild("bone5", ModelPartBuilder.create(),
                ModelTransform.of(1.0F, 0.0F, -2.0F, 0.0F, 0.0873F, 0.2618F));

        rightHoof.addChild("bone6", ModelPartBuilder.create().uv(16, 34).mirrored()
                        .cuboid(-3.2089F, -10.1159F, 8.0029F, 4.0F, 4.0F, 5.0F, Dilation.NONE)
                        .uv(0, 32).mirrored()
                        .cuboid(-3.2089F, -15.1159F, 4.0029F, 4.0F, 9.0F, 4.0F, Dilation.NONE),
                ModelTransform.pivot(-1.9F, 12.0F, 0.25F));

        return TexturedModelData.of(modelData, 64, 64);
    }

    private static TexturedModelData createFreddyModel() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        ModelPartData body = root.addChild("body", ModelPartBuilder.create().uv(0, 0)
                        .cuboid(-1.0F, -14.0F, -1.0F, 2.0F, 24.0F, 2.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, -9.0F, 0.0F));

        body.addChild("torso", ModelPartBuilder.create().uv(8, 0)
                        .cuboid(-6.0F, -9.0F, -4.0F, 12.0F, 18.0F, 8.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 0.0F, 0.0F, 0.017453292F, 0.0F, 0.0F));

        body.addChild("crotch", ModelPartBuilder.create().uv(56, 0)
                        .cuboid(-5.5F, 0.0F, -3.5F, 11.0F, 3.0F, 7.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 9.5F, 0.0F));

        ModelPartData rightArm = body.addChild("right_arm", ModelPartBuilder.create().uv(48, 0)
                        .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F, Dilation.NONE),
                ModelTransform.of(-6.5F, -8.0F, 0.0F, 0.0F, 0.0F, 0.2617994F));

        rightArm.addChild("right_arm_pad", ModelPartBuilder.create().uv(70, 10)
                        .cuboid(-2.5F, 0.0F, -2.5F, 5.0F, 9.0F, 5.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 0.5F, 0.0F));

        ModelPartData rightForearm = rightArm.addChild("right_arm2", ModelPartBuilder.create().uv(90, 20)
                        .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 9.6F, 0.0F, -0.17453292F, 0.0F, 0.0F));

        rightForearm.addChild("right_arm_pad2", ModelPartBuilder.create().uv(0, 26)
                        .cuboid(-2.5F, 0.0F, -2.5F, 5.0F, 7.0F, 5.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 0.5F, 0.0F));

        rightForearm.addChild("right_hand", ModelPartBuilder.create().uv(20, 26)
                        .cuboid(-2.0F, 0.0F, -2.5F, 4.0F, 4.0F, 5.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, -0.05235988F));

        ModelPartData leftArm = body.addChild("left_arm", ModelPartBuilder.create().uv(62, 10)
                        .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F, Dilation.NONE),
                ModelTransform.of(6.5F, -8.0F, 0.0F, 0.0F, 0.0F, -0.2617994F));

        leftArm.addChild("left_arm_pad", ModelPartBuilder.create().uv(38, 54)
                        .cuboid(-2.5F, 0.0F, -2.5F, 5.0F, 9.0F, 5.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 0.5F, 0.0F));

        ModelPartData leftForearm = leftArm.addChild("left_arm2", ModelPartBuilder.create().uv(90, 48)
                        .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 9.6F, 0.0F, -0.17453292F, 0.0F, 0.0F));

        leftForearm.addChild("left_arm_pad2", ModelPartBuilder.create().uv(0, 58)
                        .cuboid(-2.5F, 0.0F, -2.5F, 5.0F, 7.0F, 5.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 0.5F, 0.0F));

        leftForearm.addChild("left_hand", ModelPartBuilder.create().uv(58, 56)
                        .cuboid(-1.0F, 0.0F, -2.5F, 4.0F, 4.0F, 5.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.05235988F));

        ModelPartData rightLeg = body.addChild("right_leg", ModelPartBuilder.create().uv(90, 8)
                        .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F, Dilation.NONE),
                ModelTransform.pivot(-3.3F, 12.5F, 0.0F));

        rightLeg.addChild("right_leg_pad", ModelPartBuilder.create().uv(73, 33)
                        .cuboid(-3.0F, 0.0F, -3.0F, 6.0F, 9.0F, 6.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 0.5F, 0.0F));

        ModelPartData rightShin = rightLeg.addChild("right_leg2", ModelPartBuilder.create().uv(20, 35)
                        .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 9.6F, 0.0F, 0.034906585F, 0.0F, 0.0F));

        rightShin.addChild("right_leg_pad2", ModelPartBuilder.create().uv(0, 39)
                        .cuboid(-2.5F, 0.0F, -3.0F, 5.0F, 7.0F, 6.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 0.5F, 0.0F));

        rightShin.addChild("right_foot", ModelPartBuilder.create().uv(22, 39)
                        .cuboid(-2.5F, 0.0F, -6.0F, 5.0F, 3.0F, 8.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 8.0F, 0.0F, -0.034906585F, 0.0F, 0.0F));

        ModelPartData leftLeg = body.addChild("left_leg", ModelPartBuilder.create().uv(54, 10)
                        .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F, Dilation.NONE),
                ModelTransform.pivot(3.3F, 12.5F, 0.0F));

        leftLeg.addChild("left_leg_pad", ModelPartBuilder.create().uv(48, 39)
                        .cuboid(-3.0F, 0.0F, -3.0F, 6.0F, 9.0F, 6.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 0.5F, 0.0F));

        ModelPartData leftShin = leftLeg.addChild("left_leg2", ModelPartBuilder.create().uv(72, 48)
                        .cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 9.6F, 0.0F, 0.034906585F, 0.0F, 0.0F));

        leftShin.addChild("left_leg_pad2", ModelPartBuilder.create().uv(16, 50)
                        .cuboid(-2.5F, 0.0F, -3.0F, 5.0F, 7.0F, 6.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, 0.5F, 0.0F));

        leftShin.addChild("left_foot", ModelPartBuilder.create().uv(72, 50)
                        .cuboid(-2.5F, 0.0F, -6.0F, 5.0F, 3.0F, 8.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 8.0F, 0.0F, -0.034906585F, 0.0F, 0.0F));

        ModelPartData head = body.addChild("head", ModelPartBuilder.create().uv(39, 22)
                        .cuboid(-5.5F, -8.0F, -4.5F, 11.0F, 8.0F, 9.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, -13.0F, -0.5F));

        ModelPartData rightEar = head.addChild("ear_right", ModelPartBuilder.create().uv(8, 0)
                        .cuboid(-1.0F, -3.0F, -0.5F, 2.0F, 3.0F, 1.0F, Dilation.NONE),
                ModelTransform.of(-4.5F, -5.5F, 0.0F, 0.05235988F, 0.0F, -1.0471976F));

        rightEar.addChild("ear_right_pad", ModelPartBuilder.create().uv(85, 0)
                        .cuboid(-2.0F, -5.0F, -1.0F, 4.0F, 4.0F, 2.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, -1.0F, 0.0F));

        ModelPartData leftEar = head.addChild("ear_left", ModelPartBuilder.create().uv(40, 0)
                        .cuboid(-1.0F, -3.0F, -0.5F, 2.0F, 3.0F, 1.0F, Dilation.NONE),
                ModelTransform.of(4.5F, -5.5F, 0.0F, 0.05235988F, 0.0F, 1.0471976F));

        leftEar.addChild("ear_left_pad", ModelPartBuilder.create().uv(40, 39)
                        .cuboid(-2.0F, -5.0F, -1.0F, 4.0F, 4.0F, 2.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, -1.0F, 0.0F));

        ModelPartData hat = head.addChild("hat", ModelPartBuilder.create().uv(70, 24)
                        .cuboid(-3.0F, -0.5F, -3.0F, 6.0F, 1.0F, 6.0F, Dilation.NONE),
                ModelTransform.of(0.0F, -8.4F, 0.0F, -0.017453292F, 0.0F, 0.0F));

        hat.addChild("hat2", ModelPartBuilder.create().uv(78, 61)
                        .cuboid(-2.0F, -4.0F, -2.0F, 4.0F, 4.0F, 4.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 0.1F, 0.0F, -0.017453292F, 0.0F, 0.0F));

        head.addChild("nose", ModelPartBuilder.create().uv(17, 67)
                        .cuboid(-4.0F, -2.0F, -3.0F, 8.0F, 4.0F, 3.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, -2.0F, -4.5F));

        head.addChild("jaw", ModelPartBuilder.create().uv(49, 65)
                        .cuboid(-5.0F, 0.0F, -4.5F, 10.0F, 3.0F, 9.0F, Dilation.NONE),
                ModelTransform.of(0.0F, 0.5F, 0.0F, 0.08726646F, 0.0F, 0.0F));

        return TexturedModelData.of(modelData, 100, 80);
    }

    private static TexturedModelData createAmogusModel() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        root.addChild("body", ModelPartBuilder.create().uv(34, 8)
                        .cuboid(-4.0F, 6.0F, -3.0F, 8.0F, 12.0F, 6.0F, Dilation.NONE)
                        .uv(15, 10)
                        .cuboid(-3.0F, 9.0F, 3.0F, 6.0F, 8.0F, 3.0F, Dilation.NONE)
                        .uv(26, 0)
                        .cuboid(-3.0F, 5.0F, -3.0F, 6.0F, 1.0F, 6.0F, Dilation.NONE),
                ModelTransform.NONE);

        root.addChild("eye", ModelPartBuilder.create().uv(0, 10)
                        .cuboid(-3.0F, 7.0F, -4.0F, 6.0F, 4.0F, 1.0F, Dilation.NONE),
                ModelTransform.NONE);

        root.addChild("left_leg", ModelPartBuilder.create().uv(0, 0)
                        .cuboid(2.9F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F, Dilation.NONE),
                ModelTransform.pivot(-2.0F, 18.0F, 0.0F));

        root.addChild("right_leg", ModelPartBuilder.create().uv(13, 0)
                        .cuboid(-5.9F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F, Dilation.NONE),
                ModelTransform.pivot(2.0F, 18.0F, 0.0F));

        return TexturedModelData.of(modelData, 64, 64);
    }
}
