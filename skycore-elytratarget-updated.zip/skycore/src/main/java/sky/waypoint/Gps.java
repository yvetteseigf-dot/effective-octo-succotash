package sky.waypoint;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import sky.SkyInit;
import sky.util.text.CommandFeedback;
import sky.command.Command;

public final class Gps extends Command {
    public Gps() {
        super("gps");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(arg("X", IntegerArgumentType.integer())
                .then(arg("Z", IntegerArgumentType.integer()).executes(context -> {
                    int x = context.getArgument("X", Integer.class);
                    int z = context.getArgument("Z", Integer.class);
                    SkyInit.getInstance().getWaypointManager().set(new Waypoint(x, z));
                    CommandFeedback.displayInfo("GPS created and pointing to XZ: " + x + ", " + z);
                    return 1;
                })));

        builder.then(literal("player")
                .then(arg("name", StringArgumentType.word())
                        .then(arg("X", IntegerArgumentType.integer())
                                .then(arg("Z", IntegerArgumentType.integer()).executes(context -> {
                                    String name = context.getArgument("name", String.class);
                                    int x = context.getArgument("X", Integer.class);
                                    int z = context.getArgument("Z", Integer.class);
                                    SkyInit.getInstance().getWaypointManager()
                                            .setPlayerWaypoint(new Waypoint(name, x, z));
                                    CommandFeedback.displayInfo(
                                            "GPS on player " + name + " created: XZ " + x + ", " + z);
                                    return 1;
                                })))));

        builder.then(literal("player").then(literal("remove").executes(context -> {
            if (!SkyInit.getInstance().getWaypointManager().isEmptyPlayerWaypoint()) {
                SkyInit.getInstance().getWaypointManager().clearPlayerWaypoint();
                CommandFeedback.displayInfo("Player GPS removed");
            } else {
                CommandFeedback.displayInfo("No active player GPS");
            }
            return 1;
        })));

        builder.then(literal("remove").executes(context -> {
            if (!SkyInit.getInstance().getWaypointManager().isEmpty()) {
                SkyInit.getInstance().getWaypointManager().clear();
                CommandFeedback.displayInfo("Waypoint GPS removed");
            } else {
                CommandFeedback.displayInfo("No active GPS");
            }
            return 1;
        }));
    }
}
