package sky.scheduler;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import net.minecraft.util.math.MathHelper;
import sky.event.network.PacketSendEvent;

/** Estimates the server tick rate from the interval between world time updates. */
public final class TpsTracker {
    private static float adjustTicks = 0.0F;
    private static float TPS = 20.0F;
    private static final TpsTracker INSTANCE = new TpsTracker();

    private long timestamp;

    private TpsTracker() {
        EventManager.register(this);
    }

    public static TpsTracker getInstance() {
        return INSTANCE;
    }

    public static float getTPS() {
        return TPS;
    }

    public static float getAdjustTicks() {
        return adjustTicks;
    }

    @EventTarget
    private void onPacket(PacketSendEvent event) {
        if (event.getPacket() instanceof WorldTimeUpdateS2CPacket) {
            updateTPS();
        }
    }

    private void updateTPS() {
        long elapsed = System.nanoTime() - timestamp;
        float measured = 20.0F * (1.0E9F / (float) elapsed);
        float clamped = MathHelper.clamp(measured, 0.0F, 20.0F);

        TPS = Math.round(clamped * 2.0F) / 2.0F;
        adjustTicks = clamped - 20.0F;
        timestamp = System.nanoTime();
    }
}
