package sky.scheduler;

import java.util.ArrayList;
import java.util.List;

public class TickScheduler {
    private int currentTick;
    private final List<Step> steps = new ArrayList<>();

    public TickScheduler addTickStep(int ticks, Runnable action) {
        steps.add(new Step(currentTick + ticks, action));
        return this;
    }

    public void update() {
        List<Step> ready = new ArrayList<>();
        steps.removeIf(step -> {
            if (currentTick >= step.tick) {
                ready.add(step);
                return true;
            }
            return false;
        });
        ready.forEach(step -> step.action.run());
        currentTick++;
    }

    public boolean isFinished() {
        return steps.isEmpty();
    }

    public TickScheduler cleanup() {
        steps.clear();
        currentTick = 0;
        return this;
    }

    private record Step(int tick, Runnable action) {
    }
}
