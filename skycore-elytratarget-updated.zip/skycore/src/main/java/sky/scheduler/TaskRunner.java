package sky.scheduler;

public final class TaskRunner {
    private TaskRunner() {
    }

    public static void addTask(Runnable task) {
        task.run();
    }
}
