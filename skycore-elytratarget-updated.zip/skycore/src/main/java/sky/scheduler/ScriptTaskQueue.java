package sky.scheduler;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import sky.event.player.PlayerUpdateEvent;
import sky.event.player.RotationTickEvent;

import java.util.LinkedList;
import java.util.Queue;

/** Sequential event-driven script task queue. */
public class ScriptTaskQueue {
    private final Queue<ScriptTask> tasks = new LinkedList<>();

    public ScriptTaskQueue() {
        EventManager.register(this);
    }

    @EventTarget
    public void updateTick(PlayerUpdateEvent event) {
        tick(event);
    }

    public void addTask(ScriptTask task) {
        tasks.add(task);
    }

    public void tick(Object event) {
        ScriptTask current = tasks.peek();
        if (current != null && current.tryTick(event)) {
            tasks.poll();
        }
    }

    @EventTarget
    public void rotateTick(RotationTickEvent event) {
        tick(event);
    }

    public boolean isFinished() {
        return tasks.isEmpty();
    }

    public static class ScriptTask {
        private final Queue<Step<?>> steps = new LinkedList<>();
        private int idleTicks;
        private int maxIdleTicks = 400;

        public boolean tryTick(Object event) {
            Step<?> step = steps.peek();
            if (step == null) {
                return true;
            }
            if (step.eventClass.isInstance(event) && step.execute(event)) {
                steps.poll();
                idleTicks = 0;
                return steps.isEmpty();
            }
            if (++idleTicks > maxIdleTicks) {
                steps.clear();
                return true;
            }
            return false;
        }

        public ScriptTask withMaxIdleTicks(int maxIdleTicks) {
            this.maxIdleTicks = Math.max(1, maxIdleTicks);
            return this;
        }

        public boolean isCompleted() {
            return steps.isEmpty();
        }

        public <E> ScriptTask schedule(Class<E> eventClass, StepTask<E> action) {
            steps.add(new Step<>(eventClass, action));
            return this;
        }

        @FunctionalInterface
        public interface StepTask<E> {
            boolean accept(E event);
        }

        private static final class Step<E> {
            private final Class<E> eventClass;
            private final StepTask<E> action;

            private Step(Class<E> eventClass, StepTask<E> action) {
                this.eventClass = eventClass;
                this.action = action;
            }

            private boolean execute(Object event) {
                return action.accept(eventClass.cast(event));
            }
        }
    }
}
