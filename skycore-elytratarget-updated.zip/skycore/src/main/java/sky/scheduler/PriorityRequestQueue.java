package sky.scheduler;

import net.minecraft.client.MinecraftClient;
import sky.module.Module;

import java.util.Comparator;
import java.util.concurrent.PriorityBlockingQueue;

public class PriorityRequestQueue<T> {
    private int currentTick;
    private final PriorityBlockingQueue<Request<T>> activeRequests = new PriorityBlockingQueue<>(
            11, Comparator.comparingInt(request -> -request.priority));

    public void tick(int ticks) {
        currentTick += ticks;
    }

    public void request(Request<T> request) {
        activeRequests.removeIf(active -> active.provider == request.provider);
        request.expiresIn += currentTick;
        activeRequests.add(request);
    }

    public void tick() {
        tick(1);
    }

    public T getActiveRequestValue() {
        Request<T> request = activeRequests.peek();
        while (MinecraftClient.getInstance().isOnThread() && request != null
                && (request.expiresIn <= currentTick || !request.provider.isEnabled())) {
            activeRequests.poll();
            request = activeRequests.peek();
        }
        return request == null ? null : request.value;
    }

    public static class Request<T> {
        public final int priority;
        public int expiresIn;
        public final T value;
        public final Module provider;

        public Request(int expiresIn, int priority, Module provider, T value) {
            this.expiresIn = expiresIn;
            this.priority = priority;
            this.provider = provider;
            this.value = value;
        }
    }
}
