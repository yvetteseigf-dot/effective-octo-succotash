package sky.event.network;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.entity.Entity;

/** Fired after the client network handler creates an entity from a spawn packet. */
public class EntitySpawnEvent implements Event {
    private Entity entity;

    public EntitySpawnEvent(Entity entity) {
        this.entity = entity;
    }

    public Entity getEntity() {
        return entity;
    }
}
