package sky.event.network;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable lifecycle event emitted while the client joins or swaps worlds. */
public class WorldSwapEvent extends EventCancellable implements Event {
    public State state;

    public WorldSwapEvent(State state) {
        this.state = state;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof WorldSwapEvent other)) {
            return false;
        }
        if (!other.canEqual(this)) {
            return false;
        }

        State thisState = getState();
        State otherState = other.getState();
        return thisState == null ? otherState == null : thisState.equals(otherState);
    }

    protected boolean canEqual(Object object) {
        return object instanceof WorldSwapEvent;
    }

    @Override
    public int hashCode() {
        State state = getState();
        return 59 + (state == null ? 43 : state.hashCode());
    }

    @Override
    public String toString() {
        return "EventSwapWorld(state=" + getState() + ')';
    }

    public enum State {
        LOAD,
        CHANGED
    }
}
