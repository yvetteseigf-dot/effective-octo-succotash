package sky.event.network;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.network.packet.Packet;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable packet boundary event for both outgoing and incoming packets. */
public class PacketSendEvent extends EventCancellable {
    private final Packet<?> packet;
    private final PacketType packetType;

    public PacketSendEvent(Packet<?> packet, PacketType packetType) {
        this.packet = packet;
        this.packetType = packetType;
    }

    public boolean isReceive() {
        return packetType == PacketType.RECEIVE;
    }

    public boolean isSent() {
        return isSend();
    }

    public Packet<?> getPacket() {
        return packet;
    }

    public boolean isSend() {
        return packetType == PacketType.SEND;
    }

    protected boolean canEqual(Object object) {
        return object instanceof PacketSendEvent;
    }

    public PacketType getPacketType() {
        return packetType;
    }

    public enum PacketType {
        SEND,
        RECEIVE
    }
}
