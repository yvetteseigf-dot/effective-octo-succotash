package sky.event.network;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

/** Fired when the server requests the client-side item-pickup animation. */
public class PickupAnimationEvent implements Event {
    private final ItemStack itemStack;
    private final LivingEntity entity;

    public PickupAnimationEvent(LivingEntity entity, ItemStack itemStack) {
        this.entity = entity;
        this.itemStack = itemStack;
    }

    public LivingEntity getEntity() {
        return entity;
    }

    public ItemStack getItemStack() {
        return itemStack;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof PickupAnimationEvent other)) {
            return false;
        }
        if (!other.canEqual(this)) {
            return false;
        }

        LivingEntity thisEntity = getEntity();
        LivingEntity otherEntity = other.getEntity();
        if (thisEntity == null ? otherEntity != null : !thisEntity.equals(otherEntity)) {
            return false;
        }

        ItemStack thisItemStack = getItemStack();
        ItemStack otherItemStack = other.getItemStack();
        return thisItemStack == null ? otherItemStack == null : thisItemStack.equals(otherItemStack);
    }

    protected boolean canEqual(Object object) {
        return object instanceof PickupAnimationEvent;
    }

    @Override
    public int hashCode() {
        int result = 1;
        LivingEntity entity = getEntity();
        result = result * 59 + (entity == null ? 43 : entity.hashCode());
        ItemStack itemStack = getItemStack();
        result = result * 59 + (itemStack == null ? 43 : itemStack.hashCode());
        return result;
    }

    @Override
    public String toString() {
        return "EventPickupItem(entity=" + getEntity() + ", itemStack=" + getItemStack() + ')';
    }
}
