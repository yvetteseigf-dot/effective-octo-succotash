package sky.event.item;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;

public class RightClickBlockEvent extends EventCancellable implements Event {
    private final Hand hand;
    private final ClientPlayerEntity player;
    private final BlockHitResult result;
    private final ClientWorld world;

    public RightClickBlockEvent(ClientPlayerEntity player, ClientWorld world, Hand hand, BlockHitResult result) {
        this.player = player;
        this.world = world;
        this.hand = hand;
        this.result = result;
    }

    public BlockHitResult getResult() {
        return result;
    }

    public ClientPlayerEntity getPlayer() {
        return player;
    }

    public ClientWorld getWorld() {
        return world;
    }

    public Hand getHand() {
        return hand;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof RightClickBlockEvent other)) return false;
        if (!other.canEqual(this)) return false;
        ClientPlayerEntity thisPlayer = getPlayer();
        ClientPlayerEntity otherPlayer = other.getPlayer();
        if (thisPlayer == null ? otherPlayer != null : !thisPlayer.equals(otherPlayer)) return false;
        ClientWorld thisWorld = getWorld();
        ClientWorld otherWorld = other.getWorld();
        if (thisWorld == null ? otherWorld != null : !thisWorld.equals(otherWorld)) return false;
        Hand thisHand = getHand();
        Hand otherHand = other.getHand();
        if (thisHand == null ? otherHand != null : !thisHand.equals(otherHand)) return false;
        BlockHitResult thisResult = getResult();
        BlockHitResult otherResult = other.getResult();
        return thisResult == null ? otherResult == null : thisResult.equals(otherResult);
    }

    protected boolean canEqual(Object other) {
        return other instanceof RightClickBlockEvent;
    }

    @Override
    public int hashCode() {
        int result = 1;
        ClientPlayerEntity player = getPlayer();
        result = 59 + (player == null ? 43 : player.hashCode());
        ClientWorld world = getWorld();
        result = result * 59 + (world == null ? 43 : world.hashCode());
        Hand hand = getHand();
        result = result * 59 + (hand == null ? 43 : hand.hashCode());
        BlockHitResult blockHitResult = getResult();
        return result * 59 + (blockHitResult == null ? 43 : blockHitResult.hashCode());
    }

    @Override
    public String toString() {
        return "EventClickBlockRight(player=" + getPlayer() + ", world=" + getWorld() + ", hand=" + getHand() + ", result=" + getResult() + ')';
    }
}
