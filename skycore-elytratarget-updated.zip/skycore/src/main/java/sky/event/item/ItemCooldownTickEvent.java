package sky.event.item;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.item.Item;

public class ItemCooldownTickEvent extends EventCancellable implements Event {
    private final Item item;
    private int ticks;

    public ItemCooldownTickEvent(Item item, int ticks) {
        this.item = item;
        this.ticks = ticks;
    }

    public int getTicks() {
        return ticks;
    }

    public Item getItem() {
        return item;
    }

    public void setTicks(int ticks) {
        this.ticks = ticks;
    }
}
