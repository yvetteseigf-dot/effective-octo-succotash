package sky.event.item;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.item.ItemStack;

public class EnderPearlUseEvent extends EventCancellable implements Event {
    private int cooldownTicks;
    private ItemStack itemStack;

    public EnderPearlUseEvent(ItemStack itemStack, int cooldownTicks) {
        this.itemStack = itemStack;
        this.cooldownTicks = cooldownTicks;
    }

    public ItemStack getItemStack() {
        return itemStack;
    }

    public void setItemStack(ItemStack itemStack) {
        this.itemStack = itemStack;
    }

    public int getCooldownTicks() {
        return cooldownTicks;
    }

    public void setCooldownTicks(int cooldownTicks) {
        this.cooldownTicks = cooldownTicks;
    }

    protected boolean canEqual(Object other) {
        return other instanceof EnderPearlUseEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof EnderPearlUseEvent other)) {
            return false;
        }
        if (!other.canEqual(this) || getCooldownTicks() != other.getCooldownTicks()) {
            return false;
        }
        ItemStack thisItemStack = getItemStack();
        ItemStack otherItemStack = other.getItemStack();
        return thisItemStack == null ? otherItemStack == null : thisItemStack.equals(otherItemStack);
    }

    @Override
    public int hashCode() {
        int result = 59 + getCooldownTicks();
        ItemStack itemStack = getItemStack();
        return result * 59 + (itemStack == null ? 43 : itemStack.hashCode());
    }

    @Override
    public String toString() {
        return "EventUseEnderPearl(itemStack=" + getItemStack() + ", cooldownTicks=" + getCooldownTicks() + ')';
    }
}
