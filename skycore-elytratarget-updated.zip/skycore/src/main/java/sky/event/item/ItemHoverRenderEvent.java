package sky.event.item;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;

public class ItemHoverRenderEvent extends EventCancellable implements Event {
    public final ItemStack stack;
    public final MatrixStack matrixStack;
    public final int mouseY;
    public final int mouseX;

    public ItemHoverRenderEvent(MatrixStack matrixStack, ItemStack stack, int mouseX, int mouseY) {
        this.matrixStack = matrixStack;
        this.stack = stack;
        this.mouseX = mouseX;
        this.mouseY = mouseY;
    }
}
