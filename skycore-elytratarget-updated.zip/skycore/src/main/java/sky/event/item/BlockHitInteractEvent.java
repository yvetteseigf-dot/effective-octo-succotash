package sky.event.item;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;

public class BlockHitInteractEvent extends EventCancellable implements Event {
    private final Hand hand;
    private final BlockHitResult hitResult;

    public BlockHitInteractEvent(Hand hand, BlockHitResult hitResult) {
        this.hand = hand;
        this.hitResult = hitResult;
    }

    public Hand getHand() {
        return hand;
    }

    public BlockHitResult getHitResult() {
        return hitResult;
    }
}
