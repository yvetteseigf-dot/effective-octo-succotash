package sky.event.camera;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable, mutable third-person camera clipping distance. */
public class ThirdPersonDistanceEvent extends EventCancellable implements Event {
    private double distance;

    public ThirdPersonDistanceEvent(double distance) {
        this.distance = distance;
    }

    protected boolean canEqual(Object object) {
        return object instanceof ThirdPersonDistanceEvent;
    }

    @Override
    public String toString() {
        return "EventThirdPersonDistance(distance=" + getDistance() + ")";
    }

    @Override
    public int hashCode() {
        long bits = Double.doubleToLongBits(getDistance());
        return 59 + (int) (bits >>> 32 ^ bits);
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof ThirdPersonDistanceEvent other)) {
            return false;
        }
        if (!other.canEqual(this)) {
            return false;
        }
        return Double.compare(getDistance(), other.getDistance()) == 0;
    }
}
