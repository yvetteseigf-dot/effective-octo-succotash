package sky.event.camera;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.util.math.Vec3d;

/** Mutable camera orientation, interpolation and optional position override. */
public class CameraUpdateEvent extends EventCancellable implements Event {
    private float pitch;
    private float partialTicks;
    private Vec3d position;
    private float yaw;

    public CameraUpdateEvent(float yaw, float pitch, float partialTicks) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.partialTicks = partialTicks;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public float getPartialTicks() {
        return partialTicks;
    }

    public Vec3d getPosition() {
        return position;
    }

    public float getPitch() {
        return pitch;
    }

    public void setPosition(Vec3d position) {
        this.position = position;
    }

    public void setPartialTicks(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public float getYaw() {
        return yaw;
    }
}
