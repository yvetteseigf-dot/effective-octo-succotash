package sky.event.camera;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import sky.util.combat.Rotation;

public class CameraStateEvent extends EventCancellable implements Event {
    private Rotation angle;
    private boolean cameraClip;
    private float distance;

    public CameraStateEvent(boolean cameraClip, float distance, Rotation angle) {
        this.cameraClip = cameraClip;
        this.distance = distance;
        this.angle = angle;
    }

    public void setAngle(Rotation angle) {
        this.angle = angle;
    }

    public boolean isCameraClip() {
        return cameraClip;
    }

    public Rotation getAngle() {
        return angle;
    }

    public float getDistance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }

    public void setCameraClip(boolean cameraClip) {
        this.cameraClip = cameraClip;
    }
}
