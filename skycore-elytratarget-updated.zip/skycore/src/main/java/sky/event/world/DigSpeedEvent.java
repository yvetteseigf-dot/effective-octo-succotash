package sky.event.world;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.block.BlockState;

public class DigSpeedEvent extends EventCancellable implements Event {
    private BlockState blockState;
    private float digSpeed;

    public DigSpeedEvent(BlockState blockState, float digSpeed) {
        this.blockState = blockState;
        this.digSpeed = digSpeed;
    }

    public float getDigSpeed() {
        return digSpeed;
    }

    public void setDigSpeed(float digSpeed) {
        this.digSpeed = digSpeed;
    }

    public BlockState getBlockState() {
        return blockState;
    }

    public void setBlockState(BlockState blockState) {
        this.blockState = blockState;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof DigSpeedEvent other)) return false;
        if (!other.canEqual(this)) return false;
        if (Float.compare(getDigSpeed(), other.getDigSpeed()) != 0) return false;
        BlockState thisBlockState = getBlockState();
        BlockState otherBlockState = other.getBlockState();
        return thisBlockState == null ? otherBlockState == null : thisBlockState.equals(otherBlockState);
    }

    protected boolean canEqual(Object other) {
        return other instanceof DigSpeedEvent;
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = 59 + Float.floatToIntBits(getDigSpeed());
        BlockState blockState = getBlockState();
        return result * 59 + (blockState == null ? 43 : blockState.hashCode());
    }

    @Override
    public String toString() {
        return "EventGetDigSpeed(blockState=" + getBlockState() + ", digSpeed=" + getDigSpeed() + ')';
    }
}
