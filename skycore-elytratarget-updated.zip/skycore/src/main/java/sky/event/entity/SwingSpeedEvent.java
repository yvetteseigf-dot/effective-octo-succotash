package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.util.Hand;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable event that can adjust a hand's swing duration. */
public class SwingSpeedEvent extends EventCancellable implements Event {
    private Hand hand;
    private int swipeSpeed;

    public SwingSpeedEvent(int swipeSpeed, Hand hand) {
        this.swipeSpeed = swipeSpeed;
        this.hand = hand;
    }

    public int getSwipeSpeed() {
        return swipeSpeed;
    }

    public void setSwipeSpeed(int swipeSpeed) {
        this.swipeSpeed = swipeSpeed;
    }

    public Hand getHand() {
        return hand;
    }

    public void setHand(Hand hand) {
        this.hand = hand;
    }

    protected boolean canEqual(Object other) {
        return other instanceof SwingSpeedEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof SwingSpeedEvent other) || !other.canEqual(this)) {
            return false;
        }
        if (getSwipeSpeed() != other.getSwipeSpeed()) {
            return false;
        }

        Hand thisHand = getHand();
        Hand otherHand = other.getHand();
        return thisHand == null ? otherHand == null : thisHand.equals(otherHand);
    }

    @Override
    public int hashCode() {
        int result = 59 + getSwipeSpeed();
        Hand hand = getHand();
        return result * 59 + (hand == null ? 43 : hand.hashCode());
    }

    @Override
    public String toString() {
        return "EventSwingSpeed(swipeSpeed=" + getSwipeSpeed() + ", hand=" + getHand() + ')';
    }
}
