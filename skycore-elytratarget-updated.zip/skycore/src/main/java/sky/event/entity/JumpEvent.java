package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable event fired before a living entity jumps. */
public class JumpEvent extends EventCancellable implements Event {
    public JumpEvent() {
    }

    protected boolean canEqual(Object other) {
        return other instanceof JumpEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        return object instanceof JumpEvent other && other.canEqual(this);
    }

    @Override
    public int hashCode() {
        return 1;
    }

    @Override
    public String toString() {
        return "EventJump()";
    }
}
