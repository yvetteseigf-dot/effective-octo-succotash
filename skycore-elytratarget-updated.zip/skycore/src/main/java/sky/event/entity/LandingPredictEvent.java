package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable landing prediction event. */
public class LandingPredictEvent extends EventCancellable implements Event {
    private boolean willLand;

    public LandingPredictEvent(boolean willLand) {
        this.willLand = willLand;
    }

    public boolean isWillLand() {
        return willLand;
    }

    public void setWillLand(boolean willLand) {
        this.willLand = willLand;
    }

    protected boolean canEqual(Object other) {
        return other instanceof LandingPredictEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        return object instanceof LandingPredictEvent other
                && other.canEqual(this)
                && isWillLand() == other.isWillLand();
    }

    @Override
    public int hashCode() {
        return 59 + (isWillLand() ? 79 : 97);
    }

    @Override
    public String toString() {
        return "EventWillLand(willLand=" + isWillLand() + ')';
    }
}
