package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.util.math.Vec3d;

public class ElytraFlyingEvent extends EventCancellable implements Event {
    private float f;
    private Vec3d Vec3d;

    public ElytraFlyingEvent(Vec3d Vec3d, float f) {
        this.Vec3d = Vec3d;
        this.f = f;
    }

    public float getF() {
        return f;
    }

    public void setF(float f) {
        this.f = f;
    }

    public Vec3d getVec3d() {
        return Vec3d;
    }

    public void setVec3d(Vec3d Vec3d) {
        this.Vec3d = Vec3d;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof ElytraFlyingEvent other)) return false;
        if (!other.canEqual(this) || Float.compare(getF(), other.getF()) != 0) return false;
        Vec3d thisVec3d = getVec3d();
        Vec3d otherVec3d = other.getVec3d();
        return thisVec3d == null ? otherVec3d == null : thisVec3d.equals(otherVec3d);
    }

    @Override
    public int hashCode() {
        int result = 59 + Float.floatToIntBits(getF());
        Vec3d vec3d = getVec3d();
        return result * 59 + (vec3d == null ? 43 : vec3d.hashCode());
    }

    @Override
    public String toString() {
        return "EventElytraFlying(Vec3d=" + getVec3d() + ", f=" + getF() + ')';
    }

    protected boolean canEqual(Object other) {
        return other instanceof ElytraFlyingEvent;
    }
}
