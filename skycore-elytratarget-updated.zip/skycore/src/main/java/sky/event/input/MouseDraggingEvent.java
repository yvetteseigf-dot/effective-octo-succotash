package sky.event.input;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class MouseDraggingEvent extends EventCancellable implements Event {
    private final double mouseY;
    private final double mouseX;

    public MouseDraggingEvent(double mouseX, double mouseY) {
        this.mouseX = mouseX;
        this.mouseY = mouseY;
    }

    protected boolean canEqual(Object other) {
        return other instanceof MouseDraggingEvent;
    }

    public int hashCode() {
        int result = 1;
        long mouseXBits = Double.doubleToLongBits(getMouseX());
        result = result * 59 + (int) (mouseXBits >>> 32 ^ mouseXBits);
        long mouseYBits = Double.doubleToLongBits(getMouseY());
        return result * 59 + (int) (mouseYBits >>> 32 ^ mouseYBits);
    }

    public double getMouseX() {
        return mouseX;
    }

    public double getMouseY() {
        return mouseY;
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof MouseDraggingEvent that) || !that.canEqual(this)) {
            return false;
        }
        return Double.compare(getMouseX(), that.getMouseX()) == 0
                && Double.compare(getMouseY(), that.getMouseY()) == 0;
    }

    public String toString() {
        return "EventDragging(mouseX=" + getMouseX() + ", mouseY=" + getMouseY() + ")";
    }
}
