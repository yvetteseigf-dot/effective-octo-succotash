package sky.event.input;

import com.darkmagician6.eventapi.events.Event;

public class MouseTickEvent implements Event {
    private int button;

    public MouseTickEvent(int button) {
        this.button = button;
    }

    public String toString() {
        return "EventMouseTick(button=" + getButton() + ")";
    }

    public int hashCode() {
        return 59 + getButton();
    }

    public void setButton(int button) {
        this.button = button;
    }

    protected boolean canEqual(Object other) {
        return other instanceof MouseTickEvent;
    }

    public int getButton() {
        return button;
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        return other instanceof MouseTickEvent that
                && that.canEqual(this)
                && getButton() == that.getButton();
    }
}
