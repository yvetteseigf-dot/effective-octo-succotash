package sky.event.input;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class MouseReleasedEvent extends EventCancellable implements Event {
    private final double mouseX;
    private final int key;
    private final double mouseY;

    public MouseReleasedEvent(int key, double mouseX, double mouseY) {
        this.key = key;
        this.mouseX = mouseX;
        this.mouseY = mouseY;
    }

    protected boolean canEqual(Object other) {
        return other instanceof MouseReleasedEvent;
    }

    public String toString() {
        return "EventMouseReleased(key=" + getKey() + ", mouseX=" + getMouseX() + ", mouseY=" + getMouseY() + ")";
    }

    public double getMouseY() {
        return mouseY;
    }

    public int getKey() {
        return key;
    }

    public double getMouseX() {
        return mouseX;
    }

    public int hashCode() {
        int result = 59 + getKey();
        long mouseXBits = Double.doubleToLongBits(getMouseX());
        result = result * 59 + (int) (mouseXBits >>> 32 ^ mouseXBits);
        long mouseYBits = Double.doubleToLongBits(getMouseY());
        return result * 59 + (int) (mouseYBits >>> 32 ^ mouseYBits);
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof MouseReleasedEvent that) || !that.canEqual(this)) {
            return false;
        }
        return getKey() == that.getKey()
                && Double.compare(getMouseX(), that.getMouseX()) == 0
                && Double.compare(getMouseY(), that.getMouseY()) == 0;
    }
}
