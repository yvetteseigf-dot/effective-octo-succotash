package sky.event.input;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

/** Mutable yaw and pitch values emitted while the client mouse is updated. */
public class MouseUpdateMouseEvent extends EventCancellable implements Event {
    private double pitch;
    private double yaw;

    public MouseUpdateMouseEvent(double yaw, double pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public void setPitch(double pitch) {
        this.pitch = pitch;
    }

    public double getPitch() {
        return pitch;
    }

    public double getYaw() {
        return yaw;
    }

    public void setYaw(double yaw) {
        this.yaw = yaw;
    }
}
