package sky.event.input;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.util.PlayerInput;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable keyboard-input update with mutable movement and rotation state. */
public class StrafeInputEvent extends EventCancellable {
    private float strafe;
    private PlayerInput input;
    private float forward;
    private float yaw;

    public StrafeInputEvent(PlayerInput input, float forward, float strafe) {
        this.input = input;
        this.forward = forward;
        this.strafe = strafe;
    }

    public PlayerInput getInput() {
        return input;
    }

    public float getStrafe() {
        return strafe;
    }

    public float getForward() {
        return forward;
    }

    public float getYaw() {
        return yaw;
    }

    public void setInput(PlayerInput input) {
        this.input = input;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public void setForward(float forward) {
        this.forward = forward;
    }

    public void setYaw(float targetYaw, float yaw) {
        this.yaw = targetYaw;
    }

    public void setStrafe(float strafe) {
        this.strafe = strafe;
    }
}
