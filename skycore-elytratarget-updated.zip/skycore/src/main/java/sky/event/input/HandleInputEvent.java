package sky.event.input;

import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class HandleInputEvent extends EventCancellable {
}
