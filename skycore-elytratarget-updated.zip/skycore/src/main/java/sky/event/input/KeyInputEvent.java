package sky.event.input;

import com.darkmagician6.eventapi.events.Event;

/** Key state event dispatched outside a screen. */
public class KeyInputEvent implements Event {
    private int key;
    private boolean hold;

    public KeyInputEvent(int key, boolean hold) {
        this.key = key;
        this.hold = hold;
    }

    @Override
    public int hashCode() {
        int result = 59 + getKey();
        return result * 59 + (isHold() ? 79 : 97);
    }

    @Override
    public String toString() {
        return "EventKey(key=" + getKey() + ", hold=" + isHold() + ")";
    }

    public void setHold(boolean hold) {
        this.hold = hold;
    }

    public boolean isHold() {
        return hold;
    }

    public int getKey() {
        return key;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof KeyInputEvent other)) {
            return false;
        }
        return other.canEqual(this) && getKey() == other.getKey() && isHold() == other.isHold();
    }

    public void setKey(int key) {
        this.key = key;
    }

    protected boolean canEqual(Object other) {
        return other instanceof KeyInputEvent;
    }
}
