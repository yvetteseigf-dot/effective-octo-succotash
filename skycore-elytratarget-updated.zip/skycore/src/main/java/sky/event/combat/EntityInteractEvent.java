package sky.event.combat;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.entity.Entity;

public class EntityInteractEvent extends EventCancellable implements Event {
    private Entity entity;

    public EntityInteractEvent(Entity entity) {
        this.entity = entity;
    }

    public Entity getEntity() {
        return entity;
    }

    public void setEntity(Entity entity) {
        this.entity = entity;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof EntityInteractEvent other)) return false;
        if (!other.canEqual(this)) return false;
        Entity thisEntity = getEntity();
        Entity otherEntity = other.getEntity();
        return thisEntity == null ? otherEntity == null : thisEntity.equals(otherEntity);
    }

    protected boolean canEqual(Object other) {
        return other instanceof EntityInteractEvent;
    }

    @Override
    public int hashCode() {
        Entity entity = getEntity();
        return 59 + (entity == null ? 43 : entity.hashCode());
    }

    @Override
    public String toString() {
        return "EventInteract(entity=" + getEntity() + ')';
    }
}
