package sky.event.combat;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Event;
import net.minecraft.entity.Entity;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable event targeting an entity. */
public class EntityTargetEvent extends EventCancellable implements Event {
    private final Entity targetEntity;

    public EntityTargetEvent(Entity targetEntity) {
        this.targetEntity = targetEntity;
    }

    public Entity getTarget() {
        return targetEntity;
    }

    public Entity getTargetEntity() {
        return targetEntity;
    }
}
