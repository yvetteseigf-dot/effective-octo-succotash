package sky.event.combat;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable and mutable thorns-damage event. */
public class ThornsDamageEvent extends EventCancellable implements Event {
    private final int level;
    private final LivingEntity user;
    private final Entity attacker;
    private float damage;

    public ThornsDamageEvent(Entity attacker, LivingEntity user, int level, float damage) {
        this.attacker = attacker;
        this.user = user;
        this.level = level;
        this.damage = damage;
    }

    public Entity getAttacker() {
        return attacker;
    }

    public LivingEntity getUser() {
        return user;
    }

    public int getLevel() {
        return level;
    }

    public float getDamage() {
        return damage;
    }

    public void setDamage(float damage) {
        this.damage = damage;
    }

    protected boolean canEqual(Object other) {
        return other instanceof ThornsDamageEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof ThornsDamageEvent other) || !other.canEqual(this)) {
            return false;
        }
        if (getLevel() != other.getLevel() || Float.compare(getDamage(), other.getDamage()) != 0) {
            return false;
        }

        Entity thisAttacker = getAttacker();
        Entity otherAttacker = other.getAttacker();
        if (thisAttacker == null ? otherAttacker != null : !thisAttacker.equals(otherAttacker)) {
            return false;
        }

        LivingEntity thisUser = getUser();
        LivingEntity otherUser = other.getUser();
        return thisUser == null ? otherUser == null : thisUser.equals(otherUser);
    }

    @Override
    public int hashCode() {
        int result = 59 + getLevel();
        result = result * 59 + Float.floatToIntBits(getDamage());
        Entity attacker = getAttacker();
        result = result * 59 + (attacker == null ? 43 : attacker.hashCode());
        LivingEntity user = getUser();
        return result * 59 + (user == null ? 43 : user.hashCode());
    }

    @Override
    public String toString() {
        return "EventThornsDamage(attacker=" + getAttacker()
                + ", user=" + getUser()
                + ", level=" + getLevel()
                + ", damage=" + getDamage()
                + ')';
    }
}
