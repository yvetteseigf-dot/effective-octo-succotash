package sky.event.combat;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class VelocityEvent extends EventCancellable implements Event {
    private double ySpeed;
    private double y;
    private double x;
    private double zSpeed;
    private double z;
    private double xSpeed;

    public VelocityEvent(double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
        this.zSpeed = zSpeed;
    }

    public double getXSpeed() {
        return xSpeed;
    }

    public double getZSpeed() {
        return zSpeed;
    }

    public double getZ() {
        return z;
    }

    public double getY() {
        return y;
    }

    public double getYSpeed() {
        return ySpeed;
    }

    public double getX() {
        return x;
    }
}
