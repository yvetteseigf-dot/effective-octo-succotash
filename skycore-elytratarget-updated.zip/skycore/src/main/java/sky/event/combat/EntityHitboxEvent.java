package sky.event.combat;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.entity.Entity;

public class EntityHitboxEvent extends EventCancellable implements Event {
    private Entity entity;
    private float size;

    public EntityHitboxEvent(Entity entity, float size) {
        this.entity = entity;
        this.size = size;
    }

    public Entity getEntity() {
        return entity;
    }

    public void setEntity(Entity entity) {
        this.entity = entity;
    }

    public float getSize() {
        return size;
    }

    public void setSize(float size) {
        this.size = size;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof EntityHitboxEvent other)) return false;
        if (!other.canEqual(this)) return false;
        if (!super.equals(object)) return false;
        if (Float.compare(getSize(), other.getSize()) != 0) return false;
        Entity thisEntity = getEntity();
        Entity otherEntity = other.getEntity();
        return thisEntity == null ? otherEntity == null : thisEntity.equals(otherEntity);
    }

    protected boolean canEqual(Object other) {
        return other instanceof EntityHitboxEvent;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = result * 59 + Float.floatToIntBits(getSize());
        Entity entity = getEntity();
        return result * 59 + (entity == null ? 43 : entity.hashCode());
    }

    @Override
    public String toString() {
        return "EventEntityHitBox(entity=" + getEntity() + ", size=" + getSize() + ')';
    }
}
