package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class NoRenderEvent extends EventCancellable implements Event {
    public final NorenderType norenderType;

    public NoRenderEvent(NorenderType norenderType) {
        this.norenderType = norenderType;
    }

    public int hashCode() {
        Object norenderType = getNorenderType();
        return 59 + (norenderType == null ? 43 : norenderType.hashCode());
    }

    public String toString() {
        return "EventNoRender(norenderType=" + String.valueOf(getNorenderType()) + ")";
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof NoRenderEvent that) || !that.canEqual(this)) {
            return false;
        }
        Object thisNorenderType = getNorenderType();
        Object thatNorenderType = that.getNorenderType();
        return thisNorenderType == null ? thatNorenderType == null : thisNorenderType.equals(thatNorenderType);
    }

    protected boolean canEqual(Object other) {
        return other instanceof NoRenderEvent;
    }

    public NorenderType getNorenderType() {
        return norenderType;
    }

    public enum NorenderType {
        fire,
        bossbar,
        scoreboard,
        title,
        totem,
        hurttime,
        fishingrod,
        destroyparticles,
        rain,
        shadows,
        smoke,
        vignette,
        arrows,
        holograms,
        grass,
        health,
        players,
        bad_effects,
        underwater_blur,
        container_background,
        lava,
        tab,
        cameraclip,
        glowing
    }
}
