package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

/** Mutable two-dimensional render-context event. */
public class OverlayRenderEvent extends EventCancellable implements Event {
    private MatrixStack Stack;
    private float partialTicks;
    private DrawContext context;

    public OverlayRenderEvent(MatrixStack stack, float partialTicks, DrawContext context) {
        this.Stack = stack;
        this.partialTicks = partialTicks;
        this.context = context;
    }

    public DrawContext getContext() {
        return context;
    }

    public void setContext(DrawContext context) {
        this.context = context;
    }

    public MatrixStack getStack() {
        return Stack;
    }

    public void setStack(MatrixStack stack) {
        this.Stack = stack;
    }

    public float getPartialTicks() {
        return partialTicks;
    }

    public void setPartialTicks(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    protected boolean canEqual(Object other) {
        return other instanceof OverlayRenderEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof OverlayRenderEvent other)) {
            return false;
        }
        if (!other.canEqual(this) || Float.compare(getPartialTicks(), other.getPartialTicks()) != 0) {
            return false;
        }
        Object thisStack = getStack();
        Object otherStack = other.getStack();
        if (thisStack == null ? otherStack != null : !thisStack.equals(otherStack)) {
            return false;
        }
        Object thisContext = getContext();
        Object otherContext = other.getContext();
        return thisContext == null ? otherContext == null : thisContext.equals(otherContext);
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = result * 59 + Float.floatToIntBits(getPartialTicks());
        Object stack = getStack();
        result = result * 59 + (stack == null ? 43 : stack.hashCode());
        Object context = getContext();
        return result * 59 + (context == null ? 43 : context.hashCode());
    }

    @Override
    public String toString() {
        return "EventRender2D(Stack=" + getStack() + ", partialTicks=" + getPartialTicks()
                + ", context=" + getContext() + ")";
    }

    public static class World extends OverlayRenderEvent {
        public World(MatrixStack stack, float partialTicks, DrawContext context) {
            super(stack, partialTicks, context);
        }
    }

    public static class Pre extends OverlayRenderEvent {
        public Pre(MatrixStack stack, float partialTicks, DrawContext context) {
            super(stack, partialTicks, context);
        }
    }

    public static class Post extends OverlayRenderEvent {
        public Post(MatrixStack stack, float partialTicks, DrawContext context) {
            super(stack, partialTicks, context);
        }
    }

    public static class Send extends OverlayRenderEvent {
        public Send(MatrixStack stack, float partialTicks, DrawContext context) {
            super(stack, partialTicks, context);
        }
    }
}
