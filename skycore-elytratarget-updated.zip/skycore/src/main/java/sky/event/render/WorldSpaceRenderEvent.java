package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable three-dimensional world-render event. */
public class WorldSpaceRenderEvent extends EventCancellable implements Event {
    public float partialTicks;
    public Matrix4f matrix;
    public MatrixStack matrixStack;

    public WorldSpaceRenderEvent(float partialTicks, MatrixStack matrixStack, Matrix4f matrix) {
        this.partialTicks = partialTicks;
        this.matrixStack = matrixStack;
        this.matrix = matrix;
    }

    public Matrix4f getMatrix() {
        return matrix;
    }

    public void setMatrix(Matrix4f matrix) {
        this.matrix = matrix;
    }

    public float getPartialTicks() {
        return partialTicks;
    }

    public void setPartialTicks(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    public MatrixStack getMatrixStack() {
        return matrixStack;
    }

    public void setMatrixStack(MatrixStack matrixStack) {
        this.matrixStack = matrixStack;
    }

    protected boolean canEqual(Object other) {
        return other instanceof WorldSpaceRenderEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof WorldSpaceRenderEvent other)) {
            return false;
        }
        if (!other.canEqual(this) || Float.compare(getPartialTicks(), other.getPartialTicks()) != 0) {
            return false;
        }
        Object thisMatrixStack = getMatrixStack();
        Object otherMatrixStack = other.getMatrixStack();
        if (thisMatrixStack == null ? otherMatrixStack != null : !thisMatrixStack.equals(otherMatrixStack)) {
            return false;
        }
        Object thisMatrix = getMatrix();
        Object otherMatrix = other.getMatrix();
        return thisMatrix == null ? otherMatrix == null : thisMatrix.equals(otherMatrix);
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = result * 59 + Float.floatToIntBits(getPartialTicks());
        Object matrixStack = getMatrixStack();
        result = result * 59 + (matrixStack == null ? 43 : matrixStack.hashCode());
        Object matrix = getMatrix();
        return result * 59 + (matrix == null ? 43 : matrix.hashCode());
    }

    @Override
    public String toString() {
        return "EventWorld3D(partialTicks=" + getPartialTicks() + ", matrixStack=" + getMatrixStack()
                + ", matrix=" + getMatrix() + ")";
    }
}
