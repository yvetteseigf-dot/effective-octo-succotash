package sky.event.render;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

/** Mutable/cancellable crosshair render event. */
public class CrosshairRenderEvent extends EventCancellable {
    private MatrixStack stack;
    private DrawContext context;
    private float partialTicks;

    public CrosshairRenderEvent(DrawContext context, MatrixStack stack, float partialTicks) {
        this.context = context;
        this.stack = stack;
        this.partialTicks = partialTicks;
    }

    public DrawContext getContext() { return context; }
    public void setContext(DrawContext context) { this.context = context; }
    public MatrixStack getStack() { return stack; }
    public void setStack(MatrixStack stack) { this.stack = stack; }
    public float getPartialTicks() { return partialTicks; }
    public void setPartialTicks(float partialTicks) { this.partialTicks = partialTicks; }
    protected boolean canEqual(Object other) { return other instanceof CrosshairRenderEvent; }
}
