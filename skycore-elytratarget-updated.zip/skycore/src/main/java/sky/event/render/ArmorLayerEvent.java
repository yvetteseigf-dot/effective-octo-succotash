package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;

public class ArmorLayerEvent extends EventCancellable implements Event {
    private EntityModel<?> model;
    private LivingEntity entity;
    private MatrixStack matrix;

    public ArmorLayerEvent(LivingEntity entity, MatrixStack matrix, EntityModel<?> model) {
        this.entity = entity;
        this.matrix = matrix;
        this.model = model;
    }

    public LivingEntity getEntity() {
        return entity;
    }

    public void setMatrix(MatrixStack matrix) {
        this.matrix = matrix;
    }

    public MatrixStack getMatrix() {
        return matrix;
    }

    public void setModel(EntityModel<?> model) {
        this.model = model;
    }

    public EntityModel<?> getModel() {
        return model;
    }

    public void setEntity(LivingEntity entity) {
        this.entity = entity;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof ArmorLayerEvent other)) return false;
        if (!other.canEqual(this)) return false;
        LivingEntity thisEntity = getEntity();
        LivingEntity otherEntity = other.getEntity();
        if (thisEntity == null ? otherEntity != null : !thisEntity.equals(otherEntity)) return false;
        MatrixStack thisMatrix = getMatrix();
        MatrixStack otherMatrix = other.getMatrix();
        if (thisMatrix == null ? otherMatrix != null : !thisMatrix.equals(otherMatrix)) return false;
        EntityModel<?> thisModel = getModel();
        EntityModel<?> otherModel = other.getModel();
        return thisModel == null ? otherModel == null : thisModel.equals(otherModel);
    }

    @Override
    public String toString() {
        return "EventLayerHead(entity=" + getEntity() + ", matrix=" + getMatrix() + ", model=" + getModel() + ')';
    }

    @Override
    public int hashCode() {
        LivingEntity entity = getEntity();
        int result = 59 + (entity == null ? 43 : entity.hashCode());
        MatrixStack matrix = getMatrix();
        result = result * 59 + (matrix == null ? 43 : matrix.hashCode());
        EntityModel<?> model = getModel();
        return result * 59 + (model == null ? 43 : model.hashCode());
    }

    protected boolean canEqual(Object other) {
        return other instanceof ArmorLayerEvent;
    }
}
