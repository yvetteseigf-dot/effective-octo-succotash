package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.client.util.math.MatrixStack;

/** Immutable screen-render event carrying mouse coordinates. */
public class ScreenRenderEvent implements Event {
    private final int mouseX;
    private final MatrixStack matrixStack;
    private final int mouseY;

    public ScreenRenderEvent(MatrixStack matrixStack, int mouseX, int mouseY) {
        this.matrixStack = matrixStack;
        this.mouseX = mouseX;
        this.mouseY = mouseY;
    }

    public int getMouseX() {
        return mouseX;
    }

    public MatrixStack getMatrixStack() {
        return matrixStack;
    }

    public int getMouseY() {
        return mouseY;
    }
}
