package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.client.gui.DrawContext;

/** Event carrying the current GUI drawing context. */
public class GuiDrawEvent implements Event {
    private final DrawContext context;

    public GuiDrawEvent(DrawContext context) {
        this.context = context;
    }

    public DrawContext getContext() {
        return context;
    }
}
