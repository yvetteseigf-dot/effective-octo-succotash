package sky.event.render;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable event allowing fog color and distance to be changed. */
public class FogColorEvent extends EventCancellable implements Event {
    private float distance;
    private float start = 2.0F;
    private int color;
    private boolean colorSet;

    public FogColorEvent() {
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
        this.colorSet = true;
    }

    public boolean hasColor() {
        return colorSet;
    }

    public float getDistance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }

    public float getStart() {
        return start;
    }

    public void setStart(float start) {
        this.start = start;
    }
}
