package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.jetbrains.annotations.Nullable;

public class EquipOffsetEvent implements Event {
    private float equippedProg;
    private Arm Arm;
    @Nullable
    private MatrixStack matrices;

    public EquipOffsetEvent(Arm Arm, float equippedProg) {
        this.Arm = Arm;
        this.equippedProg = equippedProg;
    }

    public EquipOffsetEvent(Arm Arm, float equippedProg, @Nullable MatrixStack matrices) {
        this.Arm = Arm;
        this.equippedProg = equippedProg;
        this.matrices = matrices;
    }

    public void setArm(Arm Arm) {
        this.Arm = Arm;
    }

    public void setEquippedProg(float equippedProg) {
        this.equippedProg = equippedProg;
    }

    public void setMatrices(@Nullable MatrixStack matrices) {
        this.matrices = matrices;
    }

    public float getEquippedProg() {
        return equippedProg;
    }

    public Arm getArm() {
        return Arm;
    }

    @Nullable
    public MatrixStack getMatrices() {
        return matrices;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof EquipOffsetEvent other)) return false;
        if (!other.canEqual(this) || Float.compare(getEquippedProg(), other.getEquippedProg()) != 0) return false;
        Arm thisArm = getArm();
        Arm otherArm = other.getArm();
        if (thisArm == null ? otherArm != null : !thisArm.equals(otherArm)) return false;
        MatrixStack thisMatrices = getMatrices();
        MatrixStack otherMatrices = other.getMatrices();
        return thisMatrices == null ? otherMatrices == null : thisMatrices.equals(otherMatrices);
    }

    protected boolean canEqual(Object other) {
        return other instanceof EquipOffsetEvent;
    }

    @Override
    public String toString() {
        return "EventTransformSideFirstPerson(Arm=" + getArm() + ", equippedProg=" + getEquippedProg()
                + ", matrices=" + getMatrices() + ')';
    }

    @Override
    public int hashCode() {
        int result = 59 + Float.floatToIntBits(getEquippedProg());
        Arm arm = getArm();
        result = result * 59 + (arm == null ? 43 : arm.hashCode());
        MatrixStack matrices = getMatrices();
        return result * 59 + (matrices == null ? 43 : matrices.hashCode());
    }
}
