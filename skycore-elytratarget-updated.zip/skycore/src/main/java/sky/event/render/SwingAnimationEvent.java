package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;

public class SwingAnimationEvent extends EventCancellable implements Event {
    private float swingProgress;
    private MatrixStack matrixStack;
    private AbstractClientPlayerEntity player;
    private Hand hand;

    public SwingAnimationEvent(
            AbstractClientPlayerEntity player, float swingProgress, Hand hand, MatrixStack matrixStack) {
        this.player = player;
        this.swingProgress = swingProgress;
        this.hand = hand;
        this.matrixStack = matrixStack;
    }

    public void setHand(Hand hand) {
        this.hand = hand;
    }

    public void setMatrixStack(MatrixStack matrixStack) {
        this.matrixStack = matrixStack;
    }

    public MatrixStack getMatrixStack() {
        return matrixStack;
    }

    public void setPlayer(AbstractClientPlayerEntity player) {
        this.player = player;
    }

    public void setSwingProgress(float swingProgress) {
        this.swingProgress = swingProgress;
    }

    public float getSwingProgress() {
        return swingProgress;
    }

    public Hand getHand() {
        return hand;
    }

    public AbstractClientPlayerEntity getPlayer() {
        return player;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof SwingAnimationEvent other)) return false;
        if (!other.canEqual(this) || Float.compare(getSwingProgress(), other.getSwingProgress()) != 0) return false;
        AbstractClientPlayerEntity thisPlayer = getPlayer();
        AbstractClientPlayerEntity otherPlayer = other.getPlayer();
        if (thisPlayer == null ? otherPlayer != null : !thisPlayer.equals(otherPlayer)) return false;
        Hand thisHand = getHand();
        Hand otherHand = other.getHand();
        if (thisHand == null ? otherHand != null : !thisHand.equals(otherHand)) return false;
        MatrixStack thisMatrixStack = getMatrixStack();
        MatrixStack otherMatrixStack = other.getMatrixStack();
        return thisMatrixStack == null ? otherMatrixStack == null : thisMatrixStack.equals(otherMatrixStack);
    }

    protected boolean canEqual(Object other) {
        return other instanceof SwingAnimationEvent;
    }

    @Override
    public String toString() {
        return "EventSwingAnimation(player=" + getPlayer() + ", swingProgress=" + getSwingProgress()
                + ", hand=" + getHand() + ", matrixStack=" + getMatrixStack() + ')';
    }

    @Override
    public int hashCode() {
        int result = 59 + Float.floatToIntBits(getSwingProgress());
        AbstractClientPlayerEntity player = getPlayer();
        result = result * 59 + (player == null ? 43 : player.hashCode());
        Hand hand = getHand();
        result = result * 59 + (hand == null ? 43 : hand.hashCode());
        MatrixStack matrixStack = getMatrixStack();
        return result * 59 + (matrixStack == null ? 43 : matrixStack.hashCode());
    }
}
