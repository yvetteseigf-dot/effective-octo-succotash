package sky.event.render;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable event allowing the projection aspect ratio to be changed. */
public class ProjectionMatrixEvent extends EventCancellable implements Event {
    private float aspectRatio;

    public ProjectionMatrixEvent(float aspectRatio) {
        this.aspectRatio = aspectRatio;
    }

    public float getAspectRatio() {
        return aspectRatio;
    }

    public void setAspectRatio(float aspectRatio) {
        this.aspectRatio = aspectRatio;
    }
}
