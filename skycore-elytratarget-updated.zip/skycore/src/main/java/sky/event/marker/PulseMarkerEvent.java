package sky.event.marker;

import com.darkmagician6.eventapi.events.Event;

public class PulseMarkerEvent implements Event {
    public PulseMarkerEvent() {
    }
}
