package sky.event.marker;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class HardCancelEvent extends EventCancellable implements Event {
    public HardCancelEvent() {
    }
}
