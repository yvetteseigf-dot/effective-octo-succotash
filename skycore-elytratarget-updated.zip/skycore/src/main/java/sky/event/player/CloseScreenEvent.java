package sky.event.player;

import com.darkmagician6.eventapi.events.callables.EventCancellable;

/** Mutable/cancellable close-screen container id. */
public class CloseScreenEvent extends EventCancellable {
    private int windowId;

    public CloseScreenEvent(int windowId) {
        this.windowId = windowId;
    }

    protected boolean canEqual(Object object) {
        return object instanceof CloseScreenEvent;
    }

    public int getWindowId() {
        return windowId;
    }

    public void setWindowId(int windowId) {
        this.windowId = windowId;
    }
}
