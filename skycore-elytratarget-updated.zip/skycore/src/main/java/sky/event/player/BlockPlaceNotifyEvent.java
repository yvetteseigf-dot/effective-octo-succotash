package sky.event.player;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;

/** Non-cancellable companion interaction notification. */
public class BlockPlaceNotifyEvent implements Event {
    private final Block block;
    private final BlockPos pos;

    public BlockPlaceNotifyEvent(Block block, BlockPos pos) {
        this.block = block;
        this.pos = pos;
    }

    public BlockPos getPos() { return pos; }
    public Block getBlock() { return block; }
}
