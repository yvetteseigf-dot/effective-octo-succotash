package sky.event.player;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable post/short-circuit signal for the player movement-packet hook. */
public class MotionPostEvent extends EventCancellable {
    protected boolean canEqual(Object object) {
        return object instanceof MotionPostEvent;
    }
}
