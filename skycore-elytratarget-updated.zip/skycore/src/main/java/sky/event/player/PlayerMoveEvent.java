package sky.event.player;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.util.math.Vec3d;

/** Mutable client-player movement vector. */
public class PlayerMoveEvent extends EventCancellable {
    private Vec3d movePos;

    public PlayerMoveEvent(Vec3d movePos) {
        this.movePos = movePos;
    }

    public Vec3d getMovePos() {
        return movePos;
    }

    public void setMovePos(Vec3d movePos) {
        this.movePos = movePos;
    }
}
