package sky.event.player;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class NoRotateEvent extends EventCancellable implements Event {
    float yaw;
    float pitch;

    public NoRotateEvent(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public String toString() {
        return "EventNoRotate(yaw=" + getYaw() + ", pitch=" + getPitch() + ")";
    }

    public float getPitch() {
        return pitch;
    }

    protected boolean canEqual(Object other) {
        return other instanceof NoRotateEvent;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof NoRotateEvent that) || !that.canEqual(this)) {
            return false;
        }
        return Float.compare(getYaw(), that.getYaw()) == 0
                && Float.compare(getPitch(), that.getPitch()) == 0;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public int hashCode() {
        int result = 1;
        result = result * 59 + Float.floatToIntBits(getYaw());
        return result * 59 + Float.floatToIntBits(getPitch());
    }

    public float getYaw() {
        return yaw;
    }
}
