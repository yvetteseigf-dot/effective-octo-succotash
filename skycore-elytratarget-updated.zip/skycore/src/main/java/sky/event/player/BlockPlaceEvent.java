package sky.event.player;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable block-interaction notification. */
public class BlockPlaceEvent extends EventCancellable {
    private final Block block;
    private final BlockPos pos;

    public BlockPlaceEvent(Block block, BlockPos pos) {
        this.block = block;
        this.pos = pos;
    }

    public Block getBlock() { return block; }
    protected boolean canEqual(Object object) { return object instanceof BlockPlaceEvent; }
    public BlockPos getPos() { return pos; }
}
