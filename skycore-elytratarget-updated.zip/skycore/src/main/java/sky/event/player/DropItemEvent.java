package sky.event.player;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class DropItemEvent extends EventCancellable implements Event {
    private int currentSlot;

    public DropItemEvent(int currentSlot) {
        this.currentSlot = currentSlot;
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        return other instanceof DropItemEvent that
                && that.canEqual(this)
                && getCurrentSlot() == that.getCurrentSlot();
    }

    public int hashCode() {
        return 59 + getCurrentSlot();
    }

    public String toString() {
        return "EventDropItem(currentSlot=" + getCurrentSlot() + ")";
    }

    protected boolean canEqual(Object other) {
        return other instanceof DropItemEvent;
    }

    public int getCurrentSlot() {
        return currentSlot;
    }

    public void setCurrentSlot(int currentSlot) {
        this.currentSlot = currentSlot;
    }
}
