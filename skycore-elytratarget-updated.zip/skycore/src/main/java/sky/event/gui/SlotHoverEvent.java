package sky.event.gui;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.screen.slot.Slot;

public class SlotHoverEvent implements Event {
    private final int backgroundWidth;
    private final Slot slotHover;
    private final DrawContext drawContext;
    private final int backgroundHeight;

    public SlotHoverEvent(DrawContext drawContext, Slot slotHover, int backgroundWidth, int backgroundHeight) {
        this.drawContext = drawContext;
        this.slotHover = slotHover;
        this.backgroundWidth = backgroundWidth;
        this.backgroundHeight = backgroundHeight;
    }

    public Slot getSlotHover() {
        return slotHover;
    }

    public int getBackgroundHeight() {
        return backgroundHeight;
    }

    public int getBackgroundWidth() {
        return backgroundWidth;
    }

    public DrawContext getDrawContext() {
        return drawContext;
    }
}
