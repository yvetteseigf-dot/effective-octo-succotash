package sky.event.gui;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

public class MouseSlotClickEvent extends EventCancellable implements Event {
    private SlotActionType type;
    private int mouseButton;
    private Slot slotIn;
    private int slotId;

    public MouseSlotClickEvent(Slot slotIn, int slotId, int mouseButton, SlotActionType type) {
        this.slotIn = slotIn;
        this.slotId = slotId;
        this.mouseButton = mouseButton;
        this.type = type;
    }

    public SlotActionType getType() {
        return type;
    }

    public void setType(SlotActionType type) {
        this.type = type;
    }

    public int getMouseButton() {
        return mouseButton;
    }

    public void setMouseButton(int mouseButton) {
        this.mouseButton = mouseButton;
    }

    public Slot getSlotIn() {
        return slotIn;
    }

    public void setSlotIn(Slot slotIn) {
        this.slotIn = slotIn;
    }

    public int getSlotId() {
        return slotId;
    }

    public void setSlotId(int slotId) {
        this.slotId = slotId;
    }

    protected boolean canEqual(Object other) {
        return other instanceof MouseSlotClickEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof MouseSlotClickEvent other)) {
            return false;
        }
        if (!other.canEqual(this)
                || getSlotId() != other.getSlotId()
                || getMouseButton() != other.getMouseButton()) {
            return false;
        }
        Slot thisSlotIn = getSlotIn();
        Slot otherSlotIn = other.getSlotIn();
        if (thisSlotIn == null ? otherSlotIn != null : !thisSlotIn.equals(otherSlotIn)) {
            return false;
        }
        SlotActionType thisType = getType();
        SlotActionType otherType = other.getType();
        return thisType == null ? otherType == null : thisType.equals(otherType);
    }

    @Override
    public int hashCode() {
        int result = 59 + getSlotId();
        result = result * 59 + getMouseButton();
        Slot slotIn = getSlotIn();
        result = result * 59 + (slotIn == null ? 43 : slotIn.hashCode());
        SlotActionType type = getType();
        return result * 59 + (type == null ? 43 : type.hashCode());
    }

    @Override
    public String toString() {
        return "EventHandleMouseClick(slotIn=" + getSlotIn() + ", slotId=" + getSlotId()
                + ", mouseButton=" + getMouseButton() + ", type=" + getType() + ')';
    }
}
