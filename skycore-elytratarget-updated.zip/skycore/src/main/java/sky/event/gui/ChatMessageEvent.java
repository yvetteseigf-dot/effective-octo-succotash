package sky.event.gui;

import com.darkmagician6.eventapi.events.Event;

public class ChatMessageEvent implements Event {
    private boolean cancelled;
    private String message;

    public ChatMessageEvent(String message, boolean cancelled) {
        this.message = message;
        this.cancelled = cancelled;
    }

    public ChatMessageEvent(String message) {
        this(message, false);
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }
}
