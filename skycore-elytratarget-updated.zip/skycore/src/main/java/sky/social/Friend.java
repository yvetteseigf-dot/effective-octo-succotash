package sky.social;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.util.Formatting;
import sky.SkyInit;
import sky.util.text.CommandFeedback;

import java.util.List;
import sky.command.Command;
import sky.command.FriendArgumentParser;
import sky.command.PlayerArgumentType;

public final class Friend extends Command {
    public Friend() {
        super("friend");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("add").then(arg("player", PlayerArgumentType.create()).executes(context -> {
            String player = context.getArgument("player", String.class);
            if (SkyInit.getInstance().getFriendManager().isFriend(player)) {
                CommandFeedback.displayInfo("Player " + String.valueOf(Formatting.WHITE) + player
                        + String.valueOf(Formatting.GRAY) + " is already in the friends list");
            } else {
                SkyInit.getInstance().getFriendManager().add(player);
                CommandFeedback.displayInfo("Player " + String.valueOf(Formatting.WHITE) + player
                        + String.valueOf(Formatting.GRAY) + " added to the friends list");
            }
            return 1;
        })));

        builder.then(literal("remove").then(arg("player", FriendArgumentParser.create()).executes(context -> {
            String player = context.getArgument("player", String.class);
            SkyInit.getInstance().getFriendManager().removeFriend(player);
            CommandFeedback.displayInfo("Player " + String.valueOf(Formatting.WHITE) + player
                    + String.valueOf(Formatting.GRAY) + " removed from the friends list");
            return 1;
        })));

        builder.then(literal("list").executes(context -> {
            List<FriendsFile.FriendEntry> friends = SkyInit.getInstance().getFriendManager().getFriends();
            if (friends.isEmpty()) {
                CommandFeedback.displayInfo("Friends list is empty");
                return 1;
            }
            CommandFeedback.displayInfo(friends.toString());
            return 1;
        }));
    }
}
